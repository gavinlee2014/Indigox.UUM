﻿define("/Settings/Widgets/Navigation/ListToolBarWidget",
    [
        "Indigox.Web.JsLib.Utils.UrlUtil",
        "Indigox.Web.JsLib.Utils.StringUtil",
        "Indigox.Web.JsLib.CQRS.Batch",
        "Indigox.Web.JsLib.Controllers.ListController",
        "Indigox.Web.JsLib.Proxy.InstructionProxy",
        "Indigox.Web.JsLib.Models.RecordManager",
        "Indigox.Web.JsLib.Controls.Html.Menu",
        "Indigox/Settings/Application/Navigation"
    ],
    function (
        UrlUtil,
        StringUtil,
        Batch,
        ListController,
        InstructionProxy,
        RecordManager,
        Menu
    ) {


        var exports = function (widget) {

            var controller = new ListController({
                model: RecordManager.getInstance().createRecordSet('Navigation', {
                    addRecords: true,
                    proxy: new InstructionProxy({
                        query: "NavigationListQuery"
                    })
                })
            });

            var menuData = [{
                name: "btnCreateItem",
                value: "新建导航项",
                events: {
                    clicked: function (src, e) {
                        var root = Page().getUrlParam("Root") || "Default";
                        UrlUtil.goTo("#/NavigationNode/Edit.htm", { "Root": root });
                    }
                }
            }, {
                name: "btnCreate",
                value: "新建导航",
                events: {
                    clicked: function (src, e) {
                        UrlUtil.goTo("#/Navigation/Create.htm");
                    }
                }
            }, {
                name: "btnDelete",
                value: "删除导航",
                events: {
                    clicked: function (src, e) {
                        Page().mask();
                        if (!confirm("您确认要删除吗?")) {
                            Page().unmask();
                            return false;
                        }

                        var name = Page().getUrlParam("Root");

                        var batch = Batch.beginBatch();
                        batch.execute({
                            name: 'DeleteNavigationCommand',
                            properties: {
                                "Name": name
                            },
                            callback: function () {
                                var controller = $.Tree("NavigationTree").first().getController();
                                controller.clearModel();
                                controller.load();
                                Page().unmask();
                                UrlUtil.goTo("#/Navigation/List.htm");
                            },
                            errorCallback: function (error) {
                                ErrorHandler.logAlert(error);
                                Page().unmask();
                            }
                        });
                        batch.commit();

                    }
                }
            }, {
                name: "btnAuthorization",
                value: "导航授权",
                events: {
                    clicked: function (src, e) {
                        var id = Page().getUrlParam("ID");                
                        UrlUtil.goTo("#/Admin/Permission/List.htm", {
                            Identifier: id,
                            Type: 'Indigox.Settings.ObjectModel.Navi.Navigation'
                        });
                    }
                }
            }];

            $(widget).Menu("toolbar").first().configure({
                menuItemType: "dropdownmenuitem",
                orientation: Menu.ORIENTATION_HORIZONTAL,
                staticDisplayLevels: 1,
                childNodes: menuData
            });
        };

        return exports;
    });