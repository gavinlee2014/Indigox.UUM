﻿define("/Settings/Widgets/Navigation/NavigationWidget",
    [
        "Indigox.Web.JsLib.Utils.UrlUtil",
        "Indigox.Web.JsLib.Proxy.InstructionProxy",
        "Indigox.Web.JsLib.Models.RecordManager",
        "Indigox.Web.JsLib.Controllers.HierarchyController",
        "Indigox.Web.JsLib.Controls.PageUrlMonitor",
        "Indigox/Settings/Application/Navigation"
    ],
function (
        UrlUtil,
        InstructionProxy,
        RecordManager,
        HierarchyController,
        PageUrlMonitor
) {
    var exports = function (widget) {

        $(widget).Tree("NavigationTree").first().configure({
            mode: "SINGLE",
            allowDeselect: false,
            treeNodeType: "linktreenode",
            valueField: "ID",
            expandLevel: 2,
            controller: new HierarchyController({
                model: RecordManager.getInstance().createRecordSet('Navigation', {
                    addRecords: true,
                    proxy: new InstructionProxy({
                        query: "NavigationListQuery"
                    })
                }),
                rootValue: null,
                nodeOptions: {
                    binding: {
                        mapping: {
                            value: "ID",
                            text: "Name",
                            href: function (record) {
                                return UrlUtil.join("#/Navigation/List.htm", {
                                    Root: record.get("Name"),
                                    ID : record.get("ID")
                                });
                            }
                        }
                    }
                }
            })
        });

    };

    return exports;
});