﻿define("/Settings/Widgets/Navigation/NodeEditToolBarWidget",
    [
        "Indigox.Web.JsLib.Utils.UrlUtil",
        "Indigox.Web.JsLib.CQRS.Batch",
        "Indigox.Web.JsLib.Proxy.InstructionProxy",
        "Indigox.Web.JsLib.Models.RecordManager",
        "Indigox.Web.JsLib.Controllers.PluginController",
        "Indigox.Web.JsLib.Controls.Plugins.PermissionPlugin",
        "Indigox.Web.JsLib.Controls.Html.Menu",
        "/CMS/Widgets/Content/EffectivePermission"
    ],
    function (
        UrlUtil,
        Batch,
        InstructionProxy,
        RecordManager,
        PluginController,
        PermissionPlugin,
        Menu
    ) {
        function validate(widget, formControl) {
            var validator = $(widget).Validator("Validator").first();

            if (!isNullOrUndefined(validator)) {
                var result = validator.validate(formControl);
                if (false === result.matched) {
                    return false;
                }
            }

            return true;
        }

        var exports = function (widget) {
            var navigationNodeID = Page().getUrlParam("NavigationNodeID");

            var menuData = [{
                name: "btnSubmit",
                value: "保存",
                events: {
                    clicked: function (src, e) {
                        Page().mask();

                        var editWidget = $.Widget("NavigationNodeEditWidget").first();
                        var formControl = $(editWidget).Content("EditArea").first();
                        if (!validate(editWidget, formControl)) {
                            Page().unmask();
                            return;
                        }

                        formControl.on("submit", function (source, successed) {
                            if (successed) {
                                alert("保存成功!");
                                Page().unmask();
                                UrlUtil.goBack();
                            }
                            else {
                                alert("保存失败!");
                                Page().unmask();
                            }
                            this.un('submit', arguments.callee);
                        });
                        formControl.submit();
                    }
                }
            }, {
                name: "btnClose",
                value: "返回",
                events: {
                    clicked: function (src, e) {
                        UrlUtil.goBack();
                    }
                }
            }];

            if (navigationNodeID) {
                menuData.splice(1, 0, {
                    name: "btnDelete",
                    value: "删除",
                    events: {
                        clicked: function (src, e) {
                            Page().mask();
                            if (!confirm("您确认要删除吗?")) {
                                Page().unmask();
                                return false;
                            }
                            var editWidget = $.Widget("NavigationNodeEditWidget").first();

                            var content = $(editWidget).Content("EditArea").first();
                            content.getController().removeRecord(0);

                            content.on("submit", function (source, successed) {
                                if (successed) {
                                    alert("删除成功!");
                                    Page().unmask();
                                    UrlUtil.goBack();
                                }
                                else {
                                    alert("删除失败!");
                                    Page().unmask();
                                }
                                this.un('submit', arguments.callee);
                            });

                            content.submit();
                        }
                    }
                });
            }

            $(widget).Menu("toolbar").first().configure({
                menuItemType: "buttonmenuitem",
                orientation: Menu.ORIENTATION_HORIZONTAL,
                staticDisplayLevels: 1,
                childNodes: menuData
            });
        };

        return exports;
    });