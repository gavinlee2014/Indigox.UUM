﻿define("/Settings/Widgets/Navigation/NodeEditWidget",
    [
        "Indigox.Web.JsLib.Utils.ArrayUtil",
        "Indigox.Web.JsLib.Utils.UrlUtil",
        "Indigox.Web.JsLib.Utils.StringUtil",
        "Indigox.Web.JsLib.CQRS.Batch",
        "Indigox.Web.JsLib.Proxy.InstructionProxy",
        "Indigox.Web.JsLib.Models.RecordManager",
        "Indigox.Web.JsLib.Controllers.FormController",
        "Indigox.Web.JsLib.Controllers.ListController",
        "Indigox.Web.JsLib.Controls.Validation.Rules.NotBlankRule",
        "Indigox/Settings/Application/NavigationNode"
    ],
function (
        ArrayUtil,
        UrlUtil,
        StringUtil,
        Batch,
        InstructionProxy,
        RecordManager,
        FormController,
        ListController,
        NotBlankRule
) {
    function exports(widget) {
        var root = Page().getUrlParam('Root');
        if (StringUtil.isNullOrEmpty(root)) {
            root = "Default";
        }

        $(widget).Content("EditArea").first().configure({
            controller: new FormController({
                model: RecordManager.getInstance().createRecordSet('NavigationNode', {
                    proxy: new InstructionProxy({
                        createCommand: "CreateNavigationNodeCommand",
                        updateCommand: "UpdateNavigationNodeCommand",
                        deleteCommand: "DeleteNavigationNodeCommand"
                    })
                })
            })
        });

        var formControl = $(widget).Content("EditArea").first();
        $(formControl).TextBox("Title").first().configure({
            "validateRules": [
                {
                    "type": "notblank",
                    "errorMessage": "标题不允许为空"
                }
            ]
        });

        var formControl = $(widget).Content("EditArea").first();
        $(formControl).TextBox("ParentTitle").first().setReadonly(true);
        $(formControl).TextBox("ParentTitle").first().configure(
        {
            plugins: [{
                name: "valuedialog",
                config: {
                    dialogUrl: "/Settings/Navigation/Select.htm?Root=" + root,
                    resultMapping: {
                        "Parent": "ID",
                        "ParentTitle": "Title"
                    }
                }
            }]
        });


        $(formControl).RichTextBox("Description").first().configure({
            "mode": "plaintext"
        });

        var navigationNodeID = Page().getUrlParam("NavigationNodeID");

        if (navigationNodeID) {
            var form = $(widget).Content("EditArea").first();
            form.getController().getModel().getProxy().setQuery("NavigationNodeQuery");
            form.getController().setParam("ID", navigationNodeID);
            form.getController().setParam("Root", root);
            //form.getController().load();
        }
        else {
            var batch = Batch.beginBatch();
            batch.single({
                name: "DefaultNavigationNodeQuery",
                properties: {
                    Root: root
                },
                callback: function (data) {
                    var navigatioNode = data;

                    var controller = $(widget).Content("EditArea").first().getController();
                    controller.getModel().addRecord(navigatioNode);
                }
            });
            batch.syncCommit();
        }

//        Page().listenUrlParamChanged(["NavigationNodeID"], { container: widget }, function () {
//            var navigationNodeID = Page().getUrlParam("NavigationNodeID");
//            var form = $(widget).Content("EditArea").first();
//            form.getController().getModel().getProxy().setQuery("NavigationNodeQuery");
//            form.getController().setParam("ID", navigationNodeID);
//            form.getController().load();
//        });
    }

    return exports;
});