﻿define("/Settings/Widgets/Navigation/ListWidget",
    [
        "Indigox.Web.JsLib.Utils.StringUtil",
        "Indigox.Web.JsLib.Utils.UrlUtil",
        "Indigox.Web.JsLib.Proxy.InstructionProxy",
        "Indigox.Web.JsLib.Models.RecordManager",
        "Indigox.Web.JsLib.Controllers.ListController",
        "Indigox.Web.JsLib.Controls.Selection.ItemMode",
        "Indigox.Web.JsLib.Controls.PageUrlMonitor",
        "Indigox/Settings/Application/NavigationNode"
    ],
    function (
        StringUtil,
        UrlUtil,
        InstructionProxy,
        RecordManager,
        ListController,
        ItemMode,
        PageUrlMonitor
    ) {
        var exports = function (widget) {
            var limit = 10;

            var listControl = $(widget).DataList("NavigationList").first();


            listControl.getItemTemplate().configureChildren({
                "Title": {
                    binding: {
                        mapping: {
                            text: "Title",
                            href: function (record) {
                                var href = UrlUtil.join("#/NavigationNode/Edit.htm", {
                                    NavigationNodeID: record.get("ID"),
                                    Root: record.get("Root")
                                });

                                return href;
                            }
                        }
                    }
                }
            });
            var root = Page().getUrlParam("Root") || "Default";
            var listController = new ListController({
                model: RecordManager.getInstance().createRecordSet('NavigationNode', {
                    proxy: new InstructionProxy({
                        query: "AllNavigationNodeListQuery"
                    })
                }),
                params: {
                    "Root": root,
                    "FetchSize": limit
                }
            });

            $(widget).Paging("Paging").first().configure({
                pageSize: limit,
                arrayController: listController
            });

            listControl.setController(listController);

            listControl.setSelMode(new ItemMode({
                allowDeselect: false,
                returnValueType: "ARRAY",
                mode: "SINGLE"
            }));

            listControl.on("itemAdded", function (source, index, item) {
                $(item).Button("auth").on("clicked", GoAuth);
            });

            new PageUrlMonitor({ paramFilters: ["Root"], container: widget })
                .onUrlParamChanged(function () {
                    var root = Page().getUrlParam("Root");

                    if (!root) {
                        return;
                    }
                    listController.setParam("Root", root);
                    listController.load();
                });
        };



        function GoAuth(source) {
            var record = source.parent.getRecord();
            var id = record.get("ID");
            UrlUtil.goTo("#/Admin/Permission/List.htm", {
                Identifier: source.parent.getRecord().get("ID"),
                Type: 'Indigox.Settings.ObjectModel.Navi.NavigationNode'
            });
        };

        return exports;
    });