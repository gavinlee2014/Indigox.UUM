﻿define("/Settings/Widgets/Navigation/EditWidget",
    [
        "Indigox.Web.JsLib.Utils.ArrayUtil",
        "Indigox.Web.JsLib.Utils.UrlUtil",
        "Indigox.Web.JsLib.Utils.StringUtil",
        "Indigox.Web.JsLib.CQRS.Batch",
        "Indigox.Web.JsLib.Proxy.InstructionProxy",
        "Indigox.Web.JsLib.Models.RecordManager",
        "Indigox.Web.JsLib.Controllers.FormController",
        "Indigox.Web.JsLib.Controllers.ListController",
        "Indigox.Web.JsLib.Controls.Validation.Rules.NotBlankRule",
        "Indigox/Settings/Application/Navigation"
    ],
function (
        ArrayUtil,
        UrlUtil,
        StringUtil,
        Batch,
        InstructionProxy,
        RecordManager,
        FormController,
        ListController,
        NotBlankRule
) {
    function exports(widget) {

        $(widget).Content("EditArea").first().configure({
            controller: new FormController({
                model: RecordManager.getInstance().createRecordSet('Navigation', {
                    proxy: new InstructionProxy({
                        createCommand: "CreateNavigationCommand",
                        updateCommand: "CreateNavigationCommand"
                    })
                })
            })
        });

        var formControl = $(widget).Content("EditArea").first();
        formControl.getController().getModel().addRecord({});

        $(formControl).TextBox("Name").first().configure({
            "validateRules": [
                {
                    "type": "notblank",
                    "errorMessage": "标题不允许为空"
                }
            ]
        });

    }

    return exports;

});