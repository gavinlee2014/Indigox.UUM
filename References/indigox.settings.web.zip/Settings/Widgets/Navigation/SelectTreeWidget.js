﻿define("/Settings/Widgets/Navigation/SelectTreeWidget",
    [
        "Indigox.Web.JsLib.Utils.StringUtil",
        "Indigox.Web.JsLib.Utils.UrlUtil",
        "Indigox.Web.JsLib.Utils.Util",
        "Indigox.Web.JsLib.CQRS.AutoBatch",
        "Indigox.Web.JsLib.Proxy.ArrayProxy",
        "Indigox.Web.JsLib.Models.RecordManager",
        "Indigox.Web.JsLib.Controllers.HierarchyController",
        "Indigox.Web.JsLib.Controls.Selection.NodeMode",
        "Indigox/Settings/Application/NavigationNode"
    ],
function (
        StringUtil,
        UrlUtil,
        Util,
        AutoBatch,
        ArrayProxy,
        RecordManager,
        HierarchyController,
        NodeMode
) {

    var exports = function (widget) {
        widget.on("loaded", function () {
            bindTree(widget);
        });

        $(widget).Button('btnOk').on('clicked', function (source, e) {
            var tree = $(widget).Tree("NavigationTree").first();
            var id = tree.getSelMode().selected.get(0);
            var data = tree.getController().getModel().dataIndexer[id].data;

            window.returnValue = JSON.stringify(data);
            window.close();
        });

        $(widget).Button('btnCancel').on('clicked', function (source, e) {
            window.returnValue = null;
            window.close();
        });
    };

    function bindTree(widget) {
        $(widget).Tree("NavigationTree").first().configure({
            selMode: new NodeMode({
                mode: "SINGLE",
                allowDeselect: true
            }),
            treeNodeType: "checktreenode",
            expandLevel: 3,
            selectable: true,
            valueField: "ID",
            controller: new HierarchyController({
                model: RecordManager.getInstance().createRecordSet('NavigationNode', {
                    addRecords: true,
                    proxy: new ArrayProxy()
                }),
                rootValue: 7,
                nodeOptions: {
                    binding: {
                        mapping: {
                            value: "ID",
                            text: "Title"
                        }
                    }
                }
            })
        });

        var batch = AutoBatch.getCurrentBatch();
        batch.list({
            name: 'AllNavigationNodeListQuery',
            properties: {
                Root: Page().getUrlParam("Root")
            },
            callback: function (data) {
                var tree = $(widget).Tree("NavigationTree").first();
                if (data && data.length > 0 && tree.getController()) {
                    tree.getController().rootValue = data[0].RootID;
                }
                tree.getController().getModel().getProxy().setArray(data);
                tree.getController().load();
            }
        });
    }

    return exports;
});