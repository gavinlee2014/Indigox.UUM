﻿define("/Settings/Widgets/Common/UserMenuWidget",
    [
    ],
function (
) {
    var MenuData = [
            { id: "01", text: "全局设置", href: "#/Setting/List.htm" },
            { id: "02", text: "导航设置", href: "#/Navigation/List.htm" }
        ];
    function bindMenu(widget) {
        var menu = $(widget).Menu("mainmenu").first();
        menu.configure({
            selectable: true,
            menuItemType: "linkmenuitem",
            childNodes: MenuData
        });
    }

    var exports = function (widget) {
        bindMenu(widget);
    };

    return exports;
});