﻿define("/Settings/Widgets/Database/SettingWidget",
    [
        "Indigox.Web.JsLib.CQRS.Batch",
        "Indigox.Web.JsLib.Proxy.InstructionProxy",
        "Indigox.Web.JsLib.Models.RecordManager",
        "Indigox.Web.JsLib.Controllers.ListController",
        "Indigox.Web.JsLib.Controls.PageUrlMonitor",
        "Indigox/Settings/Application/Database/ConnectionString"
    ],
    function (
        Batch,
        InstructionProxy,
        RecordManager,
        ListController,
        PageUrlMonitor
    ) {
        var exports = function (widget) {
            var listControl = $(widget).DataList("ConnectionStringList").first();

            listControl.on("itemAdded", function (source, index, item) {
                var record = item.getRecord();
                if (record.get("Immutable") == true && record.get("Value") != "") {
                    $(item).TextBox("Value").first().setReadonly(true);
                }
            });

            listControl.configure({
                controller: new ListController({
                    model: RecordManager.getInstance().createRecordSet('ConnectionString', {
                        proxy: new InstructionProxy({
                            query: "ConnectionStringQuery"
                        })
                    })
                })
            });

            $(widget).Button("btnSave").first().on("clicked", function () {
                Page().mask();

                var items = listControl.getItems();
                var connectionStrings = [];
                for (var i = 0, length = items.length; i < length; i++) {
                    listControl.getController().updateRecord(items[i], items[i].getRecord());
                    connectionStrings.push(items[i].getRecord().data);
                }
                debug.log(connectionStrings);

                //listController.save(doSave);

                var batch = Batch.beginBatch();
                batch.execute({
                    name: "SaveConnectionStringCommand",
                    properties: {
                        ConnectionStrings: connectionStrings
                    }
                })
                .done(function () {
                    alert("保存成功！请重启IIS服务！");
                })
                .always(function () {
                    Page().unmask();
                });
                batch.commit();
            });
        };

        return exports;
    });