﻿define("/Settings/Widgets/Settings/CategoryWidget",
    [
        "Indigox.Web.JsLib.Utils.UrlUtil",
        "Indigox.Web.JsLib.Proxy.InstructionProxy",
        "Indigox.Web.JsLib.Models.RecordManager",
        "Indigox.Web.JsLib.Controllers.HierarchyController",
        "Indigox.Web.JsLib.Controls.PageUrlMonitor",
        "Indigox/Settings/Application/Settings/SettingCategory"
    ],
function (
        UrlUtil,
        InstructionProxy,
        RecordManager,
        HierarchyController,
        PageUrlMonitor
) {
    var exports = function (widget) {

        $(widget).Tree("CategoryTree").first().configure({
            mode: "SINGLE",
            allowDeselect: false,
            treeNodeType: "linktreenode",
            valueField: "ID",
            expandLevel: 2,
            controller: new HierarchyController({
                model: RecordManager.getInstance().createRecordSet('SettingCategory', {
                    addRecords: true,
                    proxy: new InstructionProxy({
                        query: "SettingCategoryListQuery"
                    })
                }),
                rootValue: null,
                nodeOptions: {
                    binding: {
                        mapping: {
                            value: "ID",
                            text: "Name",
                            href: function (record) {
                                return UrlUtil.join("#/Setting/List.htm", {
                                    Category: record.get("ID")
                                });
                            }
                        }
                    }
                }
            })
        });

        new PageUrlMonitor({ paramFilters: ["Category"], container: widget })
                .onUrlParamChanged(function () {
                    var category = Page().getUrlParam("Category");
                    if (!isNullOrUndefined(category)) {
                        $(widget).Tree("CategoryTree").first().setValue([category]);
                    }
                });
    };

    return exports;
});