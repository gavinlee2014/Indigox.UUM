﻿define("/Settings/Widgets/Settings/ListWidget",
    [
        "Indigox.Web.JsLib.Proxy.InstructionProxy",
        "Indigox.Web.JsLib.Models.RecordManager",
        "Indigox.Web.JsLib.Controllers.ListController",
        "Indigox.Web.JsLib.Controls.PageUrlMonitor",
        "Indigox/Settings/Application/Settings/Setting"
    ],
    function (
        InstructionProxy,
        RecordManager,
        ListController,
        PageUrlMonitor
    ) {
        var exports = function (widget) {
            var category = Page().getUrlParam("Category") || 0;

            var listControl = $(widget).DataList("SettingList").first();

            var listController = new ListController({
                model: RecordManager.getInstance().createRecordSet('Setting', {
                    proxy: new InstructionProxy({
                        query: "SettingListQuery",
                        updateCommand: "UpdateSettingCommand"
                    })
                }),
                params: {
                    "Category": category
                }
            });

            listControl.setController(listController);

            listControl.on("itemAdded", function (source, index, item) {
                var record = item.getRecord();
                if (record.get("Immutable") == true && (!isNullOrUndefined(record.get("Value")) && record.get("Value") != "")) {
                    $(item).TextBox("Value").first().setReadonly(true);
                }
                if (isNullOrUndefined(record.get("Value")) || record.get("Value") == "") {
                    $(item).TextBox("Value").first().setValue(record.get("DefaultValue"));
                }
            });

            $(widget).Button("btnSave").first().on("clicked", function () {
                Page().mask();
                var items = listControl.getItems();
                for (var i = 0, length = items.length; i < length; i++) {
                    listController.updateRecord(items[i], items[i].getRecord());
                }

                listController.save(doSave);
            });

            function doSave(successed) {
                if (successed) {
                    alert("保存成功!");
                }
                else {
                    alert("保存失败!");
                }
                Page().unmask();
            }

            new PageUrlMonitor({ paramFilters: ["Category"], container: widget })
                .onUrlParamChanged(function () {
                    var category = Page().getUrlParam("Category");

                    if (!category) {
                        return;
                    }
                    listController.setParam("Category", category);
                    listController.load();
                });
        };


        return exports;
    });