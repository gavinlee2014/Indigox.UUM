﻿define("Indigox/Settings/Application/Settings/Setting",
    [
        "Indigox.Web.JsLib.Models.RecordManager"
    ],
function (
    RecordManager
) {
    RecordManager.getInstance().register('Setting', {
        columns: [
            { name: 'Key', text: '设置项Key', type: String },
            { name: 'Value', text: '设置项值', type: String },
            { name: 'DefaultValue', text: '默认值', type: String },            
            { name: 'Title', text: '设置项名称', type: String },
            { name: 'Description', text: '设置项描述', type: String },
            { name: 'Immutable', text: '是否不可修改', type: String },            
            { name: 'Category', text: '设置项分类', type: String }
        ],
        primaryKey: ['Key']
    });
});
