﻿define("Indigox/Settings/Application/Settings/SettingCategory",
    [
        "Indigox.Web.JsLib.Models.RecordManager"
    ],
function (
    RecordManager
) {
    RecordManager.getInstance().register('SettingCategory', {
        columns: [
            { name: 'ID', text: '分类编号', type: String },
            { name: 'Name', text: '分类名称', type: String },
            { name: 'ParentID', text: '父分类编号', type: String }
        ],
        primaryKey: ['ID'],
        foreignKeys: [{
            columns: ["ParentID"],
            referencedSchema: "SettingCategory",
            referencedColumns: ["ID"]
        }]
    });
});
