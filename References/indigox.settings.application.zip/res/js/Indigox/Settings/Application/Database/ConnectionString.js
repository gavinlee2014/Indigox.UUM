﻿define("Indigox/Settings/Application/Database/ConnectionString",
    [
        "Indigox.Web.JsLib.Models.RecordManager"
    ],
    function (
        RecordManager
    ) {
        RecordManager.getInstance().register('ConnectionString', {
            columns: [
                { name: 'Name', text: 'Name', type: String },
                { name: 'ConnectionString', text: 'ConnectionString', type: String },
                { name: 'Database', text: 'Database', type: String },
                { name: 'Server', text: 'Server', type: String },
                { name: 'Username', text: 'Username', type: String },
                { name: 'Password', text: 'Password', type: String },
                { name: 'TrustedConnection', text: 'TrustedConnection', type: String }
            ],
            primaryKey: ['Name']
        });
    });