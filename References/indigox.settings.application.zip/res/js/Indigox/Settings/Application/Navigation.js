﻿define("Indigox/Settings/Application/Navigation",
    [
        "Indigox.Web.JsLib.Models.RecordManager"
    ],
function (
    RecordManager
) {
    RecordManager.getInstance().register('Navigation', {
        columns: [
            { name: 'ID', text: '编号', type: String },
            { name: 'Name', text: '标题', type: String },
            { name: 'ParentID', text: '父分类编号', type: String }
        ],
        primaryKey: ['ID'],
        foreignKeys: [{
            columns: ["ParentID"],
            referencedSchema: "Navigation",
            referencedColumns: ["ID"]
        }]
    });
});
