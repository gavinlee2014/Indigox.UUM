﻿define("Indigox/Settings/Application/NavigationNode",
    [
        "Indigox.Web.JsLib.Models.RecordManager"
    ],
function (
    RecordManager
) {
    RecordManager.getInstance().register('NavigationNode', {
        columns: [
            { name: 'ID', text: '编号', type: String },
            { name: 'Title', text: '标题', type: String },
            { name: 'Description', text: '描述', type: String },
            { name: 'Url', text: '链接', type: String },
            { name: 'Target', text: '打开方式', type: String },
            { name: 'Icon', text: '图标', type: String },
            { name: 'Parent', text: '父节点', type: String },
            { name: 'ParentTitle', text: '父节点标题', type: String },
            { name: 'Root', text: '根节点', type: String },
            { name: 'RootID', text: '根节点ID', type: String },
            { name: 'OrderNum', text: '排序值', type: String },
            { name: 'CreateTime', text: '创建时间', type: String },
            { name: 'ModifyTime', text: '修改时间', type: String }
        ],
        primaryKey: ['ID'],
        foreignKeys: [{
            columns: ["Parent"],
            referencedSchema: "NavigationNode",
            referencedColumns: ["ID"]
        }]
    });
});
