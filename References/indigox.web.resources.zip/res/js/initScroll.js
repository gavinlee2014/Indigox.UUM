﻿require(
    [
        "Indigox.Web.JsLib.Utils.Browser",
        "Indigox.Web.JsLib.Utils.DelayedTask",
        "Indigox.Web.JsLib.Collection.Hashtable",
        "jquery",
        "iscroll"
    ],
    function (
        Browser,
        DelayedTask,
        Hashtable,
        jQuery,
        iScroll
    ) {
        var initedIScrollInstances = (function () {
            var _iscrolls = new Hashtable();

            function getInstance(element) {
                if (element.id) {
                    return _iscrolls.get(element.id);
                }
                else {
                    return _iscrolls.get(element);
                }
            }

            function setInstance(element, instance) {
                if (element.id) {
                    _iscrolls.put(element.id, instance);
                }
                else {
                    _iscrolls.put(element, instance);
                }
            }

            // SideCatalog used this global variable. file ..\CRM\Widgets\Common\SideCatalogWidget.js:
            window._iscrolls = _iscrolls;

            return {
                getInstance: getInstance,
                setInstance: setInstance
            };
        })();

        var iScrollMainVersion = (iScroll.prototype.version) ? parseInt(iScroll.prototype.version[0], 10) : 4;

        function initVerticalScroll() {
            if (iScrollMainVersion >= 5) {
                initScroll(this, {
                    mouseWheel: true,
                    //scrollbars: true,
                    //eventPassthrough: true,
                    //scrollX: false,
                    scrollY: true,
                    preventDefault: true
                });
            }
            else {
                initScroll(this, {
                    "hScroll": false,
                    "vScroll": true
                });
            }
        }

        function initHorizontalScroll() {
            if (iScrollMainVersion >= 5) {
                initScroll(this, {
                    mouseWheel: true,
                    //scrollbars: true,
                    //eventPassthrough: true,
                    scrollX: true,
                    //scrollY: false,
                    preventDefault: true
                });
            }
            else {
                initScroll(this, {
                    "hScroll": true,
                    "vScroll": false
                });
            }
        }

        function initAllScroll() {
            if (iScrollMainVersion >= 5) {
                initScroll(this, {
                    mouseWheel: true,
                    //scrollbars: true,
                    //eventPassthrough: true,
                    scrollX: true,
                    scrollY: true,
                    preventDefault: true
                });
            }
            else {
                initScroll(this, {
                    "hScroll": true,
                    "vScroll": true
                });
            }
        }

        function initScroll(element, config) {
            if (initedIScrollInstances.getInstance(element)) {
                var name = [element.tagName, element.id].join('#');
                //debug.log(name + " already inited.");
                return;
            }

            config = config || {};

            var options = {
                scrollbarClass: 'contentScrollbar',
                onBeforeScrollStart: function (e) {
                    var target = e.target;
                    while (target.nodeType != 1) { target = target.parentNode; }

                    if (target.tagName != 'SELECT' &&
                            target.tagName != 'INPUT' &&
                            target.tagName != 'TEXTAREA') {
                        e.preventDefault();
                    }
                },
                checkDOMChanges: true
            };

            for (var option in config) {
                options[option] = config[option];
            }

            //setTimeout(function () {
            var myScroll = new iScroll(element, options);
            initedIScrollInstances.setInstance(element, myScroll);

            jQuery(element).bind('DOMSubtreeModified', { myScroll: myScroll }, function (event) {
                var _element = this;
                var _name = [_element.tagName, _element.id].join('#');
                //debug.log('DOMSubtreeModified - ' + _name + ' ');
                event.data.myScroll.refresh();
                event.preventDefault();
            });
            //}, 0);
        }

        function loaded() {
            //debug.log('DOMSubtreeModified - document. ');
            if (Browser.isTablet()) {
                jQuery(".content").each(initAllScroll);
                jQuery(".vertical dd").each(initHorizontalScroll);
            }
            jQuery(".content_list").each(initAllScroll);
        }

        var delayLoadedTask;

        function delayLoaded() {
            if (delayLoadedTask) {
                delayLoadedTask.cancel();
            }
            delayLoadedTask = new DelayedTask(loaded);
            delayLoadedTask.delay(100);
        }

        document.addEventListener('DOMSubtreeModified', delayLoaded, false);
    });