﻿require(
    [
        "Indigox.Web.JsLib.Utils.Browser",
        "Indigox.Web.JsLib.Utils.UrlUtil"
    ],
    function (
        Browser,
        UrlUtil
    ) {
        function getUplevelUrl() {
            var url = Page().getUrlPath();
            var uplevelUrl = '#';
            if (url.toLowerCase() === "/task/list.htm") {
                uplevelUrl = "#";
            }
            else if (url.toLowerCase() === "/process/edit.htm") {
                if (Browser.isTablet()) {
                    uplevelUrl = UrlUtil.join("#/process/view.htm", {
                        state: Page().getUrlParam('state'),
                        type: Page().getUrlParam('type'),
                        ProcInstID: Page().getUrlParam('SN'),
                        reload: "true"
                    });
                }
                else if (Browser.isMobile()) {
                    uplevelUrl = UrlUtil.join("#/task/list.htm", {
                        state: Page().getUrlParam('state'),
                        type: Page().getUrlParam('type')
                    });
                }
            }
            else if (url.toLowerCase() === "/process/view.htm") {
                uplevelUrl = UrlUtil.join("#/task/list.htm", {
                    state: Page().getUrlParam('state'),
                    type: Page().getUrlParam('type')
                });
            }
            else if (url.toLowerCase() === "/addressbook/list.htm") {
                uplevelUrl = "#";
            }
            else if (url.toLowerCase() === "/addressbook/view.htm") {
                uplevelUrl = "#/addressbook/list.htm";
            }
            else if (url.toLowerCase() === "/news/view.htm") {
                uplevelUrl = "#/News/List.htm";
            }
            else if (url.toLowerCase() === "/notice/view.htm") {
                uplevelUrl = "#/Notice/List.htm";
            }
            else {
                uplevelUrl = "#";
            }
            return uplevelUrl;
        }

        window.goUplevel = function () {
            if (Page().getUrlPath() == '/index.htm') {
                if (confirm("您确定要退出应用吗？")) {
                    if (isIOS()) {
                        var url = "indigox://Exit";
                        window.location.href = url;
                    }
                    else if (isAndroid()) {
                        AppClient.Exit();
                    }
                }
            }
            else {
                UrlUtil.goTo(getUplevelUrl());
            }
        };

        function isIOS() {
            try {
                return (window.navigator.userAgent.indexOf('iPhone') >= 0) ||
                       (window.navigator.userAgent.indexOf('iPad') >= 0);
            } catch (e) {
                return false;
            }
        }

        function isAndroid() {
            try {
                return (window.navigator.userAgent.indexOf('Android') >= 0);
            } catch (e) {
                return false;
            }
        }
    });