﻿define("Indigox/Task/Application/Task",
    [
        "Indigox.Web.JsLib.Models.RecordManager"
    ],
function (
    RecordManager
) {
    RecordManager.getInstance().register('TaskQueryResultItem', {
        columns: [
                { name: 'SysName', text: '类别编号', type: String },
                { name: 'SysTitle', text: '类别', type: String },
                { name: 'TaskID', text: '任务编号', type: String },
                { name: 'Title', text: '标题', type: String },
                { name: 'Url', text: '链接地址', type: String },
                { name: 'State', text: '任务状态', type: String },
                { name: 'Type', text: '任务类型', type: String },
                { name: 'StartTime', text: '开始时间', type: String },
                { name: 'StartUserID', text: '发起人编号', type: String },
                { name: 'StartUserName', text: '发起人', type: String },
                { name: 'SerialNumber', text: '流程编号', type: String },
                { name: 'ProcessStartUserOrgName', text: 'ProcessStartUserOrgName', type: String },
                { name: 'ProcessStartTime', text: 'ProcessStartTime', type: String }
            ],
        primaryKey: ['TaskID']
    });
});