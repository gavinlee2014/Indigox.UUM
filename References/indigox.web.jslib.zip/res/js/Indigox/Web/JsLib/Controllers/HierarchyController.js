﻿define("Indigox.Web.JsLib.Controllers.HierarchyController",
    [
        "Indigox.Web.JsLib.Controllers.Controller",
        "Indigox.Web.JsLib.Utils.Util",
        "Indigox.Web.JsLib.Utils.Callback",
        "Indigox.Web.JsLib.Models.Record",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Controller,
        Util,
        Callback,
        Record
) {

    var base = Controller.prototype;

    var HierarchyController =
        Namespace("Indigox.Web.JsLib.Controllers")
        .Class("HierarchyController")
        .Extend(base)
        .Constructor(
            function (option) {
                base.constructor.apply(this, arguments);

                //@private
                this.controlIndexer = {};

                option = Util.copyExist({
                    rootValue: null,
                    nodeOptions: {}
                }, option);
                this.configure(option);
            }
        )
        .Members({
            load: function (callback) {
                callback = Callback.createInstance(callback);
                if (!this.isParamChanged()) {
                    if (callback) {
                        callback.invoke();
                    }
                    return;
                }
                var params = this.buildLoadParams();
                this.model.load(params, callback);
            },

            getForeignKey: function () {
                var foreignKeys = this.model.getSchema().getForeignKeys();
                var schema = this.model.getSchema().name;
                for (var i = 0, length = foreignKeys.length; i < length; i++) {
                    var foreignKey = foreignKeys[i];
                    if (schema == foreignKey.getReferencedSchema()) {
                        return foreignKey;
                    }
                }
                return null;
            },

            buildLoadParams: function () {
                var params = {};
                var foreignKey = this.getForeignKey().getColumns()[0].getName();

                if (this.relatedRecord != null) {
                    if (this.relatedRecord instanceof Record) {
                        params[foreignKey] = this.model.getIdentity(this.relatedRecord);
                    }
                    else {
                        params[foreignKey] = this.relatedRecord;
                    }
                }
                else if (this.params != null) {
                    params = this.params;
                }
                else {
                    params[foreignKey] = this.rootValue;
                }
                return params;
            },

            onRecordAdded: function (source, index, record) {
                if (this.listenPaused) {
                    return;
                }

                base.onRecordAdded.apply(this, arguments);

                var foreignKey = this.getForeignKey();
                var parentIdentity = foreignKey.toIdentity(record);
                var parentRecord = this.model.getRecord(parentIdentity);

                if (parentIdentity && !parentRecord && parentIdentity != this.rootValue) {
                    this.setRelated(null);
                    this.setParam(this.model.getSchema().getPrimaryKey().columns[0].getName(), parentIdentity);

                    this.load();
                    parentRecord = this.model.getRecord(parentIdentity);
                    this.findControl(parentRecord).expand();
                }
                else {
                    var hierarchyControl = this.view;
                    var parentNodeControl = null;
                    if (parentIdentity && parentIdentity != this.rootValue) {
                        parentNodeControl = this.findControl(parentRecord);
                    }
                    else {
                        parentNodeControl = hierarchyControl;
                    }

                    var nodeControl = this.newNode(hierarchyControl, record);

                    this.addToIndexer(record, nodeControl);
                    this.addChildNode(parentNodeControl, nodeControl, record);
                }
            },

            addChildNode: function (parentNodeControl, node, record) {
                this.bindRecord(node, record);
                parentNodeControl.addChildNode(node);
            },

            findControl: function (index) {
                if (index instanceof Record) {
                    return this.controlIndexer[this.model.getIdentity(index)];
                }
                else {
                    return this.controlIndexer[index];
                }
            },

            addToIndexer: function (index, control) {
                if (index instanceof Record) {
                    this.controlIndexer[this.model.getIdentity(index)] = control;
                }
                else {
                    this.controlIndexer[index] = control;
                }
            },

            onRecordRemoved: function (source, index, record) {
                if (this.listenPaused) {
                    return;
                }

                base.onRecordRemoved.apply(this, arguments);

                var foreignKey = this.getForeignKey();
                var parentIdentity = foreignKey.toIdentity(record);
                var parentRecord = this.model.getRecord(parentIdentity);
                var childNodeControl = this.findControl(record);

                var hierarchyControl = this.view;

                for (var i = 0, length = childNodeControl.getChildNodes().length; i < length; i++) {
                    this.model.removeRecord(childNodeControl.getChildNodes()[i].getRecord());
                }

                var parentNodeControl = null;
                if (parentRecord) {
                    parentNodeControl = this.findControl(parentRecord);
                }
                else {
                    parentNodeControl = hierarchyControl;
                }

                parentNodeControl.removeChildNode(childNodeControl);
            },

            getNodeOptions: function () {
                return this.nodeOptions;
            },

            setNodeOptions: function (value) {
                this.nodeOptions = value;
            },

            getRootValue: function () {
                return this.rootValue;
            },

            setRootValue: function (value) {
                this.rootValue = value;
            },

            // @private
            newNode: function (control, record) {
                var newNodeConfig = this.getNodeOptions();
                newNodeConfig.record = record;
                return control.newNode(newNodeConfig);
            },

            onFieldChanged: function (source, column, value) {
                base.onFieldChanged.apply(this, arguments);
                if (this.listenPaused) {
                    return;
                }
                var control = this.findControl(source);
                this.bindRecord(control, source);
            }
        })
    .$();
});