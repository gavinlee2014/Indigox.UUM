﻿define("Indigox.Web.JsLib.Controllers.Controller",
    [
        "Indigox.Web.JsLib.Utils.Configurable",
        "Indigox.Web.JsLib.Utils.Util",
        "Indigox.Web.JsLib.Utils.Callback",
        "Indigox.Web.JsLib.Models.Model",
        "Indigox.Web.JsLib.Models.RecordManager",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Configurable,
        Util,
        Callback,
        Model,
        RecordManager
) {

    var base = Configurable.prototype;

    var Controller =
        Namespace("Indigox.Web.JsLib.Controllers")
        .Class("Controller")
        .Extend(base)
        .Constructor(
            function (option) {
                base.constructor.apply(this, arguments);

                //@private
                this.listenPaused = false;
                this.paramChanged = false;
                this.defaultParamName = "";

                option = Util.copyExist({
                    params: null,
                    model: null,
                    view: null,
                    relatedRecord: null,
                    autoLoad: true,
                    defaultParamName: null
                }, option);
                this.configure(option);
            }
        )
        .Members({
            setAutoLoad: function (value) {
                this.autoLoad = value;
            },

            getAutoLoad: function () {
                return this.autoLoad;
            },

            setDefaultParamName: function (paramName) {
                this.defaultParamName = paramName;
            },

            setDefaultParamValue: function (value) {
                this.setParam(this.defaultParamName, value);
            },

            setParam: function (key, value) {
                if (this.params == null) {
                    this.params = {};
                }
                if (this.params[key] === value) {
                    return;
                }
                this.params[key] = value;
                this.paramChanged = true;
            },

            getParam: function (key) {
                return this.params[key];
            },

            setParams: function (value) {
                if (this.params === value) {
                    return;
                }
                this.params = value;
                this.paramChanged = true;
            },

            getParams: function () {
                return this.params || {};
            },

            isParamChanged: function () {
                return this.paramChanged;
            },

            setRelated: function (value) {
                this.relatedRecord = value || {};
            },

            getRelated: function () {
                return this.relatedRecord;
            },

            setModel: function (value) {
                if ((value) && (!(value instanceof Model))) {
                    var modelInfo = value;
                    if (modelInfo.schema) {
                        RecordManager.getInstance().register(modelInfo.schemaName, modelInfo.schema);
                    }
                    value = RecordManager.getInstance().createRecordSet(modelInfo.schemaName, modelInfo);
                }
                if (this.model) {
                    var records = this.model.getRecords();
                    for (var i = 0, length = records.length; i < length; i++) {
                        records[i].removeListener(this);
                    }
                    this.model.removeListener(this);
                }
                this.model = value;
                if (this.model) {
                    this.model.addListener(this);
                }
            },

            getModel: function () {
                return this.model;
            },

            setView: function (value) {
                this.view = value;
            },

            getView: function () {
                return this.view;
            },

            load: function (callback) {
            },

            unload: function () {
                this.setModel(null);
            },

            clearModel: function () {
                if (this.model) {
                    this.model.clearRecord();
                    this.model.setTransaction(null);
                    this.model.beginTransaction();
                }
            },

            bindRecord: function (control, record) {
                if (isNullOrUndefined(record)) {
                    record = control;
                    control = this.view;
                }
                control.getBinding().bind(control, record);
            },

            updateRecord: function (control, record) {
                if (isNullOrUndefined(record)) {
                    record = this.model.getRecord(0);
                }
                if (isNullOrUndefined(control)) {
                    control = this.view;
                }

                this.pauseListen();
                if (!isNullOrUndefined(record)) {
                    this.provideValues(control, record);
                }
                this.resumeListen();
            },

            insertRecord: function (index, data) {
                if (isNullOrUndefined(data)) {
                    this.model.insertRecord(index, {});
                }
                else {
                    this.model.insertRecord(index, data);
                }
            },

            removeRecord: function (index) {
                this.model.removeRecord(index);
            },

            save: function (callback) {
                callback = Callback.createInstance(callback);
                this.model.commit({ handler: this.doSave, scope: this, args: [callback] });
            },

            doSave: function (successed, callback) {
                if (callback) {
                    callback.invoke(successed);
                }
            },

            provideValues: function (control, record) {
                control.getBinding().provide(control, record);
            },

            pauseListen: function () {
                this.listenPaused = true;
            },

            resumeListen: function () {
                this.listenPaused = false;
            },

            onRecordAdded: function (source, index, record) {
                record.addListener(this);
            },

            onRecordRemoved: function (source, index, record) {
                record.removeListener(this);
            },

            onFieldChanged: function (source, column, value) {
            }
        })
    .$();

});