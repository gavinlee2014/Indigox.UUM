﻿define("Indigox.Web.JsLib.Controllers.PluginController",
    [
        "Indigox.Web.JsLib.Controllers.Controller",
        "Indigox.Web.JsLib.Utils.Util",
        "Indigox.Web.JsLib.Utils.Callback",
        "Indigox.Web.JsLib.Collection.List",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Controller,
        Util,
        Callback,
        List
) {

    var base = Controller.prototype;

    var PluginController =
        Namespace("Indigox.Web.JsLib.Controllers")
        .Class("PluginController")
        .Extend(base)
        .Constructor(
            function (option) {
                base.constructor.apply(this, arguments);

                this.plugins = new List();

                option = Util.copyExist({
                    plugins: []
                }, option);
                this.configure(option);
            }
        )
        .Members({
            load: function (callback) {
                callback = Callback.createInstance(callback);
                var recordSet = this.model;
                if (recordSet.size() === 0) {
                    var params = this.getParams();
                    recordSet.load(params, callback);
                }
            },

            onRecordAdded: function (source, index, record) {
                if (this.listenPaused) {
                    return;
                }
                base.onRecordAdded.apply(this, arguments);
                if (this.listenPaused) {
                    return;
                }
                this.implementPlugins(record);
            },

            implementPlugins: function (record) {
                var plugins = this.getPlugins();
                var i = null,
                    length = plugins.length;
                for (i = 0; i < length; i++) {
                    plugins[i].execute(record);
                }
            },

            addPlugin: function (plugin) {
                if (isNullOrUndefined(plugin) || this.plugins.contains(plugin)) {
                    return;
                }
                //debug.log("Add Plugin :" + plugin.id);
                this.plugins.add(plugin);
            },

            removePlugin: function (plugin) {
                this.plugins.remove(plugin);
            },

            getPlugins: function () {
                return this.plugins.toArray();
            },

            setPlugins: function (value) {
                this.plugins = new List();
                this.plugins.addRange(value);
            },

            onRecordRemoved: function (source, index, record) {
                if (this.listenPaused) {
                    return;
                }
                base.onRecordRemoved.apply(this, arguments);
                if (this.listenPaused) {
                    return;
                }
            },

            onFieldChanged: function (source, column, value) {
                if (this.listenPaused) {
                    return;
                }
                if (this.model.size() > 0) {
                    this.implementPlugins(this.model.getRecord(0));
                }
            }
        })
    .$();

});