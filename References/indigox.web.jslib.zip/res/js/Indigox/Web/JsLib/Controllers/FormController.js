﻿define("Indigox.Web.JsLib.Controllers.FormController",
    [
        "Indigox.Web.JsLib.Controllers.Controller",
        "Indigox.Web.JsLib.Utils.Callback",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Controller,
        Callback
) {

    var base = Controller.prototype;

    var FormController =
        Namespace("Indigox.Web.JsLib.Controllers")
        .Class("FormController")
        .Extend(base)
        .Constructor(
            function (option) {
                base.constructor.apply(this, arguments);
            }
        )
        .Members({
            load: function (callback) {
                callback = Callback.createInstance(callback);
                var recordSet = this.model;
                if (!this.isParamChanged() || !recordSet) {
                    if (callback) {
                        callback.invoke();
                    }
                    return;
                }

                if (recordSet.size()) {
                    var record = recordSet.getRecord(0);
                    var control = this.view;
                    this.bindRecord(control, record);
                    if (callback) {
                        callback.invoke();
                    }
                }
                else {
                    var params = this.getParams();
                    recordSet.load(params, callback);
                }
            },

            save: function (callback) {
                this.updateRecord();
                base.save.apply(this, arguments);
            },

            onRecordAdded: function (source, index, record) {
                if (this.listenPaused) {
                    return;
                }
                base.onRecordAdded.apply(this, arguments);
                if (this.listenPaused) {
                    return;
                }
                var control = this.view;
                this.bindRecord(control, record);
            },

            onRecordRemoved: function (source, index, record) {
                if (this.listenPaused) {
                    return;
                }
                base.onRecordRemoved.apply(this, arguments);
            },

            onFieldChanged: function (source, column, value) {
                if (this.listenPaused) {
                    return;
                }
                base.onFieldChanged.apply(this, arguments);
                if (this.listenPaused) {
                    return;
                }
                var control = this.view;
                this.bindRecord(control, source);
            }
        })
    .$();

});