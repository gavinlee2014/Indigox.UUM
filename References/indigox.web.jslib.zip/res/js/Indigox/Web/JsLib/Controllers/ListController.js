﻿define("Indigox.Web.JsLib.Controllers.ListController",
    [
        "Indigox.Web.JsLib.Controllers.Controller",
        "Indigox.Web.JsLib.Utils.Util",
        "Indigox.Web.JsLib.Utils.Callback",
        "Indigox.Web.JsLib.Models.Record",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Controller,
        Util,
        Callback,
        Record
) {

    var base = Controller.prototype;

    var ListController =
        Namespace("Indigox.Web.JsLib.Controllers")
        .Class("ListController")
        .Extend(base)
        .Constructor(
            function (option) {
                base.constructor.apply(this, arguments);

                //@private
                this.controlIndexer = {};

                option = Util.copyExist({
                    itemOptions: {}
                }, option);
                this.configure(option);
            }
        )
        .Members({
            load: function (callback) {
                callback = Callback.createInstance(callback);
                if (!this.isParamChanged()) {
                    if (callback) {
                        callback.invoke();
                    }
                    return;
                }
                var params = this.getParams();
                this.model.load(params, callback);
            },

            onRecordAdded: function (source, index, record) {
                if (this.listenPaused) {
                    return;
                }
                base.onRecordAdded.apply(this, arguments);
                var listControl = this.view;
                var itemControl = this.newItem(listControl, record);
                this.bindRecord(itemControl, record);

                this.addToIndexer(record, itemControl);
                listControl.insertItem(index, itemControl);
            },

            onRecordRemoved: function (source, index, record) {
                if (this.listenPaused) {
                    return;
                }
                var listControl = this.view;
                var item = listControl.getItems()[index];
                listControl.removeItem(item);
            },

            onFieldChanged: function (source, column, value) {
                base.onFieldChanged.apply(this, arguments);
                if (this.listenPaused) {
                    return;
                }
                var control = this.findControl(source);
                this.bindRecord(control, source);
            },

            findControl: function (index) {
                if (index instanceof Record) {
                    return this.controlIndexer[this.model.getIdentity(index)];
                }
                else {
                    return this.controlIndexer[index];
                }
            },

            addToIndexer: function (index, control) {
                if (index instanceof Record) {
                    this.controlIndexer[this.model.getIdentity(index)] = control;
                }
                else {
                    this.controlIndexer[index] = control;
                }
            },

            getItemOptions: function () {
                return this.itemOptions;
            },

            setItemOptions: function (value) {
                this.itemOptions = value;
            },

            // @private
            newItem: function (control, record) {
                var options = this.getItemOptions();
                options.record = record;
                return control.newItem(options);
            }
        })
    .$();

});