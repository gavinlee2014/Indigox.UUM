﻿define("Indigox.Web.JsLib.Criteria.RegularExpression",
    [
        "Indigox.Web.JsLib.Criteria.Criterion",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Criterion
) {

    var base = Criterion.prototype;

    var NULL_OR_EMPTY_EXP = '^\\s*$';

    var RegularExpression =
        Namespace("Indigox.Web.JsLib.Criteria")
        .Class("RegularExpression").Extend(base)
        .Constructor(
            function (property, pattern, attributes) {
                this.property = property;
                this.pattern = pattern;
                this.attributes = attributes;
            }
        )
        .Members({
            evaluate: function (entry) {
                /*
                var regex = null;
                var nullOrEmptyRegex = new RegExp( NULL_OR_EMPTY_EXP, 'g' );
                if ( nullOrEmptyRegex.test( this.pattern ) ) {
                regex = nullOrEmptyRegex;
                }
                else {
                regex = new RegExp( this.pattern, this.attributes );
                }
                */
                var regex = new RegExp(this.pattern, this.attributes);
                return regex.test(entry[this.property]);
            }
        }).$();

});