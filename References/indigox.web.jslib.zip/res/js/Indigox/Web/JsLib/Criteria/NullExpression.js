﻿define("Indigox.Web.JsLib.Criteria.NullExpression",
    [
        "Indigox.Web.JsLib.Criteria.Criterion",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Criterion
) {

    var base = Criterion.prototype;

    var NullExpression =
        Namespace("Indigox.Web.JsLib.Criteria")
        .Class("NullExpression").Extend(base)
        .Constructor(
    /** @id Indigox.Web.JsLib.Criteria.NullExpression */
            function (property) {
                this.property = property;
            }
        )
        .Members({
            evaluate: function (entry) {
                return isNullOrUndefined(entry[this.property]);
            }
        }).$();

});