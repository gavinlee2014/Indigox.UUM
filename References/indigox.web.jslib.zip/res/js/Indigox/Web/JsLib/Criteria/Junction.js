﻿define("Indigox.Web.JsLib.Criteria.Junction",
    [
        "Indigox.Web.JsLib.Criteria.Criterion",
        "Indigox.Web.JsLib.Collection.List",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Criterion,
        List
) {


    var base = Criterion.prototype;

    var Junction =
        Namespace("Indigox.Web.JsLib.Criteria")
        .Class("Junction").Extend(base)
        .Constructor(
    /** @id Indigox.Web.JsLib.Criteria.Junction */
            function (criterion, criterion1) {
                this.criteriaList = new List();
                //var range = [].splice.call(arguments, 0);
                var range = [].slice.call(arguments);
                this.criteriaList.addRange(range);
            }
        )
        .Members({
            evaluate: function (entry) {
            }
        }).$();

});