﻿define("Indigox.Web.JsLib.Criteria.Criteria",
    [
        "Indigox.Web.JsLib.Collection.List",
        "Indigox.Web.JsLib.Core"
    ],
function (
        List
) {

    var find = function (originalList, filterList, criteria) {
        var originalListIterator, criteriaIterator,
            entry, criterion,
            isAdd;

        originalListIterator = originalList.iterator();
        while (originalListIterator.hasNext()) {
            entry = originalListIterator.next();

            isAdd = true;

            criteriaIterator = criteria.iterator();
            while (criteriaIterator.hasNext()) {
                criterion = criteriaIterator.next();
                if (!criterion.evaluate(entry)) {
                    isAdd = false;
                    break;
                }
            }
            if (isAdd) {
                filterList.add(entry);
            }
        }
    };

    var Criteria =
        Namespace("Indigox.Web.JsLib.Criteria")
        .Class("Criteria")
        .Constructor(
    /** @id Indigox.Web.JsLib.Criteria.Criteria */
            function (range) {
                this.originalList = range instanceof List ? range : new List(range);
                this.filterList = new List();
                this.criteriaList = new List();
            }
        )
        .Static({
            create: function (range) {
                return new Criteria(range);
            }
        })
        .Members({
            add: function (criterion) {
                this.criteriaList.add(criterion);
                return this;
            },
            addCriteria: function (criteria) {
                this.criteriaList.addRange(criteria);
                return this;
            },
            list: function () {
                find(this.originalList, this.filterList, this.criteriaList);
                return this.filterList;
            },

            iterator: function () {
                find(this.originalList, this.filterList, this.criteriaList);
                return this.filterList.iterator();
            },

            array: function () {
                find(this.originalList, this.filterList, this.criteriaList);
                return this.filterList.toArray();
            }
        }).$();

});