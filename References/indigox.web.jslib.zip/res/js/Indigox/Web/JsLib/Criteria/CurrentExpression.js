﻿define("Indigox.Web.JsLib.Criteria.CurrentExpression",
    [
        "Indigox.Web.JsLib.Criteria.Criterion",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Criterion
) {

    var base = Criterion.prototype;

    var CurrentExpression =
        Namespace("Indigox.Web.JsLib.Criteria")
        .Class("CurrentExpression").Extend(base)
        .Constructor(
    /** @id Indigox.Web.JsLib.Criteria.CurrentExpression */
            function (reference) {
                this.reference = reference;
            }
        )
        .Members({
            evaluate: function (entry) {
                return entry == this.reference;
            }
        }).$();

});