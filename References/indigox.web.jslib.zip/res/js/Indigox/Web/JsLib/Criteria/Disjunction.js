﻿define("Indigox.Web.JsLib.Criteria.Disjunction",
    [
        "Indigox.Web.JsLib.Criteria.Junction",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Junction
) {

    var base = Junction.prototype;

    var Disjunction =
        Namespace("Indigox.Web.JsLib.Criteria")
        .Class("Disjunction").Extend(base)
        .Constructor(
    /** @id Indigox.Web.JsLib.Criteria.Disjunction */
            function (criterion, criterion1) {
                base.constructor.apply(this, arguments);
            }
        )
        .Members({
            evaluate: function (entry) {
                var iterator = this.criteriaList.iterator();
                var criterion;
                while (iterator.hasNext()) {
                    criterion = iterator.next();
                    if (criterion.evaluate(entry)) {
                        return true;
                    }
                }
                return false;
            }
        }).$();

});