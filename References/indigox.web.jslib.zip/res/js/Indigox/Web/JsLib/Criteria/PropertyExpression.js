﻿define("Indigox.Web.JsLib.Criteria.PropertyExpression",
    [
        "Indigox.Web.JsLib.Criteria.Criterion",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Criterion
) {

    var base = Criterion.prototype;

    var PropertyExpression =
        Namespace("Indigox.Web.JsLib.Criteria")
        .Class("PropertyExpression").Extend(base)
        .Constructor(
    /** @id Indigox.Web.JsLib.Criteria.PropertyExpression */
            function (property, otherProperty, operator) {
                this.property = property;
                this.otherProperty = otherProperty;
                this.operator = operator;
            }
        )
        .Static({
            EQUAL: 0,
            NOT_EQUAL: 1,
            GREATER_THAN_OR_EQUAL: 2,
            GREATER_THAN: 3,
            LESS_THAN_OR_EQUAL: 4,
            LESS_THAN: 5
        })
        .Members({
            evaluate: function (entry) {
                switch (this.operator) {
                    case PropertyExpression.EQUAL:
                        return entry[this.property] == entry[this.otherProperty];

                    case PropertyExpression.NOT_EQUAL:
                        return entry[this.property] != entry[this.otherProperty];

                    case PropertyExpression.GREATER_THAN_OR_EQUAL:
                        return entry[this.property] >= entry[this.otherProperty];

                    case PropertyExpression.GREATER_THAN:
                        return entry[this.property] > entry[this.otherProperty];

                    case PropertyExpression.LESS_THAN_OR_EQUAL:
                        return entry[this.property] <= entry[this.otherProperty];

                    case PropertyExpression.LESS_THAN:
                        return entry[this.property] < entry[this.otherProperty];
                }
                return false;
            }
        }).$();

});