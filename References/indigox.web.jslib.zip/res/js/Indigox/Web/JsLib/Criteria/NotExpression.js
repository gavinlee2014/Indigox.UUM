﻿define("Indigox.Web.JsLib.Criteria.NotExpression",
    [
        "Indigox.Web.JsLib.Criteria.Criterion",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Criterion
) {

    var base = Criterion.prototype;

    var NotExpression =
        Namespace("Indigox.Web.JsLib.Criteria")
        .Class("NotExpression").Extend(base)
        .Constructor(
    /** @id Indigox.Web.JsLib.Criteria.NotExpression */
            function (criterion) {
                this.criterion = criterion;
            }
        )
        .Members({
            evaluate: function (entry) {
                return !this.criterion.evaluate(entry);
            }
        }).$();

});