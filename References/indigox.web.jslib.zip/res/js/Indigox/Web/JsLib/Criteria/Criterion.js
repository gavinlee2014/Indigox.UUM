﻿define("Indigox.Web.JsLib.Criteria.Criterion",
    [
        "Indigox.Web.JsLib.Core"
    ],
function (

) {

    var Criterion =
        Namespace("Indigox.Web.JsLib.Criteria")
        .Class("Criterion")
        .Constructor(
    /** @id Indigox.Web.JsLib.Criteria.Criterion */
            function () {
            }
        )
        .Members({
            evaluate: function (entry) {
            }
        }).$();

});