﻿define("Indigox.Web.JsLib.Criteria.ValueExpression",
    [
        "Indigox.Web.JsLib.Criteria.Criterion",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Criterion
) {

    var base = Criterion.prototype;

    var ValueExpression =
        Namespace("Indigox.Web.JsLib.Criteria")
        .Class("ValueExpression").Extend(base)
        .Constructor(
    /** @id Indigox.Web.JsLib.Criteria.ValueExpression */
            function (property, value, operator) {
                this.property = property;
                this.value = value;
                this.operator = operator;
            }
        )
        .Static({
            EQUAL: 0,
            NOT_EQUAL: 1,
            GREATER_THAN_OR_EQUAL: 2,
            GREATER_THAN: 3,
            LESS_THAN_OR_EQUAL: 4,
            LESS_THAN: 5
        })
        .Members({
            evaluate: function (entry) {
                switch (this.operator) {
                    case ValueExpression.EQUAL:
                        return entry[this.property] == this.value;

                    case ValueExpression.NOT_EQUAL:
                        return entry[this.property] != this.value;

                    case ValueExpression.GREATER_THAN_OR_EQUAL:
                        return entry[this.property] >= this.value;

                    case ValueExpression.GREATER_THAN:
                        return entry[this.property] > this.value;

                    case ValueExpression.LESS_THAN_OR_EQUAL:
                        return entry[this.property] <= this.value;

                    case ValueExpression.LESS_THAN:
                        return entry[this.property] < this.value;
                }
                return false;
            }
        }).$();

});