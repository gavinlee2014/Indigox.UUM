﻿define("Indigox.Web.JsLib.Criteria.Restrictions",
    [
        "Indigox.Web.JsLib.Criteria.CurrentExpression",
        "Indigox.Web.JsLib.Criteria.Conjunction",
        "Indigox.Web.JsLib.Criteria.Disjunction",
        "Indigox.Web.JsLib.Criteria.NotExpression",
        "Indigox.Web.JsLib.Criteria.NotNullExpression",
        "Indigox.Web.JsLib.Criteria.NullExpression",
        "Indigox.Web.JsLib.Criteria.PropertyExpression",
        "Indigox.Web.JsLib.Criteria.RegularExpression",
        "Indigox.Web.JsLib.Criteria.ValueExpression",
        "Indigox.Web.JsLib.Core"
    ],
function (
        CurrentExpression,
        Conjunction,
        Disjunction,
        NotExpression,
        NotNullExpression,
        NullExpression,
        PropertyExpression,
        RegularExpression,
        ValueExpression
) {



    var Restrictions =
        Namespace("Indigox.Web.JsLib.Criteria")
        .Class("Restrictions")
        .Constructor(
    /** @id Indigox.Web.JsLib.Criteria.Restrictions */
            function () {
            }
        )
        .Static({
            current: function (reference) {
                return new CurrentExpression(reference);
            },
            and: function (criterion, criterion1) {
                var conjunction = new Conjunction();
                Conjunction.apply(conjunction, arguments);
                return conjunction;
            },
            or: function (criterion, criterion1) {
                var disjunction = new Disjunction();
                Disjunction.apply(disjunction, arguments);
                return disjunction;
            },
            not: function (criterion) {
                return new NotExpression(criterion);
            },
            property: function (property) {
                return {
                    eq: function (value) {
                        return new ValueExpression(property, value, ValueExpression.EQUAL);
                    },
                    ne: function (value) {
                        return new ValueExpression(property, value, ValueExpression.NOT_EQUAL);
                    },
                    ge: function (value) {
                        return new ValueExpression(property, value, ValueExpression.GREATER_THAN_OR_EQUAL);
                    },
                    gt: function (value) {
                        return new ValueExpression(property, value, ValueExpression.GREATER_THAN);
                    },
                    le: function (value) {
                        return new ValueExpression(property, value, ValueExpression.LESS_THAN_OR_EQUAL);
                    },
                    lt: function (value) {
                        return new ValueExpression(property, value, ValueExpression.LESS_THAN);
                    },
                    match: function (pattern, attributes) {
                        return new RegularExpression(property, pattern, attributes);
                    },
                    eqProperty: function (otherProperty) {
                        return new PropertyExpression(property, otherProperty, ValueExpression.EQUAL);
                    },
                    neProperty: function (otherProperty) {
                        return new PropertyExpression(property, otherProperty, ValueExpression.NOT_EQUAL);
                    },
                    geProperty: function (otherProperty) {
                        return new PropertyExpression(property, otherProperty, ValueExpression.GREATER_THAN_OR_EQUAL);
                    },
                    gtProperty: function (otherProperty) {
                        return new PropertyExpression(property, otherProperty, ValueExpression.GREATER_THAN);
                    },
                    leProperty: function (otherProperty) {
                        return new PropertyExpression(property, otherProperty, ValueExpression.LESS_THAN_OR_EQUAL);
                    },
                    ltProperty: function (otherProperty) {
                        return new PropertyExpression(property, otherProperty, ValueExpression.LESS_THAN);
                    },
                    isNotNull: function () {
                        return new NotNullExpression(property);
                    },
                    isNull: function () {
                        return new NullExpression(property);
                    }
                };
            }
        })
        .Members({
        })
    .$();

});