﻿define("Indigox.Web.JsLib.Criteria.NotNullExpression",
    [
        "Indigox.Web.JsLib.Criteria.Criterion",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Criterion
) {

    var base = Criterion.prototype;

    var NotNullExpression =
        Namespace("Indigox.Web.JsLib.Criteria")
        .Class("NotNullExpression").Extend(base)
        .Constructor(
    /** @id Indigox.Web.JsLib.Criteria.NotNullExpression */
            function (property) {
                this.property = property;
            }
        )
        .Members({
            evaluate: function (entry) {
                return !isNullOrUndefined(entry[this.property]);
            }
        }).$();

});