﻿define("Indigox.Web.JsLib.Criteria.Conjunction",
    [
        "Indigox.Web.JsLib.Criteria.Junction",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Junction
) {

    var base = Junction.prototype;

    var Conjunction =
        Namespace("Indigox.Web.JsLib.Criteria")
        .Class("Conjunction").Extend(base)
        .Constructor(
    /** @id Indigox.Web.JsLib.Criteria.Conjunction */
            function (criterion, criterion1) {
                base.constructor.apply(this, arguments);
            }
        )
        .Members({
            evaluate: function (entry) {
                var iterator = this.criteriaList.iterator();
                var criterion;
                while (iterator.hasNext()) {
                    criterion = iterator.next();
                    if (!criterion.evaluate(entry)) {
                        return false;
                    }
                }
                return true;
            }
        }).$();

});