﻿define("Indigox.Web.JsLib.Controls.Html.CheckBoxItem",
    [
        "Indigox.Web.JsLib.Utils.Deferred",
        "Indigox.Web.JsLib.Controls.Html.ItemControl",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Deferred,
        ItemControl
) {
    var EVENT_SELECTED_CHANGED = "selectedChanged";

    var LISTENER_PROPERTY_CHANGING = "PropertyChanging",
        LISTENER_PROPERTY_CHANGED = "PropertyChanged",
        LISTENER_SELECTED_CHANGED = "SelectedChanged";

    var base = ItemControl.prototype;

    var CheckBoxItem =
        Namespace("Indigox.Web.JsLib.Controls.Html")
        .Class("CheckBoxItem")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.checkBox = null;
            }
        )
        .Members({
            registerEvents: function () {
                base.registerEvents.call(this);
                this.events.registerEvents(
                    EVENT_SELECTED_CHANGED
                );
            },

            registerListeners: function () {
                base.registerListeners.call(this);
                this.listeners.registerListeners(
                    LISTENER_SELECTED_CHANGED
                );
            },

            initChildren: function () {
                if (this.getCheckBox()) {
                    this.getCheckBox().init();
                }
            },

            preLoadChildren: function () {
                if (this.getCheckBox()) {
                    this.getCheckBox().preLoad();
                }
            },

            loadChildren: function () {
                if (this.getCheckBox()) {
                    return this.getCheckBox().load();
                }
                return null;
            },

            unloadChildren: function () {
                if (this.getCheckBox()) {
                    this.getCheckBox().unload();
                }
            },

            setValue: function (value) {
                var oldValue = this.getCheckBox().getRawValue();
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["value", value, oldValue]);
                this.getCheckBox().setRawValue(value);
                value = this.getCheckBox().getRawValue();
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["value", value, oldValue]);
            },

            getValue: function () {
                return this.getCheckBox().getRawValue();
            },

            setText: function (value) {
                return this.getCheckBox().setText(value);
            },

            getText: function () {
                return this.getCheckBox().getText();
            },

            getCheckBox: function () {
                return this.checkBox;
            },

            setCheckBox: function (value) {
                var oldValue = this.checkBox;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["checkBox", value, oldValue]);
                this.checkBox = value;
                this.checkBox.addListener(this);

                Deferred.when(this.catchUpLoadChild(value)).done({
                    handler: function () {
                        this.fireListener(LISTENER_PROPERTY_CHANGED, ["checkBox", value, oldValue]);
                    },
                    scope: this
                }).fail({
                    handler: function () {
                        debug.error([this.id, " set checkBox failed."].join(""));
                    },
                    scope: this
                });
            },

            setID: function (id) {
                base.setID.call(this, id);

                if (this.getCheckBox()) {
                    this.getCheckBox().setID(id + ".checkBox:0");
                }
            },

            getSelected: function () {
                return this.getCheckBox().getChecked();
            },

            setSelected: function (value) {
                if (isNullOrUndefined(value) || value === this.selected) {
                    return;
                }

                var oldValue = this.selected;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["selected", value, oldValue]);

                this.selected = value;
                this.getCheckBox().setChecked(value);

                this.fireListener(LISTENER_PROPERTY_CHANGED, ["selected", value, oldValue]);

                this.fireListener(LISTENER_SELECTED_CHANGED, [value]);
                this.fireEvent(EVENT_SELECTED_CHANGED, [value]);
            },

            onCheckChanged: function (source, value) {
                if (!isNullOrUndefined(value) && value != this.selected) {
                    this.setSelected(value);
                }
            }
        })
    .$();
});