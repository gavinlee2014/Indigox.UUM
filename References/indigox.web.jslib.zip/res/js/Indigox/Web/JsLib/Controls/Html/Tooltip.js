﻿define("Indigox.Web.JsLib.Controls.Html.Tooltip",
    [
        "Indigox.Web.JsLib.Controls.Html.Panel",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Panel
    ) {

    var base = Panel.prototype;

    var EVENT_SHOWN = 'shown',
        EVENT_HIDDEN = 'hidden';

    var LISTENER_SHOWN = 'Shown',
        LISTENER_HIDDEN = 'Hidden',
        LISTENER_CONTROL_ADDED = 'ControlAdded';

    var Tooltip =
        Namespace("Indigox.Web.JsLib.Controls.Html")
        .Class("Tooltip")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
            }
        )
        .Members({
            registerEvents: function () {
                base.registerEvents.call(this);
                this.events.registerEvents(
                    EVENT_SHOWN,
                    EVENT_HIDDEN
                );
            },

            registerListeners: function () {
                base.registerListeners.call(this);
                this.listeners.registerListeners(
                    LISTENER_SHOWN,
                    LISTENER_HIDDEN,
                    LISTENER_CONTROL_ADDED
                );
            },

            show: function (x, y) {
                this.setVisible(true);
                this.fireListener(LISTENER_SHOWN, [x, y]);
                this.fireEvent(EVENT_SHOWN, [x, y]);
            },

            hide: function () {
                if (this.getVisible() === false) {
                    return;
                }
                this.setVisible(false);
                this.fireEvent(EVENT_HIDDEN);
            },

            addControl: function (control) {
                this.fireListener(LISTENER_CONTROL_ADDED, [control]);
            }
        })
    .$();
});