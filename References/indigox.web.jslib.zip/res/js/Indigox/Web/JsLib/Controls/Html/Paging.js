﻿define("Indigox.Web.JsLib.Controls.Html.Paging",
    [
        "Indigox.Web.JsLib.Controls.FormControl",
        "Indigox.Web.JsLib.Utils.Callback",
        "Indigox.Web.JsLib.Utils.StringUtil",
        "Indigox.Web.JsLib.Core"
    ],
    function (
        FormControl,
         Callback,
         StringUtil

    ) {
        var base = FormControl.prototype;

        var STATE_CREATED = 0,
            STATE_INITED = 1,
            STATE_PRELOAD = 2,
            STATE_LOADING = 3,
            STATE_LOADED = 4,
            STATE_UNLOADED = 5;

        var LISTENER_PROPERTY_CHANGING = "PropertyChanging",
            LISTENER_PROPERTY_CHANGED = "PropertyChanged";

        var Paging =
            Namespace("Indigox.Web.JsLib.Controls.Html")
            .Class("Paging")
            .Extend(base)
            .Constructor(
                function () {
                    base.constructor.apply(this, arguments);
                    this.currentPage = 1;
                    this.pageSize = 10;
                    this.modelLoading = false;
                }
            )
            .Members({
                arrayController: null,
                totalCount: null,
                pageCount: null,

                getPageSize: function () {
                    return this.pageSize;
                },

                setPageSize: function (value) {
                    value = parseInt(value);
                    this.pageSize = value;
                },

                getTotalCount: function () {
                    return this.totalCount;
                },
                setTotalCount: function (value) {
                    value = parseInt(value);
                    this.totalCount = value;
                },

                getModelLoding: function () {
                    return this.modelLoading;
                },
                setModelLoding: function (value) {
                    var oldValue = this.modelLoading;
                    this.fireListener(LISTENER_PROPERTY_CHANGING, ["modelLoading", value, oldValue]);
                    this.modelLoading = value;
                    this.fireListener(LISTENER_PROPERTY_CHANGED, ["modelLoading", value, oldValue]);
                },

                getPageCount: function () {
                    return this.pageCount;
                },
                setPageCount: function (value) {
                    value = parseInt(value);
                    var oldValue = this.pageCount;
                    this.fireListener(LISTENER_PROPERTY_CHANGING, ["pageCount", value, oldValue]);
                    this.pageCount = value;
                    this.fireListener(LISTENER_PROPERTY_CHANGED, ["pageCount", value, oldValue]);
                },

                getArrayController: function () {
                    return this.arrayController;
                },
                setArrayController: function (value) {
                    this.arrayController = value;
                    this._getTotalCount({ handler: this.updatePageCount, scope: this });
                },

                getCurrentPage: function () {
                    return this.currentPage;
                },
                setCurrentPage: function (value) {
                    value = parseInt(value);
                    var oldValue = this.currentPage;
                    this.fireListener(LISTENER_PROPERTY_CHANGING, ["currentPage", value, oldValue]);
                    this.currentPage = value;
                    this.fireListener(LISTENER_PROPERTY_CHANGED, ["currentPage", value, oldValue]);
                },

                //@private
                updatePageCount: function (count) {
                    this.setTotalCount(count);

                    var pageCount = Math.ceil(this.getTotalCount() / this.getPageSize());
                    if (pageCount === 0) {
                        pageCount = 1;
                    }
                    this.setPageCount(pageCount);
                },

                //@private
                _getTotalCount: function (callback) {
                    var params = this.getArrayController().getParams();
                    return this.getArrayController().getModel().getTotalCount(params, callback);
                },

                //@private
                _reload: function (firstResult) {
                    //this.arrayController.clearModel();
                    this.setModelLoding(true);
                    this.arrayController.setParam("FirstResult", firstResult);
                    var callback = new Callback(this.onModelLoaded, this, []);
                    this.arrayController.load(callback);
                },

                //@private
                onModelLoaded: function () {
                    //TODO: 临时解决方案，paging 在 load 数据时可能被 unload 了
                    if (this.getState() === STATE_UNLOADED) {
                        return;
                    }

                    var modelSize = this.getArrayController().getModel().size();
                    if (modelSize === 0 || (modelSize % this.getPageSize()) !== 0) {
                        this.fireListener(LISTENER_PROPERTY_CHANGED, ["isLastPage", true]);
                    }
                    else {
                        this.fireListener(LISTENER_PROPERTY_CHANGED, ["isLastPage", false]);
                    }

                    this.setModelLoding(false);
                },

                previousPage: function () {
                    if (!this.isFirstPage()) {
                        this._reload((this.getCurrentPage() - 2) * this.getPageSize());
                        this.setCurrentPage(this.getCurrentPage() - 1);
                    }
                },

                nextPage: function () {
                    this._getTotalCount({ handler: this.doNextPage, scope: this });
                },

                //@private
                doNextPage: function (count) {
                    this.updatePageCount(count);

                    if (!this.isLastPage()) {
                        this._reload(this.getCurrentPage() * this.getPageSize());
                        this.setCurrentPage(this.getCurrentPage() + 1);
                    }
                },

                moveLast: function () {
                    this._getTotalCount({ handler: this.doMovelast, scope: this });
                },

                //@private
                doMovelast: function (count) {
                    this.updatePageCount(count);

                    if (!this.isLastPage()) {
                        this._reload((this.getPageCount() - 1) * this.getPageSize());
                        this.setCurrentPage(this.getPageCount());
                    }
                },

                isFirstPage: function () {
                    return (this.getCurrentPage() == 1);
                },

                isLastPage: function () {
                    if (this.getTotalCount() > 0 && this.getCurrentPage() >= this.getPageCount()) {
                        //TODO: 需要重构，不应该在 isLastPage 这个判断方法中 fireListener
                        this.fireListener(LISTENER_PROPERTY_CHANGED, ["isLastPage", true]);
                        return true;
                    }
                    return false;
                },

                moveFirst: function () {
                    this._reload(0);
                    this.setCurrentPage(1);
                },

                moveTo: function (pageNum) {
                    pageNum = StringUtil.parseInt(pageNum);
                    if (!isNaN(pageNum) && this.getPageCount() >= pageNum) {
                        this._reload((pageNum - 1) * this.getPageSize());
                        this.setCurrentPage(pageNum);
                    }
                },

                //@deprecated
                reset: function () {
                    debug.warn("Paging.reset method is deprecated, please use DataList.load to refresh DataList.");
                    this.getArrayController().clearModel();
                    this._reload(0);
                    this.setCurrentPage(1);
                    this._getTotalCount({ handler: this.updatePageCount, scope: this });
                }
            })
        .$();
    });