﻿define("Indigox.Web.JsLib.Controls.Html.HyperLink",
    [
        "Indigox.Web.JsLib.Controls.Html.FieldControl",
        "Indigox.Web.JsLib.Core"
    ],
function (
        FieldControl
) {
    var base = FieldControl.prototype;

    var LISTENER_PROPERTY_CHANGING = "PropertyChanging",
        LISTENER_PROPERTY_CHANGED = "PropertyChanged";

    var HyperLink =
        Namespace("Indigox.Web.JsLib.Controls.Html")
        .Class("HyperLink")
        .Extend(base)
        .Constructor(
            function (config) {
                base.constructor.apply(this, arguments);
                this.icon = null;
                this.text = null;
                this.href = null;
                this.target = null;
            }
        )
        .Members({
            getHref: function () {
                return this.href;
            },

            setHref: function (value) {
                if (isNullOrUndefined(value)) {
                    return;
                }
                var oldValue = this.href;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["href", value, oldValue]);
                this.href = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["href", value, oldValue]);
            },

            getText: function () {
                return this.text;
            },

            setText: function (value) {
                if (isNullOrUndefined(value)) {
                    return;
                }
                var oldValue = this.text;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["text", value, oldValue]);
                this.text = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["text", value, oldValue]);
            },

            getTarget: function () {
                return this.target;
            },

            setTarget: function (value) {
                if (isNullOrUndefined(value)) {
                    return;
                }
                var oldValue = this.target;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["target", value, oldValue]);
                this.target = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["target", value, oldValue]);
            },

            setIcon: function (value) {
                var oldValue = this.icon;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["icon", value, oldValue]);
                this.icon = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["icon", value, oldValue]);
            },

            getIcon: function () {
                return this.icon;
            }
        })
    .$();
});