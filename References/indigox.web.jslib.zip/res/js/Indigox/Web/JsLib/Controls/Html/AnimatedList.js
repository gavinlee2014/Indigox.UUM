﻿define("Indigox.Web.JsLib.Controls.Html.AnimatedList",
    [
        "Indigox.Web.JsLib.Collection.List",
        "Indigox.Web.JsLib.Controls.Template",
        "Indigox.Web.JsLib.Controls.Html.DataItem",
        "Indigox.Web.JsLib.Controls.Html.DataList",
        "Indigox.Web.JsLib.Core"
    ],
function (
        List,
        Template,
        DataItem,
        DataList
) {
    var base = DataList.prototype;

    /** @id Indigox.Web.JsLib.Controls.Html.DataList */
    var AnimatedList =
        Namespace('Indigox.Web.JsLib.Controls.Html')
        .Class('AnimatedList')
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
            }
        )
        .Members({
        })
    .$();
});