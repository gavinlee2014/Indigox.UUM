﻿define("Indigox.Web.JsLib.Controls.Selection.Mode",
    [
        "Indigox.Web.JsLib.Controls.Component",
        "Indigox.Web.JsLib.Collection.List",
        "Indigox.Web.JsLib.Utils.ArrayUtil",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Component,
        List,
        ArrayUtil
) {

    var base = Component.prototype;

    var Mode =
        Namespace("Indigox.Web.JsLib.Controls.Selection")
        .Class("Mode")
        .Extend(base)
        .Constructor(
    /*----------------------------------------
    *       config
    *
    *           mode:               "SINGLE" (default) | "MULTI"
    *           allowDeselect:      true (default) | false
    *           returnValueType:    "ARRAY" (default) | "STRING" | "FLAG"
    *
    *----------------------------------------*/
            function (config) {
                base.constructor.apply(this, arguments);
                this.selected = new List();
                this.returnValueType = "ARRAY";
                this.allowDeselect = true;
                this.working = false;

                this.modes = {
                    "SINGLE": true,
                    "MULTI": true
                };

                this.control = null;
                this.configure(config);
                this.setSelectionMode(config.mode || this.mode);
            }
        )
        .Members({
            deselectAll: function () {
                var selections = this.getSelection(),
                    i = 0,
                    len = selections.length;
                for (; i < len; i++) {
                    this.doDeselect(selections[i]);
                }
            },

            deselect: function (datas) {
                this.doDeselect(datas);
            },

            select: function (datas, keepExisting) {
                var needCommit = this.getNeedCommit();

                //TODO Convert Data To List                
                if (this.getReturnValueType() == "ARRAY") {
                    datas = datas || [];
                }

                if (this.selectionMode == "SINGLE" && datas) {
                    var data = isArray(datas) ? datas[0] : datas;
                    this.doSelectSingle(data, null, false);
                } else {
                    this.doSelectMulti(datas, keepExisting);
                }

                this.tryCommit(needCommit);
            },

            onSelectedChanged: function (data, control) {
                var needCommit = this.getNeedCommit();

                switch (this.selectionMode) {
                    case 'MULTI':
                        if (this.isSelected(data)) {
                            this.doDeselect(data, control);
                        }
                        else {
                            this.doSelectSingle(data, control, true);
                        }
                        break;

                    case 'SINGLE':
                        if (this.allowDeselect && this.isSelected(data)) {
                            this.doDeselect(data, control, needCommit);
                        }
                        else {
                            this.doSelectSingle(data, control, false);
                        }
                        break;
                }
                this.tryCommit(needCommit);
            },

            // @private
            doSelectSingle: function (data, control, keepExisting) {
                var selected = this.selected.clone();

                if (!keepExisting) {
                    var i = null,
                    length = null;
                    for (i = 0, length = selected.size(); i < length; i++) {
                        if (selected.get(i) != data) {
                            this.doDeselect(selected.get(i), null);
                        }
                    }
                }

                if (isNullOrUndefined(data)) {
                    return;
                }

                if (this.isSelected(data)) {
                    this.setControlSelected(data, control, true);
                    return;
                }

                this.selected.add(data);
                this.setControlSelected(data, control, true);
            },

            // @private
            doSelectMulti: function (datas, keepExisting) {
                var selected = this.selected;

                datas = !isArray(datas) ? [datas] : datas;

                if (!keepExisting && selected.size() > 0) {
                    this.doDeselect(this.getSelection());
                }

                var i = null,
                    len = null,
                    data = null;
                for (i = 0, len = datas.length; i < len; i++) {
                    data = datas[i];
                    if (keepExisting && this.isSelected(data)) {
                        continue;
                    }
                    selected.add(data);
                    this.setControlSelected(data, null, true);
                }
            },

            // @private
            doDeselect: function (datas, control) {
                datas = !isArray(datas) ? [datas] : datas;
                var i = null,
                    len = null,
                    data = null;
                for (i = 0, len = datas.length; i < len; i++) {
                    data = datas[i];
                    this.removeSelected(data);
                    this.setControlSelected(data, control, false);
                }
            },

            getNeedCommit: function () {
                var needCommit = false;
                if (this.working === false) {
                    needCommit = true;
                    this.working = true;
                }
                return needCommit;
            },

            tryCommit: function (needCommit) {
                if (needCommit) {
                    //debug.log("Need Commit: " + this.isValueChanged(this this.getValue()));
                    this.control.setValue(this.getValue());
                    this.working = false;
                }
            },

            getSelectionMode: function () {
                return this.selectionMode;
            },

            setSelectionMode: function (selMode) {
                selMode = selMode ? selMode.toUpperCase() : 'SINGLE';
                this.selectionMode = this.modes[selMode] ? selMode : 'SINGLE';
            },

            /**
            * 返回所有选中项的 value
            */
            getSelection: function () {
                //TODO: 返回 List
                return this.selected.toArray();
            },

            /**
            * 返回可作为返回值的选中项的 value
            */
            getValueItems: function () {
                return this.selected;
            },

            isValueChanged: function (oldValue, newValue) {
                var returnValueType = this.getReturnValueType().toUpperCase();
                switch (returnValueType) {
                    case "ARRAY":
                        oldValue = oldValue || [];
                        newValue = newValue || [];
                        return !ArrayUtil.equal(oldValue, newValue);
                    case "STRING":
                        return oldValue != newValue;
                    case "FLAG":
                        return oldValue != newValue;
                    default:
                        return true;
                }
            },

            getValue: function () {
                var returnValueType = this.returnValueType.toUpperCase();
                var valueItems = this.getValueItems();
                switch (returnValueType) {
                    case "ARRAY":
                        return valueItems.toArray();
                    case "STRING":
                        var value = null;
                        if (valueItems.size() > 0 && !isNullOrUndefined(valueItems.get(0))) {
                            value = valueItems.toArray().join(",");
                        }
                        return value;
                    case "FLAG":
                        return null;
                    default:
                        return null;
                }
            },

            getAllowDeselect: function () {
                return this.allowDeselect;
            },

            setAllowDeselect: function (value) {
                this.allowDeselect = value;
            },

            getReturnValueType: function () {
                return this.returnValueType;
            },

            setReturnValueType: function (value) {
                this.returnValueType = value;
            },

            isSelected: function (data) {
                //TODO
                var isSelected = false;
                var i = null,
                    length = this.selected.size();
                for (i = 0; i < length; i++) {
                    if (this.selected.get(i) == data) {
                        isSelected = true;
                        break;
                    }
                }

                return isSelected;
            },

            // @private
            removeSelected: function (data) {
                var index = -1;
                var i = null,
                    length = this.selected.size();
                for (i = 0; i < length; i++) {
                    if (this.selected.get(i) == data) {
                        index = i;
                        break;
                    }
                }

                this.selected.removeAt(index);
            },

            // @abstract
            setControlSelected: function (data, control, isSelected) {
            },

            // @abstract
            bindControl: function (control) {
            }
        })
    .$();

});