﻿define("Indigox.Web.JsLib.Controls.Selection.RowMode",
    [
        "Indigox.Web.JsLib.Controls.Selection.Mode",
        "Indigox.Web.JsLib.Collection.List",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Mode,
        List
) {
    var base = Mode.prototype;

    var RowMode =
        Namespace("Indigox.Web.JsLib.Controls.Selection")
        .Class("RowMode")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
            }
        )
        .Members({
            bindControl: function (control) {
                this.control = control;
                var i = 0,
                    rows = control.getRows(),
                    length = rows.length;
                for (; i < length; i++) {
                    var row = rows[i];
                    if (row.getSelected()) {
                        this.onSelectedChanged(row.getRecord());
                    }
                }
                control.addListener(this);
            },

            tryCommit: function (needCommit) {
            },

            onRowRemoved: function (source, index, row) {
                //TODO 需要考虑翻页选择，那时不需要将Row从Selected中删除
                this.selected.remove(row.getRecord());
            },

            onRowSelectedChanged: function (source, row, selected) {
                var value = row.getRecord();
                if ((selected && this.isSelected(value)) || (!selected && !this.isSelected(value))) {
                    return;
                }

                this.onSelectedChanged(value, row);
            },

            setControlSelected: function (data, row, isSelected) {
                if (isNullOrUndefined(row)) {
                    var rows = this.control.getRows();
                    var i = 0, length = rows.length;
                    for (; i < length; i++) {
                        if (rows[i].getRecord() == data) {
                            row = rows[i];
                            break;
                        }
                    }
                }
                if (!isNullOrUndefined(row)) {
                    row.setSelected(isSelected);
                }
            }
        })
    .$();

});