﻿define("Indigox.Web.JsLib.Controls.Html.FieldContainer",
    [
        "Indigox.Web.JsLib.Controls.Html.Label",
        "Indigox.Web.JsLib.Utils.Util",
        "Indigox.Web.JsLib.Controls.Container",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Label,
        Util,
        Container
) {
    var LISTENER_PROPERTY_CHANGING = "PropertyChanging",
        LISTENER_PROPERTY_CHANGED = "PropertyChanged",
        LISTENER_VALUE_CHANGED = "ValueChanged";

    var base = Container.prototype;

    var FieldContainer =
        Namespace("Indigox.Web.JsLib.Controls.Html")
        .Class("FieldContainer")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.text = "";
                this.required = false;
                this.vertical = false;
                this.collapsible = false;
                this.collapsed = false;
            }
        )
        .Members({
            getText: function () {
                return this.text;
            },

            setText: function (value) {
                this.text = value;
            },

            getRequired: function () {
                return this.required;
            },

            setRequired: function (value) {
                this.required = value;
            },

            setVertical: function (value) {
                this.vertical = value;
            },

            getVertical: function () {
                return this.vertical;
            },
            setCollapsed: function (value) {
                this.collapsed = value;
            },

            getCollapsed: function () {
                return this.collapsed;
            },
            setCollapsible: function (value) {
                this.collapsible = value;
            },

            getCollapsible: function () {
                return this.collapsible;
            },
            collapse: function () {
                this.collpased = !this.collpased;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["collapsed", this.collpased, !this.collpased]);
            },
            clearChildren: function () {
                var children = this.getChildren();
                for (var i = 0, length = children.length; i < length; i++) {
                    this.removeChild(children[i]);
                }
            },

            setChildren: function (contorlInfos) {
                if (contorlInfos.length <= 0) {
                    return;
                }

                this.clearChildren();

                for (var i = 0, length = contorlInfos.length; i < length; i++) {
                    var controlInfo = contorlInfos[i];
                    if (isNullOrUndefined(controlInfo.controlType)) {
                        throw new Error("the contorl\'s type can not be null!");
                    }
                    var child = Type.forAlias(controlInfo.controlType).createInstance();
                    child.configure(controlInfo);

                    this.addChild(child);
                }
            },

            reset: function () {
                var children = this.getChildren();
                for (var i = 0, length = children.length; i < length; i++) {
                    children[i].setValue(null);
                }
            }
        })
    .$();
});