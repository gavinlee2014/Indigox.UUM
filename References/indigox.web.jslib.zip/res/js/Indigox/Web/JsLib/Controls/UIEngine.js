﻿define("Indigox.Web.JsLib.Controls.UIEngine",
    [
        "Indigox.Web.JsLib.Collection.List",
        "Indigox.Web.JsLib.Criteria.Criteria",
        "Indigox.Web.JsLib.Criteria.Restrictions",
        "Indigox.Web.JsLib.Core"
    ],
function (
        List,
        Criteria,
        Restrictions
    ) {
    var current = Restrictions.current,
        and = Restrictions.and,
        or = Restrictions.or,
        not = Restrictions.not,
        property = Restrictions.property;

    var allControls = new List();

    /**
    *
    * (1) uiEngine.searchDescendants( controlName, controlType )
    *     在页面上按 controlName 查找指定 controlType 的控件，返回的 UIEngine 对象上有 controlType 的所有方法的委托
    *
    * (2) uiEngine.{controlType}( controlName )
    *     等同 uiEngine.searchDescendants( controlName, controlType )
    *     例如：uiEngine.TextBox('textbox1')
    *
    * (3) uiEngine.getValue()
    *     执行 uiEngine 中所有控件的 getValue 方法，但仅返回第一个 value，
    *     其它有返回值的委托方法也同样处理，如 getWidth, getHeight...
    *
    * (4) uiEngine.setValue( value )
    *     执行 uiEngine 中所有控件的 setValue 方法
    *
    * (5) uiEngine.first()
    *     返回 uiEngine 中的第一个 control
    *
    * (6) uiEngine.last()
    *     返回 uiEngine 中的第一个 control
    *
    * (7) uiEngine.get( index )
    *     返回 uiEngine 中的最后一个 control
    *
    * (8) uiEngine.each( callback )
    *     对 uiEngine 中的每个控件调用 callback，其 this 指针指向 control
    *
    */

    var UIEngine =
        Namespace("Indigox.Web.JsLib.Controls")
        .Class("UIEngine")
        .Constructor(
            function (controls, type) {
                type = type || Type.forFullName("Indigox.Web.JsLib.Controls.Control").getClass(); 

                this.controls = controls;
                for (var method in type.prototype) {
                    if (method === "constructor") {
                        continue;
                    }
                    else if (method in this) {
                        throw new Error("the method \"" + method + "\" has already in the List object. It can not be added in the object!");
                    }
                    this[method] = function (method) {
                        return function () {
                            var returnValues = new List();
                            var iterator = this.iterator();
                            while (iterator.hasNext()) {
                                var control = iterator.next();
                                returnValues.add(control[method].apply(control, arguments));
                            }
                            if (returnValues.size()) {
                                return returnValues.get(0);
                            }
                        };
                    } (method);
                }
            }
        )
        .Members({
            first: function () {
                return this.controls.get(0);
            },

            last: function () {
                return this.controls.get(this.controls.size() - 1);
            },

            get: function (index) {
                return this.controls.get(index);
            },

            each: function (callback) {
                var iterator = this.iterator();
                while (iterator.hasNext()) {
                    var control = iterator.next();
                    callback.call(control);
                }
            },

            searchDescendants: function (name, type) {
                var getDescendants = function (container) {
                    var controls = [], children, i, length;
                    if (container.children) {
                        children = container.children;
                        for (i = 0, length = children.length; i < length; i++) {
                            controls.push(children[i]);
                            controls.push.apply(controls, getDescendants(children[i]));
                        }
                    }
                    if (container.childNodes) {
                        if (container.control) {
                            controls.push(container.control);
                        }
                        children = container.getChildNodes();
                        for (i = 0, length = children.length; i < length; i++) {
                            controls.push(children[i]);
                            controls.push.apply(controls, getDescendants(children[i]));
                        }
                    }
                    if (container.items) {
                        children = container.getItems();
                        for (i = 0, length = children.length; i < length; i++) {
                            controls.push(children[i]);
                            controls.push.apply(controls, getDescendants(children[i]));
                        }
                    }
                    return controls;
                };

                var controls = [];
                var containers = this.controls;

                var i, length;
                for (i = 0, length = containers.size(); i < length; i++) {
                    controls.push.apply(controls, getDescendants(containers.get(i)));
                }

                var criteria = Criteria.create(controls);
                if (name) {
                    criteria.add(property('name').eq(name));
                }
                //TODO: 解决可以查询继承类的问题
                if (type && type !== Type.forFullName("Indigox.Web.JsLib.Controls.Control").getClass()) {
                    criteria.add(property('constructor').eq(type));
                }

                var list = criteria.list();
                var engine = new UIEngine(list, type);
                return engine;
            },

            iterator: function () {
                return this.controls.iterator();
            }
        })
        .Static({
            add: function (control) {
                if (control.isLoaded()) {
                    throw new Error("Can not create control \"" + control.id + "\" that was same with a control already created!");
                }
                else {
                    allControls.add(control);
                }
            },

            getControls: function () {
                return allControls;
            },

            clear: function () {
                allControls.clear();
            },

            contains: function (control) {
                return allControls.contains(control);
            },

            find: function (name, type) {
                var criteria = Criteria.create(allControls);
                if (name) {
                    criteria.add(property('name').eq(name));
                }
                //TODO: 解决可以查询继承类的问题
                if (type && type !== Type.forFullName("Indigox.Web.JsLib.Controls.Control").getClass()) {
                    criteria.add(property('constructor').eq(type));
                }
                var list = criteria.list();
                var engine = new UIEngine(list, type);
                return engine;
            },

            remove: function (control) {
                allControls.remove(control);
            },

            //@debugger;
            all: function () {
                return allControls.toArray();
            }
        })
    .$();
});