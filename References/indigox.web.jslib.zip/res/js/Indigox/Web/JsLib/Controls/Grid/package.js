﻿define("Indigox.Web.JsLib.Controls.Grid",
    [
        "Indigox.Web.JsLib.Controls.Grid.EditableCell",
        "Indigox.Web.JsLib.Controls.Grid.EditableRow",
        "Indigox.Web.JsLib.Controls.Grid.GridCell",
        "Indigox.Web.JsLib.Controls.Grid.GridColumn",
        "Indigox.Web.JsLib.Controls.Grid.GridFooter",
        "Indigox.Web.JsLib.Controls.Grid.GridHeader",
        "Indigox.Web.JsLib.Controls.Grid.GridRow",
        "Indigox.Web.JsLib.Controls.Grid.GridView",
        "Indigox.Web.JsLib.Controls.Grid.SummaryRow",
        "Indigox.Web.JsLib.Controls.Grid.Toolbar"
    ],
function (
        EditableCell,
        EditableRow,
        GridCell,
        GridColumn,
        GridFooter,
        GridHeader,
        GridRow,
        GridView,
        SummaryRow,
        Toolbar
) {
    return {
        EditableCell: EditableCell,
        EditableRow: EditableRow,
        GridCell: GridCell,
        GridColumn: GridColumn,
        GridFooter: GridFooter,
        GridHeader: GridHeader,
        GridRow: GridRow,
        GridView: GridView,
        SummaryRow: SummaryRow,
        Toolbar: Toolbar
    };
});