﻿define("Indigox.Web.JsLib.Controls.Html.DataList",
    [
        "Indigox.Web.JsLib.Collection.List",
        "Indigox.Web.JsLib.Controls.Template",
        "Indigox.Web.JsLib.Controls.Html.DataItem",
        "Indigox.Web.JsLib.Controls.Html.ListControl",
        "Indigox.Web.JsLib.Core"
    ],
function (
        List,
        Template,
        DataItem,
        ListControl
) {
    var LISTENER_TEMPLATE_CHANGED = 'TemplateChanged';

    var base = ListControl.prototype;

    /** @id Indigox.Web.JsLib.Controls.Html.DataList */
    var DataList =
        Namespace('Indigox.Web.JsLib.Controls.Html')
        .Class('DataList')
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.itemTemplate = null;
            }
        )
        .Members({
            registerListeners: function () {
                base.registerListeners.call(this);
                this.listeners.registerListeners(
                    LISTENER_TEMPLATE_CHANGED
                );
            },

            getItemTemplate: function () {
                return this.itemTemplate;
            },

            setItemTemplate: function (value) {
                var oldValue = this.itemTemplate;
                if (oldValue) {
                    oldValue.setParent(null);
                }
                this.itemTemplate = value;
                if (value) {
                    value.setParent(this);
                }
                this.fireListener(LISTENER_TEMPLATE_CHANGED, [value]);

                if (this.isInited()) {
                    this.itemTemplate.init();
                }
            },

            newItem: function (config) {
                var item = new DataItem();
                this.getItemTemplate().applyTo(item);
                if (config) {
                    item.configure(config);
                }
                return item;
            },

            insertChild: function (index, child) {
                if (child instanceof Template) {
                    this.setItemTemplate(child);
                }
                else {
                    base.insertChild.apply(this, arguments);
                }
            },

            init: function () {
                base.init.call(this);

                // itemTemplate include in items array, initChildren will init it.
                //if (this.getItemTemplate()) {
                //    this.getItemTemplate().init();
                //}
            }
        })
    .$();
});