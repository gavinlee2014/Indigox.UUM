﻿define("Indigox.Web.JsLib.Controls.Grid.GridRow",
    [
        "Indigox.Web.JsLib.Collection.List",
        "Indigox.Web.JsLib.Utils.ArrayUtil",
        "Indigox.Web.JsLib.Utils.Deferred",
        "Indigox.Web.JsLib.Controls.Grid.GridCell",
        "Indigox.Web.JsLib.Controls.Binding.ChildControlBinding",
        "Indigox.Web.JsLib.Controls.Container",
        "Indigox.Web.JsLib.Core"
    ],
function (
        List,
        ArrayUtil,
        Deferred,
        GridCell,
        ChildControlBinding,
        Container
) {
    var EVENT_CELL_ADDING = "cellAdded",
        EVENT_CELL_ADDED = "cellAdded",
        EVENT_CELL_REMOVING = "cellRemoving",
        EVENT_CELL_REMOVED = "cellRemoved",
        EVENT_CLICKED = "clicked",
        EVENT_SELECTED_CHANGED = "selectedChanged";

    var LISTENER_CELL_ADDING = "CellAdding",
        LISTENER_CELL_ADDED = "CellAdded",
        LISTENER_CELL_REMOVING = "CellRemoving",
        LISTENER_CELL_REMOVED = "CellRemoved",
        LISTENER_CLICKED = "Clicked",
        LISTENER_PROPERTY_CHANGING = "PropertyChanging",
        LISTENER_PROPERTY_CHANGED = "PropertyChanged",
        LISTENER_SELECTED_CHANGED = "SelectedChanged",
        LISTENER_VALUE_CHANGED = "ValueChanged";

    var base = Container.prototype;

    var GridRow =
        Namespace("Indigox.Web.JsLib.Controls.Grid")
        .Class("GridRow")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.cells = new List();
                this.selected = false;
            }
        )
        .Members({
            registerEvents: function () {
                base.registerEvents.call(this);
                this.events.registerEvents(
                    EVENT_CELL_ADDING,
                    EVENT_CELL_ADDED,
                    EVENT_CELL_REMOVING,
                    EVENT_CELL_REMOVED,
                    EVENT_SELECTED_CHANGED,
                    EVENT_CLICKED
                );
            },

            registerListeners: function () {
                base.registerListeners.call(this);
                this.listeners.registerListeners(
                    LISTENER_CELL_ADDING,
                    LISTENER_CELL_ADDED,
                    LISTENER_CELL_REMOVING,
                    LISTENER_CELL_REMOVED,
                    LISTENER_SELECTED_CHANGED,
                    LISTENER_VALUE_CHANGED,
                    LISTENER_PROPERTY_CHANGED,
                    LISTENER_CLICKED
                );
            },

            preLoadChildren: function () {
                var children = this.getCells();
                for (var i = 0, length = children.length; i < length; i++) {
                    children[i].preLoad();
                }
            },

            initChildren: function () {
                var children = this.getCells();
                for (var i = 0, length = children.length; i < length; i++) {
                    children[i].init();
                }
            },

            loadChildren: function () {
                var children = this.getCells();
                var defers = [];
                for (var i = 0, length = children.length; i < length; i++) {
                    defers.push(children[i].load());
                }
                return Deferred.when(defers);
            },

            unloadChildren: function () {
                var children = this.getCells();
                for (var i = 0, length = children.length; i < length; i++) {
                    children[i].unload();
                }
            },

            newCell: function (config) {
                var cell = new GridCell();
                if (config) {
                    cell.configure(config);
                }
                return cell;
            },

            insertCell: function (index, cell) {
                if (!(cell instanceof GridCell)) {
                    cell = this.newCell(cell);
                }
                this.cells.insert(index, cell);
                cell.addListener(this);
                this.updateChildrenID(this.cells.toArray(), index);

                cell.setParent(this);
                this.fireListener(LISTENER_CELL_ADDING, [index, cell]);
                this.fireEvent(EVENT_CELL_ADDING, [index, cell]);

                Deferred.when(this.catchUpLoadChild(cell)).done({
                    handler: function () {
                        this.fireListener(LISTENER_CELL_ADDED, [index, cell]);
                        this.fireEvent(EVENT_CELL_ADDED, [index, cell]);
                    },
                    scope: this
                }).fail({
                    handler: function () {
                        debug.error([this.id, "insertCell ", cell.id, " failed."].join(""));
                    },
                    scope: this
                });
            },

            addCell: function (cell) {
                var cells = this.getCells();
                this.insertCell(cells.length, cell);
            },

            removeCell: function (cell) {
                var cells = this.getCells();
                var index = ArrayUtil.indexOf(cells, cell);
                this.cells.remove(cell);
                this.fireEvent(EVENT_CELL_REMOVED, [index, cell]);
                this.fireListener(LISTENER_CELL_REMOVED, [index, cell]);
            },

            clearCells: function () {
                var cells = this.getCells();
                var i = null, length = null;
                for (i = 0, length = cells.length; i < length; i++) {
                    this.removeCell(cells[i]);
                }
            },

            setCells: function (cells) {
                this.clearCells();
                var i, length;
                for (i = 0, length = cells.length; i < length; i++) {
                    this.addCell(cells[i]);
                }
            },

            getCells: function () {
                return this.cells.toArray();
            },

            getCell: function (index) {
                var cells = this.getCells();
                if (isInt(index)) {
                    return cells[index];
                }
                else {
                    for (var i = 0, length = cells.length; i < length; i++) {
                        var cell = cells[i];
                        if (cell.getColumn().getField() == index) {
                            return cell;
                        }
                    }
                }
            },

            setSelected: function (value) {
                if (isNullOrUndefined(value) || value === this.selected) {
                    return;
                }

                var oldValue = this.selected;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["selected", value, oldValue]);
                this.selected = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["selected", value, oldValue]);

                this.fireListener(LISTENER_SELECTED_CHANGED, [value]);
                this.fireEvent(EVENT_SELECTED_CHANGED, [value]);
            },

            getSelected: function () {
                return this.selected;
            },

            setID: function (id) {
                base.setID.call(this, id);
                this.updateAllChildrenID(this.getCells());
            },

            onPropertyChanged: function (source, property, value, oldValue) {
                if (property === "value") {
                    this.fireListener(LISTENER_VALUE_CHANGED, [source, value]);
                }
            },

            onRemove: function () {
                var parent = this.getParent();
                parent.getController().removeRecord(this.getRecord());
                this.setRecord(null);
            },

            click: function () {
                this.setSelected(true);
                this.fireListener(LISTENER_CLICKED, [this]);
            },

            find: function (name) {
                var childList = new List();
                var cells = this.getCells();
                var children = this.getCells();
                var i, length;

                for (i = 0, length = cells.length; i < length; i++) {
                    if (cells[i].name == name) {
                        childList.add(cells[i]);
                    }
                }

                for (i = 0, length = children.length; i < length; i++) {
                    if (children[i].find) {
                        var results = children[i].find(name);
                        if (results) {
                            childList.addRange(results);
                        }
                    }
                }
                if (childList.size()) {
                    return childList.toArray();
                }
                return null;
            },

            getBinding: function () {
                if (!this.binding) {
                    this.binding = new ChildControlBinding();
                    this.binding.setChildProperty("cells");
                }
                return this.binding;
            },
            setBinding: function () {
                throw new Error("Can\'t set DataItem\'s binding property.");
            }
        })
    .$();
});