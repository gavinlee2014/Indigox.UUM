﻿define("Indigox.Web.JsLib.Controls.Grid.EditableCell",
    [
        "Indigox.Web.JsLib.Utils.Deferred",
        "Indigox.Web.JsLib.Controls.Grid.GridCell",
        "Indigox.Web.JsLib.Controls.Binding.ChildControlBinding",
        "Indigox.Web.JsLib.Controls.Binding.Binding",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Deferred,
        GridCell,
        ChildControlBinding,
        Binding
) {
    var LISTENER_PROPERTY_CHANGING = "PropertyChanging",
        LISTENER_PROPERTY_CHANGED = "PropertyChanged",
        LISTENER_INIT = "Init";

    //TODO: EditableCell 包含 editingControl，属于 Container 控件，需要修改它的继承关系
    var base = GridCell.prototype;

    var EditableCell =
        Namespace("Indigox.Web.JsLib.Controls.Grid")
        .Class("EditableCell")
        .Extend(base)
        .Constructor(
            function (column) {
                base.constructor.apply(this, arguments);
                this.editingControl = null;
                this.cellType = 0;
            }
        )
        .Static({
            TYPE_NORMAL: 0,
            TYPE_UPDATE: 1,
            TYPE_CANCEL: 2
        })
        .Members({
            isEditable: function () {
                return true;
            },

            //TODO 因为没有集成Container，不会直接调用InitChildren
            init: function () {
                if (this.isInited()) {
                    debug.warn(this.id + "(" + this.defaultName + ") init more than twice. current state is " + this.stateText);
                    //debug.error(this.id + "(" + this.defaultName + ") init more than twice. current state is " + this.stateText);
                    //return;
                }
                this.initChildren();
                this.setInited();
                this.fireListener(LISTENER_INIT);
            },

            //TODO 因为没有集成Container，不会直接调用LoadChildren
            load: function () {
                this.preLoad();
                this.setLoading();
                this._checkLoadTimeout();
                return Deferred.when(this.doLoad())
                    .then({ handler: this.loadChildren, scope: this })
                    .done({ handler: this.setLoaded, scope: this });
            },

            initChildren: function () {
                if (this.getEditingControl()) {
                    this.getEditingControl().init();
                }
            },

            preLoadChildren: function () {
                if (this.getEditingControl()) {
                    this.getEditingControl().preLoad();
                }
            },

            loadChildren: function () {
                var promises = [];
                if (this.getEditingControl()) {
                    promises.push(this.getEditingControl().load());
                }
                return Deferred.when(promises);
            },

            unloadChildren: function () {
                if (this.getEditingControl()) {
                    this.getEditingControl().unload();
                }
            },

            setID: function (id) {
                base.setID.apply(this, arguments);
                this.setControlID();
            },

            setControlID: function () {
                var editingControl = this.getEditingControl();
                if (!editingControl) {
                    return;
                }
                editingControl.setID(this.id + "." + editingControl.getName() + ":0");
            },

            setCellType: function (value) {
                var oldValue = this.cellType;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["cellType", value, oldValue]);
                this.cellType = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["cellType", value, oldValue]);
            },

            getCellType: function () {
                return this.cellType;
            },

            setEditingControl: function (value) {
                if (this.editingControl == value) {
                    return;
                }

                var oldValue = this.editingControl;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["editingControl", value, oldValue]);

                if (oldValue != null) {
                    oldValue.removeListener(this);
                    oldValue.unload();
                    oldValue.setParent(null);
                }
                this.editingControl = value;
                if (value != null) {
                    value.addListener(this);
                    value.setParent(this);
                    this.setControlID();

                    Deferred.when(this.catchUpLoadChild(value)).done({
                        handler: function () {
                            this.fireListener(LISTENER_PROPERTY_CHANGED, ["editingControl", value, oldValue]);
                        },
                        scope: this
                    }).fail({
                        handler: function () {
                            debug.error([this.id, " set editingControl failed."].join(""));
                        },
                        scope: this
                    });
                }
                else {
                    this.fireListener(LISTENER_PROPERTY_CHANGED, ["editingControl", value, oldValue]);
                }
            },

            //TODO: 从 Container 复制过来的代码，当 EditableCell 继承 Container 之后，此方法要移除
            catchUpLoadChild: function (child) {
                if (this.isInited()) {
                    child.init();
                }
                if (this.isLoaded()) {
                    return child.load();
                }
            },

            getEditingControl: function () {
                return this.editingControl;
            },

            setValue: function (value) {
                base.setValue.apply(this, arguments);
                if ((this.getEditingControl()) && (this.getEditingControl().getValue() !== value)) {
                    this.getEditingControl().setValue(value);
                }
            },

            getValue: function () {
                if (this.getEditingControl()) {
                    return this.getEditingControl().getValue();
                }
                else {
                    return this.value;
                }
            },

            getChildren: function () {
                if (this.editingControl) {
                    return [this.editingControl];
                }
                else {
                    return [];
                }
            },

            getColumn: function () {
                return this.column;
            },

            setColumn: function (value) {
                if (this.column == value) {
                    return;
                }
                this.column = value;
                if (this.column.getDefaultValue()) {
                    this.setValue(this.column.getDefaultValue());
                }
                if (this.column.getWidth()) {
                    this.setWidth(this.column.getWidth());
                }
                if (this.column.getValidateRules().length !== 0) {
                    this.setValidateRules(this.column.getValidateRules());
                }
                if (this.column.getBinding()) {
                    this.setBinding(this.column.getBinding());
                }
            },

            setBinding: function (value) {
                if (value instanceof Binding) {
                    this.binding = value;
                }
                else {
                    this.binding = new ChildControlBinding();
                    this.binding.configure(value);
                }
            },

            onPropertyChanging: function (source, property, value, oldValue) {
                this.fireListener(LISTENER_PROPERTY_CHANGING, [property, value, oldValue]);
            },

            onPropertyChanged: function (source, property, value, oldValue) {
                this.fireListener(LISTENER_PROPERTY_CHANGED, [property, value, oldValue]);
            }
        })
    .$();
});