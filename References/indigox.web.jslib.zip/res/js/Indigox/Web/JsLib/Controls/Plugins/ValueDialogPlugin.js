﻿define("Indigox.Web.JsLib.Controls.Plugins.ValueDialogPlugin",
    [
        "Indigox.Web.JsLib.Utils.Browser",
        "Indigox.Web.JsLib.Controls.Plugins.Plugin",
        "Indigox.Web.JsLib.Utils.Util",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Browser,
        Plugin,
        Util
) {
    var base = Plugin.prototype;

    var Browser = Browser.getInstance();

    var ValueDialogPlugin =
        Namespace("Indigox.Web.JsLib.Controls.Plugins")
        .Class("ValueDialogPlugin")
        .Extend(base)
        .Constructor(
            function (option) {
                this.dialogUrl = null;
                this.dialogHeight = null;
                this.dialogWidth = null;
                this.resultMapping = {};
                base.constructor.apply(this, arguments);
            }
        )
        .Members({
            setDialogUrl: function (url) {
                this.dialogUrl = url;
            },

            getDialogUrl: function () {
                return this.dialogUrl;
            },


            setDialogHeight: function (height) {
                this.dialogHeight = height;
            },

            getDialogHeight: function () {
                return this.dialogHeight;
            },

            setDialogWidth: function (width) {
                this.dialogWidth = width;
            },

            getDialogWidth: function () {
                return this.dialogWidth;
            },

            setResultMapping: function (mappig) {
                this.resultMapping = mappig;
            },

            getResultMapping: function () {
                return this.resultMapping;
            },

            setControl: function (control) {
                base.setControl.apply(this, arguments);
                if (control != null) {
                    control.addListener(this);
                }
            },

            getTargetController: function (source) {
                var parent = source.getParent();
                if (parent) {
                    if (parent.getController && parent.getController()) {
                        return parent.getController();
                    }
                    else {
                        return this.getTargetController(parent);
                    }
                }
                else {
                    return null;
                }
            },

            onClicked: function (source) {

                var mapping = this.getResultMapping() || {};

                var height = this.getDialogHeight();
                var width = this.getDialogWidth();

                var features = "";
                if (height) {
                    if (Browser.name !== 'IE') {
                        height = height + "px";
                    }
                    features += ("dialogHeight=" + height + ",");
                }
                if (width) {
                    if (Browser.name !== 'IE') {
                        width = width + "px";
                    }
                    features += ("dialogWidth=" + width + ",");
                }

                var ret = window.showModalDialog(this.getDialogUrl(), "", features);
                if (ret == null) {
                    return;
                }
                var returnObj = JSON.parse(ret);

                var controller = this.getTargetController(source);
                if (controller == null) {
                    return;
                }
                controller.updateRecord();
                var record = controller.getModel().getRecord(0);
                for (var field in mapping) {
                    var key = mapping[field];
                    record.set(field, returnObj[key]);
                }
            }




        })
    .$();
});