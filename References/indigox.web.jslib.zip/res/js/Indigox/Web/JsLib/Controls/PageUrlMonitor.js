﻿define("Indigox.Web.JsLib.Controls.PageUrlMonitor",
    [
        "Indigox.Web.JsLib.Utils.Configurable",
        "Indigox.Web.JsLib.Collection.List",
        "Indigox.Web.JsLib.Utils.Callback",
        "Indigox.Web.JsLib.Utils.Deferred",
        "Indigox.Web.JsLib.Utils.UrlUtil",
        "Indigox.Web.JsLib.Core"
    ],
    function (
        Configurable,
        List,
        Callback,
        Deferred,
        UrlUtil
    ) {
        var base = Configurable.prototype;

        var PageUrlMonitor =
            Namespace("Indigox.Web.JsLib.Controls")
            .Class("PageUrlMonitor")
            .Extend(base)
            .Constructor(
                function (options) {
                    //@private
                    this.urlPathChangedCallbacks = new List();
                    this.urlParamChangedCallbacks = new List();
                    this.urlHashChangedCallback = new Callback(this.onClientUrlChanged, this);
                    this.url = Page().getUrl();
                    this.urlParamChangePending = null;
                    this.disposed = false;

                    //@public
                    this.paramFilters = [];
                    this.paramIgnoreFilters = 0;
                    this.container = null;

                    this.configure(options);

                    UrlUtil.onHashChanged(this.urlHashChangedCallback);

                    var me = this;

                    Page().on("loading", function () {
                        me.setUrlParamChangePending(new Deferred());
                    });

                    Page().on("loaded", function () {
                        var pending = me.getUrlParamChangePending();
                        if (pending) {
                            pending.resolve();
                        }
                        me.setUrlParamChangePending(null);
                    });
                }
            )
            .Static({
                IGNORE_EMPTY_NEW_VALUE: 1,
                IGNORE_EMPTY_OLD_VALUE: 2
            })
            .Members({
                setParamFilters: function (value) {
                    this.paramFilters = value;
                },

                getParamFilters: function () {
                    return this.paramFilters;
                },

                setParamIgnoreFilters: function (value) {
                    this.paramIgnoreFilters = value;
                },

                getParamIgnoreFilters: function () {
                    return this.paramIgnoreFilters;
                },

                setContainer: function (value) {
                    this.container = value;

                    if (value != null) {
                        var me = this;
                        me.container.on('unload', function () {
                            me.dispose();
                        });
                    }
                },

                getContainer: function () {
                    return this.container;
                },

                setUrlParamChangePending: function (value) {
                    this.urlParamChangePending = value;
                },

                getUrlParamChangePending: function () {
                    return this.urlParamChangePending;
                },

                onClientUrlChanged: function () {
                    var oldUrl = this.url;
                    var newUrl = Page().getUrl();

                    this.url = newUrl;

                    var newUrlPath = UrlUtil.getPath(newUrl);
                    var oldUrlPath = UrlUtil.getPath(oldUrl);

                    if (newUrlPath.toLowerCase() !== oldUrlPath.toLowerCase()) {
                        this.urlPathChange(newUrl, oldUrl);
                    }

                    var newUrlParams = UrlUtil.getParams(newUrl);
                    var oldUrlParams = UrlUtil.getParams(oldUrl);

                    if (this.paramFilters) {
                        for (var i = 0, length = this.paramFilters.length; i < length; i++) {
                            var param = this.paramFilters[i];
                            var newValue = newUrlParams[param];
                            var oldValue = oldUrlParams[param];

                            if ((this.paramIgnoreFilters & Page.IGNORE_EMPTY_NEW_VALUE) && isNullOrUndefined(newValue)) {
                                continue;
                            }

                            if ((this.paramIgnoreFilters & Page.IGNORE_EMPTY_OLD_VALUE) && isNullOrUndefined(oldValue)) {
                                continue;
                            }

                            if (newValue !== oldValue) {
                                this.urlParamChanged = true;
                                this.urlParamChange(param, newValue, oldValue);
                                return;
                            }
                        }
                    }
                },

                urlPathChange: function (newUrl, oldUrl) {
                    if (this.disposed) {
                        return;
                    }

                    //debug.log(["urlPathChanged: '", newUrl, "' -> '", oldUrl, "'"].join(""));
                    var callbacks = this.urlPathChangedCallbacks.toArray();
                    for (var i = 0, length = callbacks.length; i < length; i++) {
                        callbacks[i].invoke();
                    }
                },

                urlParamChange: function (param, newValue, oldValue) {
                    if (this.disposed) {
                        return;
                    }

                    var pending = this.getUrlParamChangePending();
                    if (pending) {
                        pending.done({
                            handler: this.doUrlParamChange,
                            scope: this,
                            args: [param, newValue, oldValue]
                        });
                    }
                    else {
                        this.doUrlParamChange(null, param, newValue, oldValue);
                    }
                },

                doUrlParamChange: function (nul, param, newValue, oldValue) {
                    if (this.disposed) {
                        return;
                    }

                    if (this.urlParamChanged) {
                        //debug.log(["urlParamChanged [", param, "]: '", newValue, "' -> '", oldValue, "'"].join(""));
                        var callbacks = this.urlParamChangedCallbacks.toArray();
                        for (var i = 0, length = callbacks.length; i < length; i++) {
                            callbacks[i].invoke();
                        }
                        this.urlParamChanged = false;
                    }
                },

                onUrlPathChanged: function (callback) {
                    if (!callback) {
                        return;
                    }
                    callback = Callback.createInstance(callback);
                    this.urlPathChangedCallbacks.add(callback);
                },

                onUrlParamChanged: function (callback) {
                    if (!callback) {
                        return;
                    }
                    callback = Callback.createInstance(callback);
                    this.urlParamChangedCallbacks.add(callback);
                },

                dispose: function () {
                    this.disposed = true;
                }
            })
        .$();
    });