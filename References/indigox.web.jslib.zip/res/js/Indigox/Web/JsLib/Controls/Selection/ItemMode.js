﻿define("Indigox.Web.JsLib.Controls.Selection.ItemMode",
    [
        "Indigox.Web.JsLib.Controls.Selection.Mode",
        "Indigox.Web.JsLib.Collection.List",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Mode,
        List
) {

    var base = Mode.prototype;

    var ItemMode =
        Namespace("Indigox.Web.JsLib.Controls.Selection")
        .Class("ItemMode")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
            }
        )
        .Members({
            bindControl: function (control) {
                this.control = control;
                var i = 0,
                    items = control.getItems(),
                    length = items.length;
                for (; i < length; i++) {
                    var item = items[i];
                    if (item.getSelected()) {
                        this.onSelectedChanged(item.getValue(), item);
                    }
                }
                control.addListener(this);
            },

            onItemAdded: function (source, index, item) {
                if (item.getSelected()) {
                    this.onSelectedChanged(item.getValue(), item);
                }

                if (this.selected.indexOf(item.getValue()) != -1) {
                    this.control.selectItem(item.getValue());
                }
            },

            onItemSelectedChanged: function (source, item, selected) {
                var value = item.getValue();
                if ((selected && this.isSelected(value)) || (!selected && !this.isSelected(value))) {
                    return;
                }

                this.onSelectedChanged(value, item);
            },

            setControlSelected: function (data, item, isSelected) {
                if (isNullOrUndefined(item)) {
                    var items = this.control.getItems();
                    var i = 0, length = items.length;
                    for (; i < length; i++) {
                        if (items[i].getValue() == data) {
                            item = items[i];
                            break;
                        }
                    }
                }
                if (!isNullOrUndefined(item)) {
                    item.setSelected(isSelected);
                }
                else {
                    //if (!isNull(data)) {
                    //    this.control.setValue(null);
                    //}
                }
            }
        })
    .$();

});