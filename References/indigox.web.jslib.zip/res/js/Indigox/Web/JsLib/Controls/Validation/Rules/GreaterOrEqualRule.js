﻿define("Indigox.Web.JsLib.Controls.Validation.Rules.GreaterOrEqualRule",
    [
        "Indigox.Web.JsLib.Controls.Validation.Rules.Rule",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Rule
    ) {

    var base = Rule.prototype;

    var GreaterOrEqualRule =
        Namespace("Indigox.Web.JsLib.Controls.Validation.Rules")
        .Class("GreaterOrEqualRule")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.defaultMessageExpression = '输入值须大于或等于${condition}';
            }
        )
        .Members({
            isMatch: function (value) {
                return (value >= this.getCondition());
            }
        })
    .$();
});