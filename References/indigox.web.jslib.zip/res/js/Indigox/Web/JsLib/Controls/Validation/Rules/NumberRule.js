﻿define("Indigox.Web.JsLib.Controls.Validation.Rules.NumberRule",
    [
        "Indigox.Web.JsLib.Controls.Validation.Rules.Rule",
        "Indigox.Web.JsLib.Utils.StringUtil",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Rule,
        StringUtil
    ) {

    var base = Rule.prototype;

    var NumberRule =
        Namespace("Indigox.Web.JsLib.Controls.Validation.Rules")
        .Class("NumberRule")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
            }
        )
        .Members({
            isMatch: function (value) {
                if (StringUtil.isNullOrEmpty(value)) {
                    return true;
                }
                return !isNaN(value);
            }
        })
    .$();
});