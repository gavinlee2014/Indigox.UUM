﻿define("Indigox.Web.JsLib.Controls.Grid.GridView",
    [
        "Indigox.Web.JsLib.Controllers.Controller",
        "Indigox.Web.JsLib.Collection.List",
        "Indigox.Web.JsLib.Utils.ArrayUtil",
        "Indigox.Web.JsLib.Utils.Deferred",
        "Indigox.Web.JsLib.Controls.Html.Button",
        "Indigox.Web.JsLib.Controls.Grid.GridCell",
        "Indigox.Web.JsLib.Controls.Grid.GridColumn",
        "Indigox.Web.JsLib.Controls.Grid.GridFooter",
        "Indigox.Web.JsLib.Controls.Grid.GridHeader",
        "Indigox.Web.JsLib.Controls.Grid.GridRow",
        "Indigox.Web.JsLib.Controls.Grid.EditableRow",
        "Indigox.Web.JsLib.Controls.Grid.EditableCell",
        "Indigox.Web.JsLib.Controls.Grid.SummaryRow",
        "Indigox.Web.JsLib.Controls.Grid.Toolbar",
        "Indigox.Web.JsLib.Controls.Selection.RowMode",
        "Indigox.Web.JsLib.Controls.Container",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Controller,
        List,
        ArrayUtil,
        Deferred,
        Button,
        GridCell,
        GridColumn,
        GridFooter,
        GridHeader,
        GridRow,
        EditableRow,
        EditableCell,
        SummaryRow,
        Toolbar,
        RowMode,
        Container
) {
    var EVENT_ROW_ADDING = "rowAdding",
        EVENT_ROW_ADDED = "rowAdded",
        EVENT_ROW_REMOVING = "rowRemoving",
        EVENT_ROW_REMOVED = "rowRemoved",
        EVENT_ROW_SELECTED_CHANGED = "rowSelectedChanged",
        EVENT_FOOTER_ADDING = "footerAdding",
        EVENT_FOOTER_ADDED = "footerAdded",
        EVENT_FOOTER_REMOVING = "footerRemoving",
        EVENT_FOOTER_REMOVED = "footerRemoved",
        EVENT_SUMMARY_VALUE_CHANGED = "summaryValueChanged";

    var LISTENER_PROPERTY_CHANGING = "PropertyChanging",
        LISTENER_PROPERTY_CHANGED = "PropertyChanged",
        LISTENER_ROW_ADDING = "RowAdding",
        LISTENER_ROW_ADDED = "RowAdded",
        LISTENER_ROW_REMOVING = "RowRemoving",
        LISTENER_ROW_REMOVED = "RowRemoved",
        LISTENER_ROW_SELECTED_CHANGED = "RowSelectedChanged",
        LISTENER_ROW_CLICKED = "RowClicked",
        LISTENER_FOOTER_ADDING = "FooterAdding",
        LISTENER_FOOTER_ADDED = "FooterAdded",
        LISTENER_FOOTER_REMOVING = "FooterRemoving",
        LISTENER_FOOTER_REMOVED = "FooterRemoved",
        LISTENER_VALUE_CHANGED = "ValueChanged",
        LISTENER_SUMMARY_VALUE_CHANGED = "SummaryValueChanged",
        LISTENER_ENTER_FULL_VIEW = "EnterFullView",
        LISTENER_LEAVE_FULL_VIEW = "LeaveFullView";

    var base = Container.prototype;

    var GridView =
        Namespace("Indigox.Web.JsLib.Controls.Grid")
        .Class("GridView")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.columns = new List();
                this.rows = new List();
                this.footers = new List();
                this.header = new GridHeader();
                this.controller = null;
                this.allowDeselect = false;
                this.summary = null;
                this.editable = false;
                this.editCellConfigs = null;
            }
        )
        .Members({
            registerEvents: function () {
                base.registerEvents.call(this);
                this.events.registerEvents(
                    EVENT_ROW_ADDING,
                    EVENT_ROW_ADDED,
                    EVENT_ROW_REMOVING,
                    EVENT_ROW_REMOVED,
                    EVENT_FOOTER_ADDING,
                    EVENT_FOOTER_ADDED,
                    EVENT_FOOTER_REMOVING,
                    EVENT_FOOTER_REMOVED,
                    EVENT_ROW_SELECTED_CHANGED,
                    EVENT_SUMMARY_VALUE_CHANGED
                );
            },

            registerListeners: function () {
                base.registerListeners.call(this);
                this.listeners.registerListeners(
                    LISTENER_ROW_ADDING,
                    LISTENER_ROW_ADDED,
                    LISTENER_ROW_REMOVING,
                    LISTENER_ROW_REMOVED,
                    LISTENER_ROW_SELECTED_CHANGED,
                    LISTENER_FOOTER_ADDING,
                    LISTENER_FOOTER_ADDED,
                    LISTENER_FOOTER_REMOVING,
                    LISTENER_FOOTER_REMOVED,
                    LISTENER_VALUE_CHANGED,
                    LISTENER_ROW_CLICKED,
                    LISTENER_SUMMARY_VALUE_CHANGED,
                    LISTENER_ENTER_FULL_VIEW,
                    LISTENER_LEAVE_FULL_VIEW
                );
            },

            init: function () {
                this.preInit();
                base.init.apply(this, arguments);
            },

            preInit: function () {
                if (!this.getHeader()) {
                    this.setHeader(this.newHeader());
                }
            },

            load: function () {
                this.setSelMode(this.createSelectionMode());
                return base.load.apply(this, arguments);
            },

            doLoad: function (defer) {
                var dfd = new Deferred();
                if (this.getController() && this.getController().getAutoLoad() == true) {
                    this.getController().load(function () {
                        dfd.resolve();
                    });
                }
                else {
                    dfd.resolve();
                }
                return dfd.promise();
            },

            unload: function () {
                base.unload.apply(this, arguments);
                if (this.getController()) {
                    this.getController().unload();
                }
            },

            initChildren: function () {
                this.getHeader().init();

                var children = this.getRows();
                for (var i = 0, length = children.length; i < length; i++) {
                    children[i].init();
                }

                children = this.getFooters();
                for (i = 0, length = children.length; i < length; i++) {
                    children[i].init();
                }
            },

            preLoadChildren: function () {
                this.getHeader().preLoad();

                var children = this.getRows();
                for (var i = 0, length = children.length; i < length; i++) {
                    children[i].preLoad();
                }

                children = this.getFooters();
                for (i = 0, length = children.length; i < length; i++) {
                    children[i].preLoad();
                }
            },

            loadChildren: function () {
                var promises = [];

                promises.push(this.getHeader().load());

                var children = this.getRows();
                for (var i = 0, length = children.length; i < length; i++) {
                    promises.push(children[i].load());
                }

                children = this.getFooters();
                for (i = 0, length = children.length; i < length; i++) {
                    promises.push(children[i].load());
                }

                return Deferred.when(promises);
            },

            unloadChildren: function () {
                this.getHeader().unload();

                var children = this.getRows();
                for (var i = 0, length = children.length; i < length; i++) {
                    children[i].unload();
                }

                children = this.getFooters();
                for (i = 0, length = children.length; i < length; i++) {
                    children[i].unload();
                }
            },

            setController: function (controller) {
                if (!(controller instanceof Controller)) {
                    var controllerInfo = controller;
                    controller = Type.forAlias(controllerInfo.controllerType).createInstance();
                    controller.configure(controllerInfo);
                }

                if (this.controller) {
                    this.controller.setView(null);
                }
                this.controller = controller;
                if (this.controller) {
                    this.controller.setView(this);
                }

                if (this.isLoaded() && this.controller.autoLoad === true) {
                    this.controller.load();
                }
            },

            getController: function () {
                return this.controller;
            },

            newHeader: function () {
                var header = new GridHeader();
                var columns = this.getColumns();
                var i = null,
                    length = null,
                    column = null;
                for (i = 0, length = columns.length; i < length; i++) {
                    column = columns[i];
                    if (!column.getHidden()) {
                        var cell = new GridCell();
                        cell.setValue(column.getCaption());
                        cell.setColumn(column);
                        header.addCell(cell);
                    }
                }
                return header;
            },

            setHeader: function (value) {
                if (this.getHeader() == value) {
                    return;
                }
                if (!(value instanceof GridHeader)) {
                    return;
                }

                var oldValue = this.getHeader();
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["header", value, oldValue]);

                if (oldValue) {
                    oldValue.removeListener(this);
                    oldValue.unload();
                    oldValue.setParent(null);
                }
                this.header = value;
                if (value) {
                    value.addListener(this);
                    value.setID(this.id + ".header:0");
                    value.setParent(this);

                    Deferred.when(this.catchUpLoadChild(value)).done({
                        handler: function () {
                            this.fireListener(LISTENER_PROPERTY_CHANGED, ["header", value, oldValue]);
                        },
                        scope: this
                    }).fail({
                        handler: function () {
                            debug.error([this.id, " set header failed."].join(""));
                        },
                        scope: this
                    });
                }
                else {
                    this.fireListener(LISTENER_PROPERTY_CHANGED, ["header", value, oldValue]);
                }
            },

            getHeader: function () {
                return this.header;
            },

            newSummaryRow: function (value) {
                var row = new SummaryRow();
                row.setSummaryColumn(value);
                var columns = this.getColumns();
                var i = null,
                    length = columns.length,
                    column = null;
                if (length <= 0) {
                    throw new Error("Can not create new GridRow without any columns!");
                }
                for (i = 0; i < length; i++) {
                    column = columns[i];
                    if (!column.getHidden()) {
                        var cell = new GridCell(column.getField());
                        cell.setColumn(column);
                        row.addCell(cell);
                    }
                }
                return row;
            },

            setSummary: function (value) {
                if (this.getSummary() == value) {
                    return;
                }
                this.summary = value;
                var summaryRow = this.newSummaryRow(value);

                var footers = this.getFooters();
                if (footers.length > 0 && footers[0] instanceof SummaryRow) {
                    this.removeFooter(footers[0]);
                }
                this.insertFooter(0, summaryRow);
            },

            getSummary: function () {
                return this.summary;
            },

            onSummaryValueChanged: function (source, field, summaryValue) {
                //debug.log("Summary of [" + field + "] is :" + summaryValue);
                this.fireListener(LISTENER_SUMMARY_VALUE_CHANGED, [field, summaryValue]);
            },

            getEditCellConfigs: function () {
                return this.editCellConfigs;
            },

            setEditCellConfigs: function (value) {
                this.editCellConfigs = value;
                var footers = this.getFooters();
                var i = null,
                    length = null;
                for (i = 0, length = footers.length; i < length; i++) {
                    var footer = footers[i];
                    if (footer instanceof EditableRow) {
                        footer.configure({
                            cellConfigs: value
                        });
                    }
                }
            },

            getEditableCells: function () {
                return this.editableCells;
            },

            setEditableCells: function (value) {
                if (value.length === 0) {
                    return;
                }
                this.editableCells = value;
                var editableRow = this.getEditableRow();

                if (!editableRow) {
                    editableRow = new EditableRow();
                    this.addFooter(editableRow);
                    editableRow.buildCells();
                }

                editableRow.configure({
                    cells: value
                });
            },

            getEditableRow: function () {
                var footers = this.getFooters();

                for (var i = 0, length = footers.length; i < length; i++) {
                    var footer = footers[i];
                    if (footer instanceof EditableRow) {
                        return footer;
                    }
                }

                return null;
            },

            setEditable: function (value) {
                if (isNullOrUndefined(value)) {
                    return;
                }
                if (this.editable === value) {
                    return;
                }
                this.editable = value;

                var footers = this.getFooters();
                var i = null,
                    length = null,
                    hasEditableRow = false,
                    hasToolbar = false;
                for (i = 0, length = footers.length; i < length; i++) {
                    var footer = footers[i];
                    if (footer instanceof EditableRow) {
                        hasEditableRow = true;
                        if (value === false) {
                            this.removeFooter(footer);
                        }
                    }
                    if (footer instanceof Toolbar) {
                        hasToolbar = true;
                        if (value === false) {
                            this.removeFooter(footer);
                        }
                    }
                }

                if (hasEditableRow === false && value === true) {
                    var editableRow = new EditableRow();
                    this.addFooter(editableRow);
                    editableRow.buildCells();
                }

                if (hasToolbar === false && value === true) {
                    this.addFooter(new Toolbar());
                }

                this.fireListener(LISTENER_PROPERTY_CHANGED, ["editable", value]);
            },

            getEditable: function () {
                return this.editable;
            },

            addColumn: function (value) {
                var columns = this.getColumns();
                if (!(value instanceof GridColumn)) {
                    var column = new GridColumn();
                    column.configure(value);
                    value = column;
                }
                this.columns.insert(columns.length, value);
            },

            setColumns: function (value) {
                var i = null,
                    length = null;
                for (i = 0, length = value.length; i < length; i++) {
                    this.addColumn(value[i]);
                }
                this.setHeader(this.newHeader());
            },

            getColumns: function () {
                return this.columns.toArray();
            },

            newItem: function (config) {
                return this.newRow(config);
            },

            insertItem: function (index, item) {
                this.insertRow(index, item);
            },

            getItems: function () {
                return this.getRows();
            },

            removeItem: function (item) {
                this.removeRow(item);
            },

            newRow: function (config) {
                var row = new GridRow();
                var columns = this.getColumns();
                var i = null,
                    length = columns.length,
                    column = null;
                if (length <= 0) {
                    throw new Error("Can not create new GridRow without any columns!");
                }
                for (i = 0; i < length; i++) {
                    column = columns[i];
                    if (!column.getHidden()) {
                        var cell = new GridCell(column.getField());
                        cell.setColumn(column);
                        row.addCell(cell);
                    }
                }
                if (config) {
                    row.configure(config);
                }

                if (this.editable) {
                    var removeButton = new Button();
                    var removeBtnCell = new EditableCell();
                    removeBtnCell.setEditingControl(removeButton);
                    removeBtnCell.setCellType(EditableCell.TYPE_CANCEL);
                    row.addCell(removeBtnCell);
                    removeButton.addListener(row, { onClicked: row.onRemove });
                }
                return row;
            },

            addRow: function (row) {
                var rows = this.getRows();
                this.insertRow(rows.length, row);
            },

            addRows: function (range) {
                var i = null,
                    length = null;
                for (i = 0, length = range.length; i < length; i++) {
                    this.addRow(range[i]);
                }
            },

            insertRow: function (index, row) {
                var rows = this.getRows();

                if (index > rows.length) {
                    throw new Error("out of range");
                }

                if (!(row instanceof GridRow)) {
                    row = this.GridRow(row);
                }
                row.setParent(this);

                this.rows.insert(index, row);
                this.updateChildrenID(this.rows.toArray(), index);
                row.addListener(this, {
                    onSelectedChanged: this.onRowSelectedChanged,
                    onClicked: this.onRowClicked,
                    onValueChanged: this.onValueChanged
                });

                this.fireListener(LISTENER_ROW_ADDING, [index, row]);
                this.fireEvent(EVENT_ROW_ADDING, [index, row]);

                Deferred.when(this.catchUpLoadChild(row)).done({
                    handler: function () {
                        this.fireListener(LISTENER_ROW_ADDED, [index, row]);
                        this.fireEvent(EVENT_ROW_ADDED, [index, row]);
                    },
                    scope: this
                }).fail({
                    handler: function () {
                        debug.error("insertRow " + row.id + " failed.");
                    },
                    scope: this
                });
            },

            removeRow: function (row) {
                var rows = this.getRows();
                var index = ArrayUtil.indexOf(rows, row);

                this.rows.removeAt(index);
                this.updateChildrenID(this.rows.toArray(), index);

                row.removeListener(this);

                this.fireEvent(EVENT_ROW_REMOVED, [index, row]);
                this.fireListener(LISTENER_ROW_REMOVED, [index, row]);
            },

            clearRows: function () {
                var rows = this.getRows();
                var i = null, length = null;
                for (i = 0, length = rows.length; i < length; i++) {
                    this.removeRow(rows[i]);
                }
            },

            setRows: function (value) {
                this.clearRows();
                this.addRows(value);
            },

            getRows: function () {
                return this.rows.toArray();
            },

            getFooters: function () {
                return this.footers.toArray();
            },

            clearFooters: function () {
                var footers = this.getFooters();
                var i = null, length = null;
                for (i = 0, length = footers.length; i < length; i++) {
                    this.removeFooter(footers[i]);
                }
            },

            removeFooter: function (footer) {
                var footers = this.getFooters();
                var index = ArrayUtil.indexOf(footers, footer);

                this.footers.removeAt(index);
                this.fireEvent(EVENT_FOOTER_REMOVED, [index, footer]);
                this.fireListener(LISTENER_FOOTER_REMOVED, [index, footer]);
            },

            setFooters: function (value) {
                this.clearRows();
                this.addFooters(value);
            },

            addFooters: function (range) {
                var i = null,
                    length = null;
                for (i = 0, length = range.length; i < length; i++) {
                    this.addFooter(range[i]);
                }
            },

            addFooter: function (footer) {
                var footers = this.getFooters();
                this.insertFooter(footers.length, footer);
            },

            insertFooter: function (index, footer) {
                var footers = this.getFooters();

                if (index > footers.length) {
                    throw new Error("out of range when insert footer");
                }
                footer.setParent(this);

                this.footers.insert(index, footer);
                this.updateChildrenID(this.footers.toArray(), index);
                footer.addListener(this);

                this.fireListener(LISTENER_FOOTER_ADDING, [index, footer]);
                this.fireEvent(EVENT_FOOTER_ADDING, [index, footer]);

                Deferred.when(this.catchUpLoadChild(footer)).done({
                    handler: function () {
                        this.fireListener(LISTENER_FOOTER_ADDED, [index, footer]);
                        this.fireEvent(EVENT_FOOTER_ADDED, [index, footer]);
                    },
                    scope: this
                }).fail({
                    handler: function () {
                        debug.error("insertFooter " + footer.id + " failed.");
                    },
                    scope: this
                });

                this.addListener(footer);
            },

            setValue: function (values) {
                return;
                //
                // Grid load时判断如果有Controller则调用LoadModel 暂时注释掉SetValue
                //
                //this.clearRows();
                //var value = null, i = null, length = null;
                //for (i = 0, length = values.length; i < length; i++) {
                //    value = values[i];
                //    var row = this.newRow();
                //    row.setValue(value);
                //    this.addRow(row);
                //}
            },

            getValue: function () {
                var rows = this.getRows();
                var values = [];
                var i = null,
                    length = null;
                for (i = 0, length = rows.length; i < length; i++) {
                    values.push(rows[i].getRecord().data);
                }
                return values;
            },

            setID: function (id) {
                base.setID.call(this, id);
                this.updateAllChildrenID(this.getRows());
                this.updateAllChildrenID(this.getFooters());
                if (this.getHeader()) {
                    this.getHeader().setID(id + ".header:0");
                }
            },

            getCellsByField: function (field) {
                var cells = [];
                var rows = this.getRows();
                for (var i = 0, length = rows.length; i < length; i++) {
                    cells.push(rows[i].getCell(field));
                }
                return cells;
            },

            onRowSelectedChanged: function (source, selected) {
                this.fireListener(LISTENER_ROW_SELECTED_CHANGED, [source, selected]);
                this.fireEvent(EVENT_ROW_SELECTED_CHANGED, [source, selected]);
            },

            onRowClicked: function (source) {
                this.fireListener(LISTENER_ROW_CLICKED, [source]);
            },

            onValueChanged: function (source, cell, value) {
                this.fireListener(LISTENER_VALUE_CHANGED, [source, cell, value]);
            },

            createSelectionMode: function () {
                var mode = this.mode ? this.mode : "SINGLE";
                var allowDeselect = isNullOrUndefined(this.allowDeselect) ? "true" : this.allowDeselect;
                var selMode = new RowMode({ mode: mode, allowDeselect: allowDeselect });
                return selMode;
            },

            getSelMode: function () {
                return this.selMode;
            },

            setSelMode: function (value) {
                this.selMode = value;
                if (this.selMode) {
                    this.selMode.bindControl(this);
                }
            },

            getMode: function () {
                return this.mode;
            },

            setMode: function (value) {
                this.mode = value;
                this.getSelMode().setSelectionMode(value);
            },

            getAllowDeselect: function () {
                return this.allowDeselect;
            },

            setAllowDeselect: function (value) {
                this.allowDeselect = value;
                this.getMode().setAllowDeselect(value);
            },

            deselectRow: function (deselectValue) {
                var rows = this.getRows();
                var i = 0, length = rows.length;
                for (; i < length; i++) {
                    if (rows[i].getRecord() === deselectValue) {
                        rows[i].setSelected(false);
                    }
                }
            },

            selectRow: function (selectValue) {
                var rows = this.getRows();
                var i = 0, length = rows.length;
                for (; i < length; i++) {
                    if (rows[i].getRecord() === selectValue) {
                        rows[i].setSelected(true);
                    }
                }
            },

            enterFullView: function () {
                this.fireListener(LISTENER_ENTER_FULL_VIEW);
            },

            leaveFullView: function () {
                this.fireListener(LISTENER_LEAVE_FULL_VIEW);
            }
        })
    .$();
});