﻿define("Indigox.Web.JsLib.Controls",
    [
        "Indigox.Web.JsLib.Controls.Grid",
        "Indigox.Web.JsLib.Controls.Html",
        "Indigox.Web.JsLib.Controls.Component",
        "Indigox.Web.JsLib.Controls.Control",
        "Indigox.Web.JsLib.Controls.FormControl",
        "Indigox.Web.JsLib.Controls.Template",
        "Indigox.Web.JsLib.Controls.Validation.Validator",
        "Indigox.Web.JsLib.Controls.Widgets.Widget",
        "Indigox.Web.JsLib.Controls.Widgets.WidgetZone"
    ],
function (
        Grid,
        Html,
        Component,
        Control,
        FormControl,
        Template,
        Validator,
        Widget,
        WidgetZone
) {
    return {
        Grid: Grid,
        Html: Html,
        Component: Component,
        Control: Control,
        FormControl: FormControl,
        Template: Template,
        Validation: {
            Validator: Validator
        },
        Widgets: {
            Widget: Widget,
            WidgetZone: WidgetZone
        }
    };
});