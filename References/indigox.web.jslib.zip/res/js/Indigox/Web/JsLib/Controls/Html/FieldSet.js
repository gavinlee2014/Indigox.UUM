﻿define("Indigox.Web.JsLib.Controls.Html.FieldSet",
    [
        "Indigox.Web.JsLib.Controls.Html.FieldContainer",
        "Indigox.Web.JsLib.Controls.Html.ListControl",
        "Indigox.Web.JsLib.Core"
    ],
function (
        FieldContainer,
        ListControl
    ) {

    var base = ListControl.prototype;

    var FieldSet =
        Namespace("Indigox.Web.JsLib.Controls.Html")
        .Class("FieldSet")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.rowFields = 1;
            }
        )
        .Members({
            getRowFields: function () {
                return this.rowFields;
            },

            setRowFields: function (value) {
                this.rowFields = value;
            },

            getChildren: function () {
                return this.items.toArray();
            },

            /**
            * 从传入的参数（Object/String）创建ListItem对象
            * @param {Object} config
            */
            newItem: function (config) {
                var item = new FieldContainer();

                var width = (1 / this.getRowFields()) * 100 + '%';
                item.setWidth(width);

                if (config) {
                    item.configure(config);
                }
                return item;
            },

            reset: function () {
                var children = this.getChildren();
                for (var i = 0, length = children.length; i < length; i++) {
                    children[i].reset();
                }
            }
        })
    .$();
});