﻿define("Indigox.Web.JsLib.Controls.Selection.NodeMode",
    [
        "Indigox.Web.JsLib.Controls.Selection.Mode",
        "Indigox.Web.JsLib.Collection.List",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Mode,
        List
) {
    var base = Mode.prototype;

    var NodeMode =
        Namespace("Indigox.Web.JsLib.Controls.Selection")
        .Class("NodeMode")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
            }
        )
        .Members({
            bindControl: function (control) {
                this.control = control;
                var i = 0,
                    nodes = control.getNodes(),
                    length = nodes.length;
                for (; i < length; i++) {
                    var node = nodes[i];
                    if (node.getSelected()) {
                        this.onSelectedChanged(node.getValue());
                    }
                }
                control.addListener(this);
            },

            onChildNodeAdded: function (source, node) {
                // if (node.getSelected()) {
                //     this.onSelectedChanged(node.getValue());
                // }
                // if (this.selected.indexOf(node.getValue()) != -1) {
                //     this.control.selectNode(node.getValue());
                // }
            },

            onNodeSelectedChanged: function (source, node, selected) {
                var value = node.getValue();
                if ((selected && this.isSelected(value)) || (!selected && !this.isSelected(value))) {
                    return;
                }

                this.onSelectedChanged(value, node);
            },

            setControlSelected: function (data, node, isSelected) {
                if (isSelected) {
                    this.control.selectNode(data);
                } else {
                    this.control.deselectNode(data);
                }
            }
        })
    .$();

});