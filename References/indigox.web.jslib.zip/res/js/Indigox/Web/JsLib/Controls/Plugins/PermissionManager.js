﻿define("Indigox.Web.JsLib.Controls.Plugins.PermissionManager",
    [
        "Indigox.Web.JsLib.Controls.Component",
        "Indigox.Web.JsLib.Collection.Hashtable",
        "Indigox.Web.JsLib.Collection.List",
        "Indigox.Web.JsLib.Utils.ArrayUtil",
        "Indigox.Web.JsLib.CQRS.Batch",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Component,
        Hashtable,
        List,
        ArrayUtil,
        Batch
) {
    var instance = null;

    var DefaultQuery = "AuthorizedPermissionsQuery";

    var InitialState = 0,
        QueryState = 1,
        DoneSate = 2;

    var base = Component.prototype;

    var PermissionManager =
        Namespace("Indigox.Web.JsLib.Controls.Plugins")
        .Class("PermissionManager")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.resourcesPool = new Hashtable();
                this.resultPool = new Hashtable();
                this.async = false;
            }
        )
        .Static({
            getInstance: function () {
                if (instance === null) {
                    instance = new PermissionManager();
                }
                return instance;
            }
        })
        .Members({
            getAsync: function () {
                return this.async;
            },

            setAsync: function (value) {
                this.async = value;
            },

            register: function (control, options) {
                if (isNullOrUndefined(control)) {
                    throw new Error("The control can not be null or undefined!");
                }

                if (isNullOrUndefined(options.allGranted) && isNullOrUndefined(options.anyGranted)) {
                    throw new Error("must configure permission condition!");
                }

                options.query = (options.query !== undefined) ? options.query : DefaultQuery;
                options.identity = (!isUndefined(options.identity)) ? options.identity : null;

                var config = {
                    allGranted: options.allGranted,
                    anyGranted: options.anyGranted
                };

                var resource = this.findResource(options);
                if (resource != null) {
                    var accessConfig = this.resourcesPool.get(resource);
                    accessConfig.put(control, config);
                    if (resource.state == DoneSate) {
                        this.processResult(resource);
                    }
                }
                else {
                    resource = {
                        identity: options.identity,
                        query: options.query,
                        state: InitialState
                    };
                    var accessConfig = new Hashtable();
                    accessConfig.put(control, config);
                    this.resourcesPool.put(resource, accessConfig);
                    if (this.getAsync() !== true) {
                        this.processRecource(resource);
                    }
                }
            },

            processRecource: function (resource) {
                var batch = Batch.beginBatch();
                this.addResourceQuery(batch, resource);
                batch.commit();
            },

            addResourceQuery: function (batch, resource) {
                var property = {};
                if (resource.identity != null) {
                    property.Identity = resource.identity;
                }
                var me = this;
                batch.list({
                    name: resource.query,
                    properties: property,
                    callback: function (data) {
                        resource.state = DoneSate;
                        me.resultPool.put(resource, data);
                        me.processResult(resource);
                    }
                });
                resource.state = QueryState;
            },

            start: function () {
                var batch = Batch.beginBatch();
                var resources = this.resourcesPool.keys();
                for (var i = 0, length = resources.length; i < length; i++) {
                    var resource = resources[i];
                    if (resource.state == InitialState) {
                        this.addResourceQuery(batch, resource);
                    }
                }
                batch.commit();
            },

            findResource: function (options) {
                var resources = this.resourcesPool.keys();
                for (var i = 0, length = resources.length; i < length; i++) {
                    var resource = resources[i];
                    if (options.query == resource.query && options.identity == resource.identity) {
                        return resource;
                    }
                }
                return null;
            },

            processResult: function (resource) {
                var grantedPermissions = this.resultPool.get(resource);
                var accessConfig = this.resourcesPool.get(resource);
                var controls = accessConfig.keys();

                for (var i = 0, length = controls.length; i < length; i++) {
                    var control = controls[i];
                    var config = accessConfig.get(control);

                    var authorized = false;
                    if (!isNullOrUndefined(config.allGranted)) {
                        authorized = this.authorizeAllGranted(grantedPermissions, config.allGranted);
                    }
                    else if (!isNullOrUndefined(config.anyGranted)) {
                        authorized = this.authorizeAnyGranted(grantedPermissions, config.anyGranted);
                    }

                    this.processControl(control, authorized);
                    accessConfig.remove(control);
                }
            },

            processControl: function (control, authorized) {
                var setter = control.getSetter("Visible");
                if (control.hasSetter("Visible")) {
                    control[setter](authorized);
                }
                else {
                    throw new Error("The Contorl [" + control.id + "] can not set Visible!");
                }
            },

            authorizeAllGranted: function (grantedPermissions, requiredPermissions) {
                var authorized = true;
                requiredPermissions = isArray(requiredPermissions) ? requiredPermissions : [requiredPermissions];
                for (var i = 0, length = requiredPermissions.length; i < length; i++) {
                    if (ArrayUtil.indexOf(grantedPermissions, requiredPermissions[i]) == -1) {
                        authorized = false;
                        break;
                    }
                }
                return authorized;
            },

            authorizeAnyGranted: function (grantedPermissions, requiredPermissions) {
                var authorized = false;
                for (var i = 0, length = requiredPermissions.length; i < length; i++) {
                    if (ArrayUtil.indexOf(grantedPermissions, requiredPermissions[i]) != -1) {
                        authorized = true;
                        break;
                    }
                }
                return authorized;
            }
        })
    .$();
});