﻿define("Indigox.Web.JsLib.Controls.Validation.Rules.GreaterThanControlRule",
    [
        "Indigox.Web.JsLib.Controls.Validation.Rules.CompareToControlRule",
        "Indigox.Web.JsLib.Core"
    ],
function (
        CompareToControlRule
    ) {

    var base = CompareToControlRule.prototype;

    var GreaterThanControlRule =
        Namespace("Indigox.Web.JsLib.Controls.Validation.Rules")
        .Class("GreaterThanControlRule")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.defaultMessageExpression = '输入值须大于控件${controlName}的值';
            }
        )
        .Members({
            isMatch: function (value) {
                return (value > this.getCompareToControlValue());
            }
        })
    .$();
});