﻿define("Indigox.Web.JsLib.Controls.Html.FileUploadList",
    [
        "Indigox.Web.JsLib.Controls.Html.FileUploadItem",
        "Indigox.Web.JsLib.Controls.Html.ListControl",
        "Indigox.Web.JsLib.Core"
    ],
function (
        FileUploadItem,
        ListControl
    ) {

    var base = ListControl.prototype;

    var LISTENER_PROPERTY_CHANGING = "PropertyChanging",
        LISTENER_PROPERTY_CHANGED = "PropertyChanged";


    var FileUploadList =
        Namespace("Indigox.Web.JsLib.Controls.Html")
        .Class("FileUploadList")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.multi = false;
                this.addFileUploadItem();
            }
        )
        .Members({
            newItem: function (config) {
                var item = new FileUploadItem();
                item.owner = this;
                if (config) {
                    item.configure(config);
                }
                return item;
            },

            getValue: function () {
                var uploadedFiles = [];
                var i, length;
                for (i = 0, length = this.items.size(); i < length; i++) {
                    var fileupload = this.items.get(i).getFileUpload();
                    if (fileupload.getUploadState() === "completed") {
                        uploadedFiles.push(fileupload.getValue());
                    }
                }
                //debug.log(uploadedFiles);
                return uploadedFiles;
            },
            setValue: function (value) {
                value = value || [];
                this.setUploadedFiles(value);
            },

            getReadonly: function () {
                return base.getReadonly.call(this);
            },
            setReadonly: function (value) {
                base.setReadonly.call(this, value);
                var i, length;
                for (i = 0, length = this.items.size(); i < length; i++) {
                    var item = this.items.get(i);
                    item.setReadonly(value);
                }
            },

            getMulti: function () {
                return this.multi;
            },
            setMulti: function (value) {
                var oldValue = this.multi;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["multi", value, oldValue]);
                this.multi = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["multi", value, oldValue]);
            },

            isEditable: function () {
                return true;
            },

            addFileUploadItem: function () {
                //debug.log("Add 1st FileUploadItem control.");
                if (!this.getReadonly()) {
                    var item = this.newItem();
                    this.addItem(item);
                }
            },

            addItem: function (item) {
                //debug.log("multi = " + this.multi);
                if (!this.multi) {
                    if (this.items.size() > 1) {
                        this.removeItem(this.items.get(0));
                    }
                }
                base.addItem.apply(this, arguments);
            },

            setUploadedFiles: function (files) {
                this.clearItems();
                for (var i = 0, length = files.length; i < length; i++) {
                    var file = files[i];
                    var item = this.newItem();
                    item.setValue(file);
                    item.setAsCompleted();
                    item.setReadonly(this.getReadonly());
                    this.addItem(item);
                }
                this.addFileUploadItem();
            },

            onFileUploadBeginUpload: function (source, e) {
                this.addFileUploadItem();
            }
        })
    .$();
});