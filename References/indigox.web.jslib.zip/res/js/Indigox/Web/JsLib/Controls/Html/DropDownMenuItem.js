define("Indigox.Web.JsLib.Controls.Html.DropDownMenuItem",
    [
        "Indigox.Web.JsLib.Controls.Html.Button",
        "Indigox.Web.JsLib.Controls.Html.MenuItem",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Button,
        MenuItem
) {
    var EVENT_CLICKED = "clicked";

    var LISTENER_PROPERTY_CHANGING = "PropertyChanging",
        LISTENER_PROPERTY_CHANGED = "PropertyChanged",
        LISTENER_CLICKED = "Clicked";

    var base = MenuItem.prototype;

    var DropDownMenuItem =
        Namespace("Indigox.Web.JsLib.Controls.Html")
        .Class("DropDownMenuItem")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.displayMode = Button.DISPLAYMODE_TEXT_AND_ICON;
                this.icon = null;
            }
        )
        .Static({
            DISPLAYMODE_TEXT_AND_ICON: 0,
            DISPLAYMODE_TEXT_ONLY: 1,
            DISPLAYMODE_ICON_ONLY: 2
        })
        .Members({
            /** @id Indigox.Web.JsLib.Controls.Html.Button.prototype.registerEvents */
            registerEvents: function () {
                base.registerEvents.call(this);
                this.events.registerEvents(
                    EVENT_CLICKED
                );
            },

            registerListeners: function () {
                base.registerListeners.call(this);
                this.listeners.registerListeners(
                    LISTENER_CLICKED
                );
            },

            setDisplayMode: function (value) {
                this.displayMode = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["displayMode", this.getDisplayMode]);
            },

            getDisplayMode: function () {
                return this.displayMode;
            },

            setIcon: function (icon) {
                this.icon = icon;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["icon", this.icon]);
            },

            getIcon: function () {
                return this.icon;
            },

            click: function () {
                this.fireListener(LISTENER_CLICKED);
                this.fireEvent(EVENT_CLICKED);
            }
        })
    .$();
});