﻿define("Indigox.Web.JsLib.Controls.Html.DataItem",
    [
        "Indigox.Web.JsLib.Controls.Binding.Binding",
        "Indigox.Web.JsLib.Controls.Binding.ChildControlBinding",
        "Indigox.Web.JsLib.Controls.Html.ItemControl",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Binding,
        ChildControlBinding,
        ItemControl
) {
    var base = ItemControl.prototype;

    var EVENT_CLICKED = "clicked";

    var LISTENER_PROPERTY_CHANGING = "PropertyChanging",
        LISTENER_PROPERTY_CHANGED = "PropertyChanged",
        LISTENER_CLICKED = "Clicked";

    /** @id Indigox.Web.JsLib.Controls.Html */
    var DataItem =
        Namespace("Indigox.Web.JsLib.Controls.Html")
        .Class("DataItem")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.template = null;
            }
        )
        .Members({
            registerEvents: function () {
                base.registerEvents.call(this);
                this.listeners.registerListeners(
                    EVENT_CLICKED
                );
            },

            registerListeners: function () {
                base.registerListeners.call(this);
                this.listeners.registerListeners(
                    LISTENER_CLICKED,
                    LISTENER_PROPERTY_CHANGED
                );
            },

            setValue: function (value) {
                this.getBinding().bind(value);
            },

            getValue: function () {
                return this.getRecord();
            },

            setTemplate: function (value) {
                this.template = value;
            },

            getTemplate: function () {
                return this.template;
            },

            getBinding: function () {
                if (!this.binding) {
                    this.binding = new ChildControlBinding();
                }
                return this.binding;
            },

            setBinding: function () {
                throw new Error("Can't set DataItem\'s binding property.");
            },

            click: function () {
                this.fireListener(LISTENER_CLICKED, []);
                this.fireEvent(EVENT_CLICKED, []);
            }
        })
    .$();
});