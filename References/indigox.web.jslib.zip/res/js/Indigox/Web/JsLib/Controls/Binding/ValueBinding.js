﻿define("Indigox.Web.JsLib.Controls.Binding.ValueBinding",
    [
        "Indigox.Web.JsLib.Controls.Binding.Binding",
        "Indigox.Web.JsLib.Expression.ExpressionEvaluator",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Binding,
        ExpressionEvaluator
    ) {

    var base = Binding.prototype;

    var ValueBinding =
        Namespace("Indigox.Web.JsLib.Controls.Binding")
        .Class("ValueBinding")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
            }
        )
        .Members({
            bind: function (control, record, field) {
                var evaluator = new ExpressionEvaluator('${value}');

                if (typeof field === "undefined") {
                    var key = control.getName();
                    if (isNullOrUndefined(record.get(key))) { return; } /*if record does not contains specified key ,do nothing*/
                    if (record.contains(key)) {
                        evaluator.setProperty(control, record.get(key));
                    }
                }
                else {
                    if (!this.hasReference(field)) {
                        return;
                    }
                    if (isNullOrUndefined(record.get(field))) { return; } /*if record does not contains specified key ,do nothing*/
                    if (record.contains(field)) {
                        evaluator.setProperty(control, record.get(field));
                    }
                }
            },

            provide: function (control, record, field) {
                if (!control.isEditable()) {
                    return;
                }

                if (this.getMode() == "ReadOnly") {
                    return;
                }

                var evaluator = new ExpressionEvaluator('${value}');
                var value = evaluator.getProperty(control);

                var key = field;
                if (isNullOrUndefined(key)) {
                    key = control.getName();
                }

                if (record.contains(key)) {
                    record.set(key, value);
                }
            }
        })
    .$();
});