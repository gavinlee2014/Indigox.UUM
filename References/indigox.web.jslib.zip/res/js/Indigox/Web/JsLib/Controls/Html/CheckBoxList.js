define("Indigox.Web.JsLib.Controls.Html.CheckBoxList",
    [
        "Indigox.Web.JsLib.Controls.Html.CheckBox",
        "Indigox.Web.JsLib.Controls.Html.CheckBoxItem",
        "Indigox.Web.JsLib.Controls.Selection.ItemMode",
        "Indigox.Web.JsLib.Utils.Util",
        "Indigox.Web.JsLib.Controls.Html.ListControl",
        "Indigox.Web.JsLib.Core"
    ],
function (
        CheckBox,
        CheckBoxItem,
        ItemMode,
        Util,
        ListControl
) {
    var base = ListControl.prototype;

    var CheckBoxList =
        Namespace("Indigox.Web.JsLib.Controls.Html")
        .Class("CheckBoxList")
        .Extend(base)
        .Constructor(
            function () {
                // call base constructor
                this.mode = "MULTI";
                this.allowDeselect = true;
                base.constructor.apply(this, arguments);
            }
        )
        .Members({
            setReadonly: function (readonly) {
                base.setReadonly.apply(this, arguments);
                var items = this.getItems();

                var i, length = null;
                for (i = 0, length = items.length; i < length; i++) {
                    items[i].getCheckBox().setEnable(!readonly);
                }
            },

            /**
            * 从传入的参数（Object/String）创建ListItem对象
            * @param {Object} config
            */
            newItem: function (config) {
                var item = new CheckBoxItem();
                var checkBox = new CheckBox();

                item.setCheckBox(checkBox);
                if (config) {
                    item.configure(config);
                }
                return item;
            },

            createSelectionMode: function () {
                var mode = this.mode ? this.mode : "SINGLE";
                var allowDeselect = isNullOrUndefined(this.allowDeselect) ? "true" : this.allowDeselect;
                var selMode = new ItemMode({ mode: mode, allowDeselect: allowDeselect });
                return selMode;
            }
        })
    .$();
});