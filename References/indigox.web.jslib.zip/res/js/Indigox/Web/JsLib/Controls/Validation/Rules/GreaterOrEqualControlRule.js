﻿define("Indigox.Web.JsLib.Controls.Validation.Rules.GreaterOrEqualControlRule",
    [
        "Indigox.Web.JsLib.Controls.Validation.Rules.CompareToControlRule",
        "Indigox.Web.JsLib.Core"
    ],
function (
        CompareToControlRule
    ) {

    var base = CompareToControlRule.prototype;

    var GreaterOrEqualControlRule =
        Namespace("Indigox.Web.JsLib.Controls.Validation.Rules")
        .Class("GreaterOrEqualControlRule")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.defaultMessageExpression = '输入值须大于或等于控件${controlName}的值';
            }
        )
        .Members({
            isMatch: function (value) {
                return (value >= this.getCompareToControlValue());
            }
        })
    .$();
});