﻿define("Indigox.Web.JsLib.Controls.Component",
    [
        "Indigox.Web.JsLib.Utils.Configurable",
        "Indigox.Web.JsLib.Core"
    ],
    function (
        Configurable,
        Core
    ) {
        base = Configurable.prototype

        var Component =
            Namespace("Indigox.Web.JsLib.Controls")
            .Class("Component")
            .Extend(base)
            .Members({
                isConfigurableValue: function (value) {
                    return (value instanceof Component);
                },
                configureFieldOrProperty: function (key, value) {
                    if (!(this.hasField(key) || this.hasGetter(key))) {
                        return;
                    }

                    if (key == 'events') {
                        this.attach(this, value);
                        return;
                    }

                    var oldValue = this.getFieldOrProperty(key);

                    if (!this.isConfigurableValue(value) && this.isConfigurableValue(oldValue)) {
                        oldValue.configure(value);
                    }
                    else {
                        this.setFieldOrProperty(key, value);
                    }
                }
            })
        .$();
    });