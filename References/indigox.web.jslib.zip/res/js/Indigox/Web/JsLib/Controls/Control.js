﻿define("Indigox.Web.JsLib.Controls.Control",
    [
        "Indigox.Web.JsLib.Controls.Component",
        "Indigox.Web.JsLib.Collection.List",
        "Indigox.Web.JsLib.Utils.DelayedTask",
        "Indigox.Web.JsLib.Utils.Deferred",
        "Indigox.Web.JsLib.Utils.StringUtil",
        "Indigox.Web.JsLib.Utils.EventsSupport",
        "Indigox.Web.JsLib.Utils.ListenersSupport",
        "Indigox.Web.JsLib.Controls.ListenersFactory",
        "Indigox.Web.JsLib.Controls.UIEngine",
        "Indigox.Web.JsLib.Controls.Binding.Binding",
        "Indigox.Web.JsLib.Controls.Binding.ValueBinding",
        "Indigox.Web.JsLib.Controls.Binding.PropertyBinding",
        "Indigox.Web.JsLib.Controls.Plugins.Plugin",
        "Indigox.Web.JsLib.Controls.Plugins.PluginFactory",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Component,
        List,
        DelayedTask,
        Deferred,
        StringUtil,
        EventsSupport,
        ListenersSupport,
        ListenersFactory,
        UIEngine,
        Binding,
        ValueBinding,
        PropertyBinding,
        Plugin,
        PluginFactory
) {

    var EVENT_LOAD = "load",
        EVENT_LOADING = "loading",
        EVENT_LOADED = "loaded",
        EVENT_UNLOAD = "unload",
        EVENT_VALUE_CHANGED = "valueChanged";

    var LISTENER_INIT = "Init",
        LISTENER_LOAD = "Load",
        LISTENER_LOADING = "Loading",
        LISTENER_LOADED = "Loaded",
        LISTENER_UNLOAD = "Unload",
        LISTENER_PROPERTY_CHANGING = "PropertyChanging",
        LISTENER_PROPERTY_CHANGED = "PropertyChanged";

    var STATE_CREATED = 0,
        STATE_INITED = 1,
        STATE_PRELOAD = 2,
        STATE_LOADING = 3,
        STATE_LOADED = 4,
        STATE_UNLOADED = 5;

    var indent = "                                                                                   ";

    var base = Component.prototype;

    /** @id Indigox.Web.JsLib.Controls */
    var Control =
        Namespace("Indigox.Web.JsLib.Controls")
        .Class("Control")
        .Extend(base)
        .Constructor(
            function (name) {
                if (arguments.length > 1 || isObject(arguments[0])) {
                    throw new Error("Constructor can not accept Object as argument! if you want to configure the control, please use the configur method.");
                }

                base.constructor.call(this);

                this.initListeners();
                this.initEvents();

                this.state = STATE_CREATED;
                this.stateText = "created";
                this.parent = null;
                this.defaultName = Type.forInstance(this).getAlias();
                this.id = name || this.defaultName;
                this.name = name || this.defaultName;
                this.visible = true;
                this.enable = true;
                this.height = null;
                this.width = null;
                this.readonly = false;
                this.value = null;
                this.tip = null;
                this.plugins = new List();
                this.validateRules = new List();
                this.binding = null;
            }
        )
        .Members({
            registerEvents: function () {
                this.events.registerEvents(
                    EVENT_LOAD,
                    EVENT_LOADING,
                    EVENT_LOADED,
                    EVENT_UNLOAD,
                    EVENT_VALUE_CHANGED
                );
            },

            registerListeners: function () {
                this.listeners.registerListeners(
                    LISTENER_INIT,
                    LISTENER_LOAD,
                    LISTENER_LOADING,
                    LISTENER_LOADED,
                    LISTENER_UNLOAD,
                    LISTENER_PROPERTY_CHANGING,
                    LISTENER_PROPERTY_CHANGED
                );
            },

            /** @id Indigox.Web.JsLib.Controls.Component.prototype.attach */
            attach: function (scope, handlers) {
                if (this.events) {
                    this.events.attachEvent.apply(this.events, arguments);
                }
            },

            /** @id Indigox.Web.JsLib.Controls.Component.prototype.detach */
            detach: function (handlers) {
                if (this.events) {
                    this.events.detachEvent.apply(this.events, arguments);
                }
            },

            on: function (event, handler) {
                Array.prototype.unshift.call(arguments, this);
                this.attach.apply(this, arguments);
                return this;
            },

            un: function (event, handler) {
                this.detach.apply(this, arguments);
                return this;
            },

            fireEvent: function (event, args) {
                if (this.events) {
                    this.events.fire(event, args);
                }
            },

            addListener: function (listener, handlers) {
                if (this.listeners && listener != null) {
                    this.listeners.addListener(listener, handlers);
                }
            },

            removeListener: function (listener) {
                if (this.listeners && listener != null) {
                    this.listeners.removeListener(listener);
                }
            },

            fireListener: function (method, args) {
                if (this.listeners) {
                    this.listeners.fire(method, args);
                }
            },

            setParent: function (parent) {
                this.parent = parent;
            },

            getParent: function () {
                return this.parent;
            },

            getID: function () {
                return this.id;
            },

            setID: function (value) {
                if (!value) {
                    return;
                }
                if (value == this.id) {
                    return;
                }
                var oldValue = this.id;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["id", value, oldValue]);
                this.id = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["id", value, oldValue]);
            },

            setName: function (value) {
                if (isNullOrUndefined(value)) {
                    return;
                }
                if (StringUtil.isNullOrEmpty(value)) {
                    return;
                }
                if (this.name !== this.defaultName) {
                    return;
                }
                var oldValue = this.name;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["name", value, oldValue]);
                var newID = this.id.replace(new RegExp("(\\.|^)((" + oldValue + ")($|\\:\\d+$))"), "$1" + value + "$4");
                this.setID(newID);
                this.name = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["name", value, oldValue]);
            },

            getName: function () {
                return this.name;
            },

            setState: function (value) {
                this.state = value;

                switch (value) {
                    case STATE_CREATED:
                        this.stateText = "created";
                        break;
                    case STATE_INITED:
                        this.stateText = "inited";
                        break;
                    case STATE_PRELOAD:
                        this.stateText = "preload";
                        break;
                    case STATE_LOADING:
                        this.stateText = "loading";
                        break;
                    case STATE_LOADED:
                        this.stateText = "loaded";
                        break;
                    case STATE_UNLOADED:
                        this.stateText = "unloaded";
                        break;
                    default:
                        this.stateText = "unkown";
                        break;
                }
            },

            getState: function () {
                return this.state;
            },

            setVisible: function (value) {
                if (isNullOrUndefined(value)) {
                    return;
                }
                if (this.visible === value) {
                    return;
                }
                var oldValue = this.visible;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["visible", value, oldValue]);
                this.visible = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["visible", value, oldValue]);
            },

            getVisible: function () {
                return this.visible;
            },

            setEnable: function (value) {
                if (isNullOrUndefined(value)) {
                    return;
                }
                if (this.enable === value) {
                    return;
                }
                var oldValue = this.enable;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["enable", value, oldValue]);
                this.enable = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["enable", value, oldValue]);
            },

            getEnable: function () {
                return this.enable;
            },

            setReadonly: function (value) {
                if (isNullOrUndefined(value)) {
                    return;
                }
                if (this.readonly === value) {
                    return;
                }
                var oldValue = this.readonly;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["readonly", value, oldValue]);
                this.readonly = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["readonly", value, oldValue]);
            },

            getReadonly: function () {
                return this.readonly;
            },

            setHeight: function (value) {
                if (isNullOrUndefined(value)) {
                    return;
                }
                if (this.height === value) {
                    return;
                }
                var oldValue = this.height;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["height", value, oldValue]);
                this.height = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["height", value, oldValue]);
            },

            getHeight: function () {
                return this.height;
            },

            setWidth: function (value) {
                if (isNullOrUndefined(value)) {
                    return;
                }
                if (this.width === value) {
                    return;
                }
                var oldValue = this.width;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["width", value, oldValue]);
                this.width = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["width", value, oldValue]);
            },

            getWidth: function () {
                return this.width;
            },

            setValue: function (value) {
                if (this.value === value) {
                    return;
                }
                var oldValue = this.value;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["value", value, oldValue]);
                this.value = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["value", value, oldValue]);
                this.fireEvent(EVENT_VALUE_CHANGED, [this.value]);
            },

            getValue: function () {
                return this.value;
            },

            setTip: function (value) {
                if (isNullOrUndefined(value)) {
                    return;
                }
                if (this.tip === value) {
                    return;
                }
                this.tip = value;
                this.tip.setControl(this);
            },

            getTip: function () {
                return this.tip;
            },

            getPlugins: function () {
                return this.plugins.toArray();
            },

            setPlugins: function (plugins) {
                plugins = isArray(plugins) ? plugins : [plugins];

                this.removeAllPlugins();

                for (var i = 0, length = plugins.length; i < length; i++) {
                    var plugin = plugins[i];
                    if (plugin instanceof Plugin) {
                        this.addPlugin(plugin);
                    }
                    else {
                        var config = plugin;
                        if (isNullOrUndefined(plugin.name)) {
                            throw new Error("Can not add Plugin without a name!");
                        }
                        if (!isNullOrUndefined(plugin.config)) {
                            config = plugin.config;
                        }
                        this.addPlugin(PluginFactory.getInstance().createPlugin(plugin.name, config));
                    }
                }
            },

            addPlugin: function (plugin) {
                this.insertPlugin(this.plugins.size(), plugin);
            },

            insertPlugin: function (index, plugin) {
                var plugins = this.getPlugins();
                if (index > plugins.length) {
                    throw new Error("out of range");
                }
                if (!this.plugins.contains(plugin)) {
                    this.plugins.insert(index, plugin);
                }
                plugin.setControl(this);
            },

            removePlugin: function (plugin) {
                this.plugins.remove(plugin);
                plugin.setControl(null);
            },

            removeAllPlugins: function () {
                for (var i = this.plugins.size(); i > 0; i--) {
                    this.removeAllPlugins(this.plugins.get(i));
                }
            },

            getValidateRules: function () {
                return this.validateRules.toArray();
            },

            //rule is like this
            //["min", 3, "descr"],
            addValidateRule: function (rule) {
                this.validateRules.add(rule);
            },

            removeValidateRule: function (rule) {
                this.validateRules.remove(rule);
            },

            setValidateRules: function (validateRules) {
                if (isNullOrUndefined(validateRules)) {
                    return;
                }

                this.validateRules.clear();
                this.validateRules.addRange(validateRules);
            },

            isEditable: function () {
                return false;
            },

            isInited: function () {
                return (this.getState() >= STATE_INITED) && (this.getState() < STATE_UNLOADED);
            },

            setInited: function () {
                this.setState(STATE_INITED);
                UIEngine.add(this);
            },

            setLoading: function () {
                this.setState(STATE_LOADING);
                //this.loading = true;

                //debug.log(indent.substring(0, this.id.split(".").length * 2) + this.id + " loading" + "...");
                this.fireListener(LISTENER_LOADING);
                this.fireEvent(EVENT_LOADING);
            },

            setLoaded: function () {
                this.setState(STATE_LOADED);
                //this.loaded = true;

                //debug.log(indent.substring(0, this.id.split(".").length * 2) + this.id + " loaded.");
                this.fireListener(LISTENER_LOADED);
                this.fireEvent(EVENT_LOADED);
                this.fireEvent(EVENT_LOAD);
            },

            isLoading: function () {
                return this.getState() === STATE_LOADING;
                //return this.loading;
            },

            isLoaded: function () {
                return this.getState() === STATE_LOADED;
                //return this.loaded;
            },

            init: function () {
                if (this.isInited()) {
                    debug.warn(this.id + "(" + this.defaultName + ") init more than twice. current state is " + this.stateText);
                    //debug.error(this.id + "(" + this.defaultName + ") init more than twice. current state is " + this.stateText);
                    //return;
                }
                this.setInited();
                this.fireListener(LISTENER_INIT);
            },

            initListeners: function () {
                this.listeners = new ListenersSupport(this);
                this.registerListeners();

                var listeners = ListenersFactory.createListeners(this),
                    length = listeners.length,
                    listener;
                for (var i = 0; i < length; i++) {
                    listener = listeners[i];
                    this.listeners.addListener(listener);
                }
            },

            initEvents: function () {
                this.events = new EventsSupport(this);
                this.registerEvents();
            },

            load: function () {
                //debug.log(this.id + " load...");
                this.preLoad();
                this.setLoading();

                // debug code
                this._checkLoadTimeout();

                return Deferred.when(this.doLoad())
                    .done({ handler: this.setLoaded, scope: this });
            },

            //@private
            //@debugger
            _checkLoadTimeout: function () {
                //if (this._checkLoadTimeoutTask) {
                //    this._checkLoadTimeoutTask.cancel();
                //}
                //this._checkLoadTimeoutTask = new DelayedTask(function () {
                //    if (this.getState() < STATE_LOADED) {
                //        debug.warn(this.id + "\'s load is timeout.");
                //    }
                //    this._checkLoadTimeoutTask = null;
                //}, this, []);
                //this._checkLoadTimeoutTask.delay(10000);
            },

            preLoad: function () {
                if (this.getState() === STATE_PRELOAD) {
                    return;
                }
                //debug.log(this.id + " preLoad...");
                this.setState(STATE_PRELOAD);
            },

            doLoad: function () {
                //debug.log(this.id + " doLoad...");
            },

            unload: function () {
                if (!(this.getState() >= STATE_INITED && this.getState() < STATE_UNLOADED)) {
                    return;
                }

                UIEngine.remove(this);

                this.setState(STATE_UNLOADED);

                this.fireEvent(EVENT_UNLOAD);
                this.fireListener(LISTENER_UNLOAD);

                //this.listeners.clearListeners();
                //this.events.clearEvents();
            },

            showtip: function (x, y) {
                //return;
                var tip = this.getTip();
                if (tip) {
                    tip.show(x, y);
                }
            },

            hidetip: function (source) {
                //return;
                var tip = this.getTip();
                if (tip) {
                    tip.hide();
                }
            },

            getBinding: function () {
                if (!this.binding) {
                    this.binding = new ValueBinding();
                }
                return this.binding;
            },

            setBinding: function (value) {
                if (value instanceof Binding) {
                    this.binding = value;
                }
                else {
                    this.binding = new PropertyBinding();
                    this.binding.configure(value);
                }
            }
        })
    .$();

});