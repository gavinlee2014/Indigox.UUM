﻿define("Indigox.Web.JsLib.Controls.Validation.Rules.MaxLengthRule",
    [
        "Indigox.Web.JsLib.Controls.Validation.Rules.Rule",
        "Indigox.Web.JsLib.Utils.StringUtil",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Rule,
        StringUtil
    ) {

    var base = Rule.prototype;

    var MaxLengthRule =
        Namespace("Indigox.Web.JsLib.Controls.Validation.Rules")
        .Class("MaxLengthRule")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
            }
        )
        .Members({
            isMatch: function (value) {
                if (StringUtil.isNullOrEmpty(value)) {
                    return true;
                }
                var maxLength = this.getCondition();
                if (value.length > maxLength) {
                    return false;
                }
                else {
                    return true;
                }
            }
        })
    .$();
});