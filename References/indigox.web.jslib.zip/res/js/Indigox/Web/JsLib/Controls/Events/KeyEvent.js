﻿define("Indigox.Web.JsLib.Controls.Events.KeyEvent",
    [
        "Indigox.Web.JsLib.Controls.Events.InputEvent",
        "Indigox.Web.JsLib.Core"
    ],
function (
        InputEvent
    ) {
    var base = InputEvent.prototype;

    var KeyEvent =
        Namespace('Indigox.Web.JsLib.Controls.Events')
        .Class('KeyEvent')
        .Extend(base)
        .Constructor(
            function (e) {
                base.constructor.apply(this, arguments);
                this.key = e.key;
            }
        )
        .Members({
            getKey: function () {
                return this.key;
            }
        })
    .$();
});