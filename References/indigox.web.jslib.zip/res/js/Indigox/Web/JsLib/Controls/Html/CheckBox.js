﻿define("Indigox.Web.JsLib.Controls.Html.CheckBox",
    [
        "Indigox.Web.JsLib.Controls.Html.FieldControl",
        "Indigox.Web.JsLib.Core"
    ],
function (
        FieldControl
) {
    var EVENT_CLICKED = "clicked",
        EVENT_CHECK_CHANGED = "checkChanged",
        EVENT_TEXT_CHANGED = "textChanged";

    var LISTENER_PROPERTY_CHANGING = "PropertyChanging",
        LISTENER_PROPERTY_CHANGED = "PropertyChanged",
        LISTENER_CHECK_CHANGED = "CheckChanged";

    function convertToBoolean(value) {
        if (value === "1" ||
            value === 1 ||
            value === "true" ||
            value === true) {
            return true;
        }
        else if (value === "0" ||
            value === 0 ||
            value === "false" ||
            value === false) {
            return false;
        }
        else {
            return !!value;
        }
    }

    var base = FieldControl.prototype;

    var CheckBox =
        Namespace("Indigox.Web.JsLib.Controls.Html")
        .Class("CheckBox")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.checked = false;
                this.text = "";
                this.rawValue = "";
            }
        )
        .Members({
            registerEvents: function () {
                base.registerEvents.call(this);
                this.events.registerEvents(
                    EVENT_CLICKED,
                    EVENT_CHECK_CHANGED,
                    EVENT_TEXT_CHANGED
                );
            },

            registerListeners: function () {
                base.registerListeners.call(this);
                this.listeners.registerListeners(
                    LISTENER_CHECK_CHANGED
                );
            },

            setReadonly: function (readonly) {
                base.setReadonly.apply(this, arguments);
                this.setEnable(!readonly);
            },

            setRawValue: function (value) {
                if (isNullOrUndefined(value)) {
                    return;
                }
                this.rawValue = value;
            },

            getRawValue: function () {
                return this.rawValue;
            },

            setValue: function (value) {
                value = convertToBoolean(value);
                var oldValue = this.getChecked();
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["value", value, oldValue]);
                this.setChecked(value);
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["value", value, oldValue]);
            },

            getValue: function () {
                return this.getChecked();
            },

            getChecked: function () {
                return this.checked;
            },

            setChecked: function (value) {
                if (isNullOrUndefined(value) || value === this.checked) {
                    return;
                }

                var oldValue = this.checked;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["checked", value, oldValue]);
                this.checked = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["checked", value, oldValue]);
                this.fireListener(LISTENER_CHECK_CHANGED, [this.checked]);
                this.fireEvent(EVENT_CHECK_CHANGED, [this.checked]);
            },

            toggleChecked: function () {
                this.setChecked(!this.getChecked());
            },

            getText: function () {
                return this.text;
            },

            setText: function (value) {
                if (isNullOrUndefined(value)) {
                    return;
                }
                var oldValue = this.text;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["text", value, oldValue]);
                this.text = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["text", value, oldValue]);
                this.fireEvent(EVENT_TEXT_CHANGED, [this.text]);
            },

            click: function () {
                if (this.enable) {
                    this.toggleChecked();
                    this.fireEvent(EVENT_CLICKED);
                }
            }
        })
    .$();
});