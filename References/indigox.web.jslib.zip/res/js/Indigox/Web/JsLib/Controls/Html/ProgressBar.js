﻿define("Indigox.Web.JsLib.Controls.Html.ProgressBar",
    [
        "Indigox.Web.JsLib.Controls.Html.FieldControl",
        "Indigox.Web.JsLib.Controls.Html.Label",
        "Indigox.Web.JsLib.Core"
    ],
function (
        FieldControl,
        Label
    ) {

    var base = FieldControl.prototype;

    var LISTENER_PROPERTY_CHANGING = "PropertyChanging",
        LISTENER_PROPERTY_CHANGED = "PropertyChanged";


    var ProgressBar =
        Namespace("Indigox.Web.JsLib.Controls.Html")
        .Class("ProgressBar")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.maxValue = 100;
                this.value = 0;
                this.text = "";
            }
        )
        .Members({
            getMaxValue: function () {
                return this.maxValue;
            },
            setMaxValue: function (value) {
                this.maxValue = value;
            },

            getText: function () {
                return this.text;
            },
            setText: function (value) {
                var oldValue = this.text;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["text", value, oldValue]);
                this.text = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["text", value, oldValue]);
            }
        })
    .$();
});