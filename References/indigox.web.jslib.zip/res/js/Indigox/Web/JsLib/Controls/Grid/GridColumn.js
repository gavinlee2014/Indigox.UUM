﻿define("Indigox.Web.JsLib.Controls.Grid.GridColumn",
    [
        "Indigox.Web.JsLib.Controls.Component",
        "Indigox.Web.JsLib.Utils.Util",
        "Indigox.Web.JsLib.Collection.List",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Component,
        Util,
        List
) {
    var base = Component.prototype;

    var GridColumn =
        Namespace("Indigox.Web.JsLib.Controls.Grid")
        .Class("GridColumn")
        .Extend(base)
        .Constructor(function () {
            this.caption = "";
            this.hidden = false;
            this.field = "";
            this.fieldType = "string";
            this.controlType = "lable";
            this.defaultValue = "";
            this.width = null;
            this.binding = null;
            this.validateRules = new List();
        })
        .Members({
            getBinding: function () {
                return this.binding;
            },
            setBinding: function (value) {
                this.binding = value;
            },

            getCaption: function () {
                return this.caption;
            },

            setCaption: function (value) {
                this.caption = value;
            },

            getHidden: function () {
                return this.hidden;
            },

            setHidden: function (value) {
                this.hidden = value;
            },

            getField: function () {
                return this.field;
            },

            setField: function (value) {
                this.field = value;
            },

            getFiledType: function () {
                return this.fieldType;
            },

            setFiledType: function (value) {
                this.fieldType = value;
            },

            getWidth: function () {
                return this.width;
            },

            setWidth: function (value) {
                this.width = value;
            },

            getDefaultValue: function () {
                return this.defaultValue;
            },

            setDefaultValue: function (value) {
                this.defaultValue = value;
            },

            getValidateRules: function () {
                return this.validateRules.toArray();
            },

            setValidateRules: function (validateRules) {
                if (isNullOrUndefined(validateRules)) {
                    return;
                }

                this.validateRules.clear();
                this.validateRules.addRange(validateRules);
            }
            /*
            getControlType: function () {
            return this.controlType;
            }*/
        })
    .$();
});