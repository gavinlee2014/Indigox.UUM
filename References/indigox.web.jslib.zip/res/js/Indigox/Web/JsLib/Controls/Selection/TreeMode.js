﻿define("Indigox.Web.JsLib.Controls.Selection.TreeMode",
    [
        "Indigox.Web.JsLib.Controls.Selection.NodeMode",
        "Indigox.Web.JsLib.Controls.Html.TreeNode",
        "Indigox.Web.JsLib.Collection.List",
        "Indigox.Web.JsLib.Core"
    ],
function (
        NodeMode,
        TreeNode,
        List
) {

    var base = NodeMode.prototype;

    var TreeMode =
        Namespace("Indigox.Web.JsLib.Controls.Selection")
        .Class("TreeMode")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
            }
        )
        .Members({
            onChildNodeAdded: function (source, node) {
                if (this.isSelected(node.getParent().getValue()) || node.getSelected()) {
                    this.setControlSelected(node.getValue());
                }

                if (this.selected.indexOf(node.getValue()) != -1) {
                    this.control.selectNode(node.getValue());
                }
            },

            setControlSelected: function (data, node, isSelected) {
                if (isSelected) {
                    this.control.selectNode(data);
                } else {
                    this.control.deselectNode(data);
                }

                var node = this.control.findNodeByValue(data);
                if (!isNullOrUndefined(node)) {
                    this.trySelectChildNode(node, isSelected);
                    this.trySelectParentNode(node, isSelected);
                }
            },

            trySelectParentNode: function (node, isSelected) {
                var parent = node.getParent();
                if (!(parent instanceof TreeNode)) {
                    return;
                }

                var parentValue = parent.getValue();

                if (isSelected) {
                    if (!this.isSelected(parentValue) && this.isAllChildrenSelected(parent)) {
                        this.control.selectNode(parentValue);
                    }
                }
                else {
                    if (this.isSelected(parentValue)) {
                        this.control.deselectNode(parentValue);
                    }
                }
            },

            trySelectChildNode: function (node, selected) {
                if (node.getChildNodes() === 0) {
                    return;
                }

                if (this.isAllChildrenSelected(node)) {
                    if (!selected) {
                        this.selectChildNode(node, false);
                    }
                }
                else {
                    if (selected) {
                        this.selectChildNode(node, true);
                    }
                }
            },

            selectChildNode: function (node, selected) {
                var i = null,
                    length = null,
                    childNodes = node.getChildNodes();

                for (i = 0, length = childNodes.length; i < length; i++) {
                    var child = childNodes[i];
                    var childValue = child.getValue();
                    if (selected === true && !this.isSelected(childValue)) {
                        child.setSelected(selected);
                    }
                    else if (selected === false && this.isSelected(childValue)) {
                        child.setSelected(selected);
                    }
                }
            },

            isAllChildrenSelected: function (parent) {
                var allChildrenSelected = true;
                var i = null,
                    length = null,
                    childNodes = parent.getChildNodes();
                for (i = 0, length = childNodes.length; i < length; i++) {
                    if (!this.isSelected(childNodes[i].getValue())) {
                        allChildrenSelected = false;
                        break;
                    }
                }
                return allChildrenSelected;
            }
        })
    .$();

});