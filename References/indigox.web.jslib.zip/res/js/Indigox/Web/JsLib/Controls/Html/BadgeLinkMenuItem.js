﻿define("Indigox.Web.JsLib.Controls.Html.BadgeLinkMenuItem",
    [
        "Indigox.Web.JsLib.Controls.Html.LinkMenuItem",
        "Indigox.Web.JsLib.Core"
    ],
function (
        LinkMenuItem
) {
    var base = LinkMenuItem.prototype;

    var LISTENER_PROPERTY_CHANGING = "PropertyChanging",
        LISTENER_PROPERTY_CHANGED = "PropertyChanged";

    var BadgeLinkMenuItem =
        Namespace("Indigox.Web.JsLib.Controls.Html")
        .Class("BadgeLinkMenuItem")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.badge = null;
            }
        )
        .Members({
            getBadge: function () { return this.badge; },
            setBadge: function (value) {
                if (isNullOrUndefined(value)) {
                    return;
                }
                var oldValue = this.badge;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["badge", value, oldValue]);
                this.badge = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["badge", value, oldValue]);
            }
        })
    .$();
});