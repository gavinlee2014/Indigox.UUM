﻿define("Indigox.Web.JsLib.Controls.Plugins.TimeSpanPlugin",
    [
        "Indigox.Web.JsLib.Controls.Plugins.Plugin",
        "Indigox.Web.JsLib.Utils.Util",
        "Indigox.Web.JsLib.Utils.DateTimeUtil",
        "Indigox.Web.JsLib.Utils.ControlUtil",
        "Indigox.Web.JsLib.Controls.Grid.GridCell",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Plugin,
        Util,
        DateTimeUtil,
        ControlUtil,
        GridCell
) {
    var base = Plugin.prototype;

    var TimeSpanPlugin =
        Namespace("Indigox.Web.JsLib.Controls.Plugins")
        .Class("TimeSpanPlugin")
        .Extend(base)
        .Constructor(
            function (option) {
                base.constructor.apply(this, arguments);

                //@private
                this.leftDateTimeControl = null;
                this.rightDateTimeControl = null;

                option = Util.copyExist({
                    resultType: "day",            // option: day, hour
                    excludeWeekEnd: false,        // boolean
                    leftDateTimeControlName: "",  // string
                    rightDateTimeControlName: ""  // string
                }, option);
                this.configure(option);
            }
        )
        .Members({
            getResultType: function () {
                return this.resultType;
            },
            setResultType: function (value) {
                this.resultType = value;
            },

            getExcludeWeekEnd: function () {
                return this.excludeWeekEnd;
            },
            setExcludeWeekEnd: function (value) {
                this.excludeWeekEnd = value;
            },

            getLeftDateTimeControlName: function () {
                return this.leftDateTimeControlName;
            },
            setLeftDateTimeControlName: function (value) {
                this.leftDateTimeControlName = value;
            },

            getRightDateTimeControlName: function () {
                return this.rightDateTimeControlName;
            },
            setRightDateTimeControlName: function (value) {
                this.rightDateTimeControlName = value;
            },

            onLoaded: function (source) {
                var leftControls = ControlUtil.findControlFromNearestParent(source, this.getLeftDateTimeControlName());
                if (leftControls != null) {
                    this.leftDateTimeControl = leftControls[0];
                    this.leftDateTimeControl.addListener(this, {
                        onPropertyChanged: this.onRelativeControlPropertyChanged
                    });
                }
                else {
                    //ignore
                }

                var rightControls = ControlUtil.findControlFromNearestParent(source, this.getRightDateTimeControlName());
                if (rightControls != null) {
                    this.rightDateTimeControl = rightControls[0];
                    this.rightDateTimeControl.addListener(this, {
                        onPropertyChanged: this.onRelativeControlPropertyChanged
                    });
                }
                else {
                    //ignore
                }
            },

            onRelativeControlPropertyChanged: function (source, property, value, oldValue) {
                if (property == "value") {
                    var control = this.getControl();

                    if (this.canEvaluateTimeSpan()) {
                        control.setValue(this.evaluateTimeSpan());
                    }
                    else {
                        //ignore
                    }
                }
            },

            canEvaluateTimeSpan: function () {
                return !(
                    this.leftDateTimeControl == null ||
                    this.leftDateTimeControl.getValue() === "" ||
                    this.rightDateTimeControl == null ||
                    this.rightDateTimeControl.getValue() === ""
                );
            },

            evaluateTimeSpan: function () {
                var value = 0;

                var leftDateTime = DateTimeUtil.parse(this.leftDateTimeControl.getValue());
                var rightDateTime = DateTimeUtil.parse(this.rightDateTimeControl.getValue());

                var evaluateHalfDay = false;
                if (this.leftDateTimeControl instanceof GridCell) {
                    evaluateHalfDay = this.leftDateTimeControl.editingControl.getEditHMS();
                }
                else {
                    evaluateHalfDay = this.leftDateTimeControl.getEditHMS();
                }

                switch (this.getResultType()) {
                    case "workday":
                        value = evaluateWorkDays(rightDateTime, leftDateTime, evaluateHalfDay);
                        break;
                    case "day":
                        value = evaluateDays(rightDateTime, leftDateTime);
                        break;
                    case "hour":
                        value = evaluateHours(rightDateTime, leftDateTime);
                        break;
                    default:
                        throw new Error("Bad resultType, option values: day, hour.");
                }
                return value;
            }
        })
    .$();

    var millsecondsPerDay = 86400000; /* 24*60*60*1000 */
    var millsecondsPerHour = 3600000; /* 60*60*1000 */
    var minitePerDay = 1440; /* 24*60 */

    function evaluateWorkDays(begin, end, halfDay) {
        var D1 = Math.floor(begin.getTime() / millsecondsPerDay - begin.getTimezoneOffset() / minitePerDay);
        var D2 = Math.floor(end.getTime() / millsecondsPerDay - end.getTimezoneOffset() / minitePerDay);
        var d1 = begin.getDay();
        var d2 = end.getDay();

        // 周六周日休假
        switch (d1) {
            case 6: D1 += 2; d1 = 1; break;
            case 0: D1 += 1; d1 = 1; break;
        }
        switch (d2) {
            case 6: D2 -= 1; break;
            case 0: D2 -= 2; break;
        }
        var daysFromMonday = D2 - D1 + d1;
        var workDays = daysFromMonday - Math.floor(daysFromMonday / 7) * 2 - d1 + 1;

        if (halfDay) {
            // 下午2点开始计算工作时间
            var h1 = (begin.getHours() < 14) ? 0 : 1;
            var h2 = (end.getHours() < 14) ? 0 : 1;
            workDays += (h2 - h1 - 1) / 2;
        }

        return workDays;
    }

    function evaluateDays(begin, end) {
        var D1 = Math.floor(begin.getTime() / millsecondsPerDay - begin.getTimezoneOffset() / minitePerDay);
        var D2 = Math.floor(end.getTime() / millsecondsPerDay - end.getTimezoneOffset() / minitePerDay);
        return D2 - D1 + 1;
    }

    function evaluateHours(begin, end) {
        return Math.round((end.getTime() - begin.getTime()) / millsecondsPerHour * 10) / 10;
    }
});