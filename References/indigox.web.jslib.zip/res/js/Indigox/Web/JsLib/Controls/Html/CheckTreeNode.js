﻿define("Indigox.Web.JsLib.Controls.Html.CheckTreeNode",
    [
        "Indigox.Web.JsLib.Controls.Html.TreeNode",
        "Indigox.Web.JsLib.Core"
    ],
function (
        TreeNode
) {
    var base = TreeNode.prototype;

    var EVENT_CLICKED = "clicked";

    var LISTENER_PROPERTY_CHANGING = "PropertyChanging",
        LISTENER_PROPERTY_CHANGED = "PropertyChanged";

    var CheckTreeNode =
        Namespace("Indigox.Web.JsLib.Controls.Html")
        .Class("CheckTreeNode")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.checked = false;
            }
        )
        .Members({
            registerEvents: function () {
                base.registerEvents.call(this);
                this.events.registerEvents(
                    EVENT_CLICKED
                );
            },

            getText: function () { return this.text; },
            setText: function (value) {
                if (isNullOrUndefined(value)) {
                    return;
                }
                var oldValue = this.text;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["text", value, oldValue]);
                this.text = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["text", value, oldValue]);
            },

            getChecked: function () {
                return this.checked;
            },

            setChecked: function (value) {
                if (isNullOrUndefined(value) || value === this.checked) {
                    return;
                }

                var oldValue = this.checked;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["checked", value, oldValue]);
                this.checked = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["checked", value, oldValue]);

                //this.setSelected(value);
            },

            setSelected: function (value) {
                if (isNullOrUndefined(value) || value === this.selected) {
                    return;
                }

                this.setChecked(value);
                base.setSelected.call(this, value);
                var a = 1;

            },

            toggleChecked: function () {
                this.setSelected(!this.getChecked());
            },

            click: function () {
                if (this.enable) {
                    this.toggleChecked();
                    this.fireEvent(EVENT_CLICKED);
                }
            }
        })
    .$();
});