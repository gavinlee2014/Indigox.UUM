﻿define("Indigox.Web.JsLib.Controls.Html.FieldControl",
    [
        "Indigox.Web.JsLib.Utils.Util",
        "Indigox.Web.JsLib.Controls.Control",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Util,
        Control
) {
    var EVENT_NAME_CHANGED = "nameChanged";

    var LISTENER_PROPERTY_CHANGING = "PropertyChanging",
        LISTENER_PROPERTY_CHANGED = "PropertyChanged",
        LISTENER_NAME_CHANGED = "NameChanged";

    var base = Control.prototype;

    /** @id Indigox.Web.JsLib.Controls */
    var FieldControl =
        Namespace("Indigox.Web.JsLib.Controls.Html")//
        .Class("FieldControl")
        .Extend(base)//
        .Constructor(
    /** @id Indigox.Web.JsLib.Controls.Html.FormControl */
            function (config) {
                base.constructor.apply(this, arguments);
            }
        )
        .Members({
            registerEvents: function () {
                base.registerEvents.call(this);
                this.events.registerEvents(
                    EVENT_NAME_CHANGED
                );
            },
            registerListeners: function () {
                base.registerListeners.call(this);
                this.listeners.registerListeners(
                    LISTENER_NAME_CHANGED
                );
            },
            isEditable: function () {
                return true;
            }
        }).$();
});