﻿define("Indigox.Web.JsLib.Controls.Grid.GridCell",
    [
        "Indigox.Web.JsLib.Controls.Control",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Control
) {
    var base = Control.prototype;

    var GridCell =
        Namespace("Indigox.Web.JsLib.Controls.Grid")
        .Class("GridCell")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
            }
        )
        .Members({
            isEditable: function () {
                return false;
            },

            getColumn: function () {
                return this.column;
            },

            setColumn: function (value) {
                if (this.column == value) {
                    return;
                }
                this.column = value;
                if (this.column.getDefaultValue()) {
                    this.setValue(this.column.getDefaultValue());
                }
                if (this.column.getWidth()) {
                    this.setWidth(this.column.getWidth());
                }
                if (this.column.getValidateRules().length !== 0) {
                    this.setValidateRules(this.column.getValidateRules());
                }
                if (this.column.getBinding()) {
                    this.setBinding(this.column.getBinding());
                }
            }
        })
    .$();
});