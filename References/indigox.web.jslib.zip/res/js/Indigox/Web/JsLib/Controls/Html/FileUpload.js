﻿define("Indigox.Web.JsLib.Controls.Html.FileUpload",
    [
        "Indigox.Web.JsLib.Collection.List",
        "Indigox.Web.JsLib.Utils.Deferred",
        "Indigox.Web.JsLib.Utils.StringUtil",
        "Indigox.Web.JsLib.Online.OnlineViewer",
        "Indigox.Web.JsLib.Controls.Html.Button",
        "Indigox.Web.JsLib.Controls.Html.HyperLink",
        "Indigox.Web.JsLib.Controls.Html.ProgressBar",
        "Indigox.Web.JsLib.Controls.Container",
        "Indigox.Web.JsLib.Core"
    ],
function (
        List,
        Deferred,
        StringUtil,
        OnlineViewer,
        Button,
        HyperLink,
        ProgressBar,
        Container
) {
    var EVENT_STATE_CHANGED = "stateChanged",
        EVENT_UPLOAD_BEGIN = "uploadBegin",
        EVENT_UPLOAD_COMPLETED = "uploadCompleted",
        EVENT_UPLOAD_ERROR_COMPLETED = "uploadErrorCompleted",
        EVENT_CANCELED = "canceled";

    var LISTENER_STATE_CHANGED = "StateChanged",
        LISTENER_UPLOAD_BEGIN = "UploadBegin",
        LISTENER_UPLOAD_COMPLETED = "UploadCompleted",
        LISTENER_UPLOAD_ERROR_COMPLETED = "UploadErrorCompleted",
        LISTENER_CANCELED = "Canceled",
        LISTENER_PROPERTY_CHANGING = "PropertyChanging",
        LISTENER_PROPERTY_CHANGED = "PropertyChanged";

    var base = Container.prototype;

    var FileUpload =
        Namespace("Indigox.Web.JsLib.Controls.Html")
        .Class("FileUpload")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);

                //debug.log("fileupload...");
                this.text = "";
                this.href = "javascript:void(0)";
                this.uploadState = "inited"; // inited -> uploading -> completed|error|canceled
                this.readonly = true;
                this.progress = 0;
                this.progressBar = null;
                this.addDefaultChildren();
            }
        )
        .Members({
            init: function () {
                base.init.apply(this, arguments);

                var item = this.owner;
                var list = item.owner;

                this.addListener(list, {
                    onUploadBegin: list.onFileUploadBeginUpload
                });
            },

            initChildren: function () {
                if (this.getProgressBar()) {
                    this.getProgressBar().init();
                }
            },

            preLoadChildren: function () {
                if (this.getProgressBar()) {
                    this.getProgressBar().preLoad();
                }
            },

            loadChildren: function () {
                var promises = [];
                if (this.getProgressBar()) {
                    promises.push(this.getProgressBar().load());
                }
                return Deferred.when(promises);
            },

            unloadChildren: function () {
                if (this.getProgressBar()) {
                    this.getProgressBar().unload();
                }
            },

            //#region fields
            // property fields
            text: null,
            href: null,
            state: null,
            progress: null,
            progressBar: null,
            //#endregion

            //#region properties
            getText: function () {
                return this.text;
            },
            setText: function (value) {
                var oldValue = this.text;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["text", value, oldValue]);
                this.text = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["text", value, oldValue]);
            },

            getHref: function () {
                return this.href;
            },
            setHref: function (value) {
                var oldValue = this.href;

                // convert to online view url, if it is enabled.
                var onlineViewer = new OnlineViewer(value);
                if (onlineViewer.isSupportOnlineView()) {
                    value = onlineViewer.getOnlineViewUrl();
                }

                this.fireListener(LISTENER_PROPERTY_CHANGING, ["href", value, oldValue]);
                this.href = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["href", value, oldValue]);
            },

            getReadonly: function () {
                return this.readonly;
            },
            setReadonly: function (value) {
                var oldValue = this.readonly;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["readonly", value, oldValue]);
                this.readonly = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["readonly", value, oldValue]);
            },

            getValue: function () {
                return this.value;
            },
            setValue: function (value) {
                //debug.log("FileUpload.setValue");
                var oldValue = this.value;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["value", value, oldValue]);
                this.value = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["value", value, oldValue]);

                this.setText(value.fileName);
                this.setHref(value.fileUrl);
            },

            getProgress: function () {
                return this.progress;
            },
            setProgress: function (value) {
                var oldValue = this.progress;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["progress", value, oldValue]);
                this.progress = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["progress", value, oldValue]);

                this.progressBar.setText("" + value + "%");
                this.progressBar.setValue(value);
            },

            getProgressBar: function () {
                return this.progressBar;
            },

            setProgressBar: function (value) {
                var oldValue = this.progressBar;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["progressBar", value, oldValue]);

                this.progressBar = value;

                Deferred.when(this.catchUpLoadChild(value)).done({
                    handler: function () {
                        this.fireListener(LISTENER_PROPERTY_CHANGED, ["progressBar", value, oldValue]);
                    },
                    scope: this
                }).fail({
                    handler: function () {
                        debug.error([this.id, " set progressBar failed."].join(""));
                    },
                    scope: this
                });
            },

            getUploadState: function () {
                return this.uploadState;
            },
            setUploadState: function (value) {
                var oldValue = this.uploadState;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["uploadState", value, oldValue]);
                this.uploadState = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["uploadState", value, oldValue]);
            },

            //#endregion

            addDefaultChildren: function () {
                var progressBar = new ProgressBar("progressBar");
                progressBar.setText("");
                progressBar.setValue(0);
                this.setProgressBar(progressBar);
            },

            setAsCompleted: function () {
                //debug.log("FileUpload.setAsCompleted");
                this.complete();
            },

            // #region methods
            upload: function () {
                this.uploading = true;
                this.uniqueIdentifier = StringUtil.newGuid();
                this.setUploadState("uploading");
                this.fireListener(LISTENER_UPLOAD_BEGIN);
            },

            cancel: function () {
                this.uploading = false;
                this.setUploadState("canceled");
                this.fireListener(LISTENER_CANCELED);
            },

            complete: function () {
                this.uploading = false;
                this.setUploadState("completed");
                this.fireListener(LISTENER_UPLOAD_COMPLETED);
            },

            error: function (ex) {
                this.uploading = false;
                this.fireListener(LISTENER_UPLOAD_ERROR_COMPLETED);
                this.setUploadState("error");
                debug.error(ex);
                alert(ex);
            },

            isBusy: function () {
                return (this.uploading);
            },

            remove: function () {
                var item = this.owner;
                var list = item.owner;
                list.removeChild(item);
            },

            registerEvents: function () {
                base.registerEvents.call(this);
                this.events.registerEvents(
                    EVENT_STATE_CHANGED,
                    EVENT_UPLOAD_BEGIN,
                    EVENT_UPLOAD_COMPLETED,
                    EVENT_UPLOAD_ERROR_COMPLETED,
                    EVENT_CANCELED
                );
            },

            registerListeners: function () {
                base.registerListeners.call(this);
                this.listeners.registerListeners(
                    LISTENER_STATE_CHANGED,
                    LISTENER_UPLOAD_BEGIN,
                    LISTENER_UPLOAD_COMPLETED,
                    LISTENER_UPLOAD_ERROR_COMPLETED,
                    LISTENER_CANCELED
                );
            }
            //#endregion
        })
    .$();
});