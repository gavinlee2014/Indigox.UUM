﻿define("Indigox.Web.JsLib.Controls.Validation.Rules.MailAddressRule",
    [
        "Indigox.Web.JsLib.Controls.Validation.Rules.Rule",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Rule
    ) {

    var base = Rule.prototype;

    var MailAddressRule =
        Namespace("Indigox.Web.JsLib.Controls.Validation.Rules")
        .Class("MailAddressRule")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
            }
        )
        .Members({
            isMatch: function (value) {
                var reg = /^[\w-\.]+@[\w-\.]+(\.\w{2,3})$/g;
                return reg.test(value);
            }
        })
    .$();
});