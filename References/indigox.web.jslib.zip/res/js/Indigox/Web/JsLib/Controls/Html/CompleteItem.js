﻿define("Indigox.Web.JsLib.Controls.Html.CompleteItem",
    [
        "Indigox.Web.JsLib.Utils.Deferred",
        "Indigox.Web.JsLib.Controls.Html.ItemControl",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Deferred,
        ItemControl
) {
    var LISTENER_PROPERTY_CHANGING = "PropertyChanging",
        LISTENER_PROPERTY_CHANGED = "PropertyChanged";

    var base = ItemControl.prototype;

    var CompleteItem =
        Namespace("Indigox.Web.JsLib.Controls.Html")
        .Class("CompleteItem")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
            }
        )
        .Members({
            getText: function () { return this.text; },
            setText: function (value) {
                if (isNullOrUndefined(value)) {
                    return;
                }
                var oldValue = this.text;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["text", value, oldValue]);
                this.text = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["text", value, oldValue]);
            },

            remove: function () {
                this.getParent().removeCompleteItem(this);
            }
        })
    .$();
});