﻿define("Indigox.Web.JsLib.Controls.Grid.Toolbar",
    [
        "Indigox.Web.JsLib.Controls.Container",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Container
) {
    var base = Container.prototype;

    var Toolbar =
        Namespace("Indigox.Web.JsLib.Controls.Grid")
        .Class("Toolbar")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
            }
        )
        .Members({
            addRow: function () {
                var parent = this.getParent();
                parent.getController().insertRecord(parent.getRows().length);

                var rows = parent.getRows();
                var length = rows.length;
                rows[length - 1].click();
            },

            setParent: function (parent) {
                base.setParent.apply(this, arguments);
                if (this.getParent()) {
                    if (this.getParent().isInited()) {
                        this.init();
                    }
                    if (this.getParent().isLoaded()) {
                        this.load();
                    }
                }
            }
        })
    .$();
});