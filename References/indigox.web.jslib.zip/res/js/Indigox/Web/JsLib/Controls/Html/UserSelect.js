﻿define("Indigox.Web.JsLib.Controls.Html.UserSelect",
    [
        "Indigox.Web.JsLib.Controls.Html.UserNode",
        "Indigox.Web.JsLib.Controls.Html.Button",
        "Indigox.Web.JsLib.Controls.Container",
        "Indigox.Web.JsLib.Core"
    ],
function (
        UserNode,
        Button,
        Container
    ) {

    var base = Container.prototype;

    var EVENT_SELECTBUTTONCLICKED = "selectButtonClicked",
        EVENT_VALUE_CHANGED = "valueChanged";

    var LISTENER_SELECTBUTTONCLICKED = "SelectButtonClicked",
        LISTENER_PROPERTY_CHANGING = "PropertyChanging",
        LISTENER_PROPERTY_CHANGED = "PropertyChanged",
        LISTENER_OPEN_DIALOG = "OpenDialog";


    var UserSelect =
        Namespace("Indigox.Web.JsLib.Controls.Html")
        .Class("UserSelect")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.value = [];
                /*
                *  mode:
                *    1 = 选择部门
                *    2 = 选择用户
                *    3 = 选择群组
                *    4 = 选择职位
                *    5 = 选择角色
                */
                this.mode = "12345";
                this.buttonText = "...";
                this.multi = false;
                this.userNodes = [];
            }
        )
        .Members({
            registerEvents: function () {
                base.registerEvents.call(this);
                this.events.registerEvents(
                    EVENT_SELECTBUTTONCLICKED,
                    EVENT_VALUE_CHANGED
                );
            },

            registerListeners: function () {
                base.registerListeners.call(this);
                this.listeners.registerListeners(
                    LISTENER_SELECTBUTTONCLICKED,
                    LISTENER_OPEN_DIALOG
                );
            },

            getValue: function () {
                return this.value;
            },
            setValue: function (users) {
                this.setUsers(users);
                this.fireEvent(EVENT_VALUE_CHANGED, [this.value]);
            },

            getUserNodes: function () {
                return this.userNodes;
            },
            setUserNodes: function (value) {
                var oldValue = this.userNodes;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["userNodes", value, oldValue]);
                this.userNodes = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["userNodes", value, oldValue]);
            },

            getMode: function () {
                return this.mode;
            },
            setMode: function (value) {
                var oldValue = this.mode;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["mode", value, oldValue]);
                this.mode = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["mode", value, oldValue]);
            },

            getMulti: function () {
                return this.multi;
            },
            setMulti: function (value) {
                var oldValue = this.multi;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["multi", value, oldValue]);
                this.multi = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["multi", value, oldValue]);
            },

            setUsers: function (users) {
                //debug.log("setUsers:");
                //debug.log(users);
                this.clearUsers();
                this.addUserRange(users);
            },

            addUserRange: function (users) {
                if (users != null && users.length > 0) {
                    var i = null, length = null;
                    for (i = 0, length = users.length; i < length; i++) {
                        this.addUser(users[i]);
                    }
                }
            },

            addUser: function (value) {
                //if(userAdded(value)) return;
                this.value.push(value);
                var item = new UserNode();
                item.configure(value);
                this.userNodes.push(item);
                //this.fireListener(LISTENER_PROPERTY_CHANGED, ["userNodes", this.userNodes]);
                this.addChild(item);
                return item;
            },

            clearUsers: function () {
                if (this.userNodes) {
                    var i = null, length = null;
                    for (i = 0, length = this.userNodes.length; i < length; i++) {
                        var userNode = this.userNodes[i];
                        this.removeChild(userNode);
                    }
                    this.userNodes = [];
                    this.value = [];
                }
                //this.fireListener(LISTENER_PROPERTY_CHANGED, ["userNodes", this.userNodes]);
            },

            openDialog: function () {
                if (this.getEnable() === true && this.getReadonly() === false) {
                    this.fireListener(LISTENER_OPEN_DIALOG);
                }
            },

            isEditable: function () {
                return true;
            }
        })
    .$();
});