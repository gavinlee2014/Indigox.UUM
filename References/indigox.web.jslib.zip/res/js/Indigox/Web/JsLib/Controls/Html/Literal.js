﻿define("Indigox.Web.JsLib.Controls.Html.Literal",
    [
        "Indigox.Web.JsLib.Utils.EncodeUtil",
        "Indigox.Web.JsLib.Controls.Control",
        "Indigox.Web.JsLib.Core"
    ],
function (
        EncodeUtil,
        Control
    ) {

    var base = Control.prototype;

    var LISTENER_PROPERTY_CHANGING = "PropertyChanging",
        LISTENER_PROPERTY_CHANGED = "PropertyChanged";

    var EVENT_VALUE_CHANGED = "valueChanged";    

    var Literal =
        Namespace("Indigox.Web.JsLib.Controls.Html")
        .Class("Literal")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.mode = Literal.MODE_ENCODE;
                this.html = "";
            }
        )
        .Static({
            MODE_PASSTHROUGH: 0,
            MODE_ENCODE: 1
        })
        .Members({
            isEditable: function () {
                return false;
            },

            setMode: function (value) {
                if (this.mode === value) {
                    return;
                }

                var oldValue = this.mode;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["mode", value, oldValue]);
                this.mode = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["mode", value, oldValue]);

                this.setHtml(this.converteToHtml(value, this.getMode()));
            },

            getMode: function () {
                return this.mode;
            },

            setValue: function (value) {
                if (this.value === value) {
                    return;
                }

                var oldValue = this.value;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["value", value, oldValue]);
                this.value = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["value", value, oldValue]);

                this.setHtml(this.converteToHtml(value, this.getMode()));
            },

            getValue: function () {
                return this.value;
            },

            setHtml: function (value) {
                var oldValue = this.html;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["html", value, oldValue]);
                this.html = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["html", value, oldValue]);
            },

            getHtml: function () {
                return [this.html].join(""); // convert <null>, <undefined> to <empty string>
            },

            converteToHtml: function (value) {
                if (this.getMode() === Literal.MODE_PASSTHROUGH) {
                    return value;
                }
                else {
                    value = EncodeUtil.encodeHTML(this.value);
                    value = value.replace(/\r?\n/g, "</br>").replace(/[ ]/g, "&nbsp;");
                    return value;
                }
            }
        })
    .$();
});