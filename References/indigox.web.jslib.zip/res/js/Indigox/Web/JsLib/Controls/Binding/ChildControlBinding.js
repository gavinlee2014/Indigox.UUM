﻿define("Indigox.Web.JsLib.Controls.Binding.ChildControlBinding",
    [
        "Indigox.Web.JsLib.Controls.Binding.Binding",
        "Indigox.Web.JsLib.Expression.ExpressionEvaluator",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Binding,
        ExpressionEvaluator
    ) {
    
    var base = Binding.prototype;

    var ChildControlBinding =
        Namespace("Indigox.Web.JsLib.Controls.Binding")
        .Class("ChildControlBinding")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.childProperty = "children";
            }
        )
        .Members({
            getChildProperty: function () {
                return this.childProperty;
            },

            setChildProperty: function (value) {
                this.childProperty = value;
            },

            bind: function (control, record) {
                var evaluator = new ExpressionEvaluator('${' + this.getChildProperty() + '}');
                var childControls = evaluator.getProperty(control);
                if (childControls) {
                    for (var i = 0, length = childControls.length; i < length; i++) {
                        var childControl = childControls[i];
                        childControl.getBinding().bind(childControl, record);
                        this.bind(childControl, record);
                    }
                }
            },

            provide: function (control, record) {
                if (this.getMode() == "ReadOnly") {
                    return;
                }

                var evaluator = new ExpressionEvaluator('${' + this.getChildProperty() + '}');
                var childControls = evaluator.getProperty(control);
                if (childControls) {
                    for (var i = 0, length = childControls.length; i < length; i++) {
                        var childControl = childControls[i];
                        childControl.getBinding().provide(childControl, record);
                        this.provide(childControl, record);
                    }
                }
            }
        })
    .$();
});