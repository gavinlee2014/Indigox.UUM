﻿define("Indigox.Web.JsLib.Controls.Html.NodeControl",
    [
        "Indigox.Web.JsLib.Utils.ArrayUtil",
        "Indigox.Web.JsLib.Collection.List",
        "Indigox.Web.JsLib.Utils.Deferred",
        "Indigox.Web.JsLib.Controls.Container",
        "Indigox.Web.JsLib.Core"
    ],
function (
         ArrayUtil,
         List,
         Deferred ,
         Container
    ) {

    var base = Container.prototype;

    var EVENT_NODE_ADDING = "nodeAdding",
        EVENT_NODE_ADDED = "nodeAdded",
        EVENT_NODE_REMOVING = "nodeRemoving",
        EVENT_NODE_REMOVED = "nodeRemoved",
        EVENT_SELECTED_CHANGED = "selectedChanged",
        EVENT_VALUE_CHANGED = "valueChanged";

    var LISTENER_PROPERTY_CHANGING = "PropertyChanging",
        LISTENER_PROPERTY_CHANGED = "PropertyChanged",
        LISTENER_NODE_ADDING = "NodeAdding",
        LISTENER_NODE_ADDED = "NodeAdded",
        LISTENER_NODE_REMOVING = "NodeRemoving",
        LISTENER_NODE_REMOVED = "NodeRemoved",
        LISTENER_SELECTED_CHANGED = "SelectedChanged";

    
    
    /*--------------------------------------------------
    /  Derived classes:
    /     Indigox.Web.JsLib.Controls.Html.TreeNode
    /     Indigox.Web.JsLib.Controls.Html.MenuItem
    /--------------------------------------------------*/
    var NodeControl =
        Namespace("Indigox.Web.JsLib.Controls.Html")
        .Class("NodeControl")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.selected = false;
                this.text = "";
                this.root = null;               /* HierarchyControl */
                this.childNodes = new List();   /* List */
                //? this.record = null;
                this.level = 1;                 /* int */
                // debug code
                //this.seed = (__seed++);
            }
        )
        .Members({
            registerEvents: function () {
                base.registerEvents.call(this);
                this.events.registerEvents(
                    EVENT_NODE_ADDING,
                    EVENT_NODE_ADDED,
                    EVENT_NODE_REMOVING,
                    EVENT_NODE_REMOVED,
                    EVENT_SELECTED_CHANGED
                );
            },

            registerListeners: function () {
                base.registerListeners.call(this);
                this.listeners.registerListeners(
                    LISTENER_NODE_ADDING,
                    LISTENER_NODE_ADDED,
                    LISTENER_NODE_REMOVING,
                    LISTENER_NODE_REMOVED,
                    LISTENER_SELECTED_CHANGED
                );
            },

            setLevel: function (value) {
                if (this.level === value) {
                    return;
                }
                this.level = value;
            },

            getLevel: function () {
                return this.level;
            },

            setRoot: function (value) {
                this.root = value;
                this.addListener(value);
            },

            getRoot: function () {
                return this.root;
            },

            setParent: function (value) {
                if (value === this.parent) {
                    return;
                }
                this.parent = value;

                if (value === null) {
                    if (this.isLoaded()) {
                        this.unload();
                    }
                }
            },

            setValue: function (value) {
                if (this.value === value) {
                    return;
                }
                var oldValue = this.value;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["value", value, oldValue]);
                this.value = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["value", value, oldValue]);

                this.fireEvent(EVENT_VALUE_CHANGED, [this.value]);
            },

            getValue: function () {
                return this.value;
            },

            setText: function (value) {
                if (this.text === value) {
                    return;
                }
                var oldValue = this.text;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["text", value, oldValue]);
                this.text = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["text", value, oldValue]);
            },

            getText: function () {
                return this.text;
            },

            getSelected: function () {
                return this.selected;
            },

            setSelected: function (value) {
                if (isNullOrUndefined(value) || value === this.selected) {
                    return;
                }

                var oldValue = this.selected;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["selected", value, oldValue]);
                this.selected = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["selected", value, oldValue]);

                this.fireListener(LISTENER_SELECTED_CHANGED, [value]);
                this.fireEvent(EVENT_SELECTED_CHANGED, [value]);
            },

            toggleSelected: function () {
                this.setSelected(!this.getSelected());
            },

            setChildNodes: function (value) {
                this.clearChildNodes();
                var i = null, length = null;

                var list = new List(value);
                var root = this.getRoot();

                for (i = 0, length = value.length; i < length; i++) {
                    if (value[i] instanceof NodeControl) {
                        this.addChildNode(value[i]);
                    }
                    else {
                        var newNode = root.newNode(value[i]);
                        list.set(i, newNode);
                        this.addChildNode(newNode);
                    }
                }
                this.childNodes = list;
            },

            hasChildNodes: function () {
                return this.childNodes.size() !== 0;
            },

            getChildNodes: function () {
                return this.childNodes.toArray();
            },

            addChildNode: function (node) {
                var index = this.getChildNodes().length;
                this.insertChildNode(index, node);
            },

            insertChildNode: function (index, node) {
                var root = this.getRoot(); /* HierarchyControl */

                if (!(node instanceof NodeControl)) {
                    node = root.newNode(node);
                }

                node.setParent(this);

                this.childNodes.insert(index, node);
                this.updateChildID(index);

                this.fireListener(LISTENER_NODE_ADDING, [index, node]);
                this.fireEvent(EVENT_NODE_ADDING, [index, node]);
                node.setLevel(this.getLevel() + 1);

                if (root) {
                    root.addNode(node); /* HierarchyControl.addNode() */
                    node.setRoot(root);
                }

                if (this.isInited()) {
                    node.init();
                }

                if (this.isLoaded()) {
                    Deferred.when(node.load()).done({
                        handler: function () {
                            this.fireListener(LISTENER_NODE_ADDED, [index, node]);
                            this.fireEvent(EVENT_NODE_ADDED, [index, node]);
                        },
                        scope: this
                    }).fail({
                        handler: function () {
                            debug.error([this.id, " insertChildNode ", node.id, " failed."].join(""));
                        },
                        scope: this
                    });
                }
                else {
                    this.fireListener(LISTENER_NODE_ADDED, [index, node]);
                    this.fireEvent(EVENT_NODE_ADDED, [index, node]);
                }
            },

            removeChildNode: function (node) {
                var childNodes = this.getChildNodes();
                var index = ArrayUtil.indexOf(childNodes, node);

                this.fireEvent(EVENT_NODE_REMOVING, [index, node]);
                this.fireListener(LISTENER_NODE_REMOVING, [index, node]);

                this.childNodes.remove(node);
                node.unload();
                node.setParent(null);
                this.updateChildID(index);

                this.fireEvent(EVENT_NODE_REMOVED, [index, node]);
                this.fireListener(LISTENER_NODE_REMOVED, [index, node]);
            },

            clearChildNodes: function () {
                var childNodes = this.getChildNodes();
                var i = null, length = null;
                for (i = 0, length = childNodes.length; i < length; i++) {
                    this.removeChildNode(childNodes[i]);
                }
            },

            preLoadChildren: function () {
                var children = this.getChildNodes();
                for (var i = 0, length = children.length; i < length; i++) {
                    children[i].preLoad();
                }
            },

            loadChildren: function () {
                var children = this.getChildNodes();
                var defers = [];
                for (var i = 0, length = children.length; i < length; i++) {
                    defers.push(children[i].load());
                }
                return Deferred.when(defers);
            },

            unloadChildren: function () {
                var childNodes = this.childNodes;
                for (var i = 0, length = childNodes.size(); i < length; i++) {
                    childNodes.get(i).unload();
                }
            },

            initChildren: function () {
                var childNodes = this.childNodes;
                for (var i = 0, length = childNodes.size(); i < length; i++) {
                    childNodes.get(i).init();
                }
            },

            updateChildID: function (index) {
                var childNodes = this.childNodes,
                    i = null,
                    length = null;
                if (index >= childNodes.size()) {
                    return;
                }

                var parentId = this.id,
                    name = childNodes.get(index).getName(),
                    count = 0;
                for (i = 0, length = index; i < length; i++) {
                    if (childNodes.get(i).getName() === name) {
                        count++;
                    }
                }
                for (i = index, length = childNodes.size(); i < length; i++) {
                    var childNode = childNodes.get(i);
                    if (childNode.getName() === name) {
                        var childId = parentId + "." + name + ":" + count++;
                        childNode.setID(childId);
                        // debug code
                        //debug.log("" + this.seed + ":" + this.id + " > " + childNode.seed + ":" + childNode.id);

                        childNode.updateChildrenID();
                    }
                }
            },

            updateChildrenID: function () {
                var childNodes = this.childNodes;
                for (var i = 0, length = childNodes.size(); i < length; i++) {
                    this.updateChildID(i);
                }
            },

            isEditable: function () {
                return true;
            }
        })
    .$();
} );