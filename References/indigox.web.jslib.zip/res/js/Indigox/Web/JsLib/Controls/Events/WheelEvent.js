﻿define("Indigox.Web.JsLib.Controls.Events.WheelEvent",
    [
        "Indigox.Web.JsLib.Controls.Events.MouseEvent",
        "Indigox.Web.JsLib.Core"
    ],
function (
        MouseEvent
    ) {
    var base = MouseEvent.prototype;
    var WheelEvent =
        Namespace('Indigox.Web.JsLib.Controls.Events')
        .Class('WheelEvent')
        .Extend(base)
        .Constructor(
            function (e) {
                base.constructor.apply(this, arguments);
                this.deltaX = e.deltaX;
                this.deltaY = e.deltaY;
                this.deltaZ = e.deltaZ;
            }
        )
        .Members({
            getDeltaX: function () {
                return this.deltaX;
            },
            getDeltaY: function () {
                return this.deltaY;
            },
            getDeltaZ: function () {
                return this.deltaZ;
            }
        })
    .$();
});