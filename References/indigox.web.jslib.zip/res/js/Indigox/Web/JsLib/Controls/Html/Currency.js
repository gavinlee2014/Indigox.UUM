﻿define("Indigox.Web.JsLib.Controls.Html.Currency",
    [
        "Indigox.Web.JsLib.Controls.Html.FieldControl",
        "Indigox.Web.JsLib.Core"
    ],
    function (
        FieldControl
    ) {
        var F;

        var LISTENER_PROPERTY_CHANGING = "PropertyChanging",
            LISTENER_PROPERTY_CHANGED = "PropertyChanged",
            LISTENER_VALUE_CHANGED = "ValueChanged";

        var base = FieldControl.prototype;

        var Currency =
            Namespace("Indigox.Web.JsLib.Controls.Html")
            .Class("Currency")
            .Extend(base)
            .Constructor(
                function () {
                    base.constructor.apply(this, arguments);
                }
            )
            .Members({
                getValue: function () {
                    return this.value || "0";
                },
                setValue: function (value) {
                    base.setValue.apply(this, arguments);
                    this.setAmountInWords(F.getAmountInWords(this.value));
                },
                getAmountInWords: function () {
                    return this.amountInWords || F.getAmountInWords("0");
                },
                setAmountInWords: function (value) {
                    var oldValue = this.amountInWords;
                    this.fireListener(LISTENER_PROPERTY_CHANGING, ["amountInWords", value, oldValue]);
                    this.amountInWords = value;
                    this.fireListener(LISTENER_PROPERTY_CHANGED, ["amountInWords", value, oldValue]);
                },
                init: function () {
                    base.init.apply(this, arguments);
                    this.setValue("0");
                    this.setAmountInWords(F.getAmountInWords("0"));
                }
            })
        .$();

        F = (function () {
            var minValue = 0;
            var maxValue = 999999999.99;
            var template = "           "; // 11 blanks
            var chsNums = "零壹贰叁肆伍陸柒捌玖";
            var units = "亿仟佰拾萬仟佰拾元角分";
            //var empty = "ⓧ亿ⓧ仟ⓧ佰ⓧ拾ⓧ萬ⓧ仟ⓧ佰ⓧ拾ⓧ元ⓧ角ⓧ分";
            var empty = "";

            function padLeft(text, template) {
                if (text.length < template.length) {
                    return template.substring(0, template.length - text.length) + text;
                }
                return text;
            }

            function getCharAt(text, index) {
                // IE7 can't use units[i] to get a char from string
                return text.substring(index, index + 1);
            }

            return {
                getAmountInWords: function (value) {
                    if (!value || isNaN(value)) {
                        return empty;
                    }
                    value = parseFloat(value);
                    if (value === 0) {
                        return empty;
                    }
                    if (value > maxValue || value < minValue) {
                        throw Error("Currency value is overflow. (" + value + ")");
                    }
                    var text = padLeft(Math.floor(value * 100).toString(), template);
                    var segs = [];
                    for (var i = 0, length = text.length - 2; i < length; i++) {
                        if (getCharAt(text, i) == " ") {
                            //segs.push("ⓧ" + getCharAt(units,i));
                        }
                        else {
                            //
                            segs.push("" + getCharAt(chsNums, parseInt(getCharAt(text, i), 10)) + getCharAt(units, i));
                        }
                    }
                    if (text.substring(text.length - 2, text.length) === "00") {
                        segs.push("整");
                    }
                    else {
                        segs.push("" + getCharAt(chsNums, parseInt(getCharAt(text, text.length - 2), 10)) + getCharAt(units, text.length - 2));
                        segs.push("" + getCharAt(chsNums, parseInt(getCharAt(text, text.length - 1), 10)) + getCharAt(units, text.length - 1));
                    }
                    return segs.join("");
                }
            };
        } ());
    });