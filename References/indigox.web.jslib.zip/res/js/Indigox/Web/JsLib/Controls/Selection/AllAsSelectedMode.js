﻿define("Indigox.Web.JsLib.Controls.Selection.AllAsSelectedMode",
    [
        "Indigox.Web.JsLib.Controls.Selection.Mode",
        "Indigox.Web.JsLib.Collection.List",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Mode,
        List
) {

    var base = Mode.prototype;

    /**
    * 所有 Item 都被视为已选中，并且当选中值移除后，对应的 Item 也将被移除。
    */
    var AllAsSelectedMode =
        Namespace("Indigox.Web.JsLib.Controls.Selection")
        .Class("AllAsSelectedMode")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
            }
        )
        .Members({
            bindControl: function (control) {
                this.control = control;
            },

            select: function (datas, keepExisting) {
                var control = this.control;

                if (!keepExisting) {
                    control.clearItems();
                }

                var value = null;
                if (datas) {
                    for (var i = 0, length = datas.length; i < length; i++) {
                        value = datas[i];
                        var item = control.newItem({
                            value: value
                        });
                        control.addItem(item);
                    }
                }
            },

            tryCommit: function (needCommit) {
            },

            onRowRemoved: function (source, index, row) {
            },

            onRowSelectedChanged: function (source, row, selected) {
            },

            setControlSelected: function (data, row, isSelected) {
            },

            getSelectionMode: function () {
                return "ARRAY";
            },

            setSelectionMode: function () {
                //throw new Error("Can't set selectionMode.");
            }
        })
    .$();

});