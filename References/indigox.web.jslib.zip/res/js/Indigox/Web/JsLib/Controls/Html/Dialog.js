﻿define("Indigox.Web.JsLib.Controls.Html.Dialog",
    [
        "Indigox.Web.JsLib.Controls.Html.Panel",
        "Indigox.Web.JsLib.Core"
    ],
function (
    Panel
) {
    var EVENT_CLOSED = "closed",
        EVENT_OPENED = "opened";

    var LISTENER_PROPERTY_CHANGING = "PropertyChanging",
        LISTENER_PROPERTY_CHANGED = "PropertyChanged",
        LISTENER_CLOSED = "Closed",
        LISTENER_OPENED = "Opened";

    var base = Panel.prototype;

    var Dialog =
        Namespace("Indigox.Web.JsLib.Controls.Html")
        .Class("Dialog")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.autoCenter = true;
                this.collapsible = true;
                this.collapsed = false;
                this.callback = null;
                this.dialogResult = null;
                this.params = null;
                //this.returnValue = undefined;
                Page().addListener(this, { onScrolling: this.onPageScrolling });
            }
        )
        .Static({
            DIALOG_RESULT_OK: "ok",
            DIALOG_RESULT_CANCEL: "cancel"
        })
        .Members({
            registerEvents: function () {
                base.registerEvents.call(this);
                this.events.registerEvents(
                    EVENT_CLOSED,
                    EVENT_OPENED
                );
            },

            registerListeners: function () {
                base.registerListeners.call(this);
                this.listeners.registerListeners(
                    LISTENER_PROPERTY_CHANGED,
                    LISTENER_CLOSED,
                    LISTENER_OPENED
                );
            },

            setCollapsed: function (value) {
                this.collapsed = false;
            },

            getCollapsed: function () {
                return false;
            },

            setValue: function (value) {
                base.setValue.apply(this, arguments);
                for (var i = 0, child; child = this.children[i]; i++) {
                    var key = child.getName();
                    if ((this.value != null) && (key in this.value)) {
                        child.setValue(this.value[key]);
                    }
                }
            },

            setAutoCenter: function (value) {
                if (isNullOrUndefined(value)) {
                    return;
                }
                if (this.autoCenter === value) {
                    return;
                }
                var oldValue = this.autoCenter;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["autoCenter", value, oldValue]);
                this.autoCenter = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["autoCenter", value, oldValue]);
            },

            getAutoCenter: function () {
                return this.autoCenter;
            },

            init: function () {
                base.init.apply(this, arguments);
                // Page().addListener(this, { onScrolling: this.onPageScrolling });
            },

            getParams: function () {
                return this.params;
            },

            getParam: function (paramName) {
                if (this.params) {
                    return this.params[paramName];
                }
                return undefined;
            },

            open: function (params, callback) {
                this.callback = callback;
                this.dialogResult = Dialog.DIALOG_RESULT_CANCEL;
                //this.returnValue = undefined;
                this.params = params;
                this.setVisible(true);
                this.fireListener(LISTENER_OPENED);
                this.fireEvent(EVENT_OPENED);
            },

            close: function () {
                if (this.callback) {
                    this.callback.invoke(this.dialogResult, this.returnValue);
                }
                this.callback = null;
                this.params = null;
                this.setVisible(false);
                this.fireListener(LISTENER_CLOSED);
                this.fireEvent(EVENT_CLOSED);
            }
        })
    .$();
});