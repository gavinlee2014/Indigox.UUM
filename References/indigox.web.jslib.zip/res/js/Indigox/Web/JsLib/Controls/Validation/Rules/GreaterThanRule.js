﻿define("Indigox.Web.JsLib.Controls.Validation.Rules.GreaterThanRule",
    [
        "Indigox.Web.JsLib.Controls.Validation.Rules.Rule",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Rule
    ) {

    var base = Rule.prototype;

    var GreaterThanRule =
        Namespace("Indigox.Web.JsLib.Controls.Validation.Rules")
        .Class("GreaterThanRule")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.defaultMessageExpression = '输入值须大于${condition}';
            }
        )
        .Members({
            isMatch: function (value) {
                return (value > this.getCondition());
            }
        })
    .$();
});