﻿define("Indigox.Web.JsLib.Controls.Html.BlankDropDownItem",
    [
        "Indigox.Web.JsLib.Controls.Html.DropDownItem",
        "Indigox.Web.JsLib.Core"
    ],
function (
        DropDownItem
) {
    var base = DropDownItem.prototype;

    var BlankDropDownItem =
        Namespace("Indigox.Web.JsLib.Controls.Html")
        .Class("BlankDropDownItem")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.text = '';
            }
        )
    .$();
});