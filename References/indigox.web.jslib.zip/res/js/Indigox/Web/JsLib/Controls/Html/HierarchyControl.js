﻿define("Indigox.Web.JsLib.Controls.Html.HierarchyControl",
    [
        "Indigox.Web.JsLib.Controllers.Controller",
        "Indigox.Web.JsLib.Collection.List",
        "Indigox.Web.JsLib.Utils.Deferred",
        "Indigox.Web.JsLib.Controls.Selection.NodeMode",
        "Indigox.Web.JsLib.Controls.Html.NodeControl",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Controller,
        List,
        Deferred,
        NodeMode,
        NodeControl
    ) {

    var base = NodeControl.prototype;

    var EVENT_NODE_SELECTED_CHANGED = "nodeSelectedChanged",
        EVENT_VALUE_CHANGED = "valueChanged";

    var LISTENER_PROPERTY_CHANGING = "PropertyChanging",
        LISTENER_PROPERTY_CHANGED = "PropertyChanged",
        LISTENER_NODE_SELECTED_CHANGED = "NodeSelectedChanged";



    /*--------------------------------------------------
    /  Root of NodeControl
    /
    /  Derived classes:
    /     Indigox.Web.JsLib.Controls.Html.Tree
    /     Indigox.Web.JsLib.Controls.Html.Menu
    /--------------------------------------------------*/
    var HierarchyControl =
        Namespace("Indigox.Web.JsLib.Controls.Html")
        .Class("HierarchyControl")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.controller = null;
                this.nodes = new List();
            }
        )
        .Members({
            registerListeners: function () {
                base.registerListeners.call(this);
                this.listeners.registerListeners(
                    LISTENER_NODE_SELECTED_CHANGED
                );
            },

            registerEvents: function () {
                base.registerEvents.call(this);
                this.events.registerEvents(
                    EVENT_VALUE_CHANGED,
                    EVENT_NODE_SELECTED_CHANGED
                );
            },

            setController: function (controller) {
                if (!(controller instanceof Controller)) {
                    var controllerInfo = controller;
                    controller = Type.forAlias(controllerInfo.controllerType).createInstance();
                    controller.configure(controllerInfo);
                }

                if (this.controller) {
                    this.controller.setView(null);
                }
                this.controller = controller;
                if (this.controller) {
                    this.controller.setView(this);
                }
                if (this.isLoaded() && this.controller.autoLoad === true) {
                    this.controller.load();
                }
            },

            getController: function () {
                return this.controller;
            },

            setRoot: function (value) {
            },

            getRoot: function () {
                return this;
            },
            getNodes: function () {
                return this.nodes.toArray();
            },

            addNode: function (node) {
                this.nodes.add(node);
            },

            load: function () {
                return base.load.apply(this, arguments);
            },

            doLoad: function () {
                var dfd = new Deferred();
                if (this.getController() && this.getController().getAutoLoad() == true) {
                    this.getController().load(function () {
                        dfd.resolve();
                    });
                }
                else {
                    dfd.resolve();
                }
                return dfd.promise();
            },

            loadChildren: function () {
                return base.loadChildren.apply(this, arguments);
            },

            unload: function () {
                base.unload.apply(this, arguments);
                if (this.getController()) {
                    this.getController().unload();
                }
            },

            getSelMode: function () {
                return this.selMode;
            },

            setSelMode: function (value) {
                this.selMode = value;
                if (this.selMode) {
                    this.selMode.bindControl(this);
                }
            },

            createSelectionMode: function () {
                var mode = this.mode ? this.mode : "SINGLE";
                var allowDeselect = isNullOrUndefined(this.allowDeselect) ? "true" : this.allowDeselect;
                var selMode = new NodeMode({ mode: mode, allowDeselect: allowDeselect });
                return selMode;
            },

            selectNode: function (selectedValue) {
                var nodes = this.getNodes();
                var i = null,
                    length = null;
                for (i = 0, length = nodes.length; i < length; i++) {
                    if (nodes[i].getValue() == selectedValue) {
                        nodes[i].setSelected(true);
                    }
                }
            },

            deselectNode: function (deselectedValue) {
                var nodes = this.getNodes();
                var i = null,
                    length = null;
                for (i = 0, length = nodes.length; i < length; i++) {
                    if (nodes[i].getValue() == deselectedValue) {
                        nodes[i].setSelected(false);
                    }
                }
            },

            onSelectedChanged: function (source, selected) {
                this.fireListener(LISTENER_NODE_SELECTED_CHANGED, [source, selected]);
                this.fireEvent(EVENT_NODE_SELECTED_CHANGED, [source, selected]);
            },

            setValue: function (value) {
                if (this.getSelMode()) {
                    if (isNullOrUndefined(value) || !this.getSelMode().isValueChanged(this.value, value)) {
                        return;
                    }

                    var oldValue = this.value;
                    this.fireListener(LISTENER_PROPERTY_CHANGING, ["value", value, oldValue]);

                    this.value = value;
                    this.getSelMode().select(value, false);

                    this.fireListener(LISTENER_PROPERTY_CHANGED, ["value", value, oldValue]);
                    this.fireEvent(EVENT_VALUE_CHANGED, [this.value]);
                }
            },

            getValue: function () {
                if (this.getSelMode()) {
                    return this.value;
                }
                else {
                    var values = [], nodes = this.getNodes();
                    for (var i = 0, length = nodes.length; i < length; i++) {
                        values.push(nodes[i].getValue());
                    }
                    return values;
                }
            }
        })
    .$();
});