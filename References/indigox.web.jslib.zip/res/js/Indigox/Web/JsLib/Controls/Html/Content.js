﻿define("Indigox.Web.JsLib.Controls.Html.Content",
    [
        "Indigox.Web.JsLib.Utils.AsyncUtil",
        "Indigox.Web.JsLib.Controls.Html.FieldSet",
        "Indigox.Web.JsLib.Controls.Binding.ChildControlBinding",
        "Indigox.Web.JsLib.Controls.Html.FieldContainer",
        "Indigox.Web.JsLib.Controls.FormControl",
        "Indigox.Web.JsLib.Core"
    ],
    function (
        AsyncUtil,
        FieldSet,
        ChildControlBinding,
        FieldContainer,
        FormControl
    ) {
        var base = FormControl.prototype;

        var Content =
            Namespace("Indigox.Web.JsLib.Controls.Html")
            .Class("Content")
            .Extend(base)
            .Constructor(
                function () {
                    base.constructor.apply(this, arguments);
                }
            )
            .Members({
                //load: function () {
                //    var t = this;
                //    AsyncUtil.invokeAsync({ scope: this, handler: this.doLoad });
                //},
                //
                //doLoad: function () {
                //    base.load.call(this);
                //},

                setControls: function (contorlInfos) {
                    if (contorlInfos.length <= 0) {
                        return;
                    }

                    this.clearChildren();

                    for (var i = 0, length = contorlInfos.length; i < length; i++) {
                        var controlInfo = contorlInfos[i];
                        if (isNullOrUndefined(controlInfo.controlType)) {
                            throw new Error("the contorl's type can not be null!");
                        }
                        var child = Type.forAlias(controlInfo.controlType).createInstance();
                        child.configure(controlInfo);

                        this.addChild(child);
                    }
                },

                getBinding: function () {
                    if (!this.binding) {
                        this.binding = new ChildControlBinding();
                    }
                    return this.binding;
                },

                setBinding: function () {
                    throw new Error("Can't set DataItem's binding property.");
                }
            })
        .$();
    });