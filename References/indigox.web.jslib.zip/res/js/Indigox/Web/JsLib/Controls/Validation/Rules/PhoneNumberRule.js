﻿define("Indigox.Web.JsLib.Controls.Validation.Rules.PhoneNumberRule",
    [
        "Indigox.Web.JsLib.Controls.Validation.Rules.Rule",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Rule
    ) {

    var base = Rule.prototype;

    var PhoneNumberRule =
        Namespace("Indigox.Web.JsLib.Controls.Validation.Rules")
        .Class("PhoneNumberRule")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
            }
        )
        .Members({
            isMatch: function (value) {
                var reg = /^\d[\d\-]+\d$/g;
                return reg.test(value);
            }
        })
    .$();
});