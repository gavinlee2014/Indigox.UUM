﻿define("Indigox.Web.JsLib.Controls.Html.TreeNode",
    [
        "Indigox.Web.JsLib.Utils.AsyncUtil",
        "Indigox.Web.JsLib.Controls.Html.NodeControl",
        "Indigox.Web.JsLib.Core"
    ],
function (
        AsyncUtil,
        NodeControl
    ) {

    var base = NodeControl.prototype;

    var EVENT_EXPANDED = "expanded",
        EVENT_COLLAPSED = "collapsed",
        EVENT_NODE_ADDED = "nodeAdded",
        EVENT_NODE_REMOVED = "nodeRemoved",
        EVENT_CLICKED = "clicked";

    var LISTENER_EXPANDED = "Expanded",
        LISTENER_COLLAPSED = "Collapsed",
        LISTENER_NODE_ADDED = "NodeAdded",
        LISTENER_NODE_REMOVED = "NodeRemoved",
        LISTENER_CONTROL_CHANGED = "ControlChanged",
        LISTENER_BUTTON_CHANGED = "ButtonChanged",
        LISTENER_PROPERTY_CHANGING = "PropertyChanging",
        LISTENER_PROPERTY_CHANGED = "PropertyChanged",
        LISTENER_CLICKED = "Clicked";

    var TreeNode =
        Namespace("Indigox.Web.JsLib.Controls.Html")
        .Class("TreeNode")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.collapsed = true;
                this.childLoaded = false;
            }
        )
        .Members({
            registerEvents: function () {
                base.registerEvents.call(this);
                this.events.registerEvents(
                    EVENT_EXPANDED,
                    EVENT_COLLAPSED,
                    EVENT_CLICKED
                );
            },

            registerListeners: function () {
                base.registerListeners.call(this);
                this.listeners.registerListeners(
                    LISTENER_EXPANDED,
                    LISTENER_COLLAPSED,
                    LISTENER_BUTTON_CHANGED,
                    LISTENER_CONTROL_CHANGED,
                    LISTENER_CLICKED
                );
            },

            setCollapsed: function (value) {
                var oldValue = this.collapsed;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["collapsed", value, oldValue]);
                this.collapsed = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["collapsed", value, oldValue]);
            },

            getCollapsed: function () {
                return this.collapsed;
            },

            hasChildNodes: function () {
                if (this.childLoaded) {
                    return this.childNodes.size() > 0;
                }
                else {
                    return true;
                }
            },

            isLastChild: function () {
                var siblings = this.getParent().getChildNodes();
                var length = siblings.length;
                return siblings[length - 1] === this;
            },

            load: function () {
                var promise = base.load.apply(this, arguments).done({
                    handler: function () {
                        if (this.getLevel() < this.getRoot().getExpandLevel()) {
                            this.expand();
                        }
                    },
                    scope: this
                });
                return promise;
            },

            collapse: function () {
                this.setCollapsed(true);
                AsyncUtil.invokeAsync({ scope: this, handler: this.doCollapse });
            },

            doCollapse: function () {
                this.fireListener(LISTENER_COLLAPSED, [this]);
                this.fireEvent(EVENT_COLLAPSED, [this]);
            },

            expand: function () {
                if (this.getCollapsed()) {
                    this.setCollapsed(false);
                    if (!this.childLoaded) {
                        this.getRoot().expandNode(this);
                    }
                    AsyncUtil.invokeAsync({ scope: this, handler: this.doExpand });
                }
            },

            doExpand: function () {
                this.fireListener(LISTENER_EXPANDED, [this]);
                this.fireEvent(EVENT_EXPANDED, [this]);
            },

            toggleCollapse: function () {
                if (this.getCollapsed()) {
                    this.expand();
                }
                else {
                    this.collapse();
                }
            },

            click: function () {
                this.toggleSelected();
                this.fireListener(LISTENER_CLICKED, []);
                this.fireEvent(EVENT_CLICKED, []);
            }
        })
    .$();
});