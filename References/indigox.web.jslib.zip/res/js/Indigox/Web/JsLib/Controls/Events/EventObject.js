﻿define("Indigox.Web.JsLib.Controls.Events.EventObject",
    [
        "Indigox.Web.JsLib.Core"
    ],
    function (

    ) {
        var EventObject =
            Namespace('Indigox.Web.JsLib.Controls.Events')
            .Class('EventObject')//
            .Constructor(
                function () {
                }
            )
            .Members({
            })
        .$();
    });