﻿define("Indigox.Web.JsLib.Controls.Grid.GridFooter",
    [
        "Indigox.Web.JsLib.Controls.Grid.GridRow",
        "Indigox.Web.JsLib.Core"
    ],
function (
        GridRow
) {

    var base = GridRow.prototype;

    var GridFooter =
        Namespace("Indigox.Web.JsLib.Controls.Grid")
        .Class("GridFooter")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
            }
        )
        .Members({
        })
    .$();
});