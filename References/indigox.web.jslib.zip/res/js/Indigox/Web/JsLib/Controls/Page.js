﻿define("Indigox.Web.JsLib.Controls.Page",
    [
        "Indigox.Web.JsLib.Collection.Hashtable",
        "Indigox.Web.JsLib.Utils.Deferred",
         "Indigox.Web.JsLib.Utils.Browser",
        "Indigox.Web.JsLib.Utils.DelayedTask",
        "Indigox.Web.JsLib.Utils.UrlUtil",
        "Indigox.Web.JsLib.Controls.PageUrlMonitor",
        "Indigox.Web.JsLib.Controls.Html.LoadMask",
        "Indigox.Web.JsLib.Controls.Widgets.Widget",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Hashtable,
        Deferred,
        Browser,
        DelayedTask,
        UrlUtil,
        PageUrlMonitor,
        LoadMask,
        Widget
) {
    var LISTENER_PROPERTY_CHANGING = "PropertyChanging",
        LISTENER_PROPERTY_CHANGED = "PropertyChanged";

    var instance = null;

    var base = Widget.prototype;

    var Page =
        Namespace("Indigox.Web.JsLib.Controls")
        .Class("Page")
        .Extend(base)
        .Constructor(
            function (id) {
                base.constructor.apply(this, arguments);
                this.loadMask = null;
                this.masked = LoadMask.NONE; // LoadMask.NONE = null
                this.context = new Hashtable();
            }
        )
        .Static({
            getInstance: function () {
                if (!instance) {
                    instance = new Page();
                }
                return instance;
            },
            IGNORE_EMPTY_NEW_VALUE: 1,
            IGNORE_EMPTY_OLD_VALUE: 2
        })
        .Members({
            initChildren: function () {
                base.initChildren.apply(this, arguments);
                if (this.getLoadMask()) {
                    this.getLoadMask().init();
                }
            },

            preLoadChildren: function () {
                var promise = base.preLoadChildren.apply(this, arguments);
                if (this.getLoadMask()) {
                    this.getLoadMask().load();
                }
            },

            loadChildren: function () {
                var promise = base.loadChildren.apply(this, arguments);
                if (this.getLoadMask()) {
                    this.getLoadMask().load();
                }
                return promise;
            },

            unloadChildren: function () {
                base.unloadChildren.apply(this, arguments);
                if (this.getLoadMask()) {
                    this.getLoadMask().unload();
                }
            },

            getContextValue: function (key) {
                return this.context.get(key);
            },

            setContextValue: function (key, value) {
                this.context.put(key, value);
            },

            setID: function (id) {
                base.setID.call(this, id);
                this.updateAllChildrenID(this.children);
            },

            updateAllChildrenID: function (children) {
                var i = null,
                    length = null;
                var name = null,
                    counts = {};
                for (i = 0, length = children.length; i < length; i++) {
                    name = children[i].getName();
                    if (!(name in counts)) {
                        counts[name] = 0;
                    }
                    children[i].setID(name + ":" + counts[name]++);
                }
            },

            updateChildrenID: function (children, index) {
                var i = null,
                    length = null;
                if (children.length === 0) {
                    return;
                }

                var control = children[index],
                    name = control.getName(),
                    count = 0;
                for (i = 0, length = index; i < length; i++) {
                    if (children[i].getName() === name) {
                        count++;
                    }
                }
                for (i = index, length = children.length; i < length; i++) {
                    if (children[i].getName() === name) {
                        children[i].setID(name + ":" + count++);
                    }
                }
            },

            setLoadMask: function (value) {
                var oldValue = this.getLoadMask();
                //this.fireListener(LISTENER_PROPERTY_CHANGING, ["loadMask", value, oldValue]);

                if (oldValue) {
                    oldValue.setParent(null);
                }
                if (value) {
                    value.setParent(this);
                }
                this.loadMask = value;

                this.fireListener(LISTENER_PROPERTY_CHANGED, ["loadMask", value, oldValue]);
            },

            getLoadMask: function () {
                return this.loadMask;
            },

            setMasked: function (value) {
                this.masked = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["masked", this.masked]);
            },

            getMasked: function () {
                return this.masked;
            },

            mask: function () {
                this.loadMask.show();
            },

            unmask: function () {
                this.loadMask.hide();
                //this.loadMask.setValue("");
            },

            unload: function () {
                base.unload.apply(this, arguments);
                instance = null;
            },

            getUrl: function () {
                if (location.hash.length > 1) {
                    var hash = location.hash.substring(1);
                    var url = UrlUtil.concate(hash);
                    return url;
                }

                var _page = UrlUtil.get('page');
                if (_page) {
                    return _page;
                }

                return window.location.href;
            },

            getUrlPath: function () {
                return UrlUtil.getPath(this.getUrl());
            },

            getUrlParam: function (name) {
                return UrlUtil.get(name, this.getUrl());
            },

            getUrlParams: function () {
                return UrlUtil.getParams(this.getUrl());
            },

            //@deprecated
            listenUrlParamChanged: function (paramNames, option, callback) {
                var monitorOptions = {
                    paramFilters: paramNames
                };

                if (option) {
                    if (option.mode) {
                        monitorOptions.paramIgnoreFilters = option.mode;
                    }
                    if (option.container) {
                        monitorOptions.container = option.container;
                    }
                }

                new PageUrlMonitor(monitorOptions).onUrlParamChanged(callback);
            }
        })
    .$();

    window.Page = Page.getInstance;
});