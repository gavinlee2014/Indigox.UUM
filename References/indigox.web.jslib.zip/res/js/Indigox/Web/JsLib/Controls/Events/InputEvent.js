﻿define("Indigox.Web.JsLib.Controls.Events.InputEvent",
    [
        "Indigox.Web.JsLib.Controls.Events.EventObject",
        "Indigox.Web.JsLib.Core"
    ],
function (
        EventObject
    ) {
    var base = EventObject.prototype;

    var InputEvent =
        Namespace('Indigox.Web.JsLib.Controls.Events')
        .Class('InputEvent')
        .Extend(base)
        .Constructor(
            function (e) {
                base.constructor.apply(this, arguments);
                this.alt = e.altKey;
                this.ctrl = e.ctrlKey;
                this.shift = e.shiftKey;
                this.modifiers = null;
            }
        )
        .Members({
            getAlt: function () {
                return this.alt;
            },
            getCtrl: function () {
                return this.ctrl;
            },
            getShift: function () {
                return this.shift;
            },
            getModifiers: function () {
                return this.modifiers = null;
            }
        })
    .$();
});