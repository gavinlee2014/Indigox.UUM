﻿define("Indigox.Web.JsLib.Controls.Template",
    [
        "Indigox.Web.JsLib.Collection.List",
        "Indigox.Web.JsLib.Collection.Hashtable",
        "Indigox.Web.JsLib.Controls.Control",
        "Indigox.Web.JsLib.Controls.ListenersFactory",
        "Indigox.Web.JsLib.Controls.Container",
        "Indigox.Web.JsLib.Core"
    ],
    function (
        List,
        Hashtable,
        Control,
        ListenersFactory,
        Container
    ) {
        var base = Container.prototype;

        var EXCLUDE_FIELDS = {
            defaultName: true,
            loaded: true,
            //name: true,
            id: true,
            state: true,
            stateText: true
        };

        var applyTo = function (source, target) {
            var objectsCache = new Hashtable();

            var clone = function (source) {
                if (!isObject(source) || !(source instanceof Control) || isNullOrUndefined(source)) {
                    return source;
                }

                if (objectsCache.containsKey(source)) {
                    return objectsCache.get(source);
                }

                target = new source.constructor();
                objectsCache.put(source, target);
                copy(source, target);

                return target;
            };

            var copy = function (source, target) {
                //debug.log( source );
                for (var key in source) {
                    //TODO: 临时解决方案
                    if (key === 'binding') {
                        target.binding = source.binding;
                        continue;
                    }
                    //临时解决方案 end

                    if (isFunction(source[key]) || key in EXCLUDE_FIELDS) {
                        continue;
                    }
                    if (source[key] instanceof Array) {
                        arraycopy(source[key], target[key]);
                    }
                    else if (source[key] instanceof List) {
                        listcopy(source[key], target[key]);
                    }
                    else if (source[key] instanceof Control) {
                        target[key] = clone(source[key]);
                    }
                    else if (isObject(source[key])) {
                        if (isNullOrUndefined(source[key])) {
                            target[key] = null;
                        }
                        else {
                            objectsCache.put(source[key], target[key]);
                        }
                    }
                    else {
                        target[key] = source[key];
                    }
                }
            };

            var arraycopy = function (source, target) {
                var length = source.length,
                    element = null;
                var i = null;
                for (i = 0; i < length; i++) {
                    element = source[i];
                    if (element instanceof Control) {
                        target.push(clone(element));
                    }
                }
            };

            var listcopy = function (source, target) {
                var array = source.toArray(),
                    length = array.length,
                    element = null,
                    i = null;
                for (i = 0; i < length; i++) {
                    element = array[i];
                    if (element instanceof Control) {
                        target.add(clone(element));
                    }
                }
            };

            objectsCache.put(source, target);
            //排除父控件以及源控件
            objectsCache.put(source.getParent(), null);
            if (source.getSource) {
                objectsCache.put(source.getSource(), null);
            }

            copy(source, target);
        };

        var LISTENER_INIT = 'Init';

        var Template =
            Namespace('Indigox.Web.JsLib.Controls')
            .Class('Template')
            .Extend(base)
            .Constructor(
                function () {
                    base.constructor.apply(this, arguments);
                    this.source = null;
                }
            )
            .Static({
                reference: function (container) {
                    var template = new Template();
                    applyTo(container, template);
                    template.setSource(container);
                    return template;
                }
            })
            .Members({
                getSource: function () {
                    return this.source;
                },

                setSource: function (value) {
                    this.source = value;
                },

                init: function () {
                    base.init.apply(this, arguments);
                },

                load: function () {
                },

                applyTo: function (container) {
                    applyTo(this, container);
                    container.setTemplate(this);
                },

                configureChildren: function (options) {
                    for (var p in options) {
                        var child = this.getChild(p);
                        if (child && child.configure) {
                            child.configure(options[p]);
                        }
                    }
                }
            })
        .$();
    });