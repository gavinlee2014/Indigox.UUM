﻿define("Indigox.Web.JsLib.Controls.Widgets.WidgetZone",
    [
        "Indigox.Web.JsLib.Collection.List",
        "Indigox.Web.JsLib.Utils.Deferred",
        "Indigox.Web.JsLib.Controls.Widgets.Widget",
        "Indigox.Web.JsLib.Controls.Html.Panel",
        "Indigox.Web.JsLib.Core"
    ],
function (
        List,
        Deferred,
        Widget,
        Panel
) {
    var EVENT_WIDGET_ADDING = "widgetAdding",
        EVENT_WIDGET_REMOVING = "widgetRemoving",
        EVENT_WIDGET_ADDED = "widgetAdded",
        EVENT_WIDGET_REMOVED = "widgetRemoved";

    var LISTENER_WIDGET_ADDING = "WidgetAdding",
        LISTENER_WIDGET_REMOVING = "WidgetRemoving",
        LISTENER_WIDGET_ADDED = "WidgetAdded",
        LISTENER_WIDGET_REMOVED = "WidgetRemoved";

    var base = Panel.prototype;

    var WidgetZone =
        Namespace("Indigox.Web.JsLib.Controls.Widgets")
        .Class("WidgetZone")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.widgets = new List();
            }
        )
        .Members({
            registerEvents: function () {
                base.registerEvents.call(this);
                this.events.registerEvents(
                    EVENT_WIDGET_ADDING,
                    EVENT_WIDGET_ADDED,
                    EVENT_WIDGET_REMOVING,
                    EVENT_WIDGET_REMOVED
                );
            },
            registerListeners: function () {
                base.registerListeners.call(this);
                this.listeners.registerListeners(
                    LISTENER_WIDGET_ADDING,
                    LISTENER_WIDGET_ADDED,
                    LISTENER_WIDGET_REMOVING,
                    LISTENER_WIDGET_REMOVED
                );
            },

            preLoadChildren: function () {
                var children = this.getChildren();
                for (var i = 0, length = children.length; i < length; i++) {
                    children[i].preLoad();
                }
            },

            doLoad: function () {
                var promise = Application.getWidgetZoneInfo(this);
                this.configure({ widgets: promise });
                return promise;
            },

            loadChildren: function () {
                var children = this.getChildren();
                var defers = [];
                for (var i = 0, length = children.length; i < length; i++) {
                    defers.push(children[i].load());
                }
                return Deferred.when(defers);
            },

            insertChild: function (index, child) {
                this.insertWidget(index, child);
            },

            removeChild: function (child) {
                this.removeWidget(child);
            },

            addWidget: function (widget) {
                this.insertWidget(this.widgets.size(), widget);
            },

            insertWidget: function (index, widget) {
                /**新增Widget时，不要load，应该等Widget的Resource加载完后再load*/
                if (this.widgets.contains(widget)) {
                    return;
                }

                this.fireListener(LISTENER_WIDGET_ADDING, [index, widget]);
                this.fireEvent(EVENT_WIDGET_ADDING, [index, widget]);

                this.widgets.insert(index, widget);
                widget.setParent(this);
                this.updateChildrenID(this.getWidgets(), index);

                if (this.isInited()) {
                    widget.init();
                }
                if (this.isLoaded()) {
                    Deferred.when(widget.load()).done({
                        handler: function () {
                            this.fireListener(LISTENER_WIDGET_ADDED, [index, widget]);
                            this.fireEvent(EVENT_WIDGET_ADDED, [index, widget]);
                        },
                        scope: this
                    }).fail({
                        handler: function () {
                            debug.error([this.id, " insertWidget ", widget.id, " failed."].join(""));
                        },
                        scope: this
                    });
                }
                else {
                    this.fireListener(LISTENER_WIDGET_ADDED, [index, widget]);
                    this.fireEvent(EVENT_WIDGET_ADDED, [index, widget]);
                }
            },

            removeWidget: function (widget) {
                if (!this.widgets.contains(widget)) {
                    return;
                }
                var index = this.widgets.indexOf(widget);

                this.fireEvent(EVENT_WIDGET_REMOVING, [index, widget]);
                this.fireListener(LISTENER_WIDGET_REMOVING, [index, widget]);

                widget.unload();
                widget.setParent(null);
                this.widgets.remove(widget);
                this.updateChildrenID(this.getWidgets(), index);

                this.fireEvent(EVENT_WIDGET_REMOVED, [index, widget]);
                this.fireListener(LISTENER_WIDGET_REMOVED, [index, widget]);
            },

            clearWidgets: function () {
                var widgetList = this.getWidgets();
                var i = null, length = null;
                for (i = 0, length = widgetList.length; i < length; i++) {
                    this.removeWidget(widgetList[i]);
                }
            },

            setWidgets: function (widgets) {
                var oldWidgets = this.getWidgets();

                if (widgets.length > 0) {
                    for (var i = 0, ilength = widgets.length; i < ilength; i++) {
                        if (isNullOrUndefined(oldWidgets[i]) || (oldWidgets[i].name != widgets[i].Name)) {
                            var newWidget = this.insertNewWidget(this, oldWidgets, widgets[i], i);
                        }
                    }
                    for (var j = widgets.length, jlength = oldWidgets.length; j < jlength; j++) {
                        this.removeWidget(oldWidgets[j]);
                    }
                }
                else {
                    this.clearWidgets();
                }
            },

            getWidgets: function () {
                return this.widgets.toArray();
            },

            getChildren: function () {
                return this.widgets.toArray();
            },

            //@private
            insertNewWidget: function (widgetZone, oldWidgets, newWidget, index) {
                //TODO: refactor
                var widgets = oldWidgets.slice(0, oldWidgets.length);
                for (var i = index, length = widgets.length; i < length; i++) {
                    if (widgets[i].name == newWidget.Name) {
                        return;
                    }
                    else {
                        oldWidgets.splice(index, 1);
                        widgetZone.removeWidget(widgets[i]);
                    }
                }
                var widget = new Widget();
                widget.configure(newWidget);
                widgetZone.insertWidget(index, widget);
                oldWidgets.splice(index, 0, newWidget);
                return widget;
            }
        })
    .$();
});