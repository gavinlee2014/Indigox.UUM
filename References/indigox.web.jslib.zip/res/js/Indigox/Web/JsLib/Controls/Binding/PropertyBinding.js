﻿define("Indigox.Web.JsLib.Controls.Binding.PropertyBinding",
    [
        "Indigox.Web.JsLib.Controls.Binding.Binding",
        "Indigox.Web.JsLib.Expression.ExpressionEvaluator",
        "Indigox.Web.JsLib.Formatters.Formatter",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Binding,
        ExpressionEvaluator,
        Formatter
    ) {

    var base = Binding.prototype;

    var PropertyBinding =
        Namespace("Indigox.Web.JsLib.Controls.Binding")
        .Class("PropertyBinding")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.mapping = null;
            }
        )
        .Members({
            getMapping: function () {
                return this.mapping;
            },

            setMapping: function (value) {
                this.mapping = value;
            },

            bind: function (control, record, field) {
                var mapping = this.mapping;

                if (typeof field === "undefined") {
                    for (var property in mapping) {
                        if (property === 'readValue') {
                            mapping[property](control, record);
                        }
                        else if (property === 'writeValue') {
                        }
                        else {
                            var evaluator = new ExpressionEvaluator('${' + property + '}');
                            if (isFunction(mapping[property])) {
                                evaluator.setProperty(control, mapping[property](record));
                            }
                            else if (mapping[property] instanceof Formatter) {
                                var formatter = mapping[property];
                                var column = control.getName();
                                if (record.contains(column)) {
                                    evaluator.setProperty(control, formatter.getText(record.get(column)));
                                }
                            }
                            else {
                                var column = mapping[property];
                                if (record.contains(column)) {
                                    evaluator.setProperty(control, record.get(column));
                                }
                            }
                        }
                    }
                }
                else {
                    if (!this.hasReference(field)) {
                        return;
                    }
                    this.bind(control, record);
                }
            },

            provide: function (control, record, field) {
                if (!control.isEditable()) {
                    return;
                }

                if (this.getMode() == "ReadOnly") {
                    return;
                }

                var column = null,
                    evaluator = null,
                    value = null;

                var mapping = this.mapping;

                for (var property in this.getMapping()) {
                    if (property === 'readValue') {
                    }
                    else if (property === 'writeValue') {
                        mapping[property](record, control);
                        column = undefined;
                    }
                    else {
                        evaluator = new ExpressionEvaluator('${' + property + '}');
                        if (isFunction(mapping[property])) {
                            //
                        }
                        else if (mapping[property] instanceof Formatter) {
                            //
                        }
                        else {
                            column = mapping[property];
                            value = evaluator.getProperty(control);
                        }
                    }

                    if (record.contains(column)) {
                        record.set(column, value);
                    }
                }
            }
        })
    .$();
});