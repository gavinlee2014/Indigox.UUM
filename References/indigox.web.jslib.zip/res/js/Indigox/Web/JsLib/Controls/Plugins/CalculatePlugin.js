﻿define("Indigox.Web.JsLib.Controls.Plugins.CalculatePlugin",
    [
        "Indigox.Web.JsLib.Controls.Plugins.Plugin",
        "Indigox.Web.JsLib.Utils.Util",
        "Indigox.Web.JsLib.Utils.StringUtil",
        "Indigox.Web.JsLib.Utils.ControlUtil",
        "Indigox.Web.JsLib.Core"
    ],
    function (
        Plugin,
        Util,
        StringUtil,
        ControlUtil
    ) {
        var base = Plugin.prototype;

        var CalculatePlugin =
            Namespace("Indigox.Web.JsLib.Controls.Plugins")
            .Class("CalculatePlugin")
            .Extend(base)
            .Constructor(
                function (option) {
                    base.constructor.apply(this, arguments);

                    //@private
                    this.relativeControls = [];

                    option = Util.copyExist({
                        formular: null
                    }, option);
                    this.configure(option);
                }
            )
            .Members({
                setFormular: function (formular) {
                    this.formular = formular;
                    this._initFormular();
                },

                getFormular: function () {
                    return this.formular;
                },

                evaluateValue: function () {
                    var formularString = this.getFormular();
                    var i, length;
                    for (i = 0; i < this.relativeControls.length; i++) {
                        var val = this.relativeControls[i].getValue();
                        if ((isNaN(val)) && (isString(val))) {
                            val = val.replace(/\'/g, "\\\'");
                            val = val.replace(/\"/g, "\\\"");
                            val = "\"" + val + "\"";
                        }
                        if (StringUtil.isNullOrEmpty(val)) {
                            val = "0";
                        }
                        var reg = eval("/{" + this.relativeControls[i].getName() + "}/g");
                        formularString = formularString.replace(reg, "(" + val + ")");
                    }
                    var result = eval(formularString);
                    if ((typeof (result) === "number") && (result.toString() == "NaN")) {
                        result = "";
                    }
                    return result;
                },

                onRelativeControlPropertyChanged: function (source, property, value, oldValue) {
                    if (property == "value") {
                        this.getControl().setValue(this.evaluateValue());
                    }
                },

                setControl: function (control) {
                    base.setControl.apply(this, arguments);
                    this._initFormular();
                },

                onLoading: function () {
                    this._initFormular();
                },

                _initFormular: function () {
                    if (this.getFormular() == null) {
                        return;
                    }
                    if (this.getControl() == null) {
                        return;
                    }
                    var formularReg = /(\{\w*\})/g;
                    var reg = /(\w+)/g;
                    var matches = this.getFormular().match(formularReg);
                    var i, length;
                    for (i = 0; i < matches.length; i++) {
                        var controlName = matches[i].match(reg)[0];
                        var controls = ControlUtil.findControlFromNearestParent(this.getControl(), controlName);
                        if ((controls == null) || (controls.length === 0)) {
                            continue;
                        }
                        var control = controls[0];
                        this.relativeControls.push(control);
                        control.addListener(this, {
                            onPropertyChanged: this.onRelativeControlPropertyChanged
                        });
                    }
                }
            })
        .$();
    });