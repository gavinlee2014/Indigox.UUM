﻿define("Indigox.Web.JsLib.Controls.Validation.Rules.RegxRule",
    [
        "Indigox.Web.JsLib.Controls.Validation.Rules.Rule",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Rule
    ) {

    var base = Rule.prototype;

    var RegxRule =
        Namespace("Indigox.Web.JsLib.Controls.Validation.Rules")
        .Class("RegxRule")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
            }
        )
        .Members({
            isMatch: function (value) {
                var reg = this.getCondition();
                if (typeof reg == "string") {
                    reg = new RegExp(reg);
                }
                return reg.test(value);
            }
        })
    .$();
});