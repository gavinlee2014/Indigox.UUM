define("Indigox.Web.JsLib.Controls.ListenersFactory",
    [
        "Indigox.Web.JsLib.Collection.Hashtable",
        "Indigox.Web.JsLib.Collection.List",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Hashtable,
        List
) {

    /** @id Indigox.Web.JsLib.Controls.ListenersFactory.listenersMap */
    var listenersMap = new Hashtable();

    var ListenersFactory =
        Namespace("Indigox.Web.JsLib.Controls")
        .Class("ListenersFactory")
        .Constructor(
            function () {
            }
        )
        .Static({
            addListener: function (controlType, listener) {
                var listenersList;
                if (listenersMap.containsKey(controlType)) {
                    listenersList = listenersMap.get(controlType);
                }
                else {
                    listenersList = new List();
                    listenersMap.put(controlType, listenersList);
                }
                listenersList.add(listener);
            },
            removeListener: function (controlType, listener) {
                var listenersList;
                if (listenersMap.containsKey(controlType)) {
                    listenersList = listenersMap.get(controlType);
                }
                else {
                    throw new Error("There is no listener in the ListenersFactory");
                }
                listenersList.remove(listener);
            },
            clearListeners: function () {
                listenersMap.clear();
            },
            createListeners: function (control) {
                if (!control) {
                    return new List();
                }
                var controlType;
                if (isObject(control)) {
                    controlType = control.constructor;
                }
                else {
                    controlType = control;
                }

                var listenersList = null;
                if (listenersMap.containsKey(controlType)) {
                    listenersList = new List();
                    listenersList.addRange(listenersMap.get(controlType));
                }
                if (!listenersList) {
                    return this.createListeners(controlType.superclass);
                }

                return listenersList.toArray();
            }
        })
    .$();

});