﻿define("Indigox.Web.JsLib.Controls.Validation.Rules.LessThanRule",
    [
        "Indigox.Web.JsLib.Controls.Validation.Rules.Rule",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Rule
    ) {

    var base = Rule.prototype;

    var LessThanRule =
        Namespace("Indigox.Web.JsLib.Controls.Validation.Rules")
        .Class("LessThanRule")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.defaultMessageExpression = '输入值须小于${condition}';
            }
        )
        .Members({
            isMatch: function (value) {
                return (value < this.getCondition());
            }
        })
    .$();
});