﻿define("Indigox.Web.JsLib.Controls.Html.Panel",
    [
        "Indigox.Web.JsLib.Controls.FormControl",
        "Indigox.Web.JsLib.Core"
    ],
function (
        FormControl
    ) {

    var base = FormControl.prototype;

    var EVENT_EXPANDED = "expanded",
        EVENT_COLLAPSED = "collapsed";

    var LISTENER_PROPERTY_CHANGING = "PropertyChanging",
        LISTENER_PROPERTY_CHANGED = "PropertyChanged";

    var Panel =
        Namespace("Indigox.Web.JsLib.Controls.Html")
        .Class("Panel")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.title = null;
                this.collapsible = true;
                this.collapsed = true;
            }
        )
        .Members({
            registerEvents: function () {
                base.registerEvents.call(this);
                this.events.registerEvents(
                    EVENT_EXPANDED,
                    EVENT_COLLAPSED
                );
            },

            setTitle: function (value) {
                if (isNullOrUndefined(value)) {
                    return;
                }
                if (this.title === value) {
                    return;
                }
                var oldValue = this.title;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["title", value, oldValue]);
                this.title = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["title", value, oldValue]);
            },
            getTitle: function () {
                return this.title;
            },
            setCollapsed: function (value) {
                if (isNullOrUndefined(value)) {
                    return;
                }
                if (this.collapsed === value) {
                    return;
                }
                var oldValue = this.collapsed;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["collapsed", value, oldValue]);
                this.collapsed = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["collapsed", value, oldValue]);
            },
            getCollapsed: function () {
                return this.collapsed;
            },
            collapse: function () {
                this.setCollapsed(true);
                this.fireEvent(EVENT_COLLAPSED, [this.getCollapsed()]);
            },
            expand: function () {
                this.setCollapsed(false);
                this.fireEvent(EVENT_EXPANDED, [this.getCollapsed()]);
            },
            toggleCollapse: function () {
                if (this.getCollapsed()) {
                    this.expand();
                }
                else {
                    this.collapse();
                }
            }
        })
    .$();
});