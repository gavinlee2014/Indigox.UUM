﻿define("Indigox.Web.JsLib.Controls.Container",
    [
        "Indigox.Web.JsLib.Collection.List",
        "Indigox.Web.JsLib.Utils.ArrayUtil",
        "Indigox.Web.JsLib.Utils.Deferred",
        "Indigox.Web.JsLib.Controls.Control",
        "Indigox.Web.JsLib.Core"
    ],
function (
        List,
        ArrayUtil,
        Deferred,
        Control
) {
    var base = Control.prototype;

    var EVENT_CHILD_ADDING = "childAdding",
        EVENT_CHILD_ADDED = "childAdded",
        EVENT_CHILD_REMOVING = "childRemoving",
        EVENT_CHILD_REMOVED = "childRemoved";

    var LISTENER_INIT = "Init",
        LISTENER_CHILD_ADDING = "ChildAdding",
        LISTENER_CHILD_ADDED = "ChildAdded",
        LISTENER_CHILD_REMOVING = "ChildRemoving",
        LISTENER_CHILD_REMOVED = "ChildRemoved",
        LISTENER_PROPERTY_CHANGING = "PropertyChanging",
        LISTENER_PROPERTY_CHANGED = "PropertyChanged";

    var Container =
        Namespace("Indigox.Web.JsLib.Controls")
        .Class("Container")
        .Extend(base)
        .Constructor(
            function () {
                /** @id Indigox.Web.JsLib.Controls.Container */
                base.constructor.apply(this, arguments);
                /** @id Indigox.Web.JsLib.Controls.Container.prototype.children */
                this.children = [];
            }
        )
        .Members({
            /** @id Indigox.Web.JsLib.Controls.Container.prototype.registerEvents */
            registerEvents: function () {
                base.registerEvents.call(this);
                this.events.registerEvents(
                    EVENT_CHILD_ADDING,
                    EVENT_CHILD_ADDED,
                    EVENT_CHILD_REMOVING,
                    EVENT_CHILD_REMOVED
                );
            },

            /** @id Indigox.Web.JsLib.Controls.Container.prototype.registerEvents */
            registerListeners: function () {
                base.registerListeners.call(this);
                this.listeners.registerListeners(
                    LISTENER_CHILD_ADDING,
                    LISTENER_CHILD_ADDED,
                    LISTENER_CHILD_REMOVING,
                    LISTENER_CHILD_REMOVED
                );
            },

            setID: function (id) {
                base.setID.call(this, id);
                this.updateAllChildrenID(this.getChildren());
            },

            /** @id Indigox.Web.JsLib.Controls.Control.prototype.addChild */
            addChild: function (child) {
                this.insertChild(this.children.length, child);
            },

            /** @id Indigox.Web.JsLib.Controls.Control.prototype.insertChild */
            insertChild: function (index, child) {
                this.fireListener(LISTENER_CHILD_ADDING, [index, child]);
                this.fireEvent(EVENT_CHILD_ADDING, [index, child]);

                this.children.splice(index, 0, child);
                child.setParent(this);
                this.updateChildrenID(this.children, index);

                Deferred.when(this.catchUpLoadChild(child)).done({
                    handler: function () {
                        this.fireListener(LISTENER_CHILD_ADDED, [index, child]);
                        this.fireEvent(EVENT_CHILD_ADDED, [index, child]);
                    },
                    scope: this
                }).fail({
                    handler: function () {
                        debug.error([this.id, " insertChild ", child.id, " failed."].join(""));
                    },
                    scope: this
                });
            },

            catchUpLoadChild: function (child) {
                if (this.isInited()) {
                    child.init();
                }
                if (this.isLoaded()) {
                    return child.load();
                }
            },

            replaceChild: function (index, child) {
                var oldChild = this.children[index];
                if (oldChild) {
                    this.removeChild(oldChild);
                }
                if (child) {
                    this.insertChild(index, child);
                }
            },

            clearChildren: function () {
                var children = this.getChildren();
                for (var i = 0, length = children.length; i < length; i++) {
                    this.removeChild(children[i]);
                }
            },

            /** @id Indigox.Web.JsLib.Controls.Container.prototype.removeChild */
            removeChild: function (child) {
                var index = ArrayUtil.indexOf(this.getChildren(), child);

                this.fireEvent(EVENT_CHILD_REMOVING, [index, child]);
                this.fireListener(LISTENER_CHILD_REMOVING, [index, child]);

                child.unload();
                child.setParent(null);
                this.children.splice(index, 1);
                this.updateChildrenID(this.getChildren(), index);

                this.fireEvent(EVENT_CHILD_REMOVED, [index, child]);
                this.fireListener(LISTENER_CHILD_REMOVED, [index, child]);
            },

            updateAllChildrenID: function (children) {
                if (!children) {
                    return;
                }

                var parentId = this.id,
                    name = null,
                    counts = {};
                for (var i = 0, length = children.length; i < length; i++) {
                    name = children[i].getName();
                    if (!(name in counts)) {
                        counts[name] = 0;
                    }
                    children[i].setID(parentId + "." + name + ":" + counts[name]++);
                }
            },

            updateChildrenID: function (children, index) {
                var i = null,
                    length = null;
                if (index >= children.length) {
                    return;
                }

                var control = children[index],
                    parentId = this.id,
                    name = control.getName(),
                    count = 0;
                for (i = 0, length = index; i < length; i++) {
                    if (children[i].getName() === name) {
                        count++;
                    }
                }
                for (i = index, length = children.length; i < length; i++) {
                    if (children[i].getName() === name) {
                        children[i].setID(parentId + "." + name + ":" + count++);
                    }
                }
            },

            /** @id Indigox.Web.JsLib.Controls.Control.prototype.getFirstChild */
            getFirstChild: function () {
                return this.children[0];
            },

            /** @id Indigox.Web.JsLib.Controls.Control.prototype.getLastChild */
            getLastChild: function () {
                return this.children[this.children.length - 1];
            },

            getChildren: function () {
                return this.children.slice(0);
            },

            setChildren: function (value) {
                if (value.length <= 0) {
                    return;
                }

                this.clearChildren();

                for (var i = 0, length = value.length; i < length; i++) {
                    this.addChild(value[i]);
                }
            },

            /** @id Indigox.Web.JsLib.Controls.Control.prototype.getChild */
            getChild: function (name) {
                if (isInt(name)) {
                    return this.children[name];
                }
                else {
                    var children = this.children,
                        i = null,
                        length = null;
                    for (i = 0, length = children.length; i < length; i++) {
                        if (children[i].id === name) {
                            return children[i];
                        }
                        else if (children[i].name === name) {
                            return children[i];
                        }
                    }
                    return null;
                }
            },

            //TODO : rename findChild
            find: function (name) {
                var childList = new List();
                var child = this.getChild(name);
                if (child) {
                    childList.add(child);
                }
                var children = this.getChildren();
                for (var i = 0, length = children.length; i < length; i++) {
                    if (children[i].find) {
                        var results = children[i].find(name);
                        if (results) {
                            childList.addRange(results);
                        }
                    }
                }
                if (childList.size()) {
                    return childList.toArray();
                }
                return null;
            },

            contains: function (id) {
                var children = this.children,
                    i = null,
                    length = null;
                for (i = 0, length = children.length; i < length; i++) {
                    if (children[i].id === id) {
                        return true;
                    }
                }
                return false;
            },

            setValue: function (value) {
                var oldValue = this.getValue();
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["value", value, oldValue]);

                var children = this.children;
                for (var i = 0, length = children.length; i < length; i++) {
                    var key = children[i].getName();
                    if ((value != null) && (key in value)) {
                        children[i].setValue(value[key]);
                    }
                }
                value = this.getValue();
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["value", value, oldValue]);
            },

            getValue: function () {
                var value = {};
                var children = this.children;
                for (var i = 0, length = children.length; i < length; i++) {
                    var key = children[i].getName();
                    value[key] = children[i].getValue();
                }
                return value;
            },

            setRecord: function (value) {
                this.record = value;
            },

            getRecord: function () {
                return this.record;
            },

            /** @id Indigox.Web.JsLib.Controls.Container.prototype.init */
            init: function () {
                if (this.isInited()) {
                    debug.warn(this.id + "(" + this.defaultName + ") init more than twice. current state is " + this.stateText);
                    //debug.error(this.id + "(" + this.defaultName + ") init more than twice. current state is " + this.stateText);
                    //return;
                }
                this.initChildren();
                this.setInited();
                this.fireListener(LISTENER_INIT);
            },

            initChildren: function () {
                var children = this.getChildren();
                for (var i = 0, length = children.length; i < length; i++) {
                    children[i].init();
                }
            },

            load: function () {
                //debug.log(this.id + " load...");
                this.preLoad();
                this.setLoading();

                // debug code
                this._checkLoadTimeout();

                return Deferred.when(this.doLoad())
                    .then({ handler: this.loadChildren, scope: this })
                    .done({ handler: this.setLoaded, scope: this });
            },

            preLoad: function () {
                base.preLoad.apply(this, arguments);
                this.preLoadChildren();
            },

            preLoadChildren: function () {
                var children = this.getChildren();
                for (var i = 0, length = children.length; i < length; i++) {
                    children[i].preLoad();
                }
            },

            loadChildren: function () {
                var children = this.getChildren();
                var defers = [];
                for (var i = 0, length = children.length; i < length; i++) {
                    defers.push(children[i].load());
                }
                return Deferred.when(defers);
            },

            /** @id Indigox.Web.JsLib.Controls.Container.prototype.unload */
            unload: function () {
                this.unloadChildren();
                base.unload.apply(this, arguments);
            },

            unloadChildren: function () {
                var children = this.getChildren();
                for (var i = 0, length = children.length; i < length; i++) {
                    children[i].unload();
                }
            }
        })
    .$();
});