﻿define("Indigox.Web.JsLib.Controls.Plugins.SummaryFieldPlugin",
    [
        "Indigox.Web.JsLib.Controls.Plugins.Plugin",
        "Indigox.Web.JsLib.Utils.Util",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Plugin,
        Util
) {
    var base = Plugin.prototype;

    var SummaryFieldPlugin =
        Namespace("Indigox.Web.JsLib.Controls.Plugins")
        .Class("SummaryFieldPlugin")
        .Extend(base)
        .Constructor(
            function (option) {
                base.constructor.apply(this, arguments);

                option = Util.copyExist({
                    gridView: "",
                    summaryField: ""
                }, option);
                this.configure(option);
            }
        )
        .Members({
            setSummaryField: function (value) {
                this.summaryField = value;
            },

            getSummaryField: function () {
                return this.summaryField;
            },

            setGridView: function (value) {
                if (isNullOrUndefined(value)) {
                    return;
                }
                this.gridView = value;
                var control = $.GridView(this.gridView).first();
                if (control != null) {
                    control.addListener(this);
                }
            },

            getGridView: function () {
                return this.gridView;
            },

            onSummaryValueChanged: function (source, field, summaryValue) {
                if (this.getSummaryField() == field && this.control != null) {
                    this.control.setValue(summaryValue);
                }
            }
        })
    .$();
});