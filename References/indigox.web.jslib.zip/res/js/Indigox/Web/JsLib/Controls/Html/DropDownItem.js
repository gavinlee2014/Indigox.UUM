﻿define("Indigox.Web.JsLib.Controls.Html.DropDownItem",
    [
        "Indigox.Web.JsLib.Utils.Util",
        "Indigox.Web.JsLib.Controls.Html.CheckBox",
        "Indigox.Web.JsLib.Controls.Html.ItemControl",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Util,
        CheckBox,
        ItemControl
) {
    var base = ItemControl.prototype;

    var EVENT_CLICKED = "clicked",
        EVENT_TEXT_CHANGED = "textChanged",
        EVENT_SELECTED_CHANGED = "selectedChanged";

    var LISTENER_PROPERTY_CHANGING = "PropertyChanging",
        LISTENER_PROPERTY_CHANGED = "PropertyChanged",
        LISTENER_SELECTED_CHANGED = "SelectedChanged";

    var DropDownItem =
        Namespace("Indigox.Web.JsLib.Controls.Html")
        .Class("DropDownItem")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.text = "";
            }
        )
        .Members({
            registerEvents: function () {
                base.registerEvents.call(this);
                this.events.registerEvents(
                    EVENT_CLICKED,
                    EVENT_TEXT_CHANGED,
                    EVENT_SELECTED_CHANGED
                );
            },

            registerListeners: function () {
                base.registerListeners.call(this);
                this.listeners.registerListeners(
                    LISTENER_PROPERTY_CHANGED,
                    LISTENER_SELECTED_CHANGED
                );
            },

            setText: function (value) {
                if (isNullOrUndefined(value)) {
                    return;
                }
                var oldValue = this.text;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["text", value, oldValue]);
                this.text = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["text", value, oldValue]);
                this.fireEvent(EVENT_TEXT_CHANGED, [this.getText()]);
            },

            getText: function () {
                return this.text;
            },

            getSelected: function () {
                return this.selected;
            },

            setSelected: function (value) {
                if (isNullOrUndefined(value) || value === this.selected) {
                    return;
                }

                var oldValue = this.selected;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["selected", value, oldValue]);
                this.selected = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["selected", value, oldValue]);
                this.fireListener(LISTENER_SELECTED_CHANGED, [value]);
                this.fireEvent(EVENT_SELECTED_CHANGED, [value]);
            }
        })
    .$();
});