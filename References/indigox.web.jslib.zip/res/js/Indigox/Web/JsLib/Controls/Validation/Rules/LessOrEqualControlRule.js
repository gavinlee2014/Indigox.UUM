﻿define("Indigox.Web.JsLib.Controls.Validation.Rules.LessOrEqualControlRule",
    [
        "Indigox.Web.JsLib.Controls.Validation.Rules.CompareToControlRule",
        "Indigox.Web.JsLib.Core"
    ],
function (
        CompareToControlRule
    ) {

    var base = CompareToControlRule.prototype;

    var LessOrEqualControlRule =
        Namespace("Indigox.Web.JsLib.Controls.Validation.Rules")
        .Class("LessOrEqualControlRule")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.defaultMessageExpression = '输入值须小于或等于控件${controlName}的值';
            }
        )
        .Members({
            isMatch: function (value) {
                return (value <= this.getCompareToControlValue());
            }
        })
    .$();
});