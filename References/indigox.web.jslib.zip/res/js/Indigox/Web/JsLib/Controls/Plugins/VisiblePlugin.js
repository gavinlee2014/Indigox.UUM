﻿define("Indigox.Web.JsLib.Controls.Plugins.VisiblePlugin",
    [
        "Indigox.Web.JsLib.Controls.Plugins.Plugin",
        "Indigox.Web.JsLib.Utils.Util",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Plugin,
        Util
) {
    var base = Plugin.prototype;

    var VisiblePlugin =
        Namespace("Indigox.Web.JsLib.Controls.Plugins")
        .Class("VisiblePlugin")
        .Extend(base)
        .Constructor(
            function (option) {
                base.constructor.apply(this, arguments);

                option = Util.copyExist({
                    criteria: null
                }, option);
                this.configure(option);
            }
        )
        .Members({
            setCriteria: function (value) {
                this.criteria = value;
            },

            getCriteria: function () {
                return this.criteria;
            },

            setControl: function (control) {
                base.setControl.apply(this, arguments);
                if (control != null) {
                    control.setVisible(false);
                }
            },

            execute: function (record) {
                var control = this.getControl();
                if (!control) {
                    return;
                }

                var matched = true;
                var criteria = this.getCriteria();
                var criteriaIterator = criteria.criteriaList.iterator();
                while (criteriaIterator.hasNext()) {
                    var criterion = criteriaIterator.next();
                    if (!criterion.evaluate(record.data)) {
                        matched = false;
                        break;
                    }
                }

                var setter = control.getSetter("Visible");
                if (control.hasSetter("Visible")) {
                    if (matched) {
                        control[setter](true);
                    }
                    else {
                        control[setter](false);
                    }
                }
                else {
                    throw new Error("The Contorl [" + control.id + "] can not set Visible!");
                }
            }
        })
    .$();
});