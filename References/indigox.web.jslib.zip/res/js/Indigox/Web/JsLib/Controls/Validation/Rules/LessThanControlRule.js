﻿define("Indigox.Web.JsLib.Controls.Validation.Rules.LessThanControlRule",
    [
        "Indigox.Web.JsLib.Controls.Validation.Rules.CompareToControlRule",
        "Indigox.Web.JsLib.Core"
    ],
function (
        CompareToControlRule
    ) {

    var base = CompareToControlRule.prototype;

    var LessThanControlRule =
        Namespace("Indigox.Web.JsLib.Controls.Validation.Rules")
        .Class("LessThanControlRule")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.defaultMessageExpression = '输入值须小于控件${controlName}的值';
            }
        )
        .Members({
            isMatch: function (value) {
                return (value < this.getCompareToControlValue());
            }
        })
    .$();
});