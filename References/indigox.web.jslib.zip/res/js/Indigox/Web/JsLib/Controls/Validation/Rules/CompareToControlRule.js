﻿define("Indigox.Web.JsLib.Controls.Validation.Rules.CompareToControlRule",
    [
        "Indigox.Web.JsLib.Controls.UIEngine",
        "Indigox.Web.JsLib.Controls.Validation.Rules.Rule",
        "Indigox.Web.JsLib.Core"
    ],
function (
        UIEngine,
        Rule
    ) {

    var base = Rule.prototype;

    var CompareToControlRule =
        Namespace("Indigox.Web.JsLib.Controls.Validation.Rules")
        .Class("CompareToControlRule")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
            }
        )
        .Members({
            getControlName: function () {
                return this.getCondition();
            },

            setControlName: function (value) {
                return this.setCondition(value);
            },

            getCompareToControlValue: function () {
                var ctrlName = this.getControlName();
                var ctrl = UIEngine.find(ctrlName).get(0);
                if (!ctrl) {
                    throw '找不到控件：' + ctrlName;
                }
                return ctrl.getValue();
            }
        })
    .$();
});