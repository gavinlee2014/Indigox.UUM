﻿define("Indigox.Web.JsLib.Controls.Html.RichTextBox",
    [
        "Indigox.Web.JsLib.Controls.Html.FieldControl",
        "Indigox.Web.JsLib.Core"
    ],
function (
        FieldControl
    ) {

    var base = FieldControl.prototype;

    var LISTENER_PROPERTY_CHANGING = "PropertyChanging",
        LISTENER_PROPERTY_CHANGED = "PropertyChanged";

    var RichTextBox =
        Namespace("Indigox.Web.JsLib.Controls.Html")
        .Class("RichTextBox")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.value = this.value || "";
                this.mode = this.mode || "simplehtml"; // plaintext, simplehtml, advancehtml
            }
        )
        .Members({
            getMode: function () {
                return this.mode;
            },
            setMode: function (value) {
                var oldValue = this.mode;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["mode", value, oldValue]);
                this.mode = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["mode", value, oldValue]);
            }
        })
    .$();
});