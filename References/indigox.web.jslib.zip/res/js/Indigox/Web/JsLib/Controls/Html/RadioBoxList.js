﻿define("Indigox.Web.JsLib.Controls.Html.RadioBoxList",
    [
        "Indigox.Web.JsLib.Controls.Html.ListControl",
        "Indigox.Web.JsLib.Controls.Html.RadioBox",
        "Indigox.Web.JsLib.Controls.Html.RadioBoxItem",
        "Indigox.Web.JsLib.Controls.Selection.ItemMode",
        "Indigox.Web.JsLib.Core"
    ],
function (
        ListControl,
        RadioBox,
        RadioBoxItem,
        ItemMode
    ) {

    var base = ListControl.prototype;

    var RadioBoxList =
        Namespace("Indigox.Web.JsLib.Controls.Html")
        .Class("RadioBoxList")
        .Extend(base)
        .Constructor(
            function () {
                this.allowDeselect = false;
                base.constructor.apply(this, arguments);
            }
        ) 
        .Members({
            setReadonly: function (readonly) {
                base.setReadonly.apply(this, arguments);
                var items = this.getItems();
                var i = null, length = null;
                for (i = 0, length = items.length; i < length; i++) {
                    items[i].getRadioBox().setEnable(!readonly);
                }
            },

            /**
            * 从传入的参数（Object/String）创建ListItem对象
            * @param {Object} config
            */
            newItem: function (config) {
                var item = new RadioBoxItem();
                var radioBox = new RadioBox();
                item.setRadioBox(radioBox);
                if (config) {
                    item.configure(config);
                }
                return item;
            },

            insertItem: function (index, item) {
                base.insertItem.apply(this, arguments);
                this.items.get(index).addListener(this);
            },

            createSelectionMode: function () {
                var mode = this.mode ? this.mode : "SINGLE";
                var allowDeselect = isNullOrUndefined(this.allowDeselect) ? "true" : this.allowDeselect;
                var selMode = new ItemMode({ mode: mode, allowDeselect: allowDeselect });
                return selMode;
            }
        })
    .$();
});