﻿define("Indigox.Web.JsLib.Controls.Html.ListControl",
    [
        "Indigox.Web.JsLib.Controls.Container",
        "Indigox.Web.JsLib.Collection.List",
        "Indigox.Web.JsLib.Controllers.Controller",
        "Indigox.Web.JsLib.Utils.ArrayUtil",
        "Indigox.Web.JsLib.Utils.Deferred",
        "Indigox.Web.JsLib.Utils.Util",
        "Indigox.Web.JsLib.Controls.Selection.AllAsSelectedMode",
        "Indigox.Web.JsLib.Controls.Template",
        "Indigox.Web.JsLib.Controls.Html.ItemControl",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Container,
        List,
        Controller,
        ArrayUtil,
        Deferred,
        Util,
        AllAsSelectedMode,
        Template,
        ItemControl
    ) {

    var base = Container.prototype;

    var EVENT_VALUE_CHANGED = "valueChanged",
        EVENT_ITEM_ADDING = "itemAdding",
        EVENT_ITEM_ADDED = "itemAdded",
        EVENT_ITEM_REMOVING = "itemRemoving",
        EVENT_ITEM_REMOVED = "itemRemoved",
        EVENT_ITEM_SELECTED_CHANGED = "itemSelectedChanged",
        EVENT_SELECTED_CHANGED = "selectedChanged";

    var LISTENER_PROPERTY_CHANGING = "PropertyChanging",
        LISTENER_PROPERTY_CHANGED = "PropertyChanged",
        LISTENER_ITEM_ADDING = "ItemAdding",
        LISTENER_ITEM_ADDED = "ItemAdded",
        LISTENER_ITEM_REMOVING = "ItemRemoving",
        LISTENER_ITEM_REMOVED = "ItemRemoved",
        LISTENER_ITEM_SELECTED_CHANGED = "ItemSelectedChanged",
        LISTENER_SELECTED_CHANGED = "SelectedChanged";



    var ListControl =
        Namespace("Indigox.Web.JsLib.Controls.Html")
        .Class("ListControl")
        .Extend(base)
        .Constructor(
            function (name) {
                // call base constructor
                base.constructor.apply(this, arguments);
                this.controller = null;
                this.items = new List();
                this.setSelMode(this.createSelectionMode());
            }
        )
        .Members({
            registerEvents: function () {
                base.registerEvents.call(this);
                this.events.registerEvents(
                    EVENT_ITEM_ADDING,
                    EVENT_ITEM_ADDED,
                    EVENT_ITEM_REMOVING,
                    EVENT_ITEM_REMOVED,
                    EVENT_ITEM_SELECTED_CHANGED,
                    EVENT_SELECTED_CHANGED
                );
            },

            registerListeners: function () {
                base.registerListeners.call(this);
                this.listeners.registerListeners(
                    LISTENER_ITEM_ADDING,
                    LISTENER_ITEM_ADDED,
                    LISTENER_ITEM_REMOVING,
                    LISTENER_ITEM_REMOVED,
                    LISTENER_ITEM_SELECTED_CHANGED,
                    LISTENER_SELECTED_CHANGED
                );
            },

            initChildren: function () {
                var children = this.getItems();
                for (var i = 0, length = children.length; i < length; i++) {
                    children[i].init();
                }
            },

            load: function () {
                return base.load.apply(this, arguments);
            },

            doLoad: function (defer) {
                var dfd = new Deferred();
                if (this.getController() && this.getController().getAutoLoad() == true) {
                    this.getController().load(function () {
                        dfd.resolve();
                    });
                }
                else {
                    dfd.resolve();
                }
                return dfd.promise();
            },

            preLoadChildren: function () {
                var children = this.getItems();
                for (var i = 0, length = children.length; i < length; i++) {
                    children[i].preLoad();
                }
            },

            loadChildren: function () {
                var children = this.getItems();
                var defers = [];
                for (var i = 0, length = children.length; i < length; i++) {
                    defers.push(children[i].load());
                }
                return Deferred.when(defers);
            },

            unload: function () {
                base.unload.apply(this, arguments);
                if (this.getController()) {
                    this.getController().unload();
                }
            },

            unloadChildren: function () {
                var children = this.getItems();
                for (var i = 0, length = children.length; i < length; i++) {
                    children[i].unload();
                }
            },

            setID: function (id) {
                base.setID.call(this, id);
                this.updateAllChildrenID(this.items.toArray());
            },

            setController: function (controller) {
                if (!(controller instanceof Controller)) {
                    var controllerInfo = controller;
                    controller = Type.forAlias(controllerInfo.controllerType).createInstance();
                    controller.configure(controllerInfo);
                }

                if (this.controller) {
                    this.controller.setView(null);
                }
                this.controller = controller;
                if (this.controller) {
                    this.controller.setView(this);
                }
                this.clearItems();
                if (this.isLoaded() && this.controller.autoLoad === true) {
                    this.controller.load();
                }
            },

            getController: function () {
                return this.controller;
            },

            setValue: function (value) {
                if (isUndefined(value) || !this.getSelMode().isValueChanged(this.value, value)) {
                    return;
                }

                var oldValue = this.value;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["value", value, oldValue]);

                this.value = value;
                this.getSelMode().select(value, false);

                this.fireListener(LISTENER_PROPERTY_CHANGED, ["value", value, oldValue]);
                this.fireEvent(EVENT_VALUE_CHANGED, [value]);
            },

            getValue: function () {
                return this.value;
            },

            insertChild: function (index, item) {
                this.insertItem(index, item);
            },

            removeChild: function (item) {
                this.removeItem(item);
            },
            /**
            * 从传入的参数（Object/String）创建ItemControl对象
            * @alias Indigox.Web.JsLib.Controls.Html.ListControl.prototype.newItem
            * @param {Object} value
            */
            newItem: function (value) {
                // virtual method, implement by extend classes
            },

            /**
            * 添加选项
            * @alias Indigox.Web.JsLib.Controls.Html.ListControl.prototype.addItems
            * @param {ItemControl} item
            */
            addItem: function (item) {
                var items = this.getItems();
                this.insertItem(items.length, item);
            },

            /**
            * 添加选项
            * @alias Indigox.Web.JsLib.Controls.Html.ListControl.prototype.addItems
            * @param {Array} range
            */
            addItems: function (range) {
                for (var i = 0, item; item = range[i]; i++) {
                    this.addItem(item);
                }
            },

            /**
            * 插入选项
            * @alias Indigox.Web.JsLib.Controls.Html.ListControl.prototype.insertItem
            * @param {Int} index
            * @param {ItemControl} item
            */
            insertItem: function (index, item) {
                var items = this.getItems();
                if (index > items.length) {
                    throw new Error("out of range");
                }
                if (item instanceof Template) {
                    this.setItemTemplate(item);
                    this.items.insert(index, item);
                }
                else {
                    if (!(item instanceof ItemControl)) {
                        item = this.newItem(item);
                    }
                    this.items.insert(index, item);
                    item.setParent(this);
                    item.addListener(this);
                    this.updateChildrenID(this.items.toArray(), index);

                    this.fireListener(LISTENER_ITEM_ADDING, [index, item]);
                    this.fireEvent(EVENT_ITEM_ADDING, [index, item]);

                    if (this.isInited()) {
                        item.init();
                    }
                    if (this.isLoaded()) {
                        Deferred.when(item.load()).done({
                            handler: function () {
                                this.fireListener(LISTENER_ITEM_ADDED, [index, item]);
                                this.fireEvent(EVENT_ITEM_ADDED, [index, item]);
                            },
                            scope: this
                        }).fail({
                            handler: function () {
                                debug.error([this.id, " insertItem ", item.id, " failed."].join(""));
                            },
                            scope: this
                        });
                    }
                    else {
                        this.fireListener(LISTENER_ITEM_ADDED, [index, item]);
                        this.fireEvent(EVENT_ITEM_ADDED, [index, item]);
                    }
                }
            },

            /**
            * 插入选项
            * @alias Indigox.Web.JsLib.Controls.Html.ListControl.prototype.insertItem
            * @param {Int} index
            * @param {Arrat} range
            */
            insertItems: function (index, range) {
                var i = null, item = null;
                for (i = range.length - 1; i >= 0; i--) {
                    item = range[i];
                    this.insertItem(index, item);
                }
            },

            /**
            * 移除选项
            * @alias Indigox.Web.JsLib.Controls.Html.ListControl.removeItem
            * @param {ItemControl} item
            */
            removeItem: function (item) {
                var items = this.getItems();
                var index = ArrayUtil.indexOf(items, item);

                //base.removeChild.call(this, item);

                this.fireListener(LISTENER_ITEM_REMOVING, [index, item]);
                this.fireEvent(EVENT_ITEM_REMOVED, [index, item]);
                this.items.remove(item);
                item.unload();
                item.setParent(null);
                this.updateChildrenID(this.items.toArray(), index);
                this.fireEvent(EVENT_ITEM_REMOVED, [index, item]);
                this.fireListener(LISTENER_ITEM_REMOVED, [index, item]);
            },

            /**
            * 移除选项
            * @alias Indigox.Web.JsLib.Controls.Html.ListControl.removeItem
            * @param {Array} range
            */
            removeItems: function (range) {
                var items = this.getItems();
                var i = null, length = null;
                for (i = 0, length = items.length; i < length; i++) {
                    var j = null, length1 = null;
                    for (j = 0, length1 = range.length; j < length1; j++) {
                        if (items[i] === range[j]) {
                            this.removeItem(items[i]);
                            break;
                        }
                    }
                }
            },

            /**
            * 清空选项
            * @alias Indigox.Web.JsLib.Controls.Html.ListControl.clearItems
            */
            clearItems: function () {
                var items = this.getItems();
                var i = null, length = null;
                for (i = 0, length = items.length; i < length; i++) {
                    this.removeItem(items[i]);
                }
            },

            setItems: function (value) {
                this.clearItems();
                this.addItems(value);
            },

            getItems: function () {
                return this.items.toArray();
            },

            deselectItem: function (deselectValue) {
                var items = this.getItems();
                var i = 0, length = items.length;
                for (; i < length; i++) {
                    if (items[i].getValue() == deselectValue) {
                        items[i].setSelected(false);
                    }
                }
            },

            selectItem: function (selectValue) {
                var items = this.getItems();
                var i = 0, length = items.length;
                for (; i < length; i++) {
                    if (items[i].getValue() == selectValue) {
                        items[i].setSelected(true);
                    }
                }
            },

            getSelMode: function () {
                return this.selMode;
            },

            setSelMode: function (value) {
                if (this.selMode) {
                    this.removeListener(this.selMode);
                }
                this.selMode = value;
                if (this.selMode) {
                    this.selMode.bindControl(this);
                }
            },

            createSelectionMode: function () {
                var selMode = new AllAsSelectedMode({});
                return selMode;
            },

            getAllowDeselect: function () {
                if (this.getSelMode()) {
                    return this.getSelMode().getAllowDeselect();
                }
            },

            setAllowDeselect: function (value) {
                if (this.getSelMode()) {
                    return this.getSelMode().setAllowDeselect(value);
                }
            },

            getReturnValueType: function (type) {
                if (this.getSelMode()) {
                    return this.getSelMode().returnValueType;
                }
                return "ARRAY";
            },

            setReturnValueType: function (type) {
                if (this.getSelMode()) {
                    this.getSelMode().returnValueType = type;
                }
            },

            getMode: function () {
                if (this.getSelMode()) {
                    return this.getSelMode().getSelectionMode();
                }
            },

            setMode: function (value) {
                if (this.getSelMode()) {
                    this.getSelMode().setSelectionMode(value);
                }
            },

            isEditable: function () {
                return true;
            },

            /**
            * 获取已选中的可选项
            * @alias Indigox.Web.JsLib.Controls.Html.ListControl.getSelectedItems
            * @return {Array}
            */
            getSelectedItems: function () {
                var selectedItems = [],
                    items = this.getItems();
                var i = null, length = null;
                for (i = 0, length = items.length; i < length; i++) {
                    if (items[i].getSelected()) {
                        selectedItems.push(items[i]);
                    }
                }
                return selectedItems;
            },

            /**
            * 选中传入参数的值
            * @alias Indigox.Web.JsLib.Controls.Html.ListControl.selectAll
            */
            select: function (values) {
                this.setValue(values);
            },

            /**
            * 选中所有项
            * @alias Indigox.Web.JsLib.Controls.Html.ListControl.selectAll
            */
            selectAll: function () {
                var items = this.items;
                for (var i = 0, length = items.length; i < length; i++) {
                    items[i].setSelected(true);
                }
            },

            /**
            * 取消所有项
            * @alias Indigox.Web.JsLib.Controls.Html.ListControl.unselectAll
            */
            unselectAll: function () {
                var items = this.items;
                for (var i = 0, length = items.length; i < length; i++) {
                    items[i].setSelected(false);
                }
            },

            /**
            * 反选
            * @alias Indigox.Web.JsLib.Controls.Html.ListControl.reverse
            */
            reverse: function () {
                var items = this.items;
                for (var i = 0, length = items.length; i < length; i++) {
                    items[i].setSelected(items[i].getSelected());
                }
            },

            /**
            * A listener handler, bind on ItemControl
            */
            onSelectedChanged: function (source, selected) {
                //TODO: 另建一个绑定对象，事件触发时调用 onItemSelectedChanged 方法
                this.fireListener(LISTENER_ITEM_SELECTED_CHANGED, [source, selected]);
                this.fireEvent(EVENT_ITEM_SELECTED_CHANGED, [source, selected]);
            }
        })
    .$();
});