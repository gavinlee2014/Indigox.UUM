﻿define("Indigox.Web.JsLib.Controls.Html.Contact",
    [
        "Indigox.Web.JsLib.Controls.Control",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Control
) {
    var base = Control.prototype;

    var LISTENER_PROPERTY_CHANGING = "PropertyChanging",
        LISTENER_PROPERTY_CHANGED = "PropertyChanged";

    var Contact =
        Namespace("Indigox.Web.JsLib.Controls.Html")
        .Class("Contact")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.text = "";
                this.presence = "";
            }
        )
        .Static({
            PRESENCE_ONLINE: "online",
            PRESENCE_OFFLINE: "offline",
            PRESENCE_AWAY: "away",
            PRESENCE_BUSY: "busy",
            PRESENCE_NOTDISTURB: "notdisturb",
            PRESENCE_UNKNOWN: "unknown"
        })
        .Members({
            getText: function () {
                if (!isNullOrUndefined(this.value)) {
                    return this.value.Name;
                }
                else {
                    return "";
                }
            },

            setValue: function (value) {
                var oldText = this.getText();
                base.setValue.apply(this, arguments);
                var newText = this.getText();
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["text", newText, oldText]);
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["text", newText, oldText]);
            },

            getPresence: function () {
                return this.presence;
            },

            setPresence: function (value) {
                if (value == this.getPresence()) {
                    return;
                }
                var oldValue = this.presence;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["presence", value, oldValue]);
                this.presence = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["presence", value, oldValue]);
            }
        })
    .$();
});