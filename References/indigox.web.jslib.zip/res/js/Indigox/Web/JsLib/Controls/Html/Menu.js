﻿define("Indigox.Web.JsLib.Controls.Html.Menu",
    [
        "Indigox.Web.JsLib.Controls.Selection.NodeMode",
        "Indigox.Web.JsLib.Controls.Html.HierarchyControl",
        "Indigox.Web.JsLib.Core"
    ],
function (
        NodeMode,
        HierarchyControl
    ) {

    var base = HierarchyControl.prototype;

    var LISTENER_PROPERTY_CHANGING = "PropertyChanging",
        LISTENER_PROPERTY_CHANGED = "PropertyChanged";

    var Menu =
        Namespace("Indigox.Web.JsLib.Controls.Html")
        .Class("Menu")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.controller = null;
                this.orientation = Menu.ORIENTATION_HORIZONTAL;
                this.staticDisplayLevels = 1;
                this.menuItemType = "menuitem";
                this.actionMode = Menu.ACTION_MODE_MOUSEOVER;

                // selMode is inhiret from HierarchyControl
                this.setSelMode(new NodeMode({ mode: "SINGLE", allowDeselect: false }));
            }
        )
        .Static({
            ORIENTATION_HORIZONTAL: 0,
            ORIENTATION_VERTICAL: 1,
            ACTION_MODE_MOUSEOVER: 0,
            ACTION_MODE_CLICK: 1
        })
        .Members({
            setOrientation: function (value) {
                var oldValue = this.orientation;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["orientation", value, oldValue]);
                this.orientation = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["orientation", value, oldValue]);
            },

            getOrientation: function () {
                return this.orientation;
            },

            setStaticDisplayLevels: function (value) {
                var oldValue = this.staticDisplayLevels;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["staticDisplayLevels", value, oldValue]);
                this.staticDisplayLevels = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["staticDisplayLevels", value, oldValue]);
            },

            getStaticDisplayLevels: function () {
                return this.staticDisplayLevels;
            },

            setActionMode: function (value) {
                var oldValue = this.actionMode;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["actionMode", value, oldValue]);
                this.actionMode = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["actionMode", value, oldValue]);
            },

            getActionMode: function () {
                return this.actionMode;
            },

            getLevel: function () {
                return 0;
            },

            getSelectedText: function () {
                var nodes = this.getNodes();
                for (var i = 0, length = nodes.length; i < length; i++) {
                    var node = nodes[i];
                    if (node.selected === true) {
                        return node.getText();
                    }
                }
                return "";
            },

            onSelectedChanged: function (source, selected) {
                base.onSelectedChanged.apply(this, arguments);
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["selectedText", this.getSelectedText()]);
            },

            expandNode: function (node) {
                var controller = this.getController();
                if (controller) {
                    controller.setRelated(node.getRecord());
                    controller.load();
                }
                node.childLoaded = true;
            },

            newNode: function (config) {
                var node = Type.forAlias(this.menuItemType).createInstance();
                node.setRoot(this);
                if (config) {
                    node.configure(config);
                }
                return node;
            }
        })
    .$();
});