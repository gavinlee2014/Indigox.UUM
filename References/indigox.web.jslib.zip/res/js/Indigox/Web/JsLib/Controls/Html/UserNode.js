﻿define("Indigox.Web.JsLib.Controls.Html.UserNode",
    [
        "Indigox.Web.JsLib.Controls.Html.ItemControl",
        "Indigox.Web.JsLib.Core"
    ],
function (
        ItemControl
    ) {
    var base = ItemControl.prototype;

    var EVENT_VALUE_CHANGED = "valueChanged",
        EVENT_TEXT_CHANGED = "textChanged";

    var LISTENER_PROPERTY_CHANGING = "PropertyChanging",
        LISTENER_PROPERTY_CHANGED = "PropertyChanged",
        LISTENER_VALUE_CHANGED = "ValueChanged",
        LISTENER_TEXT_CHANGED = "TextChanged";

    var UserNode =
        Namespace("Indigox.Web.JsLib.Controls.Html")
        .Class("UserNode")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.text = this.text || "";
                this.value = this.value || "";
            }
        )
        .Members({
            getValue: function () {
                return this.value;
            },

            getText: function () {
                return this.text;
            },

            setValue: function (value) {
                var oldValue = this.value;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["value", value, oldValue]);
                this.value = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["value", value, oldValue]);

                this.fireEvent(EVENT_VALUE_CHANGED, [this.value]);
            },

            setText: function (value) {
                var oldValue = this.text;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["text", value, oldValue]);
                this.text = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["text", value, oldValue]);

                this.fireEvent(EVENT_TEXT_CHANGED, [this.text]);
            },

            setUserName: function (value) {
                this.setText(value);
            },
            getUserName: function () {
                return this.getText();
            },
            setUserID: function (value) {
                this.setValue(value);
            },
            getUserID: function () {
                return this.getValue();
            },
            registerEvents: function () {
                base.registerEvents.call(this);
                this.events.registerEvents(
                    EVENT_VALUE_CHANGED,
                    EVENT_TEXT_CHANGED
                );
            },

            registerListeners: function () {
                base.registerListeners.call(this);
                this.listeners.registerListeners(
                    LISTENER_VALUE_CHANGED,
                    LISTENER_TEXT_CHANGED
                );
            }
        }).$();
});