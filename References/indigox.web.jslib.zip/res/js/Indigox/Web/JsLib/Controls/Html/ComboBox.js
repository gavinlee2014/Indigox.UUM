﻿define("Indigox.Web.JsLib.Controls.Html.ComboBox",
    [
        "Indigox.Web.JsLib.Utils.Util",
        "Indigox.Web.JsLib.Collection.List",
        "Indigox.Web.JsLib.Utils.ArrayUtil",
        "Indigox.Web.JsLib.Utils.DelayedTask",
        "Indigox.Web.JsLib.Utils.Deferred",
        "Indigox.Web.JsLib.Controls.Html.ListControl",
        "Indigox.Web.JsLib.Controls.Html.ComboItem",
        "Indigox.Web.JsLib.Controls.Html.ComboNode",
        "Indigox.Web.JsLib.Core"
    ],
    function (
        Util,
        List,
        ArrayUtil,
        DelayedTask,
        Deferred,
        ListControl,
        ComboItem,
        ComboNode
    ) {

        var base = ListControl.prototype;

        var EVENT_NODE_ADDING = "nodeAdding",
            EVENT_NODE_ADDED = "nodeAdded",
            EVENT_NODE_REMOVING = "nodeRemoving",
            EVENT_NODE_REMOVED = "nodeRemoved";

        var LISTENER_NODE_ADDING = "NodeAdding",
            LISTENER_NODE_ADDED = "NodeAdded",
            LISTENER_NODE_REMOVING = "NodeRemoving",
            LISTENER_NODE_REMOVED = "NodeRemoved";

        var ComboBox =
            Namespace("Indigox.Web.JsLib.Controls.Html")
            .Class("ComboBox")
            .Extend(base)
            .Constructor(
                function () {
                    this.nodes = new List();
                    this.delayedTask = null;
                    base.constructor.apply(this, arguments);
                }
            )
            .Members({
                registerEvents: function () {
                    base.registerEvents.call(this);
                    this.events.registerEvents(
                        EVENT_NODE_ADDING,
                        EVENT_NODE_ADDED,
                        EVENT_NODE_REMOVING,
                        EVENT_NODE_REMOVED
                    );
                },

                registerListeners: function () {
                    base.registerListeners.call(this);
                    this.listeners.registerListeners(
                        LISTENER_NODE_ADDING,
                        LISTENER_NODE_ADDED,
                        LISTENER_NODE_REMOVING,
                        LISTENER_NODE_REMOVED
                    );
                },



                getValue: function () {
                    var nodes = this.getNodes();
                    var values = [], node;
                    for (var i in nodes) {
                        node = nodes[i];
                        values.push({
                            value: node.getValue(),
                            text: node.getText()
                        });
                    }
                    return values;
                },

                setValue: function (value) {
                    if (Object.prototype.toString.call(value) != '[object Array]') {
                        value = [value];
                    }
                    var length = this.getNodes().length();
                    for (var i in value) {
                        var newNode = this.newNode(value[i].getText(), value[i].getValue());
                        this.insertNode(length, newNode);
                        length = length + 1;
                    }
                },

                newItem: function (config) {
                    var item = new ComboItem();
                    item.configure(config);
                    return item;
                },

                newNode: function (text, value) {
                    var node = new ComboNode();
                    node.setText(text);
                    node.setValue(value);
                    return node;
                },

                getNodes: function () {
                    return this.nodes.toArray();
                },

                insertNode: function (index, node) {
                    var nodes = this.getNodes();
                    if (index > nodes.length) {
                        throw new Error("out of range");
                    }

                    this.nodes.insert(index, node);
                    node.setParent(this);
                    node.addListener(this);
                    this.updateChildrenID(this.nodes.toArray(), index);

                    this.fireListener(LISTENER_NODE_ADDING, [index, node]);
                    this.fireEvent(EVENT_NODE_ADDING, [index, node]);

                    Deferred.when(this.catchUpLoadChild(node)).done({
                        handler: function () {
                            this.fireListener(LISTENER_NODE_ADDED, [index, node]);
                            this.fireEvent(EVENT_NODE_ADDED, [index, node]);
                        },
                        scope: this
                    }).fail({
                        handler: function () {
                            debug.error([this.id, "insertNode ", node.id, " failed."].join(""));
                        },
                        scope: this
                    });
                },

                removeNode: function (node) {
                    var nodes = this.getNodes();
                    var index = ArrayUtil.indexOf(nodes, node);

                    this.fireListener(LISTENER_NODE_REMOVING, [index, node]);
                    this.fireEvent(EVENT_NODE_REMOVED, [index, node]);
                    this.nodes.remove(node);
                    node.unload();
                    node.setParent(null);
                    this.updateChildrenID(this.nodes.toArray(), index);
                    this.fireEvent(EVENT_NODE_REMOVED, [index, node]);
                    this.fireListener(LISTENER_NODE_REMOVED, [index, node]);
                },

                search: function (condition) {
                    if (this.delayedTask) {
                        this.delayedTask.cancel();
                    }

                    this.delayedTask = new DelayedTask(function (condition) {
                        this.doSearch(condition);
                        this.delayedTask = null;
                    }, this, [condition]);

                    this.delayedTask.delay(50);
                },

                doSearch: function (condition) {
                    var controller = this.getController();
                    controller.setDefaultParamValue(condition);
                    controller.load();
                },

                onSelectedChanged: function (source) {
                    var node = this.newNode(source.getText(), source.getValue());
                    this.insertNode(this.nodes.size(), node);

                    this.getController().clearModel();
                }

            })
        .$();
    });