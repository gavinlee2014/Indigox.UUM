﻿define("Indigox.Web.JsLib.Controls.Html.ItemControl",
    [
        "Indigox.Web.JsLib.Controls.Container",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Container
) {
    var base = Container.prototype;

    var EVENT_CLICKED = "clicked",
        EVENT_SELECTED_CHANGED = "selectedChanged";

    var LISTENER_CLICKED = "Clicked",
        LISTENER_SELECTED_CHANGED = "SelectedChanged",
        LISTENER_PROPERTY_CHANGING = "PropertyChanging",
        LISTENER_PROPERTY_CHANGED = "PropertyChanged";

    var ItemControl =
        Namespace("Indigox.Web.JsLib.Controls.Html")
        .Class("ItemControl")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.selected = false;
            }
        )
        .Members({
            registerEvents: function () {
                base.registerEvents.call(this);
                this.events.registerEvents(
                    EVENT_SELECTED_CHANGED,
                    EVENT_CLICKED
                );
            },

            registerListeners: function () {
                base.registerListeners.call(this);
                this.listeners.registerListeners(
                    LISTENER_SELECTED_CHANGED,
                    LISTENER_CLICKED
                );
            },

            setValue: function (value) {
                if (isUndefined(value)) {
                    return;
                }
                var oldValue = this.value;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["value", value, oldValue]);
                this.value = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["value", value, oldValue]);
            },

            getValue: function () {
                return this.value;
            },

            setSelected: function (value) {
                if (isNullOrUndefined(value) || value === this.selected) {
                    return;
                }

                var oldValue = this.selected;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["selected", value, oldValue]);
                this.selected = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["selected", value, oldValue]);
                this.fireListener(LISTENER_SELECTED_CHANGED, [value]);
                this.fireEvent(EVENT_SELECTED_CHANGED, [value]);
            },

            getSelected: function () {
                return this.selected;
            },

            toggleSelected: function () {
                this.setSelected(!this.getSelected());
            }
        })
    .$();
});