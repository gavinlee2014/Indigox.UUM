﻿define("Indigox.Web.JsLib.Controls.Plugins.PluginFactory",
    [
        "Indigox.Web.JsLib.Collection.Hashtable",
        "Indigox.Web.JsLib.Collection.List",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Hashtable,
        List
) {
    var instance = null;

    var PluginFactory =
        Namespace("Indigox.Web.JsLib.Controls.Plugins")
        .Class("PluginFactory")
        .Constructor(
            function () {
                this.pluginMappings = {};
            }
        )
        .Static({
            getInstance: function () {
                if (instance === null) {
                    instance = new PluginFactory();
                }
                return instance;
            }
        })
        .Members({
            registerPlugin: function (alias, plugin) {
                this.pluginMappings[alias] = plugin;
            },

            unregisterPlugin: function (alias) {
                if (alias in this.pluginMappings) {
                    delete this.pluginMappings[alias];
                }
            },

            createPlugin: function (pluginName, config) {
                var pluginType = this.pluginMappings[pluginName.toLowerCase()];
                if (isNullOrUndefined(pluginType)) {
                    throw new Error("Can not create Plugin for \"" + pluginName + "\"");
                }
                else {
                    var plugin = Type.forClass(pluginType).createInstance();
                    plugin.configure(config);
                    return plugin;
                }
            }
        })
    .$();
});