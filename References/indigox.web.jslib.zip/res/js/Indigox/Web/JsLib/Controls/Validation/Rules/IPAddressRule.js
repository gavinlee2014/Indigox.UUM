﻿define("Indigox.Web.JsLib.Controls.Validation.Rules.IPAddressRule",
    [
        "Indigox.Web.JsLib.Controls.Validation.Rules.Rule",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Rule
    ) {

    var base = Rule.prototype;

    var IPAddressRule =
        Namespace("Indigox.Web.JsLib.Controls.Validation.Rules")
        .Class("IPAddressRule")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
            }
        )
        .Members({
            isMatch: function (value) {
                var reg = /^(?:[0-9]|[1-9][0-9]|1[0-9]{2}|2(?:[0-4][0-9]|5[0-5]))(?:\.(?:[0-9]|[1-9][0-9]|1[0-9]{2}|2(?:[0-4][0-9]|5[0-5]))){3}$/g;
                return reg.test(value);
            }
        })
    .$();
});