﻿define("Indigox.Web.JsLib.Controls.Html.DropDownList",
    [
        "Indigox.Web.JsLib.Controls.Html.DropDownItem",
        "Indigox.Web.JsLib.Controls.Html.BlankDropDownItem",
        "Indigox.Web.JsLib.Controls.Selection.ItemMode",
        "Indigox.Web.JsLib.Utils.Util",
        "Indigox.Web.JsLib.Utils.ArrayUtil",
        "Indigox.Web.JsLib.Controls.Html.ListControl",
        "Indigox.Web.JsLib.Core"
    ],
    function (
        DropDownItem,
        BlankDropDownItem,
        ItemMode,
        Util,
        ArrayUtil,
        ListControl
    ) {
        var LISTENER_PROPERTY_CHANGING = "PropertyChanging",
            LISTENER_PROPERTY_CHANGED = "PropertyChanged";

        var base = ListControl.prototype;

        var DropDownList =
            Namespace("Indigox.Web.JsLib.Controls.Html")
            .Class("DropDownList")
            .Extend(base)
            .Constructor(
                function () {
                    this.allowDeselect = false;
                    this.allowBlank = false;
                    this.blankText = "请选择...";
                    base.constructor.apply(this, arguments);
                }
            )
            .Members({
                getReadonly: function () {
                    return base.getReadonly.apply(this, arguments);
                },

                setReadonly: function (value) {
                    base.setReadonly.apply(this, arguments);
                    this.setEnable(!value);
                },

                getAllowBlank: function () {
                    return this.allowBlank;
                },

                setAllowBlank: function (value) {
                    var oldValue = this.allowBlank;
                    this.fireListener(LISTENER_PROPERTY_CHANGING, ["allowBlank", value, oldValue]);
                    this.allowBlank = value;
                    this.fireListener(LISTENER_PROPERTY_CHANGED, ["allowBlank", value, oldValue]);

                    if (this.allowBlank) {
                        base.insertItem.call(this, 0, this.newBlankItem({
                            text: this.getBlankText()
                        }));
                    }
                    else {
                        if ((this.getItems().length > 0) && (this.getItems()[0] instanceof BlankDropDownItem)) {
                            base.removeItem.call(this, this.getItems()[0]);
                        }
                    }
                },

                getBlankText: function () {
                    return this.blankText;
                },

                setBlankText: function (value) {
                    var oldValue = this.blankText;
                    this.fireListener(LISTENER_PROPERTY_CHANGING, ["blankText", value, oldValue]);
                    this.blankText = value;
                    this.fireListener(LISTENER_PROPERTY_CHANGED, ["blankText", value, oldValue]);

                    if ((this.getItems().length > 0) && (this.getItems()[0] instanceof BlankDropDownItem)) {
                        this.getItems()[0].setText(this.blankText);
                    }
                },

                /**
                * 从传入的参数（Object/String）创建ListItem对象
                * @param {Object} config
                */
                newItem: function (config) {
                    var item = new DropDownItem();
                    item.configure(config);
                    return item;
                },

                newBlankItem: function (config) {
                    var item = new BlankDropDownItem();
                    item.configure(config);
                    return item;
                },

                removeItem: function (item) {
                    if (item instanceof BlankDropDownItem) {
                        return;
                    }
                    base.removeItem.apply(this, arguments);
                },

                insertItem: function (index, item) {
                    if (item instanceof BlankDropDownItem) {
                        return;
                    }
                    base.insertItem.call(this, index, item);

                    //if ((this.getItems().length > 0) && (this.getItems()[0] instanceof BlankDropDownItem)) {
                    //    base.insertItem.call(this, index + 1, item);
                    //}
                    //else {
                    //    base.insertItem.call(this, index, item);
                    //}
                },

                load: function () {
                    var promise = base.load.apply(this, arguments).done({
                        handler: function () {
                            if ((isNullOrUndefined(this.value) || this.value.length === 0) && this.getItems().length > 0) {
                                this.getItems()[0].setSelected(true);
                            }
                        },
                        scope: this
                    });
                    return promise;
                },

                change: function (value) {
                    var items = this.getItems();
                    var i = null,
                        length = items.length;
                    for (i = 0; i < length; i++) {
                        if (items[i].getValue() == value) {
                            items[i].setSelected(true);
                            break;
                        }
                    }
                },

                createSelectionMode: function () {
                    var mode = this.mode ? this.mode : "SINGLE";
                    var allowDeselect = isNullOrUndefined(this.allowDeselect) ? "true" : this.allowDeselect;
                    var selMode = new ItemMode({ mode: mode, allowDeselect: allowDeselect });
                    return selMode;
                }
            })
        .$();
    });