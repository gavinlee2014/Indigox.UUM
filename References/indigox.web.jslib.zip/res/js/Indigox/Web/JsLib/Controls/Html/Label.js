﻿define("Indigox.Web.JsLib.Controls.Html.Label",
    [
        "Indigox.Web.JsLib.Controls.Control",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Control
) {
    var base = Control.prototype;

    var Label =
        Namespace("Indigox.Web.JsLib.Controls.Html")
        .Class("Label")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
            }
        )
        .Members({
            isEditable: function () {
                return false;
            },

            getValue: function () {
                if (isNullOrUndefined(this.value)) {
                    return "";
                }
                return this.value;
            }
        })
    .$();
});