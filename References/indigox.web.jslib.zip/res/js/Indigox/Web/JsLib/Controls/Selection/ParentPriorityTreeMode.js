﻿define("Indigox.Web.JsLib.Controls.Selection.ParentPriorityTreeMode",
    [
        "Indigox.Web.JsLib.Controls.Selection.TreeMode",
        "Indigox.Web.JsLib.Controls.Html.TreeNode",
        "Indigox.Web.JsLib.Collection.List",
        "Indigox.Web.JsLib.Core"
    ],
function (
        TreeMode,
        TreeNode,
        List
) {

    var base = TreeMode.prototype;

    /*-------------------------------------------------------------------
    *
    *  父级优先选择模式
    *
    *  当所有的子节点都被选中时，getSelectedValues 仅返回选中的父级节点
    *
    *-------------------------------------------------------------------*/
    var ParentPriorityTreeMode =
        Namespace("Indigox.Web.JsLib.Controls.Selection")
        .Class("ParentPriorityTreeMode")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.selection = new List();
            }
        )
        .Members({
            setControlSelected: function (data, node, isSelected) {
                if (isSelected) {
                    this.control.selectNode(data);
                } else {
                    this.control.deselectNode(data);
                }

                var node = this.control.findNodeByValue(data);
                if (!isNullOrUndefined(node)) {
                    var parent = node.getParent();

                    if (isSelected) {
                        this.removeChildrenSelection(node);
                        if (!(parent instanceof TreeNode) || !parent.getSelected()) {
                            this.selection.add(data);
                        }
                    } else {
                        this.selection.remove(data);
                        this.addChildrenSelection(node);
                    }

                    this.trySelectChildNode(node, isSelected);
                    this.trySelectParentNode(node, isSelected);
                }
            },

            removeChildrenSelection: function (parent) {
                var i = null;
                var length = null;
                var childNodes = parent.getChildNodes();
                for (i = 0, length = childNodes.length; i < length; i++) {
                    this.selection.remove(childNodes[i].getValue());
                }
            },

            addChildrenSelection: function (parent) {
                var i = null;
                var length = null;
                var childNodes = parent.getChildNodes();
                for (i = 0, length = childNodes.length; i < length; i++) {
                    var childValue = childNodes[i].getValue();
                    if (this.isSelected(childValue) && !this.selection.contains(childValue)) {
                        this.selection.add(childValue);
                    }
                }
            },

            /**
            * 返回所有选中项中最顶级项的 value
            */
            getValueItems: function () {
                return this.selection;
            }
        })
    .$();

});