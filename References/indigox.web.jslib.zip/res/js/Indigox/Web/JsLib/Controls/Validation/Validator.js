﻿define("Indigox.Web.JsLib.Controls.Validation.Validator",
    [
        "Indigox.Web.JsLib.Utils.StringUtil",
        "Indigox.Web.JsLib.Controls.Validation.ValidateRuleFactory",
        "Indigox.Web.JsLib.Controls.Control",
        "Indigox.Web.JsLib.Controls.Grid.GridView",
        "Indigox.Web.JsLib.Controls.Container"
    ],
function (
        StringUtil,
        ValidateRuleFactory,
        Control,
        GridView,
        Container
) {
    var LISTENER_PROPERTY_CHANGING = "PropertyChanging",
        LISTENER_PROPERTY_CHANGED = "PropertyChanged";

    var base = Control.prototype;

    var Validator =
        Namespace("Indigox.Web.JsLib.Controls.Validation")
        .Class("Validator")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.errorMessage = "";
            }
        )
        .Members({
            getErrorMessage: function () {
                return this.errorMessage;
            },
            setErrorMessage: function (message) {
                if (isNullOrUndefined(message)) {
                    return;
                }
                this.errorMessage = message;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["errorMessage", this.errorMessage]);
            },

            validate: function (control) {
                var result = this.validateControl(control);
                if (true !== result.matched) {
                    return result;
                }

                if (control instanceof GridView) {
                    return this.validateGridView(control);
                }
                else if (control instanceof Container) {
                    return this.validateChildren(control.getChildren());
                }

                return { matched: true };
            },

            //@private
            validateChildren: function (children) {
                for (var i = 0, length = children.length; i < length; i++) {
                    var child = children[i];
                    var result = this.validate(child);
                    if (true !== result.matched) {
                        return result;
                    }
                }
                return { matched: true };
            },

            //@private
            validateControl: function (control) {
                var validateRules = control.getValidateRules();
                var val = control.getValue();
                for (var i = 0, length = validateRules.length; i < length; i++) {
                    var ruleDescriptor = validateRules[i];
                    var rule = ValidateRuleFactory.getInstance().createValidateRule(
                        ruleDescriptor.type,
                        ruleDescriptor.condition,
                        ruleDescriptor.errorMessage
                    );

                    var result = rule.check(val);
                    if (true !== result.matched) {
                        this.setErrorMessage(result.message);
                        this.show();
                        return result;
                    }
                }
                return { matched: true };
            },

            //@private
            validateGridView: function (control) {
                var rows = control.getRows();
                for (var i = 0, length = rows.length; i < length; i++) {
                    var cells = rows[i].getCells();
                    for (var j = 0, lengthJ = cells.length; j < lengthJ; j++) {
                        var result = this.validateControl(cells[j]);
                        if (true !== result.matched) {
                            return result;
                        }
                    }
                }
                return { matched: true };
            },

            show: function () {
                this.setVisible(true);
            },

            hide: function () {
                if (this.getVisible() === false) {
                    return;
                }
                this.setVisible(false);
            }
        })
    .$();
});