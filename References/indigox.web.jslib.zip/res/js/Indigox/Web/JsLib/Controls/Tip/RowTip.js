﻿
define("Indigox.Web.JsLib.Controls.Tip.RowTip",
    [
        "Indigox.Web.JsLib.Controls.Html.Tooltip",
        "Indigox.Web.JsLib.Controls.Html.Content",
        "Indigox.Web.JsLib.Controls.Component",
        "Indigox.Web.JsLib.Core"
    ],
function (
        ToolTip,
        Content,
        Component
    ) {

    var base = Component.prototype;

    var RowTip =
        Namespace('Indigox.Web.JsLib.Controls.Tip')
        .Class('RowTip')
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.tipControl = null;
                this.control = null;
                this.isDynamic = true;
                //this.task = new DelayedTask();
            }
        )
        .Members({

            setTipControl: function (value) {
                if (isNullOrUndefined(value)) {
                    return;
                }

                if (typeof value === 'string') {
                }
                else {
                    this.tipControl = value;
                }
            },

            getTipControl: function () {
                return this.tipControl;
            },

            setControl: function (value) {
                this.control = value;
                if (this.tipControl) {
                    this.tipControl.addControl(this.control);
                }
            },

            getControl: function () {
                return this.control;
            },

            getIsDynamic: function () {
                return this.isDynamic;
            },

            setIsDynamic: function (value) {
                this.isDynamic = value;
            },

            getIdentity: function () {
                var control = this.getControl();
                if (isNullOrUndefined(control)) {
                    throw new Error("Cannot find control of this tip");
                }
                return this.getControl().getRecord().getIdentity();
            },

            fillTipControl: function () {
                var tip = this.getTipControl();

                if (tip.children.length === 0) {
                    throw new Error("the tipcontrol has no place to show tip");
                }

                var tipContent = tip.children[0];
                if (tipContent instanceof Content) {
                    if (this.getIsDynamic() == true) {
                        var controller = tipContent.getController();
                        controller.setParam("Identity", this.getIdentity());
                        controller.getModel().clearRecord();
                        controller.load();
                    }
                    else {
                        var controller = tipContent.getController();
                        controller.setParam("Identity", this.getIdentity());
                        controller.getModel().clearRecord();
                        controller.bindRecord(this.getControl().getRecord());
                    }
                }
                else {
                    throw new Error("the tipcontrol's first child control should be a Content");
                }
            },

            show: function (x, y) {
                var tip = this.getTipControl();
                tip.show(x, y);
                this.fillTipControl();
            },

            hide: function () {
                this.getTipControl().hide();
            }
        })
    .$();
});