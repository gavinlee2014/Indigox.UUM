﻿define("Indigox.Web.JsLib.Controls.Events.TextEvent",
    [
        "Indigox.Web.JsLib.Controls.Events.EventObject",
        "Indigox.Web.JsLib.Core"
    ],
function (
        EventObject
    ) {
    var base = EventObject.prototype;

    var TextEvent =
        Namespace('Indigox.Web.JsLib.Controls.Events')
        .Class('TextEvent')
        .Extend(base)
        .Constructor(
            function (text) {
                base.constructor.apply(this, arguments);
                this.text = text;
            }
        )
        .Members({
            getText: function () {
                return this.text;
            }
        })
    .$();
});