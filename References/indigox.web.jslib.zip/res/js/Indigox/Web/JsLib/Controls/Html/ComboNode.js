﻿define("Indigox.Web.JsLib.Controls.Html.ComboNode",
    [
        "Indigox.Web.JsLib.Utils.Deferred",
        "Indigox.Web.JsLib.Controls.Html.ItemControl",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Deferred,
        ItemControl
) {
    var EVENT_SELECTED_CHANGED = "selectedChanged";

    var LISTENER_PROPERTY_CHANGING = "PropertyChanging",
        LISTENER_PROPERTY_CHANGED = "PropertyChanged",
        LISTENER_SELECTED_CHANGED = "SelectedChanged";

    var base = ItemControl.prototype;

    var ComboNode =
        Namespace("Indigox.Web.JsLib.Controls.Html")
        .Class("ComboNode")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
            }
        )
        .Members({
            getText: function () { return this.text; },
            setText: function (value) {
                if (isNullOrUndefined(value)) {
                    return;
                }
                var oldValue = this.text;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["text", value, oldValue]);
                this.text = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["text", value, oldValue]);
            },

            remove: function () {
                this.getParent().removeNode(this);
            }
        })
    .$();
});