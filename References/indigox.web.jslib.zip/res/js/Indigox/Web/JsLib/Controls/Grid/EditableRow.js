﻿define("Indigox.Web.JsLib.Controls.Grid.EditableRow",
    [
        "Indigox.Web.JsLib.Utils.AsyncUtil",
        "Indigox.Web.JsLib.Models.RecordManager",
        "Indigox.Web.JsLib.Controls.Html.Button",
        "Indigox.Web.JsLib.Controls.Html.TextBox",
        "Indigox.Web.JsLib.Controllers.Controller",
        "Indigox.Web.JsLib.Controllers.FormController",
        "Indigox.Web.JsLib.Controls.Grid.EditableCell",
        "Indigox.Web.JsLib.Controls.Grid.GridRow",
        "Indigox.Web.JsLib.DOM.Element",
        "Indigox.Web.JsLib.Core"
    ],
function (
        AsyncUtil,
        RecordManager,
        Button,
        TextBox,
        Controller,
        FormController,
        EditableCell,
        GridRow,
        Element
) {
    var EVENT_EDIT = 'edit',
        EVENT_UPDATE = 'update';

    var LISTENER_EDIT = 'Edit',
        LISTENER_UPDATE = 'Update';

    var base = GridRow.prototype;
    var El = Element.el;

    var EditableRow =
        Namespace("Indigox.Web.JsLib.Controls.Grid")
        .Class("EditableRow")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.cellConfigs = {};
                this.editingRow = null;
                this.updateBtnCell = null;
                this.cancelBtnCell = null;
                this.cellMapping = {};
                this.controller = new FormController();
            }
        )
        .Members({
            registerEvents: function () {
                base.registerEvents.call(this);
                this.events.registerEvents(
                    EVENT_EDIT,
                    EVENT_UPDATE
                );
            },

            registerListeners: function () {
                base.registerListeners.call(this);
                this.listeners.registerListeners(
                    LISTENER_EDIT,
                    LISTENER_UPDATE
                );
            },

            setController: function (controller) {
                if (!(controller instanceof Controller)) {
                    var controllerInfo = controller;
                    controller = Type.forAlias(controllerInfo.controllerType).createInstance();
                    controller.configure(controllerInfo);
                }

                if (this.controller) {
                    this.controller.setView(null);
                }
                this.controller = controller;
                if (this.controller) {
                    this.controller.setView(this);
                }
            },

            getController: function () {
                return this.controller;
            },

            setParent: function (parent) {
                base.setParent.apply(this, arguments);
                parent.addListener(this);
            },

            load: function () {
                var promise = base.load.apply(this, arguments);

                //this.buildCells();
                this.resetEdit();

                var element = document.body;
                El(element).addListener("mousedown", this.onMouseDown, document, [this]);

                return promise;
            },

            unload: function () {
                base.unload.apply(this, arguments);
                if (this.getController()) {
                    this.getController().unload();
                }
            },

            onMouseDown: function (source, e, control) {
                var visible = control.getVisible();
                if (visible === true) {
                    var parent = document.getElementById(control.id);
                    //debug.log("parent:" + parent.id + ",source:" + source.className + ",isParent:" + control.isParent(source, parent));
                    if (!control.isParent(source, parent)) {
                        AsyncUtil.invokeAsync(function () { control.update(); });
                    }
                }
            },

            isParent: function (obj, parentObj) {
                while (!isNullOrUndefined(obj) && obj.tagName.toUpperCase() != 'BODY') {
                    if (obj == parentObj || obj.id.toUpperCase() == 'UI-DATEPICKER-DIV') {
                        return true;
                    }
                    obj = obj.parentNode;
                }
                return false;
            },

            newCell: function (config) {
                var cell = new EditableCell();

                if (config) {
                    cell.configure(config);
                }
                if (cell.getEditingControl() == null) {
                    var controlType = "textbox";
                    var controlConfig = {};
                    if (config && config.column && this.cellConfigs[config.column.getField()]) {
                        controlType = this.cellConfigs[config.column.getField()].type;
                        controlConfig = this.cellConfigs[config.column.getField()].config;
                    }
                    var editingControl = Type.forAlias(controlType).createInstance();
                    editingControl.configure(controlConfig);
                    cell.setEditingControl(editingControl);
                }

                return cell;
            },

            buildCells: function () {
                var columns = this.getParent().getColumns();
                var i, length;
                for (i = 0, length = columns.length; i < length; i++) {
                    var field = columns[i].getField();
                    var cell = this.newCell({ column: columns[i], name: columns[i].getField() });
                    this.addCell(cell);
                    this.cellMapping[field] = cell;
                }
            },

            setCellConfigs: function (configs) {
                for (var field in configs) {
                    this.setCellConfig(field, configs[field]);
                }
            },

            setCellConfig: function (field, config) {
                this.cellConfigs[field] = config;
                if (this.cellMapping[field]) {
                    var cell = this.cellMapping[field];
                    if (config.type) {
                        var editingControl = Type.forAlias(config.type).createInstance();
                        editingControl.configure(config.config);
                        cell.setEditingControl(editingControl);
                    }
                }
            },

            setCells: function (value) {
                for (var i = 0, length = value.length; i < length; i++) {
                    var options = value[i];
                    var cell = this.cellMapping[options.name];

                    if (options.editingControl.controlType) {
                        var control = Type.forAlias(options.editingControl.controlType).createInstance();
                        control.configure(options.editingControl);
                        cell.setEditingControl(control);
                    }
                }
            },

            onRowClicked: function (source, row) {
                if (this.editingRow != row) {
                    this.edit(row);
                }
            },

            onRowRemoved: function (source, index, row) {
                this.resetEdit();
            },

            edit: function (row) {
                if (this.getVisible() === true) {
                    var editableRow = this;
                    setTimeout(function () { editableRow.edit(row); }, 100);
                    return;
                }
                this.resetEdit();

                var record = row.getRecord();

                if (isNullOrUndefined(record)) {
                    return;
                }

                this.editingRow = row;
                this.setVisible(true);

                var editingCells = row.getCells();
                var i, length, values = [];
                for (i = 0, length = editingCells.length; i < length; i++) {
                    var editingCell = editingCells[i];
                    if (!(editingCell instanceof EditableCell)) {
                        var field = editingCell.getColumn().getField();
                        var cell = this.cellMapping[field];
                        if (!cell) {
                            cell = this.newCell({ column: editingCell.getColumn() });
                            this.insertCell(i, cell);
                        }
                    }
                }

                this.controller.bindRecord(this, record);

                this.fireListener(LISTENER_EDIT, [row, values]);
                this.fireEvent(EVENT_EDIT, [row, values]);
            },

            update: function () {
                var record = this.editingRow.getRecord();
                this.controller.updateRecord(this, record);

                this.resetEdit();
            },

            resetEdit: function () {
                this.editingRow = null;
                this.setVisible(false);
                this.clearValue();
            },

            getCells: function () {
                var cells = [];
                for (var key in this.cellMapping) {
                    cells.push(this.cellMapping[key]);
                }
                return cells;
            },

            clearValue: function () {
                for (var field in this.cellMapping) {
                    this.cellMapping[field].setValue(null);
                }
            }
        })
    .$();
});