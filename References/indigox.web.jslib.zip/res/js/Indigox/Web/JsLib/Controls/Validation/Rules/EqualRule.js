﻿define("Indigox.Web.JsLib.Controls.Validation.Rules.EqualRule",
    [
        "Indigox.Web.JsLib.Controls.Validation.Rules.Rule",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Rule
    ) {

    var base = Rule.prototype;

    var EqualRule =
        Namespace("Indigox.Web.JsLib.Controls.Validation.Rules")
        .Class("EqualRule")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.defaultMessageExpression = '输入值须等于${condition}';
            }
        )
        .Members({
            isMatch: function (value) {
                return (value == this.getCondition());
            }
        })
    .$();
});