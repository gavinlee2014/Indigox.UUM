﻿define("Indigox.Web.JsLib.Controls.Html.LoadMask",
    [
        "Indigox.Web.JsLib.Controls.Control",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Control
    ) {

    var base = Control.prototype;

    var EVENT_SHOW = "show",
        EVENT_HIDE = "hide";

    var LISTENER_PROPERTY_CHANGING = "PropertyChanging",
        LISTENER_PROPERTY_CHANGED = "PropertyChanged",
        LISTENER_SHOW = "Show",
        LISTENER_HIDE = "Hide";

    

    var LoadMask =
        Namespace("Indigox.Web.JsLib.Controls.Html")
        .Class("LoadMask")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.mode = LoadMask.OPACITY;
                this.remain = 0;
            }
        )
        .Static({
            NONE: null,
            OPACITY: "opacity",
            TRANSPARENT: "transparent"
        })
        .Members({
            registerEvents: function () {
                base.registerEvents.call(this);
                this.events.registerEvents(
                    EVENT_SHOW,
                    EVENT_HIDE
                );
            },
            registerListeners: function () {
                base.registerListeners.call(this);
                this.listeners.registerListeners(
                    LISTENER_SHOW,
                    LISTENER_HIDE
                );
            },
            setMode: function (value) {
                var oldValue = this.mode;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["mode", value, oldValue]);
                this.mode = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["mode", value, oldValue]);
            },
            getMode: function () {
                return this.mode;
            },
            show: function () {
                this.setVisible(true);
                this.getParent().setMasked(this.mode);
                this.fireListener(LISTENER_SHOW);
                this.fireEvent(EVENT_SHOW);
            },
            hide: function () {
                this.setVisible(false);
                this.getParent().setMasked(LoadMask.NONE);
                this.fireListener(LISTENER_HIDE);
                this.fireEvent(EVENT_HIDE);
            }
        })
    .$();
});