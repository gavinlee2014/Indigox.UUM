﻿define("Indigox.Web.JsLib.Controls.Html.ButtonMenuItem",
    [
        "Indigox.Web.JsLib.Utils.ArrayUtil",
        "Indigox.Web.JsLib.Collection.List",
        "Indigox.Web.JsLib.Controls.Html.Label",
        "Indigox.Web.JsLib.Controls.Html.CheckBox",
        "Indigox.Web.JsLib.Controls.Html.Button",
        "Indigox.Web.JsLib.Controls.Html.Menu",
        "Indigox.Web.JsLib.Controls.Html.MenuItem",
        "Indigox.Web.JsLib.Core"
    ],
function (
        ArrayUtil,
        List,
        Label,
        CheckBox,
        Button,
        Menu,
        MenuItem
) {
    var EVENT_CLICKED = "clicked";

    var LISTENER_PROPERTY_CHANGING = "PropertyChanging",
        LISTENER_PROPERTY_CHANGED = "PropertyChanged",
        LISTENER_CLICKED = "Clicked";

    var base = MenuItem.prototype;

    var ButtonMenuItem =
        Namespace("Indigox.Web.JsLib.Controls.Html")
        .Class("ButtonMenuItem")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.displayMode = Button.DISPLAYMODE_TEXT_AND_ICON;
                this.icon = null;
            }
        )
        .Static({
            DISPLAYMODE_TEXT_AND_ICON: 0,
            DISPLAYMODE_TEXT_ONLY: 1,
            DISPLAYMODE_ICON_ONLY: 2
        })
        .Members({
            /** @id Indigox.Web.JsLib.Controls.Html.Button.prototype.registerEvents */
            registerEvents: function () {
                base.registerEvents.call(this);
                this.events.registerEvents(
                    EVENT_CLICKED
                );
            },

            registerListeners: function () {
                base.registerListeners.call(this);
                this.listeners.registerListeners(
                    LISTENER_CLICKED
                );
            },

            setDisplayMode: function (value) {
                var oldValue = this.displayMode;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["displayMode", value, oldValue]);
                this.displayMode = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["displayMode", value, oldValue]);
            },

            getDisplayMode: function () {
                return this.displayMode;
            },

            setIcon: function (value) {
                var oldValue = this.icon;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["icon", value, oldValue]);
                this.icon = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["icon", value, oldValue]);
            },

            getIcon: function () {
                return this.icon;
            },

            click: function () {
                this.fireListener(LISTENER_CLICKED);
                this.fireEvent(EVENT_CLICKED);
            }
        })
    .$();
});