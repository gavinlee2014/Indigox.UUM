﻿define("Indigox.Web.JsLib.Controls.Validation.Rules.NotBlankRule",
    [
        "Indigox.Web.JsLib.Controls.Validation.Rules.Rule",
        "Indigox.Web.JsLib.Utils.StringUtil",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Rule,
        StringUtil
    ) {

    var base = Rule.prototype;

    var NotBlankRule =
        Namespace("Indigox.Web.JsLib.Controls.Validation.Rules")
        .Class("NotBlankRule")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
            }
        )
        .Members({
            isMatch: function (value) {
                if (StringUtil.isNullOrEmpty(value)) {
                    return false;
                }
                else {
                    return true;
                }
            }
        })
    .$();
});