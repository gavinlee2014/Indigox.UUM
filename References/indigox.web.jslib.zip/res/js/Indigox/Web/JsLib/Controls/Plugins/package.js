﻿define("Indigox.Web.JsLib.Controls.Plugins",
      [
        "Indigox.Web.JsLib.Controls.Plugins.BadgePlugin",
        "Indigox.Web.JsLib.Controls.Plugins.CalculatePlugin",
        "Indigox.Web.JsLib.Controls.Plugins.PermissionPlugin",
        "Indigox.Web.JsLib.Controls.Plugins.PropertyMappingPlugin",
        "Indigox.Web.JsLib.Controls.Plugins.SummaryFieldPlugin",
        "Indigox.Web.JsLib.Controls.Plugins.TimeSpanPlugin",
        "Indigox.Web.JsLib.Controls.Plugins.VisiblePlugin",
        "Indigox.Web.JsLib.Controls.Plugins.ValueDialogPlugin"
      ],
function (
    BadgePlugin,
    CalculatePlugin,
    PermissionPlugin,
    PropertyMappingPlugin,
    SummaryFieldPlugin,
    TimeSpanPlugin,
    VisiblePlugin,
    ValueDialogPlugin
) {
    return {
        BadgePlugin: BadgePlugin,
        CalculatePlugin: CalculatePlugin,
        PermissionPlugin: PermissionPlugin,
        PropertyMappingPlugin: PropertyMappingPlugin,
        SummaryFieldPlugin: SummaryFieldPlugin,
        TimeSpanPlugin: TimeSpanPlugin,
        VisiblePlugin: VisiblePlugin,
        ValueDialogPlugin: ValueDialogPlugin
    };
});