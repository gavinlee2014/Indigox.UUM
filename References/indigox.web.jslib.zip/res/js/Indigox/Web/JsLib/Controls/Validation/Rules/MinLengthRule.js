﻿define("Indigox.Web.JsLib.Controls.Validation.Rules.MinLengthRule",
    [
        "Indigox.Web.JsLib.Controls.Validation.Rules.Rule",
        "Indigox.Web.JsLib.Utils.StringUtil",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Rule,
        StringUtil
    ) {

    var base = Rule.prototype;

    var MinLengthRule =
        Namespace("Indigox.Web.JsLib.Controls.Validation.Rules")
        .Class("MinLengthRule")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
            }
        )
        .Members({
            isMatch: function (value) {
                var minLength = this.getCondition();
                if (minLength === 0) {
                    return true;
                }
                if (StringUtil.isNullOrEmpty(value)) {
                    return false;
                }
                if (value.length < minLength) {
                    return false;
                }
                else {
                    return true;
                }
            }
        })
    .$();
});