﻿define("Indigox.Web.JsLib.Controls.Plugins.Plugin",
    [
        "Indigox.Web.JsLib.Controls.Component",
        "Indigox.Web.JsLib.Utils.Util",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Component,
        Util
) {
    var base = Component.prototype;

    var Plugin =
        Namespace("Indigox.Web.JsLib.Controls.Plugins")
        .Class("Plugin")
        .Extend(base)
        .Constructor(
            function (option) {
                base.constructor.apply(this, arguments);

                option = Util.copyExist({
                    control: null,
                    controller: null,
                    loaded: false
                }, option);
                this.configure(option);
            }
        )
        .Members({
            setController: function (controller) {
                if (isNullOrUndefined(controller) || this.controller == controller) {
                    return;
                }

                if (this.controller != null) {
                    this.controller.removePlugin(this);
                }

                this.controller = controller;

                if (this.controller != null) {
                    controller.addPlugin(this);
                }
            },

            getController: function () {
                return this.controller;
            },

            setControl: function (control) {
                if (this.control == control) {
                    return;
                }
                if (this.control != null) {
                    this.control.removeListener(this);
                }
                this.control = control;
                if (this.control != null) {
                    this.control.addListener(this);
                }
            },

            getControl: function () {
                return this.control;
            },

            execute: function (record) {
            }
        })
    .$();
});