﻿define("Indigox.Web.JsLib.Controls.Widgets.Widget",
    [
        "Indigox.Web.JsLib.Collection.Hashtable",
        "Indigox.Web.JsLib.Utils.Deferred",
        "Indigox.Web.JsLib.Controls.Control",
        "Indigox.Web.JsLib.Controls.Container",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Hashtable,
        Deferred,
        Control,
        Container
) {
    var EVENT_PARAM_CHANGED = "paramChanged";

    var LISTENER_LOAD_RESOURCES = "LoadResources",
        LISTENER_PARAM_CHANGED = "ParamChanged";

    var base = Container.prototype;

    var Widget =
        Namespace("Indigox.Web.JsLib.Controls.Widgets")
        .Class("Widget")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.title = "";
                this.layout = null;
                this.presentation = null;
                this.resources = [];
                this.params = new Hashtable();
                this.pending = null;
            }
        )
        .Members({
            registerEvents: function () {
                base.registerEvents.call(this);
                this.events.registerEvents(
                    EVENT_PARAM_CHANGED
                );
            },

            registerListeners: function () {
                base.registerListeners.apply(this, arguments);
                this.listeners.registerListeners(
                    LISTENER_PARAM_CHANGED
                );
            },

            doLoad: function () {
                if (this.getPending()) {
                    return this.getPending().then({ handler: this.doLoad, scope: this });
                }
                else {
                    return base.doLoad.apply(this, arguments);
                }
            },

            setPending: function (value) {
                this.pending = value;
            },

            getPending: function () {
                return this.pending;
            },

            setLayout: function (value) {
                this.layout = value;
            },

            getLayout: function () {
                return this.layout;
            },

            setTitle: function (value) {
                this.title = value;
            },

            getTitle: function () {
                return this.title;
            },

            setParam: function (name, value) {
                var oldValue = null;
                if (this.params.containsKey(name)) {
                    oldValue = this.params.get(name);
                }
                this.params.put(name, value);
                this.fireListener(LISTENER_PARAM_CHANGED, [name, value, oldValue]);
                this.fireEvent(EVENT_PARAM_CHANGED, [name, value, oldValue]);
            },

            getParam: function (name) {
                return this.params.get(name);
            },

            removeParam: function (name) {
                var oldValue = null;
                if (this.params.containsKey(name)) {
                    oldValue = this.params.get(name);
                }
                this.params.remove(name);
                this.fireListener(LISTENER_PARAM_CHANGED, [name, null, oldValue]);
                this.fireEvent(EVENT_PARAM_CHANGED, [name, null, oldValue]);
            },

            setParams: function (params) {
                for (var name in params) {
                    this.setParam(name, params[name]);
                }
            },

            getParams: function () {
                var params = {};
                var names = this.params.keys();
                var i, length;
                for (i = 0, length = names.length; i < length; i++) {
                    params[names[i]] = this.getParam(names[i]);
                }
                return params;
            },

            hasParam: function (name) {
                return this.params.containsKey(name);
            },

            setResources: function (resources) {
                this.resources = resources;
            },

            getResources: function () {
                return this.resources;
            },

            setPresentation: function (presentation) {
                this.presentation = presentation;
            },

            getPresentation: function () {
                return this.presentation;
            }
        })
    .$();
});