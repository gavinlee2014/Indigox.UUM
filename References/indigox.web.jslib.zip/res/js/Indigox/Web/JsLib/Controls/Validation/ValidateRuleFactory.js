﻿define("Indigox.Web.JsLib.Controls.Validation.ValidateRuleFactory",
    [
        "Indigox.Web.JsLib.Collection.Hashtable",
        "Indigox.Web.JsLib.Collection.List"
    ],
function (
        Hashtable,
        List     
    ) {
    
    var instance = null;

    var ValidateRuleFactory =
        Namespace("Indigox.Web.JsLib.Controls.Validation")
        .Class("ValidateRuleFactory")
        .Constructor(
            function () {
                this.ruleMappings = {};
            }
        )
        .Static({
            getInstance: function () {
                if (instance === null) {
                    instance = new ValidateRuleFactory();
                }
                return instance;
            }
        })
        .Members({
            registerRule: function (alias, rule) {
                this.ruleMappings[alias] = rule;
            },

            unregisterRule: function (alias) {
                if (alias in this.ruleMappings) {
                    delete this.ruleMappings[alias];
                }
            },

            createValidateRule: function (ruleName, condition, message) {
                var ruleType = this.ruleMappings[ruleName.toLowerCase()];
                if (isNullOrUndefined(ruleType)) {
                    throw new Error("Can not create ValidateRule for \"" + ruleName + "\"");
                }
                else {
                    var rule = Type.forClass(ruleType).createInstance();
                    rule.setCondition(condition);
                    rule.setMessage(message);
                    return rule;
                }
            }
        })
    .$();
});