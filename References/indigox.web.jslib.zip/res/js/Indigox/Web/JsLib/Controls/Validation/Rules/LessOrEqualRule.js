﻿define("Indigox.Web.JsLib.Controls.Validation.Rules.LessOrEqualRule",
    [
        "Indigox.Web.JsLib.Controls.Validation.Rules.Rule",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Rule
    ) {

    var base = Rule.prototype;

    var LessOrEqualRule =
        Namespace("Indigox.Web.JsLib.Controls.Validation.Rules")
        .Class("LessOrEqualRule")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.defaultMessageExpression = '输入值须小于或等于${condition}';
            }
        )
        .Members({
            isMatch: function (value) {
                return (value <= this.getCondition());
            }
        })
    .$();
});