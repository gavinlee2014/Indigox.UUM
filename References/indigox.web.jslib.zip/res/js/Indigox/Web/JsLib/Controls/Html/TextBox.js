﻿define("Indigox.Web.JsLib.Controls.Html.TextBox",
    [
        "Indigox.Web.JsLib.Controls.Html.FieldControl",
        "Indigox.Web.JsLib.Core"
    ],
function (
        FieldControl
    ) {

    var base = FieldControl.prototype;

    var LISTENER_CLICKED = "Clicked",
        LISTENER_PROPERTY_CHANGING = "PropertyChanging",
        LISTENER_PROPERTY_CHANGED = "PropertyChanged",
        LISTENER_VALUE_CHANGED = "ValueChanged";

    var EVENT_CLICKED = "clicked";

    var TextBox =
        Namespace("Indigox.Web.JsLib.Controls.Html")
        .Class("TextBox")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                //this.value = this.value || "";
            }
        )
        .Members({
            getValue: function () {
                if (isNullOrUndefined(this.value)) {
                    return "";
                }
                else {
                    return this.value;
                }
            },
            click: function (e) {
                this.fireListener(LISTENER_CLICKED, [e]);
                this.fireEvent(EVENT_CLICKED, [e]);
            },
            registerEvents: function () {
                base.registerEvents.apply(this, arguments);
                this.events.registerEvents(
                    EVENT_CLICKED
                );
            },
            registerListeners: function () {
                base.registerListeners.apply(this, arguments);
                this.listeners.registerListeners(
                    LISTENER_CLICKED
                );
            }
        })
    .$();
});