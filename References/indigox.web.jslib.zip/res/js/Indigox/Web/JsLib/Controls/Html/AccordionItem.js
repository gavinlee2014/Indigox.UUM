﻿define("Indigox.Web.JsLib.Controls.Html.AccordionItem",
    [
        "Indigox.Web.JsLib.Utils.ArrayUtil",
        "Indigox.Web.JsLib.Collection.List",
        "Indigox.Web.JsLib.Controls.Html.Label",
        "Indigox.Web.JsLib.Controls.Html.CheckBox",
        "Indigox.Web.JsLib.Controls.Html.Button",
        "Indigox.Web.JsLib.Controls.Html.DataList",
        "Indigox.Web.JsLib.Controls.Html.ItemControl",
        "Indigox.Web.JsLib.Core"
    ],
function (
        ArrayUtil,
        List,
        Label,
        CheckBox,
        Button,
        DataList,
        ItemControl
) {

    var base = ItemControl.prototype;

    var EVENT_COLLAPSED = "collapsed",
        EVENT_EXPANDED = "expanded";

    var LISTENER_PROPERTY_CHANGING = "PropertyChanging",
        LISTENER_PROPERTY_CHANGED = "PropertyChanged";

    var AccordionItem =
        Namespace("Indigox.Web.JsLib.Controls.Html")
        .Class("AccordionItem")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.text = null;
                this.collapsed = true;
            }
        )
        .Members({
            registerEvents: function () {
                base.registerEvents.call(this);
                this.events.registerEvents(
                    EVENT_COLLAPSED,
                    EVENT_EXPANDED
                );
            },

            setParent: function (value) {
                var oldParent = this.getParent();
                base.setParent.apply(this, arguments);
                if (isNullOrUndefined(value)) {
                    this.removeListener(oldParent);
                }
                else {
                    this.addListener(this.getParent());
                }
            },

            setText: function (value) {
                var oldValue = this.text;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["text", value, oldValue]);
                this.text = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["text", value, oldValue]);
            },
            getText: function () {
                return this.text;
            },
            setCollapsed: function (value) {
                if (this.collapsed === value) {
                    return;
                }
                var oldValue = this.collapsed;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["collapsed", value, oldValue]);
                this.collapsed = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["collapsed", value, oldValue]);
            },
            getCollapsed: function () {
                return this.collapsed;
            },
            collapse: function () {
                this.setCollapsed(true);
                this.fireEvent(EVENT_COLLAPSED, [this.getCollapsed()]);
            },
            expand: function () {
                this.setCollapsed(false);
                this.fireEvent(EVENT_EXPANDED, [this.getCollapsed()]);
            },
            toggleCollapse: function () {
                if (this.getCollapsed()) {
                    this.expand();
                }
                else {
                    this.collapse();
                }
            }
        })
    .$();
});