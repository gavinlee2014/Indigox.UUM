﻿define("Indigox.Web.JsLib.Controls.Html.AutoCompleteBox",
    [
        "Indigox.Web.JsLib.Utils.Util",
        "Indigox.Web.JsLib.Collection.List",
        "Indigox.Web.JsLib.Utils.ArrayUtil",
        "Indigox.Web.JsLib.Utils.Callback",
        "Indigox.Web.JsLib.Utils.DelayedTask",
        "Indigox.Web.JsLib.Utils.Deferred",
        "Indigox.Web.JsLib.Controls.Html.ListControl",
        "Indigox.Web.JsLib.Controls.Html.AutoCompleteItem",
        "Indigox.Web.JsLib.Controls.Html.CompleteItem",
        "Indigox.Web.JsLib.Core"
    ],
    function (
        Util,
        List,
        ArrayUtil,
        Callback,
        DelayedTask,
        Deferred,
        ListControl,
        AutoCompleteItem,
        CompleteItem
    ) {

        var base = ListControl.prototype;

        var EVENT_COMPLETE_ITEM_ADDING = "completeItemAdding",
            EVENT_COMPLETE_ITEM_ADDED = "completeItemAdded",
            EVENT_COMPLETE_ITEM_REMOVING = "completeItemRemoving",
            EVENT_COMPLETE_ITEM_REMOVED = "completeItemRemoved",
            EVENT_ITEM_SELECTED_CHANGED = "itemSelectedChanged";

        var LISTENER_COMPLETE_ITEM_ADDING = "CompleteItemAdding",
            LISTENER_COMPLETE_ITEM_ADDED = "CompleteItemAdded",
            LISTENER_COMPLETE_ITEM_REMOVING = "CompleteItemRemoving",
            LISTENER_COMPLETE_ITEM_REMOVED = "CompleteItemRemoved",
            LISTENER_ITEM_SELECTED_CHANGED = "ItemSelectedChanged",
            LISTENER_COMPLETE_ITEM_INDEX_RESET = "IndexReset",
            LISTENER_PROPERTY_CHANGING = "PropertyChanging",
            LISTENER_PROPERTY_CHANGED = "PropertyChanged";



        var AutoCompleteBox =
            Namespace("Indigox.Web.JsLib.Controls.Html")
            .Class("AutoCompleteBox")
            .Extend(base)
            .Constructor(
                function () {
                    this.completeItems = new List();
                    this.delayedTask = null;
                    this.multi = false;
                    this.itemIndex = -1;
                    this.showItems = false;
                    base.constructor.apply(this, arguments);
                }
            )
            .Members({
                registerEvents: function () {
                    base.registerEvents.call(this);
                    this.events.registerEvents(
                        EVENT_COMPLETE_ITEM_ADDING,
                        EVENT_COMPLETE_ITEM_ADDED,
                        EVENT_COMPLETE_ITEM_REMOVING,
                        EVENT_COMPLETE_ITEM_REMOVED,
                        EVENT_ITEM_SELECTED_CHANGED
                    );
                },

                registerListeners: function () {
                    base.registerListeners.call(this);
                    this.listeners.registerListeners(
                        LISTENER_COMPLETE_ITEM_ADDING,
                        LISTENER_COMPLETE_ITEM_ADDED,
                        LISTENER_COMPLETE_ITEM_REMOVING,
                        LISTENER_COMPLETE_ITEM_REMOVED,
                        LISTENER_ITEM_SELECTED_CHANGED,
                        LISTENER_COMPLETE_ITEM_INDEX_RESET
                    );
                },
                clearItems: function () {
                    //this.itemIndex = -1;
                    base.clearItems.apply(this, arguments);
                },
                getText: function () { return this.text; },
                setText: function (value) {
                    if (isNullOrUndefined(value)) {
                        return;
                    }
                    var oldValue = this.text;
                    this.fireListener(LISTENER_PROPERTY_CHANGING, ["text", value, oldValue]);
                    this.text = value;
                    this.fireListener(LISTENER_PROPERTY_CHANGED, ["text", value, oldValue]);
                },

                getShowItems: function () { return this.showItems; },
                setShowItems: function (value) {
                    if (isNullOrUndefined(value)) {
                        return;
                    }
                    var oldValue = this.showItems;
                    this.fireListener(LISTENER_PROPERTY_CHANGING, ["showItems", value, oldValue]);
                    this.showItems = value;
                    this.fireListener(LISTENER_PROPERTY_CHANGED, ["showItems", value, oldValue]);
                },


                getValue: function () {
                    var items = this.getCompleteItems();
                    var values = [], item;
                    for (var i in items) {
                        item = items[i];
                        values.push({
                            value: item.getValue(),
                            text: item.getText()
                        });
                    }
                    return values;
                },

                setValue: function (value) {
                    this.clearCompleteItem();

                    if (isNullOrUndefined(value)) {
                        return;
                    }

                    if (Object.prototype.toString.call(value) != '[object Array]') {
                        value = [value];
                    }

                    var length = 0;

                    for (var i in value) {
                        var newNode = this.newCompleteItem(value[i].text, value[i].value);
                        this.insertCompleteItem(length, newNode);
                        length = length + 1;
                    }
                },

                getMulti: function () {
                    return this.multi;
                },
                setMulti: function (value) {
                    var oldValue = this.multi;
                    this.fireListener(LISTENER_PROPERTY_CHANGING, ["multi", value, oldValue]);
                    this.multi = value;
                    this.fireListener(LISTENER_PROPERTY_CHANGED, ["multi", value, oldValue]);
                },

                newItem: function (config) {
                    var item = new AutoCompleteItem();
                    item.configure(config);
                    return item;
                },

                newCompleteItem: function (text, value) {
                    var item = new CompleteItem();
                    item.setText(text);
                    item.setValue(value);
                    return item;
                },
                getCompleteItems: function () {
                    return this.completeItems.toArray();
                },

                insertCompleteItem: function (index, item) {
                    var items = this.getCompleteItems();
                    if (index > items.length) {
                        throw new Error("out of range");
                    }

                    this.completeItems.insert(index, item);
                    item.setParent(this);
                    item.addListener(this);
                    this.updateChildrenID(this.completeItems.toArray(), index);

                    this.fireListener(LISTENER_COMPLETE_ITEM_ADDING, [index, item]);
                    this.fireEvent(EVENT_COMPLETE_ITEM_ADDING, [index, item]);

                    Deferred.when(this.catchUpLoadChild(item)).done({
                        handler: function () {
                            this.fireListener(LISTENER_COMPLETE_ITEM_ADDED, [index, item]);
                            this.fireEvent(EVENT_COMPLETE_ITEM_ADDED, [index, item]);
                        },
                        scope: this
                    }).fail({
                        handler: function () {
                            debug.error([this.id, "insertNode ", item.id, " failed."].join(""));
                        },
                        scope: this
                    });
                },

                removeCompleteItem: function (item) {
                    var items = this.getCompleteItems();
                    var index = ArrayUtil.indexOf(items, item);

                    this.fireListener(LISTENER_COMPLETE_ITEM_REMOVING, [index, item]);
                    this.fireEvent(EVENT_COMPLETE_ITEM_REMOVED, [index, item]);
                    this.completeItems.remove(item);
                    item.unload();
                    item.setParent(null);
                    this.updateChildrenID(this.completeItems.toArray(), index);
                    this.fireEvent(EVENT_COMPLETE_ITEM_REMOVED, [index, item]);
                    this.fireListener(LISTENER_COMPLETE_ITEM_REMOVED, [index, item]);
                },

                clearCompleteItem: function () {
                    var items = this.getCompleteItems();
                    var i = null, length = null;
                    for (i = 0, length = items.length; i < length; i++) {
                        this.removeCompleteItem(items[i]);
                    }
                },

                search: function (condition, autoSelected) {
                    if (this.delayedTask) {
                        this.delayedTask.cancel();
                    }

                    this.delayedTask = new DelayedTask(function (condition) {
                        this.doSearch(condition, autoSelected);
                        this.delayedTask = null;
                    }, this, [condition, autoSelected]);

                    this.delayedTask.delay(500);
                },

                doSearch: function (condition, autoSelected) {
                    this.fireListener(LISTENER_COMPLETE_ITEM_INDEX_RESET);
                    this.setShowItems(true);
                    var controller = this.getController();
                    controller.clearModel();
                    if (condition == "") {
                        this.setShowItems(false);
                        return false;
                    }
                    var callback = new Callback(this.afterLoadItems, this, [condition, autoSelected]);
                    controller.setDefaultParamValue(condition);
                    controller.load(callback);
                },

                afterLoadItems: function (defaultText, autoSelected) {
                    var items = this.getItems();
                    if (items.length > 0) {
                        if (autoSelected == true) {
                            this.onSelectedChanged(items[0]);
                        }
                    }
                    else {
                        if (autoSelected == true) {
                            var item = this.newItem({ text: defaultText, value: "" });
                            this.onSelectedChanged(item);
                        }
                        this.setShowItems(false);
                    }
                },
                deactiveItem: function (index) {
                    if (index < 0) { return; }
                    var items = this.getItems();
                    if (index > items.length) { return; }
                    items[index].mark(false);
                },
                activeItem: function (index) {
                    if (index < 0) { return; }
                    var items = this.getItems();
                    if (index > items.length) { return; }
                    items[index].mark(true);
                },
                onSelectedChanged: function (source) {
                    if (this.getMulti() == false) {
                        this.clearCompleteItem();
                    }

                    var item = this.newCompleteItem(source.getText(), source.getValue());
                    this.insertCompleteItem(this.completeItems.size(), item);
                    this.getController().clearModel();
                    this.setText("");
                    this.setShowItems(false);

                    this.fireListener(LISTENER_ITEM_SELECTED_CHANGED, [source, true]);
                    this.fireEvent(EVENT_ITEM_SELECTED_CHANGED, [source, true]);
                }

            })
        .$();
    });