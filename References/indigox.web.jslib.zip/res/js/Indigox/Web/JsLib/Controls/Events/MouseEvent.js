﻿define("Indigox.Web.JsLib.Controls.Events.MouseEvent",
    [
        "Indigox.Web.JsLib.Controls.Events.InputEvent",
        "Indigox.Web.JsLib.Core"
    ],
function (
        InputEvent
    ) {
    var base = InputEvent.prototype;

    var MouseEvent =
        Namespace('Indigox.Web.JsLib.Controls.Events')
        .Class('MouseEvent')
        .Extend(base)
        .Constructor(
            function (e) {
                base.constructor.apply(this, arguments);
                this.button = e.button;
                this.clicks = e.detail;
                this.pageX = e.clientX;
                this.pageY = e.clientY;
            }
        )
        .Members({
            getButton: function () {
                return this.button;
            },
            getClicks: function () {
                return this.clicks;
            },
            getPageX: function () {
                return this.pageX;
            },
            getPageY: function () {
                return this.pageY;
            }
        })
    .$();
});