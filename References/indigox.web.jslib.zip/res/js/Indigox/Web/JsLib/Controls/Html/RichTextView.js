﻿define("Indigox.Web.JsLib.Controls.Html.RichTextView",
    [
        "Indigox.Web.JsLib.Utils.EncodeUtil",
        "Indigox.Web.JsLib.Controls.Html.Literal",
        "Indigox.Web.JsLib.Core"
    ],
    function (
        EncodeUtil,
        Literal
    ) {

        var LISTENER_PROPERTY_CHANGING = "PropertyChanging",
            LISTENER_PROPERTY_CHANGED = "PropertyChanged";

        var EVENT_VALUE_CHANGED = "valueChanged";

        var base = Literal.prototype;

        var RichTextView =
            Namespace("Indigox.Web.JsLib.Controls.Html")
            .Class("RichTextView")
            .Extend(base)
            .Constructor(
                function () {
                    base.constructor.apply(this, arguments);
                    this.mode = Literal.MODE_PASSTHROUGH;
                }
            )
            .Members({
            })
        .$();
    });