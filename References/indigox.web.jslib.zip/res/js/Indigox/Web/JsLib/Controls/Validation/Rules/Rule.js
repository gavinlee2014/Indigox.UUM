﻿define("Indigox.Web.JsLib.Controls.Validation.Rules.Rule",
    [
        "Indigox.Web.JsLib.Controls.Component",
        "Indigox.Web.JsLib.Expression.ExpressionEvaluator",
        "Indigox.Web.JsLib.Expression.MixinExpressionEvaluator",
        "Indigox.Web.JsLib.Utils.StringUtil",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Component,
        ExpressionEvaluator  ,   
        MixinExpressionEvaluator,
        StringUtil              
    ) {

    var base = Component.prototype;

    var Rule =
        Namespace("Indigox.Web.JsLib.Controls.Validation.Rules")
        .Class("Rule")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.control = null;
                this.condition = null;
                this.message = null;
                this.defaultMessageExpression = "不符合校验规则";
            }
        )
        .Members({
            check: function (value) {
                var matched = this.isMatch(value);
                var message = "";
                if (!matched) {
                    message = this.getMessage();
                }
                return { matched: matched, message: message };
            },

            isMatch: function (value) {
            },

            setCondition: function (condition) {
                this.condition = condition;
            },

            getCondition: function () {
                return this.condition;
            },

            setMessage: function (message) {
                this.message = message;
            },

            getMessage: function () {
                if (StringUtil.isNullOrEmpty(this.message)) {
                    return this.getDefaultMessage();
                }
                return this.message;
            },

            getDefaultMessage: function () {
                var evaluator = new MixinExpressionEvaluator(this.getDefaultMessageExpression());
                return evaluator.evaluate(this);
            },

            getDefaultMessageExpression: function () {
                return this.defaultMessageExpression;
            },

            setDefaultMessageExpression: function (value) {
                this.defaultMessageExpression = value;
            }
        })
    .$();
});