﻿define("Indigox.Web.JsLib.Controls.Html.RadioBoxItem",
    [
        "Indigox.Web.JsLib.Controls.Html.ItemControl",
        "Indigox.Web.JsLib.Utils.Deferred",
        "Indigox.Web.JsLib.Core"
    ],
function (
        ItemControl,
        Deferred
    ) {

    var base = ItemControl.prototype;

    var EVENT_SELECTED_CHANGED = "selectedChanged";

    var LISTENER_PROPERTY_CHANGING = "PropertyChanging",
        LISTENER_PROPERTY_CHANGED = "PropertyChanged",
        LISTENER_SELECTED_CHANGED = "SelectedChanged";

    var RadioBoxItem =
        Namespace("Indigox.Web.JsLib.Controls.Html")
        .Class("RadioBoxItem")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.radioBox = null;
            }
        )
        .Members({
            registerEvents: function () {
                base.registerEvents.call(this);
                this.events.registerEvents(
                    EVENT_SELECTED_CHANGED
                );
            },

            registerListeners: function () {
                base.registerListeners.call(this);
                this.listeners.registerListeners(
                    LISTENER_SELECTED_CHANGED
                );
            },

            initChildren: function () {
                if (this.getRadioBox()) {
                    this.getRadioBox().init();
                }
            },
            
            preLoadChildren: function () {
                if (this.getRadioBox()) {
                    this.getRadioBox().preLoad();
                }
            },

            loadChildren: function () {
                if (this.getRadioBox()) {
                    return this.getRadioBox().load();
                }
                return null;
            },

            unloadChildren: function () {
                if (this.getRadioBox()) {
                    this.getRadioBox().unload();
                }
            },

            setValue: function (value) {
                var oldValue = this.getRadioBox().getRawValue();
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["value", value, oldValue]);
                this.getRadioBox().setRawValue(value);
                value = this.getRadioBox().getRawValue();
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["value", value, oldValue]);
            },

            getValue: function () {
                return this.getRadioBox().getRawValue();
            },

            setText: function (value) {
                return this.getRadioBox().setText(value);
            },

            getText: function () {
                return this.getRadioBox().getText();
            },

            getRadioBox: function () {
                return this.radioBox;
            },

            setRadioBox: function (value) {
                var oldValue = this.radioBox;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["radioBox", value, oldValue]);
                this.radioBox = value;
                this.radioBox.addListener(this);

                Deferred.when(this.catchUpLoadChild(value)).done({
                    handler: function () {
                        this.fireListener(LISTENER_PROPERTY_CHANGED, ["radioBox", value, oldValue]);
                    },
                    scope: this
                }).fail({
                    handler: function () {
                        debug.error([this.id, " set radioBox failed."].join(""));
                    },
                    scope: this
                });
            },

            setID: function (id) {
                base.setID.call(this, id);

                if (this.getRadioBox()) {
                    this.getRadioBox().setID(id + ".radioBox:0");
                }
            },

            getSelected: function () {
                return this.getRadioBox().getChecked();
            },

            setSelected: function (value) {
                if (isNullOrUndefined(value) || value === this.selected) {
                    return;
                }

                var oldValue = this.selected;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["selected", value, oldValue]);

                this.selected = value;
                this.getRadioBox().setChecked(value);

                this.fireListener(LISTENER_PROPERTY_CHANGED, ["selected", value, oldValue]);

                this.fireListener(LISTENER_SELECTED_CHANGED, [value]);
                this.fireEvent(EVENT_SELECTED_CHANGED, [value]);
            },

            onCheckChanged: function (source, value) {
                if (!isNullOrUndefined(value) && value != this.selected) {
                    this.setSelected(value);
                }
            }
        })
    .$();
});