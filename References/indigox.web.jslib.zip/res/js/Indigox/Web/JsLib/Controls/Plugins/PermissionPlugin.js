﻿define("Indigox.Web.JsLib.Controls.Plugins.PermissionPlugin",
    [
        "Indigox.Web.JsLib.Controls.Plugins.Plugin",
        "Indigox.Web.JsLib.Utils.Util",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Plugin,
        Util
) {
    var base = Plugin.prototype;

    var PermissionPlugin =
        Namespace("Indigox.Web.JsLib.Controls.Plugins")
        .Class("PermissionPlugin")
        .Extend(base)
        .Constructor(
            function (option) {
                base.constructor.apply(this, arguments);

                option = Util.copyExist({
                    permission: 0
                }, option);
                this.configure(option);
            }
        )
        .Static({
            READ: 1 << 0,
            WRITE: 1 << 1,
            DELETE: 1 << 2,
            CREATE: 1 << 3,
            LIST: 1 << 4,
            ADMINISTRATION: 1 << 5,
            WFTerminate: 1 << 10,
            WFCancel: 1 << 11,
            WFGoto: 1 << 12,
            WFReject: 1 << 13,
            WFWithdraw: 1 << 14,
            WFRedirect: 1 << 15,
            WFReply: 1 << 16
        })
        .Members({
            setPermission: function (value) {
                this.permission = value;
            },

            getPermission: function () {
                return this.permission;
            },

            setControl: function (control) {
                base.setControl.apply(this, arguments);
                if (control != null) {
                    control.setVisible(false);
                }
            },

            execute: function (record) {
                var control = this.getControl();
                if (!control) {
                    return;
                }

                var allowedPermission = record.get("EffectivePermission");
                var matched = false;
                if ((this.permission & allowedPermission) == this.permission) {
                    matched = true;
                }

                var setter = control.getSetter("Visible");
                if (control.hasSetter("Visible")) {
                    if (matched) {
                        control[setter](true);
                    }
                    else {
                        control[setter](false);
                    }
                }
                else {
                    throw new Error("The Contorl [" + control.id + "] can not set Visible!");
                }
            }
        })
    .$();
});