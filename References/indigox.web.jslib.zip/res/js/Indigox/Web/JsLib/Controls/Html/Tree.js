﻿define("Indigox.Web.JsLib.Controls.Html.Tree",
    [
        "Indigox.Web.JsLib.Controls.Html.Button",
        "Indigox.Web.JsLib.Utils.ArrayUtil",
        "Indigox.Web.JsLib.Controls.Html.TreeNode",
        "Indigox.Web.JsLib.Utils.Util",
        "Indigox.Web.JsLib.Utils.StringUtil",
        "Indigox.Web.JsLib.Collection.List",
        "Indigox.Web.JsLib.Controls.Html.HierarchyControl",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Button,
        ArrayUtil,
        TreeNode,
        Util,
        StringUtil,
        List,
        HierarchyControl
    ) {

    var base = HierarchyControl.prototype;

    var LISTENER_NODE_ADDED = 'NodeAdded',
        LISTENER_NODE_REMOVED = 'NodeRemoved',
        LISTENER_NODE_SELECTED_CHANGED = 'NodeSelectedChanged';

    var Tree =
        Namespace("Indigox.Web.JsLib.Controls.Html")
        .Class("Tree")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.controller = null;
                this.treeNodeType = "treenode";
                this.valueField = "id";
                this.value = new List();
                this.selectable = false;
                this.expandLevel = 1;
                this.selectedPath = "";
                this.mode = "MULTI";
                this.allowDeselect = true;
                this.nodeIndexer = {};
            }
        )
        .Members({
            newNode: function (config) {
                var node = Type.forAlias(this.treeNodeType).createInstance();
                node.setRoot(this);
                if (config) {
                    node.configure(config);
                }
                return node;
            },
            getExpandLevel: function () {
                return this.expandLevel;
            },
            expandNode: function (node) {
                this.getController().setRelated(node.getRecord());
                this.getController().load();
                node.childLoaded = true;
                node.fireListener('PropertyChanged', ['hasChildNodes()', node.hasChildNodes()]);
            },
            getLevel: function () {
                return 0;
            },

            expandPath: function (path) {/* /jituan/fengongsi/abc */
                if (StringUtil.isNullOrEmpty(path)) {
                    return;
                }
                var nodes = path.split("/");
                var i = null,
                    length = null;
                for (i = 0, length = nodes.length; i < (length - 1); i++) {
                    this.findNodeByValue(nodes[i]).expand();
                }

                if (length > 0) {
                    var treeNode = this.findNodeByValue(nodes[length - 1]);
                    if (treeNode) {
                        treeNode.setSelected(true);
                    }
                    else {
                        //debug.log("Not find Node :" + nodes[length - 1]);
                    }
                }
            },

            findNodeByValue: function (value) {
                if (isNullOrUndefined(this.nodeIndexer[value])) {
                    this.visit(this);
                }
                return this.nodeIndexer[value];
            },

            visit: function (node) {
                var i = null;
                var length = null;
                var childNodes = node.getChildNodes();
                for (i = 0, length = childNodes.length; i < length; i++) {
                    var child = childNodes[i];
                    var childValue = child.getValue();
                    this.nodeIndexer[childValue] = child;
                    this.visit(child);
                }
            },

            load: function () {
                var promise = base.load.apply(this, arguments);
                if (!this.getSelMode()) {
                    this.setSelMode(this.createSelectionMode());
                }
                this.expandPath(this.selectedPath);
                return promise;
            },

            onNodeAdded: function (source, index, node) {
                //this.fireListener(LISTENER_NODE_ADDED, [index, node]);
            },

            setValue: function () {
                base.setValue.apply(this, arguments);
            },

            selectNode: function (selectedValue) {
                var nodes = this.getNodes();
                var i = null,
                    length = null,
                    isSeleted = false;
                for (i = 0, length = nodes.length; i < length; i++) {
                    if (nodes[i].getValue() == selectedValue) {
                        nodes[i].setSelected(true);
                        isSeleted = true;
                        break;
                    }
                }
                if (!isSeleted) {
                    var controller = this.getController();
                    controller.setParam(this.valueField, selectedValue);
                    controller.load({ handler: this.selectNode, scope: this, args: [selectedValue] });
                    // var path = controller.getNodePath(this.valueField, selectedValue);
                    // this.expandPath(path);
                }
            }
        })
    .$();
});