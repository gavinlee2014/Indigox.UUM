﻿define("Indigox.Web.JsLib.Controls.Validation.Rules.StringRule",
    [
        "Indigox.Web.JsLib.Controls.Validation.Rules.Rule",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Rule
    ) {

    var base = Rule.prototype;

    var StringRule =
        Namespace("Indigox.Web.JsLib.Controls.Validation.Rules")
        .Class("StringRule")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
            }
        )
        .Members({
            isMatch: function (value) {
                if (StringUtil.isNullOrEmpty(value)) {
                    return true;
                }
                if (!isNaN(value)) {
                    return false;
                }
                return isString(value);
            }
        })
    .$();
} );