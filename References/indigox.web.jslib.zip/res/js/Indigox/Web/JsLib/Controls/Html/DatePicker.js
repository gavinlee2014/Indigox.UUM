﻿define("Indigox.Web.JsLib.Controls.Html.DatePicker",
    [
        "Indigox.Web.JsLib.Utils.DateTimeUtil",
        "Indigox.Web.JsLib.Utils.Deferred",
        "Indigox.Web.JsLib.Utils.StringUtil",
        "Indigox.Web.JsLib.Controls.Html.Button",
        "Indigox.Web.JsLib.Controls.Html.TextBox",
        "Indigox.Web.JsLib.Controls.Html.FieldControl",
        "Indigox.Web.JsLib.Core"
    ],
function (
        DateTimeUtil,
        Deferred,
        StringUtil,
        Button,
        TextBox,
        FieldControl
) {
    var EVENT_VALUE_CHANGED = "valueChanged";

    var LISTENER_PROPERTY_CHANGING = "PropertyChanging",
        LISTENER_PROPERTY_CHANGED = "PropertyChanged";

    var base = FieldControl.prototype;

    var DatePicker =
        Namespace("Indigox.Web.JsLib.Controls.Html")
        .Class("DatePicker")
        .Extend(base)
        .Constructor(
            function () {
                this.dateTime = null;
                this.editHMS = true;
                this.maxDate = null; // Date
                this.minDate = null; // Date

                base.constructor.apply(this, arguments);
            }
        )
        .Members({
            setYear: function (value) {
                this.setDateTime(value, null, null, null, null, null, false);
            },
            getYear: function () {
                if (this.isEmpty()) {
                    return "";
                }
                var value = this.dateTime.getFullYear();
                return value.toString();
            },

            setMonth: function (value) {
                this.setDateTime(null, value, null, null, null, null, false);
            },
            getMonth: function () {
                if (this.isEmpty()) {
                    return "";
                }
                var value = this.dateTime.getMonth() + 1;
                return this.padLeft(value, 2, "00");
            },

            setDay: function (value) {
                this.setDateTime(null, null, value, null, null, null, false);
            },
            getDay: function () {
                if (this.isEmpty()) {
                    return "";
                }
                var value = this.dateTime.getDate();
                return this.padLeft(value, 2, "00");
            },

            setHours: function (value) {
                this.setDateTime(null, null, null, value, null, null, false);
            },
            getHours: function () {
                if (this.isEmpty()) {
                    return "";
                }
                var value = this.dateTime.getHours();
                return this.padLeft(value, 2, "00");
            },

            setMinutes: function (value) {
                this.setDateTime(null, null, null, null, value, null, false);
            },
            getMinutes: function () {
                if (this.isEmpty()) {
                    return "";
                }
                var value = this.dateTime.getMinutes();
                return this.padLeft(value, 2, "00");
            },

            setSeconds: function (value) {
                this.setDateTime(null, null, null, null, null, value, false);
            },
            getSeconds: function () {
                if (this.isEmpty()) {
                    return "";
                }
                var value = this.dateTime.getSeconds();
                return this.padLeft(value, 2, "00");
            },

            setDate: function (value) {
                if (isNullOrUndefined(value) || value === "") {
                    this.clear();
                    return;
                }

                var date = DateTimeUtil.parse(value);
                this.setDateTime(date.getFullYear(), date.getMonth() + 1, date.getDate(), null, null, null, false);
            },
            getDate: function () {
                if (this.isEmpty()) {
                    return "";
                }
                return DateTimeUtil.toShortString(
                    this.dateTime.getFullYear(),
                    this.dateTime.getMonth() + 1,
                    this.dateTime.getDate());
            },

            setTime: function (value) {
                var date = DateTimeUtil.parse("1900-01-01 " + value);
                this.setDateTime(null, null, null, date.getHours(), date.getMinutes(), date.getSeconds(), false);
            },
            getTime: function () {
                if (this.isEmpty()) {
                    return "";
                }
                return DateTimeUtil.toLongString(
                    this.dateTime.getFullYear(),
                    this.dateTime.getMonth() + 1,
                    this.dateTime.getDate(),
                    this.dateTime.getHours(),
                    this.dateTime.getMinutes(),
                    this.dateTime.getSeconds()).substring(10);
            },

            setValue: function (value) {
                if (isNullOrUndefined(value) || value === "") {
                    this.clear();
                    return;
                }

                var date = DateTimeUtil.parse(value);
                this.setDateTime(date.getFullYear(), date.getMonth() + 1, date.getDate(), date.getHours(), date.getMinutes(), date.getSeconds(), false);
            },
            getValue: function () {
                if (this.isEmpty()) {
                    return "";
                }
                else if (this.getEditHMS()) {
                    return DateTimeUtil.toLongString(
                        this.dateTime.getFullYear(),
                        this.dateTime.getMonth() + 1,
                        this.dateTime.getDate(),
                        this.dateTime.getHours(),
                        this.dateTime.getMinutes(),
                        this.dateTime.getSeconds());
                }
                else {
                    return DateTimeUtil.toShortString(
                        this.dateTime.getFullYear(),
                        this.dateTime.getMonth() + 1,
                        this.dateTime.getDate());
                }
            },

            setDateTime: function (year, month, day, hours, minutes, seconds, empty) {
                var editHMS = this.getEditHMS();

                // old values
                var _dateTime = this.dateTime,
                    _empty = !_dateTime,
                    _y = "",
                    _M = "",
                    _d = "",
                    _H = "",
                    _m = "",
                    _s = "",
                    _date = "",
                    _time = "",
                    _value = "";

                if (!_empty) {
                    _y = this.padLeft(_dateTime.getFullYear(), 2, "00");
                    _M = this.padLeft(_dateTime.getMonth() + 1, 2, "00");
                    _d = this.padLeft(_dateTime.getDate(), 2, "00");
                    _H = this.padLeft(_dateTime.getHours(), 2, "00");
                    _m = this.padLeft(_dateTime.getMinutes(), 2, "00");
                    _s = this.padLeft(_dateTime.getSeconds(), 2, "00");
                    _date = DateTimeUtil.toShortString(_y, _M, _d);
                    _time = DateTimeUtil.toLongString(_y, _M, _d, _H, _m, _s).substring(10);
                    _value = (editHMS) ? DateTimeUtil.toLongString(_y, _M, _d, _H, _m, _s) : DateTimeUtil.toShortString(_y, _M, _d);
                }

                // new values
                var dateTime = this.dateTime,
                    y = "",
                    M = "",
                    d = "",
                    H = "",
                    m = "",
                    s = "",
                    date = "",
                    time = "",
                    value = "";

                if (empty) {
                    if (!_empty) {
                        this.fireListener(LISTENER_PROPERTY_CHANGING, ["year", y, _y]);
                        this.fireListener(LISTENER_PROPERTY_CHANGED, ["year", y, _y]);

                        this.fireListener(LISTENER_PROPERTY_CHANGING, ["month", M, _M]);
                        this.fireListener(LISTENER_PROPERTY_CHANGED, ["month", M, _M]);

                        this.fireListener(LISTENER_PROPERTY_CHANGING, ["day", d, _d]);
                        this.fireListener(LISTENER_PROPERTY_CHANGED, ["day", d, _d]);

                        this.fireListener(LISTENER_PROPERTY_CHANGING, ["hours", H, _H]);
                        this.fireListener(LISTENER_PROPERTY_CHANGED, ["hours", H, _H]);

                        this.fireListener(LISTENER_PROPERTY_CHANGING, ["minutes", m, _m]);
                        this.fireListener(LISTENER_PROPERTY_CHANGED, ["minutes", m, _m]);

                        this.fireListener(LISTENER_PROPERTY_CHANGING, ["seconds", s, _s]);
                        this.fireListener(LISTENER_PROPERTY_CHANGED, ["seconds", s, _s]);

                        this.fireListener(LISTENER_PROPERTY_CHANGING, ["date", date, _date]);
                        this.fireListener(LISTENER_PROPERTY_CHANGED, ["date", date, _date]);

                        this.fireListener(LISTENER_PROPERTY_CHANGING, ["time", time, _time]);
                        this.fireListener(LISTENER_PROPERTY_CHANGED, ["time", time, _time]);

                        this.fireListener(LISTENER_PROPERTY_CHANGING, ["value", value, _value]);
                        this.fireListener(LISTENER_PROPERTY_CHANGED, ["value", value, _value]);
                        this.fireEvent(EVENT_VALUE_CHANGED, [value]);

                        this.dateTime = null;
                    }
                    return;
                }

                if (_empty) {
                    dateTime = DateTimeUtil.parse("1900-01-01 00:00:00");
                    this.dateTime = dateTime;
                }

                y = this.padLeft(year || dateTime.getFullYear(), 2, "00");
                M = this.padLeft(month || dateTime.getMonth() + 1, 2, "00");
                d = this.padLeft(day || dateTime.getDate(), 2, "00");
                H = this.padLeft(hours || dateTime.getHours(), 2, "00");
                m = this.padLeft(minutes || dateTime.getMinutes(), 2, "00");
                s = this.padLeft(seconds || dateTime.getSeconds(), 2, "00");
                date = DateTimeUtil.toShortString(y, M, d);
                time = DateTimeUtil.toLongString(y, M, d, H, m, s).substring(10);
                value = (editHMS) ? DateTimeUtil.toLongString(y, M, d, H, m, s) : DateTimeUtil.toShortString(y, M, d);

                if (y != _y) {
                    this.fireListener(LISTENER_PROPERTY_CHANGING, ["year", y, _y]);
                    dateTime.setFullYear(y);
                    this.fireListener(LISTENER_PROPERTY_CHANGED, ["year", y, _y]);
                }

                if (M != _M) {
                    this.fireListener(LISTENER_PROPERTY_CHANGING, ["month", M, _M]);
                    dateTime.setMonth(M - 1);
                    this.fireListener(LISTENER_PROPERTY_CHANGED, ["month", M, _M]);
                }

                if (d != _d) {
                    this.fireListener(LISTENER_PROPERTY_CHANGING, ["day", d, _d]);
                    dateTime.setDate(d);
                    this.fireListener(LISTENER_PROPERTY_CHANGED, ["day", d, _d]);
                }

                if (H != _H) {
                    this.fireListener(LISTENER_PROPERTY_CHANGING, ["hours", H, _H]);
                    dateTime.setHours(H);
                    this.fireListener(LISTENER_PROPERTY_CHANGED, ["hours", H, _H]);
                }

                if (m != _m) {
                    this.fireListener(LISTENER_PROPERTY_CHANGING, ["minutes", m, _m]);
                    dateTime.setMinutes(m);
                    this.fireListener(LISTENER_PROPERTY_CHANGED, ["minutes", m, _m]);
                }

                if (s != _s) {
                    this.fireListener(LISTENER_PROPERTY_CHANGING, ["seconds", s, _s]);
                    dateTime.setSeconds(s);
                    this.fireListener(LISTENER_PROPERTY_CHANGED, ["seconds", s, _s]);
                }

                if (date != _date) {
                    this.fireListener(LISTENER_PROPERTY_CHANGING, ["date", date, _date]);
                    this.fireListener(LISTENER_PROPERTY_CHANGED, ["date", date, _date]);
                }

                if (time != _time) {
                    this.fireListener(LISTENER_PROPERTY_CHANGING, ["time", time, _time]);
                    this.fireListener(LISTENER_PROPERTY_CHANGED, ["time", time, _time]);
                }

                if (value != _value) {
                    this.fireListener(LISTENER_PROPERTY_CHANGING, ["value", value, _value]);
                    this.fireListener(LISTENER_PROPERTY_CHANGED, ["value", value, _value]);
                    this.fireEvent(EVENT_VALUE_CHANGED, [value]);
                }
            },

            padLeft: function (text, length, mask) {
                text = text.toString();
                if (text.length >= length) {
                    return text;
                }
                return mask.substring(length - text.length) + text;
            },

            isEmpty: function () {
                return !this.dateTime;
            },

            clear: function () {
                this.setDateTime(null, null, null, null, null, null, true);
            },

            setEditHMS: function (value) {
                var oldValue = this.getEditHMS();
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["editHMS", value, oldValue]);
                this.editHMS = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["editHMS", value, oldValue]);
            },

            getEditHMS: function () {
                return this.editHMS;
            },

            setMaxDate: function (value) {
                if (isNaN(value)) {
                    value = new Date(value);
                }

                var oldValue = this.getMaxDate();
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["maxDate", value, oldValue]);
                this.maxDate = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["maxDate", value, oldValue]);
            },

            getMaxDate: function () {
                return this.maxDate;
            },

            setMinDate: function (value) {
                if (isNaN(value)) {
                    value = new Date(value);
                }

                var oldValue = this.getMinDate();
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["minDate", value, oldValue]);
                this.minDate = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["minDate", value, oldValue]);
            },

            getMinDate: function () {
                return this.minDate;
            }
        })
    .$();
});