﻿define("Indigox.Web.JsLib.Controls.Grid.SummaryRow",
    [
        "Indigox.Web.JsLib.Controls.Grid.GridRow",
        "Indigox.Web.JsLib.Utils.NumberUtil",
        "Indigox.Web.JsLib.Core"
    ],
function (
        GridRow,
        NumberUtil
) {
    var EVENT_SUMMARY_VALUE_CHANGED = "summaryValueChanged";

    var LISTENER_SUMMARY_VALUE_CHANGED = "SummaryValueChanged";

    var base = GridRow.prototype;

    var SummaryRow =
        Namespace("Indigox.Web.JsLib.Controls.Grid")
        .Class("SummaryRow")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.summaryColumn = null;
            }
        )
        .Members({
            registerEvents: function () {
                base.registerEvents.call(this);
                this.events.registerEvents(
                    EVENT_SUMMARY_VALUE_CHANGED
                );
            },

            registerListeners: function () {
                base.registerListeners.call(this);
                this.listeners.registerListeners(
                    LISTENER_SUMMARY_VALUE_CHANGED
                );
            },

            load: function () {
                base.load.apply(this, arguments);
                this.addUp();
            },

            setSummaryColumn: function (value) {
                this.summaryColumn = value;
            },

            getSummaryColumn: function () {
                return this.summaryColumn;
            },

            onRowRemoved: function (source, index, row) {
                this.addUp();
            },

            onRowAdded: function (source, index, row) {
                this.addUp();
            },

            onValueChanged: function (source, row, cell, value) {
                if (cell.getColumn().getField() in this.summaryColumn) {
                    this.addUp(cell.getColumn().getField());
                }
            },

            addUp: function (field) {
                var type;
                if (isNullOrUndefined(field)) {
                    for (var key in this.summaryColumn) {
                        if (key === undefined) {
                            continue;
                        }
                        type = this.summaryColumn[key];
                        this.setSummaryValue(key, type);
                    }
                }
                else {
                    if (field in this.summaryColumn) {
                        type = this.summaryColumn[field];
                        this.setSummaryValue(field, type);
                    }
                }
            },

            setSummaryValue: function (field, type) {
                var oldValue = this.getCell(field).getValue();
                var summaryValue = this.getSummaryValue(field, type);
                if (isNullOrUndefined(summaryValue)) {
                    summaryValue = "";
                }
                if (oldValue == summaryValue) {
                    return;
                }
                this.getCell(field).setValue(summaryValue);
                this.fireListener(LISTENER_SUMMARY_VALUE_CHANGED, [field, summaryValue]);
                this.fireEvent(EVENT_SUMMARY_VALUE_CHANGED, [field, summaryValue]);
            },

            getSummaryValue: function (field, type) {
                if (type) {
                    if (isFunction(type)) {
                        return null; //exec function
                    }
                    switch (type) {
                        case 'count': return this.getCount(field);
                        case 'min': return this.getMin(field);
                        case 'max': return this.getMax(field);
                        case 'sum': return this.getSum(field);
                        case 'average': return this.getAverage(field);
                        default: return '';
                    }
                }
            },

            getCount: function (field) {
                var parent = this.getParent();
                var count = parent.getRows().length;
                return count;
            },

            getMin: function (field) {
                var parent = this.getParent();
                var cells = parent.getCellsByField(field);
                var min = null;
                var i = 0,
                    length = cells.length;
                for (; i < length; i++) {
                    var cell = cells[i];
                    if (min == null || min > cell.getValue()) {
                        min = cell.getValue();
                    }
                }
                return min;
            },

            getMax: function (field) {
                var parent = this.getParent();
                var cells = parent.getCellsByField(field);
                var max = null, cell = null;
                var i = 0,
                    length = cells.length;
                for (; i < length; i++) {
                    cell = cells[i];
                    if (max == null || max < cell.getValue()) {
                        max = cell.getValue();
                    }
                }
                return max;
            },

            getSum: function (field) {
                var cells = this.getParent().getCellsByField(field);
                var sum = parseFloat("0"), cell = null;
                var i = 0,
                    length = cells.length;
                for (; i < length; i++) {
                    var value = cells[i].getValue();
                    if (value === "") {
                        value = 0;
                    }
                    if (!isNullOrUndefined(value) && !isNaN(value)) {
                        sum = NumberUtil.add(sum, value);
                    }
                }
                return sum;
            },

            getAverage: function (field) {
                var sum = this.getSum(field);
                var count = this.getCount(field);
                return sum / count;
            },

            onPropertyChanged: function (source, property, value, oldValue) {
            }
        })
    .$();
});