﻿define("Indigox.Web.JsLib.Controls.Plugins.BadgePlugin",
    [
        "Indigox.Web.JsLib.Controls.Plugins.Plugin",
        "Indigox.Web.JsLib.Utils.Util",
        "Indigox.Web.JsLib.CQRS.Batch",
        "Indigox.Web.JsLib.CQRS.AutoBatch",
        "Indigox.Web.JsLib.Utils.DelayedTask",
        "Indigox.Web.JsLib.Utils.Delegate",
        "Indigox.Web.JsLib.Core"
    ],
    function (
        Plugin,
        Util,
        Batch,
        AutoBatch,
        DelayedTask,
        Delegate
    ) {
        var base = Plugin.prototype;

        var BadgePlugin =
            Namespace("Indigox.Web.JsLib.Controls.Plugins")
            .Class("BadgePlugin")
            .Extend(base)
            .Constructor(
                function (option) {
                    base.constructor.apply(this, arguments);

                    option = Util.copyExist({
                        query: null,
                        timeout: null
                    }, option);
                    this.configure(option);
                    this.delayTask = null;
                    this.delayTask = new DelayedTask(function () {
                        this.queryBadge();
                    }, this, []);
                }
            )
            .Members({
                setQuery: function (value) {
                    this.query = value;
                },

                getQuery: function () {
                    return this.query;
                },

                setTimeout: function (value) {
                    this.timeout = value;
                },

                getTimeout: function () {
                    return this.timeout;
                },

                onLoading: function () {
                    this.queryBadge();
                },

                onUnload: function () {
                    if (this.delayTask) {
                        this.delayTask.cancel();
                        this.delaytask = null;
                    }
                },

                queryBadge: function () {
                    debug.log("queryBadge " + new Date());
                    if (this.delayTask) {
                        this.delayTask.cancel();
                    }
                    var batch = AutoBatch.getCurrentBatch();
                    batch.size({
                        name: this.getQuery(),
                        callback: Delegate.create(this.handleBadge, this)
                    });
                },

                handleBadge: function (count) {
                    this.getControl().setBadge(count);
                    var timeout = this.getTimeout();
                    if (!isNullOrUndefined(timeout)) {
                        /*this.delayTask = new DelayedTask(function () {
                        this.queryBadge();
                        }, this, []);*/
                        this.delayTask.delay(timeout);
                    }
                }
            })
        .$();
    });