﻿define("Indigox.Web.JsLib.Controls.FormControl",
    [
        "Indigox.Web.JsLib.Controllers.Controller",
        "Indigox.Web.JsLib.Utils.Util",
        "Indigox.Web.JsLib.Utils.Callback",
        "Indigox.Web.JsLib.Utils.Deferred",
        "Indigox.Web.JsLib.Collection.List",
        "Indigox.Web.JsLib.Controls.Container",
        "Indigox.Web.JsLib.Controls.Html.FieldControl",
        "Indigox.Web.JsLib.Controls.Html.ListControl",
        "Indigox.Web.JsLib.Controls.Html.ItemControl",
        "Indigox.Web.JsLib.Controls.Html.FieldSet",
        "Indigox.Web.JsLib.Core"
    ],
    function (
        Controller,
        Util,
        Callback,
        Deferred,
        List,
        Container,
        FieldControl,
        ListControl,
        ItemControl,
        FieldSet
    ) {
        var base = Container.prototype;

        var EVENT_SUBMIT = 'submit';

        var FormControl =
        Namespace("Indigox.Web.JsLib.Controls")
            .Class("FormControl")
            .Extend(base)
            .Constructor(
                function () {
                    base.constructor.apply(this, arguments);

                    this.controller = null;
                }
            )
            .Members({
                doLoad: function () {
                    var dfd = new Deferred();
                    if (this.getController() && this.getController().getAutoLoad() == true) {
                        this.getController().load(function () {
                            dfd.resolve();
                        });
                    }
                    else {
                        dfd.resolve();
                    }
                    return dfd.promise();
                },

                unload: function () {
                    base.unload.apply(this, arguments);
                    if (this.getController()) {
                        this.getController().unload();
                    }
                },

                registerEvents: function () {
                    base.registerEvents.call(this);
                    this.events.registerEvents(
                        EVENT_SUBMIT
                    );
                },

                setController: function (controller) {
                    if (!(controller instanceof Controller)) {
                        var controllerInfo = controller;
                        controller = Type.forAlias(controllerInfo.controllerType).createInstance();
                        controller.configure(controllerInfo);
                    }

                    if (this.controller) {
                        this.controller.setView(null);
                    }
                    this.controller = controller;
                    if (this.controller) {
                        this.controller.setView(this);
                    }

                    if (this.isLoaded() && this.controller.autoLoad === true) {
                        this.controller.load();
                    }
                },

                getController: function () {
                    return this.controller;
                },

                isFieldChild: function (child) {
                    if (child instanceof FieldControl ||
                        child instanceof ListControl ||
                        child instanceof ItemControl) {
                        return true;
                    }
                    return false;
                },

                getFields: function () {
                    var fields = [];
                    var child = null;
                    var i = null, length = null;
                    for (i = 0, length = this.children.length; i < length; i++) {
                        child = this.children[i];
                        if (child instanceof FieldSet) {
                            var fieldsetChild = null;
                            var j = null, lengthJ = null;
                            for (j = 0, lengthJ = child.children.length; j < lengthJ; j++) {
                                fieldsetChild = child.children[j];
                                var k = null, fieldChild = null, lengthK;
                                for (k = 0, lengthK = fieldsetChild.children.length; k < lengthK; k++) {
                                    fieldChild = fieldsetChild.children[k];
                                    if (this.isFieldChild(fieldChild)) {
                                        fields.push(fieldChild);
                                    }
                                }
                            }
                        }
                        if (this.isFieldChild(child)) {
                            fields.push(child);
                        }
                    }
                    return fields;
                },

                submit: function () {
                    this.getController().save(new Callback(this.doSubmit, this));
                },

                doSubmit: function (successed) {
                    //if (successed) {
                    //    debug.log("Form submited successed");
                    //}
                    //else {
                    //    debug.error("Form submited faild");
                    //}
                    this.fireEvent(EVENT_SUBMIT, [successed]);
                },

                reset: function () {
                    var fields = this.getFields();
                    var i, length, field;
                    for (i = 0, length = fields.length; i < length; i++) {
                        field = fields[i];
                        if (field instanceof FieldSet) { 
                            field.reset();                        
                        }
                        else if(field.isEditable()) {
                            field.setValue(null);
                        }
                    }
                }
            })
        .$();
    });