﻿define("Indigox.Web.JsLib.Controls.Html.Accordion",
    [
        "Indigox.Web.JsLib.Utils.Util",
        "Indigox.Web.JsLib.Utils.ArrayUtil",
        "Indigox.Web.JsLib.Collection.List",
        "Indigox.Web.JsLib.Controls.Html.Button",
        "Indigox.Web.JsLib.Controls.Html.AccordionItem",
        "Indigox.Web.JsLib.Controls.Html.ListControl",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Util,
        ArrayUtil,
        List,
        Button,
        AccordionItem,
        ListControl
) {
    var base = ListControl.prototype;

    var LISTENER_PROPERTY_CHANGING = "PropertyChanging",
        LISTENER_PROPERTY_CHANGED = "PropertyChanged";

    var Accordion =
        Namespace("Indigox.Web.JsLib.Controls.Html")
        .Class("Accordion")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.controller = null;
                this.orientation = Accordion.ORIENTATION_VERTICAL;
                //this.controlType = "label";
                this.autoCollapse = true;
            }
        )
        .Static({
            ORIENTATION_HORIZONTAL: 0,
            ORIENTATION_VERTICAL: 1
        })
        .Members({
            setAutoCollapse: function (value) {
                var oldValue = this.autoCollapse;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["autoCollapse", value, oldValue]);
                this.autoCollapse = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["autoCollapse", value, oldValue]);
            },
            getAutoCollapse: function () {
                return this.autoCollapse;
            },

            setOrientation: function (value) {
                var oldValue = this.orientation;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["orientation", value, oldValue]);
                this.orientation = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["orientation", value, oldValue]);
            },
            getOrientation: function () {
                return this.orientation;
            },
            expandItem: function (item) {
                if (this.getAutoCollapse()) {
                    var items = this.getItems();
                    var i, length;
                    for (i = 0, length = items.length; i < length; i++) {
                        if (items[i] !== item) {
                            items[i].collapse();
                        }
                    }
                }
                item.expand();
            },
            newItem: function (config) {
                var item = new AccordionItem();
                //item.setControl(Type.forAlias(this.controlType).createInstance());
                if (config) {
                    item.configure(config);
                }
                return item;
            },

            onPropertyChanged: function (source, property, value, oldValue) {
                if ((property === "collapsed") && (!value)) {
                    this.expandItem(source);
                }
            }
        })
    .$();
});