﻿define("Indigox.Web.JsLib.Controls.Plugins.PropertyMappingPlugin",
    [
        "Indigox.Web.JsLib.Controls.Plugins.Plugin",
        "Indigox.Web.JsLib.Utils.Util",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Plugin,
        Util
) {
    var base = Plugin.prototype;

    var PropertyMappingPlugin =
        Namespace("Indigox.Web.JsLib.Controls.Plugins")
        .Class("PropertyMappingPlugin")
        .Extend(base)
        .Constructor(
            function (option) {
                base.constructor.apply(this, arguments);

                option = Util.copyExist({
                    columnName: null,
                    propertyName: null,
                    mapping: null
                }, option);
                this.configure(option);
            }
        )
        .Members({
            setColumnName: function (columnName) {
                this.columnName = columnName;
            },

            getColumnName: function () {
                return this.columnName;
            },

            setPropertyName: function (propertyName) {
                this.propertyName = propertyName;
            },

            getPropertyName: function () {
                return this.propertyName;
            },

            setMapping: function (mapping) {
                this.mapping = mapping;
            },

            getMapping: function () {
                return this.mapping;
            },

            execute: function (record) {
                var control = this.getControl();
                if (!control) {
                    return;
                }
                var propertyName = this.getPropertyName();
                var val = record.get(this.getColumnName());
                if (this.getMapping()) {
                    val = this.getMapping()[val];
                }
                var setter = control.getSetter(propertyName);
                if (control.hasSetter(propertyName)) {
                    control[setter](val);
                }
            }
        })
    .$();
});