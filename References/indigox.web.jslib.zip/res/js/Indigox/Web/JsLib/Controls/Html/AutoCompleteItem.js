﻿define("Indigox.Web.JsLib.Controls.Html.AutoCompleteItem",
    [
        "Indigox.Web.JsLib.Utils.Deferred",
        "Indigox.Web.JsLib.Controls.Html.ItemControl",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Deferred,
        ItemControl
) {
    var EVENT_SELECTED_CHANGED = "selectedChanged";

    var LISTENER_PROPERTY_CHANGING = "PropertyChanging",
        LISTENER_PROPERTY_CHANGED = "PropertyChanged",
        LISTENER_SELECTED_CHANGED = "SelectedChanged";

    var base = ItemControl.prototype;

    var AutoCompleteItem =
        Namespace("Indigox.Web.JsLib.Controls.Html")
        .Class("AutoCompleteItem")
        .Extend(base)
        .Constructor(
            function () {
                this.isActive = false;
                base.constructor.apply(this, arguments);
            }
        )
        .Members({
            registerListeners: function () {
                base.registerListeners.call(this);
                this.listeners.registerListeners(
                    LISTENER_PROPERTY_CHANGED
                );
            },
            getIsActive: function () { return this.isActive; },
            setIsActive: function (value) {
                if (isNullOrUndefined(value)) {
                    return;
                }
                var oldValue = this.isActive;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["isActive", value, oldValue]);
                this.isActive = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["isActive", value, oldValue]);
            },

            getText: function () { return this.text; },
            setText: function (value) {
                if (isNullOrUndefined(value)) {
                    return;
                }
                var oldValue = this.text;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["text", value, oldValue]);
                this.text = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["text", value, oldValue]);
            },

            select: function () {
                this.fireListener(LISTENER_SELECTED_CHANGED, []);
            },
            mark: function (active) {
                this.isActive = true;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["isActive", active, !active]);
            }
        })
    .$();
});