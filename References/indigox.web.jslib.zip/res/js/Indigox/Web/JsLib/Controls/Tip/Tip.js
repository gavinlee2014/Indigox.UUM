﻿define("Indigox.Web.JsLib.Controls.Tip.Tip", 
    [
        "Indigox.Web.JsLib.Controls.Html.Label",
        "Indigox.Web.JsLib.Controls.Component",
        "Indigox.Web.JsLib.Core"
    ],
    function (
        Label,
        Component
    ) {

        var base = Component.prototype;

        var Tip =
        Namespace('Indigox.Web.JsLib.Controls.Tip')
        .Class('Tip')
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.tiptext = "";
                this.tipControl = null;
                this.control = null;
            }
        )
        .Members({
            setTipText: function (value) {
                if (this.tiptext === value) {
                    return;
                }
                this.tiptext = value;
            },

            getTipText: function () {
                return this.tiptext;
            },
            setControl: function (value) {
                this.control = value;
            },

            getControl: function () {
                return this.control;
            },

            setTipControl: function (value) {
                if (isNullOrUndefined(value)) {
                    return;
                }

                if (typeof value === 'string') {
                }
                else {
                    this.tipControl = value;
                }
            },

            getTipControl: function () {
                return this.tipControl;
            },

            fillTipControl: function () {
                var tip = this.getTipControl();

                if (tip.children.length === 0) {
                    throw new Error("the tipcontrol has no place to show tip");
                }

                var tiptext = tip.children[0];
                if (tiptext instanceof Label) {
                    tiptext.setValue(this.getTipText());
                }
                else {
                    throw new Error("the tipcontrol's first child control should be a Label");
                }
            },

            show: function (x, y) {
                var tip = this.getTipControl();

                this.fillTipControl();

                tip.show(x, y);
            },

            hide: function () {
                this.getTipControl().hide();
            }
        })
    .$();
    });