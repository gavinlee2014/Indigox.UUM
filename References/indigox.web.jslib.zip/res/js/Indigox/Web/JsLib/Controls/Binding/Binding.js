﻿define("Indigox.Web.JsLib.Controls.Binding.Binding",
    [
        "Indigox.Web.JsLib.Utils.Configurable",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Configurable
    ) {

    var base = Configurable.prototype;

    var Binding =
        Namespace("Indigox.Web.JsLib.Controls.Binding")
        .Class("Binding")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.referenceFields = [];
                this.mode = "ReadAndWrite";
            }
        )
        .Members({
            getReferenceFields: function () {
                return this.referenceFields;
            },

            setReferenceFields: function (value) {
                this.referenceFields = value;
            },

            getMode: function () {
                return this.mode;
            },

            setMode: function (value) {
                this.mode = value;
            },

            bind: function (control, record, field) {
            },

            provide: function (control, record, field) {
            }
        })
    .$();
});