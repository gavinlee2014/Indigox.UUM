﻿define("Indigox.Web.JsLib.Controls.Html.MenuItem",
    [
        "Indigox.Web.JsLib.Controls.Html.NodeControl",
        "Indigox.Web.JsLib.Controls.Html.Menu",
        "Indigox.Web.JsLib.Core"
    ],
function (
        NodeControl,
        Menu
    ) {
    
    var base = NodeControl.prototype;

    var EVENT_VALUE_CHANGED = "valueChanged",
        EVENT_ITEM_ADDED = "itemAdded",
        EVENT_ITEM_REMOVED = "itemRemoved";

    var LISTENER_PROPERTY_CHANGING = "PropertyChanging",
        LISTENER_PROPERTY_CHANGED = "PropertyChanged",
        LISTENER_ITEM_ADDED = "ItemAdded",
        LISTENER_ITEM_REMOVED = "ItemRemoved";

    var MenuItem =
        Namespace("Indigox.Web.JsLib.Controls.Html")
        .Class("MenuItem")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.topMenu = false;
                this.level = 1;
                this.orientation = MenuItem.ORIENTATION_VERTICAL;
                this.displaySubMenu = MenuItem.DISPLAYSUBMENU_STATIC;
                this.popout = false;
                this.popDirection = MenuItem.POPDIRECTION_RIGHT_TO_LEFT;
                this.menu = null;
            }
        )
        .Static({
            ORIENTATION_HORIZONTAL: 0,
            ORIENTATION_VERTICAL: 1,
            DISPLAYSUBMENU_STATIC: 0,
            DISPLAYSUBMENU_DYNAMIC: 1,
            POPDIRECTION_RIGHT_TO_LEFT: 0,
            POPDIRECTION_TOP_TO_DOWN: 1
        })
        .Members({
            load: function () {
                var promise = base.load.apply(this, arguments);
                this.computeDisplaySubMenu();
                return promise;
            },

            registerEvents: function () {
                base.registerEvents.call(this);
                this.events.registerEvents(
                    EVENT_ITEM_ADDED,
                    EVENT_ITEM_REMOVED
                );
            },

            registerListeners: function () {
                base.registerListeners.call(this);
                this.listeners.registerListeners(
                    LISTENER_ITEM_ADDED,
                    LISTENER_ITEM_REMOVED
                );
            },

            hasChildMenus: function () {
                return this.childNodes.size() > 0;
            },

            setParent: function (value) {
                if (value instanceof Menu) {
                    this.setTopMenu(true);
                }
                else {
                    this.setTopMenu(false);
                }
                base.setParent.apply(this, arguments);
            },

            setTopMenu: function (value) {
                if (this.topMenu === value) {
                    return;
                }
                var oldValue = this.topMenu;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["topMenu", value, oldValue]);
                this.topMenu = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["topMenu", value, oldValue]);
            },

            getTopMenu: function () {
                return this.topMenu;
            },

            setLevel: function (value) {
                if (this.level === value) {
                    return;
                }
                this.level = value;
                //this.fireListener(LISTENER_PROPERTY_CHANGED, ["level", this.getLevel()]);
            },

            getLevel: function () {
                return this.level;
            },

            setOrientation: function (value) {
                if (this.orientation === value) {
                    return;
                }
                var oldValue = this.orientation;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["orientation", value, oldValue]);
                this.orientation = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["orientation", value, oldValue]);
            },

            getOrientation: function () {
                return this.orientation;
            },

            setDisplaySubMenu: function (value) {
                if (this.displaySubMenu === value) {
                    return;
                }
                this.displaySubMenu = value;
            },

            getDisplaySubMenu: function () {
                return this.displaySubMenu;
            },

            setPopout: function (value) {
                if (this.popout === value) {
                    return;
                }
                var oldValue = this.popout;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["popout", value, oldValue]);
                this.popout = value;
                //TODO: async to expand node
                if (!this.childLoaded) {
                    this.getRoot().expandNode(this);
                }
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["popout", value, oldValue]);
            },

            getPopout: function () {
                return this.popout;
            },

            setPopDirection: function (value) {
                var oldValue = this.popDirection;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["popDirection", value, oldValue]);
                this.popDirection = value;
                this.fireListener(LISTENER_PROPERTY_CHANGED, ["popDirection", value, oldValue]);
            },

            getPopDirection: function () {
                return this.popDirection;
            },

            showChildMenu: function () {
                if (this.getDisplaySubMenu() === MenuItem.DISPLAYSUBMENU_DYNAMIC) {
                    this.setPopout(true);
                }
            },

            hideChildMenu: function () {
                if (this.getDisplaySubMenu() === MenuItem.DISPLAYSUBMENU_DYNAMIC) {
                    this.setPopout(false);
                }
            },

            toggleChildMenu: function () {
                if (this.getDisplaySubMenu() === MenuItem.DISPLAYSUBMENU_DYNAMIC) {
                    if (this.getPopout()) {
                        this.setPopout(false);
                    }
                    else {
                        this.setPopout(true);
                    }
                }
            },

            computeDisplaySubMenu: function () {
                if (this.getRoot() != null) {
                    if (this.getRoot().getStaticDisplayLevels() > this.getLevel()) {
                        this.setDisplaySubMenu(MenuItem.DISPLAYSUBMENU_STATIC);
                        this.setPopout(true);
                    }
                    else {
                        this.setDisplaySubMenu(MenuItem.DISPLAYSUBMENU_DYNAMIC);
                        //this.setPopout(false);
                    }
                }
            },

            onPropertyChanged: function (source, property, value, oldValue) {
                if (property === "staticDisplayLevels") {
                    this.computeDisplaySubMenu();
                }
            }
        })
    .$();
});