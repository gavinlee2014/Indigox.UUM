﻿define("Indigox.Web.JsLib.Controls.Html.FileUploadItem",
    [
        "Indigox.Web.JsLib.Utils.Deferred",
        "Indigox.Web.JsLib.Controls.Html.FileUpload",
        "Indigox.Web.JsLib.Controls.Html.ItemControl",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Deferred,
        FileUpload,
        ItemControl
) {
    var LISTENER_PROPERTY_CHANGING = "PropertyChanging",
        LISTENER_PROPERTY_CHANGED = "PropertyChanged";

    var base = ItemControl.prototype;

    var FileUploadItem =
        Namespace("Indigox.Web.JsLib.Controls.Html")
        .Class("FileUploadItem")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.fileUpload = null;
                this.addDefaultChildren();
            }
        )
        .Members({
            initChildren: function () {
                if (this.getFileUpload()) {
                    this.getFileUpload().init();
                }
            },

            preLoadChildren: function () {
                if (this.getFileUpload()) {
                    this.getFileUpload().preLoad();
                }
            },

            loadChildren: function () {
                if (this.getFileUpload()) {
                    this.getFileUpload().load();
                }
            },

            unloadChildren: function () {
                if (this.getFileUpload()) {
                    this.getFileUpload().unload();
                }
            },

            addDefaultChildren: function () {
                this.setFileUpload(new FileUpload("fileupload"));
            },

            getFileUpload: function () {
                return this.fileUpload;
            },

            setFileUpload: function (value) {
                var oldValue = this.fileUpload;
                this.fireListener(LISTENER_PROPERTY_CHANGING, ["fileUpload", value, oldValue]);

                this.fileUpload = value;
                this.fileUpload.owner = this;

                Deferred.when(this.catchUpLoadChild(value)).done({
                    handler: function () {
                        this.fireListener(LISTENER_PROPERTY_CHANGED, ["fileUpload", this.fileUpload]);
                    },
                    scope: this
                }).fail({
                    handler: function () {
                        debug.error([this.id, " set fileUpload failed."].join(""));
                    },
                    scope: this
                });
            },

            getValue: function () {
                return this.fileUpload.getValue();
            },
            setValue: function (value) {
                this.fileUpload.setValue(value);
            },

            getReadonly: function () {
                return base.getReadonly.call(this);
            },
            setReadonly: function (value) {
                //debug.log("FileUploadItem.readonly from " + this.readonly + " to " + value);
                base.setReadonly.call(this, value);
                this.fileUpload.setReadonly(value);
            },

            setAsCompleted: function () {
                this.fileUpload.setAsCompleted();
            }
        })
    .$();
});