﻿define("Indigox.Web.JsLib.Mappings.FormatMapping",
    [
        "Indigox.Web.JsLib.Mappings.DefaultMapping",
        "Indigox.Web.JsLib.Utils.StringUtil",
        "Indigox.Web.JsLib.Core"
    ],
function (
        DefaultMapping,
        StringUtil
    ) {
    
    var base = DefaultMapping.prototype;

    var FormatMapping =
        Namespace("Indigox.Web.JsLib.Mappings")
        .Class("FormatMapping")
        .Extend(base)
        .Constructor(
            function (format) {
                this.format = format;
            }
        )
        .Members({
            map: function (value) {
                if (!StringUtil.isNullOrEmpty(value)) {
                    return StringUtil.format(this.format, value);
                }
                else {
                    return value;
                }
            },
            unmap: function (value) {
                if (!StringUtil.isNullOrEmpty(value)) {
                    var expression = this.format
                        .replace("\\", "\\\\")
                        .replace("(", "\\(")
                        .replace(")", "\\)")
                        .replace(".", "\\.")
                        .replace("+", "\\+")
                        .replace("{0}", "(.+)")
                        .replace("[", "\\[")
                        .replace("]", "\\]")
                        .replace("{", "\\{")
                        .replace("}", "\\}")
                        .replace("*", "\\*")
                        .replace("?", "\\?")
                        .replace("^", "\\^")
                        .replace("$", "\\$")
                        .replace("|", "\\|")
                        .replace("/", "\\/")
                    //.replace( "'", "'|\"" )
                        .replace("#", "\\#")
                        .replace("/", "\\/")
                        .replace("-", "\\-");
                    var regex = new RegExp("^" + expression + "$");
                    var match;
                    if (match = regex.exec(value)) {
                        return match[1];
                    }
                }
                else {
                    return value;
                }
            }
        })
    .$();
} );