﻿define("Indigox.Web.JsLib.Mappings.DefaultMapping",
    [
        "Indigox.Web.JsLib.Core"
    ],
function () {
    var instance = null;

    var DefaultMapping =
        Namespace("Indigox.Web.JsLib.Mappings")
        .Class("DefaultMapping")
        .Constructor(
            function () {
                this.pairs = [];
                var pair = null;
                var i = null,
                    length = null;
                for (i = 0, length = arguments.length; i < length; i++) {
                    pair = arguments[i];
                    this.pairs.push({
                        propValue: pair[0],
                        attrValue: pair[1]
                    });
                }
            }
        )
        .Static({
            getInstance: function () {
                if (!instance) {
                    instance = new DefaultMapping();
                }
                return instance;
            }
        })
        .Members({
            map: function (value) {
                if (isNullOrUndefined(value)) {
                    return value;
                }
                var pairs = this.pairs;

                var i = null,
                    length = null;
                for (i = 0, length = pairs.length; i < length; i++) {
                    if (pairs[i].propValue === value) {
                        return pairs[i].attrValue;
                    }
                }
                return value;
            },
            unmap: function (value) {
                if (!isNullOrUndefined(value)) {
                    var pairs = this.pairs;

                    var i = null,
                        length = pairs.length;
                    for (i = 0, length = pairs.length; i < length; i++) {
                        if (pairs[i].attrValue === value) {
                            return pairs[i].propValue;
                        }
                    }
                }
                return value;
            }
        })
    .$();
});