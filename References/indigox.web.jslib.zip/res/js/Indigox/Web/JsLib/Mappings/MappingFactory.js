﻿define("Indigox.Web.JsLib.Mappings.MappingFactory",
    [
        "Indigox.Web.JsLib.Core"
    ],
    function (

    ) {
        var instance = null;

        var MappingFactory =
            Namespace("Indigox.Web.JsLib.Mappings")
            .Class("MappingFactory")
            .Constructor(
                function () {
                    this.defaultMapping = null;
                    this.mappings = {};
                }
            )
            .Static({
                getInstance: function () {
                    if (!instance) {
                        instance = new MappingFactory();
                    }
                    return instance;
                }
            })
            .Members({
                register: function (identifier, mapping) {
                    this.mappings[identifier] = mapping;
                },
                unregister: function (identifier) {
                    delete this.mappings[identifier];
                },
                getDefaultMapping: function () {
                    return this.defaultMapping;
                },
                setDefaultMapping: function (mapping) {
                    this.defaultMapping = mapping;
                },
                getMapping: function (identifier) {
                    var mappings = this.mappings;
                    if (identifier in mappings) {
                        return mappings[identifier];
                    }
                    return this.getDefaultMapping();
                }
            })
        .$();
    });