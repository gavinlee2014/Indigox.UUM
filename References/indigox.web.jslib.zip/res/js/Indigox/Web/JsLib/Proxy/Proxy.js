﻿define("Indigox.Web.JsLib.Proxy.Proxy",
    [
        "Indigox.Web.JsLib.Utils.Configurable",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Configurable
) {
    var base = Configurable.prototype;

    var Proxy =
        Namespace("Indigox.Web.JsLib.Proxy")
        .Class("Proxy")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
            }
        )
        .Members({
            create: function () {
            },

            read: function () {
            },

            update: function () {
            },

            destroy: function () {
            },

            list: function () {
            },

            size: function () {
            }
        })
    .$();

});