﻿define("Indigox.Web.JsLib.Proxy.InstructionProxy",
    [
        "Indigox.Web.JsLib.Proxy.Proxy",
        "Indigox.Web.JsLib.Utils.Util",
        "Indigox.Web.JsLib.Utils.Callback",
        "Indigox.Web.JsLib.CQRS.Batch",
        "Indigox.Web.JsLib.CQRS.AutoBatch",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Proxy,
        Util,
        Callback,
        Batch,
        AutoBatch
) {
    var base = Proxy.prototype;

    var InstructionProxy =
        Namespace("Indigox.Web.JsLib.Proxy")
        .Class("InstructionProxy")
        .Extend(base)
        .Constructor(
            function (option) {
                base.constructor.apply(this, arguments);
                option = Util.copyExist({
                    query: "",
                    createCommand: "",
                    updateCommand: "",
                    deleteCommand: "",
                    batch: null
                }, option);
                this.configure(option);
            }
        )
        .Members({
            setQuery: function (value) {
                this.query = value;
            },

            getQuery: function () {
                return this.query;
            },

            setCreateCommand: function (value) {
                this.createCommand = value;
            },

            getCreateCommand: function () {
                return this.createCommand;
            },

            setUpdateCommand: function (value) {
                this.updateCommand = value;
            },

            getUpdateCommand: function () {
                return this.updateCommand;
            },

            setDeleteCommand: function (value) {
                this.deleteCommand = value;
            },

            getDeleteCommand: function () {
                return this.deleteCommand;
            },

            getBatch: function () {
                return this.batch;
            },

            setBatch: function (value) {
                this.batch = value;
            },

            create: function (rawData, callback) {
                this.executeCommand(this.createCommand, rawData, callback);
            },

            update: function (rawData, callback) {
                this.executeCommand(this.updateCommand, rawData, callback);
            },

            destroy: function (rawData, callback) {
                this.executeCommand(this.deleteCommand, rawData, callback);
            },

            list: function (params, callback) {
                this.executeQuery('list', params, callback);
            },

            single: function (params, callback) {
                this.executeQuery('single', params, callback);
            },

            size: function (params, callback) {
                this.executeQuery('size', params, callback);
            },

            //@private
            executeQuery: function (type, params, callback) {
                var loadParams = this.getQueryParams(params);
                var _callback = Callback.createInstance(callback);

                if (this.query === "") {
                    if (_callback) {
                        _callback.invoke({});
                    }
                    return;
                }

                var batch = this.getBatch();
                var batchSpecified = !isNullOrUndefined(batch);
                if (!batchSpecified) {
                    //batch = Batch.beginBatch();
                    batch = AutoBatch.getCurrentBatch();
                }

                batch[type]({
                    name: this.query,
                    properties: loadParams,
                    callback: function (data) {
                        if (_callback) {
                            _callback.invoke(data);
                        }
                    },
                    errorCallback: function (data) {
                        if (_callback) {
                            _callback.invoke(data);
                        }
                    }
                });
            },

            //@private
            getQueryParams: function (params) {
                // clone a copy
                params = Util.copy({}, params);
                params.FirstResult = params.FirstResult || 0;
                return params;
            },

            //@private
            executeCommand: function (command, rawData, callback) {
                var batch = this.getBatch();
                var batchSpecified = !isNullOrUndefined(batch);
                if (!batchSpecified) {
                    //batch = Batch.beginBatch();
                    batch = AutoBatch.getCurrentBatch();
                }
                var _callback = Callback.createInstance(callback);
                batch.execute({
                    name: command,
                    properties: rawData,
                    callback: function (data) {
                        if (_callback) {
                            _callback.invoke(0);
                        }
                    },
                    errorCallback: function (data) {
                        if (_callback) {
                            _callback.invoke(1);
                        }
                    }
                });
                if (!batchSpecified) {
                    batch.commit();
                }
                //?
                // else {
                //     _callback.invoke(0);
                // }
            }
        })
    .$();

});