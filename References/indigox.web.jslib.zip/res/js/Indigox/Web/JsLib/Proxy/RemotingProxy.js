﻿define("Indigox.Web.JsLib.Proxy.RemotingProxy",
    [
        "Indigox.Web.JsLib.Proxy.Proxy",
        "Indigox.Web.JsLib.Utils.Util",
        "Indigox.Web.JsLib.Utils.Callback",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Proxy,
        Util,
        Callback
) {
    var base = Proxy.prototype;

    //@deprecated
    var RemotingProxy =
        Namespace("Indigox.Web.JsLib.Proxy")
        .Class("RemotingProxy")
        .Extend(base)
        .Constructor(
            function (option) {
                debug.warn("RemotingProxy is deprecated, please use InstructionProxy.");
                base.constructor.apply(this, arguments);
                option = Util.copyExist({
                    listMethod: "GetList",
                    readMethod: "Read",
                    createMethod: "Create",
                    updateMethod: "Update",
                    deleteMethod: "Delete",
                    getTotalMethod: "GetTotalCount"
                }, option);
                this.configure(option);
            }
        )
        .Members({
            setService: function (service) {
                this.service = service;
            },

            getService: function () {
                return this.service;
            },

            setListMethod: function (listMethod) {
                this.listMethod = listMethod;
            },

            getListMethod: function () {
                return this.listMethod;
            },

            setReadMethod: function (readMethod) {
                this.readMethod = readMethod;
            },

            getReadMethod: function () {
                return this.readMethod;
            },

            setCreateMethod: function (createMethod) {
                this.createMethod = createMethod;
            },

            getCreateMethod: function () {
                return this.createMethod;
            },

            setUpdateMethod: function (updateMethod) {
                this.updateMethod = updateMethod;
            },

            getUpdateMethod: function () {
                return this.updateMethod;
            },

            setDeleteMethod: function (deleteMethod) {
                this.deleteMethod = deleteMethod;
            },

            getDeleteMethod: function () {
                return this.deleteMethod;
            },

            setGetTotalMethod: function (getTotalMethod) {
                this.getTotalMethod = getTotalMethod;
            },

            getGetTotalMethod: function () {
                return this.getTotalMethod;
            },

            create: function (rawData, callback) {
                try {
                    if (isFunction(this.createMethod)) {
                        this.createMethod(rawData);
                    }
                    else {
                        this.service[this.createMethod](rawData);
                    }
                    callback.invoke(0);
                } catch (e) {
                    callback.invoke(1);
                }
            },

            update: function (rawData, callback) {
                try {
                    if (isFunction(this.updateMethod)) {
                        this.updateMethod(rawData);
                    }
                    else {
                        this.service[this.updateMethod](rawData);
                    }
                    callback.invoke(0);
                } catch (e) {
                    debug.error("update error : ");
                    debug.error(e);
                    callback.invoke(1);
                }
            },

            destroy: function (rawData, callback) {
                try {
                    if (isFunction(this.deleteMethod)) {
                        this.deleteMethod(rawData);
                    }
                    else {
                        this.service[this.deleteMethod](rawData);
                    }
                    callback.invoke(0);
                } catch (e) {
                    callback.invoke(1);
                }
            },

            read: function (loadParams) {
                if (isFunction(this.readMethod)) {
                    return this.readMethod.apply(this.service, loadParams);
                }
                else {
                    return this.service[this.readMethod].apply(this.service, loadParams);
                }
            },

            list: function (params, callback) {
                var loadParams = this.getQueryParams(params);

                var rawData = [];
                if (isFunction(this.listMethod)) {
                    rawData = this.listMethod.apply(this, loadParams);
                }
                else {
                    rawData = this.service[this.listMethod].apply(this.service, loadParams);
                }

                callback = Callback.createInstance(callback);
                if (callback) {
                    callback.invoke(rawData);
                }
            },

            size: function (params, callback) {
                var loadParams = this.getQueryParams(params);

                var size = 0;

                if (isFunction(this.getTotalMethod)) {
                    size = this.getTotalMethod.apply(this.service, loadParams);
                }
                else {
                    size = this.service[this.getTotalMethod].apply(this.service, loadParams);
                }

                callback = Callback.createInstance(callback);
                if (callback) {
                    callback.invoke(size);
                }
            },

            //@private
            getQueryParams: function (params) {
                // clone a copy
                params = Util.copy({}, params);

                var startindex = params.startindex || 0;
                var pagesize = params.pagesize;

                delete params.startindex;
                delete params.pagesize;

                var loadParams = [];
                var name = "";
                for (name in params) {
                    loadParams.push(params[name]);
                }
                loadParams.push(startindex);
                if (pagesize != null) {
                    loadParams.push(pagesize);
                }
                return loadParams;
            }
        })
    .$();

});