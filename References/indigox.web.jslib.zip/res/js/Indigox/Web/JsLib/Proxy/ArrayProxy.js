﻿define("Indigox.Web.JsLib.Proxy.ArrayProxy",
    [
        "Indigox.Web.JsLib.Proxy.Proxy",
        "Indigox.Web.JsLib.Utils.Util",
        "Indigox.Web.JsLib.Utils.ArrayUtil",
        "Indigox.Web.JsLib.Utils.Callback",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Proxy,
        Util,
        ArrayUtil,
        Callback
) {



    var base = Proxy.prototype;

    var ArrayProxy =
        Namespace("Indigox.Web.JsLib.Proxy")
        .Class("ArrayProxy")
        .Extend(base)
        .Constructor(
            function (option) {
                base.constructor.apply(this, arguments);
                option = Util.copyExist({
                    array: []
                }, option);
                this.configure(option);
            }
        )
        .Members({
            setArray: function (array) {
                this.array = array;
            },

            getArray: function () {
                return this.array;
            },

            create: function () {
            },

            read: function () {
            },

            update: function () {
            },

            list: function (params, callback) {
                params = params || {};
                var data = [],
                    array = this.array;

                if (!array) {
                    return;
                }

                var i = null,
                    length = null;
                for (i = 0, length = array.length; i < length; i++) {
                    if (this.filter(array[i], params)) {
                        data.push(array[i]);
                    }
                }
                callback = Callback.createInstance(callback);
                if (callback) {
                    callback.invoke(data);
                }
            },

            filter: function (value, params) {
                for (var name in params) {
                    if (isArray(params[name])) {
                        if (!ArrayUtil.contains(params[name], value[name])) {
                            return false;
                        }
                    }
                    if (value[name] != params[name]) {
                        return false;
                    }
                }
                return true;
            },

            destroy: function () {
            },

            size: function () {
                return this.data.length;
            }
        })
    .$();

});