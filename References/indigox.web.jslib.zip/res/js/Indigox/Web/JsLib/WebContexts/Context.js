﻿define("Indigox.Web.JsLib.WebContexts.Context",
    [
        "/_remoting/ContextQuery/Single/jsonp?!callback=define",
        "Indigox.Web.JsLib.Utils.ErrorHandler",
        "Indigox.Web.JsLib.Core"
    ],
    function (
        contextQuery,
        ErrorHandler
    ) {
        var instance = null;

        var Context =
            Namespace("Indigox.Web.JsLib.WebContexts")
            .Class("Context")
            .Constructor(
                function () {
                    this.settings = {};
                    this.navigation = {};
                    this.user = {};
                }
            )
            .Static({
                getInstance: function () {
                    if (!instance) {
                        instance = new Context();

                        if (contextQuery.Status === 0) {
                            var result = contextQuery.Result;
                            instance.settings = result.Settings;
                            instance.navigation = result.Navigation;
                            instance.user = result.User;
                        }
                        else {
                            ErrorHandler.log(contextQuery.Error);
                        }
                    }
                    return instance;
                }
            })
            .Members({
                getSettings: function () {
                    return this.settings;
                },

                getSetting: function (key) {
                    return this.settings[key];
                },

                getNavigation: function (nav) {
                    var name = 'Default';
                    if (nav) {
                        name = nav;
                    }
                    return this.navigation[name];
                },

                getUser: function () {
                    return this.user;
                }
            })
        .$();
    });