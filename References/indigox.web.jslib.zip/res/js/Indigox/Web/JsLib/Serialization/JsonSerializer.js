﻿define("Indigox.Web.JsLib.Serialization.JsonSerializer",
    [
        "Indigox.Web.JsLib.Utils.Util",
        "json2",
        "Indigox.Web.JsLib.Core"
    ],
    function (
        Util,
        JSON
    ) {
        var functionMatcher = /^\s*function\s*\([\s\S]*\)\s*\{[\s\S]*\}\s*$/;

        function tryParseDate(value) {
            var d = new Date(value.slice(5, -1));
            if (d) {
                return d;
            }
            return value;
        }

        function parseFunction(value) {
            try {
                return eval('(function(){var f=' + value + ';return f;}());');
            } catch (e) {
                debug.error(e);
                throw new Error("can't parse function string: " + value);
            }
        }

        function specialTypeConverter(key, value) {
            if (typeof value === 'string') {
                // date string
                if (value.slice(0, 5) === 'Date(' && value.slice(-1) === ')') {
                    return tryParseDate(value);
                }

                // function string
                if (functionMatcher.test(value)) {
                    return parseFunction(value);
                }
            }

            return value;
        }

        var instance = null;

        var JsonSerializer =
            Namespace("Indigox.Web.JsLib.Serialization")
            .Class("JsonSerializer")
            .Static({
                getInstance: function () {
                    if (instance === null) {
                        instance = new JsonSerializer();
                    }
                    return instance;
                }
            })
            .Members({
                deserialize: function (text) {
                    try {
                        return JSON.parse(text, specialTypeConverter);
                        //return JSON.parse(text);
                    } catch (e) {
                        debug.error("Can't parse json text:\r\n" + text);
                        throw new Error("Can't parse json text.");
                    }
                },
                serialize: function (o) {
                    return JSON.stringify(o);
                }
            })
        .$();
    });