﻿define("Indigox.Web.JsLib.Invokers.FieldGetterInvoker",
    [
        "Indigox.Web.JsLib.Invokers.MemberInvoker",
        "Indigox.Web.JsLib.Core"
    ],
function (
        MemberInvoker
    ) {

    var base = MemberInvoker.prototype;

    var FieldGetterInvoker =
        Namespace("Indigox.Web.JsLib.Invokers")
        .Class("FieldGetterInvoker")
        .Extend(base)
        .Constructor(
            function (member) {
                base.constructor.apply(this, arguments);
            }
        )
        .Members({
            getMember: function () {
                return this.member;
            },
            hasMember: function (obj) {
                var member = this.getMember();
                return member in obj;
            },
            invoke: function (obj, args) {
                return obj[this.getMember()];
            },
            tryInvoke: function (obj, args) {
                if (this.hasMember(obj)) {
                    return this.invoke(obj, args);
                }
                else {
                    return null;
                }
            }
        })
    .$();
});