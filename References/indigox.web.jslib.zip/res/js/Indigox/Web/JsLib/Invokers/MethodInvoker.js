﻿define("Indigox.Web.JsLib.Invokers.MethodInvoker",
    [
        "Indigox.Web.JsLib.Invokers.MemberInvoker",
        "Indigox.Web.JsLib.Core"
    ],
function (
        MemberInvoker
    ) {

    var base = MemberInvoker.prototype;
    
    var MethodInvoker =
        Namespace("Indigox.Web.JsLib.Invokers")
        .Class("MethodInvoker")
        .Extend(base)
        .Constructor(
            function (member) {
                base.constructor.apply(this, arguments);
            }
        )
        .Members({
            getMember: function () {
                return this.member;
            },
            hasMember: function (obj) {
                var member = this.getMember();
                return member in obj;
            },
            invoke: function (obj, args) {
                if (isNullOrUndefined(args)) {
                    return obj[this.getMember()].apply(obj);
                }
                else {
                    return obj[this.getMember()].apply(obj, args);
                }
            },
            tryInvoke: function (obj, args) {
                if (this.hasMember(obj)) {
                    return this.invoke(obj, args);
                }
                else {
                    return null;
                }
            }
        })
    .$();
});