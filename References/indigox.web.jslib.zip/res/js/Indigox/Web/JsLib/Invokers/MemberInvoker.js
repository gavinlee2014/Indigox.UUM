﻿define("Indigox.Web.JsLib.Invokers.MemberInvoker", 
    [
        "Indigox.Web.JsLib.Core"
    ],
function () {
    var MemberInvoker =
        Namespace("Indigox.Web.JsLib.Invokers")
        .Class("MemberInvoker")
        .Constructor(
            function (member) {
                this.member = member;
            }
        )
        .Members({
            getMember: function () {
                return this.member;
            },
            invoke: function (obj, args) {
            },
            tryInvoke: function (obj, args) {
            }
        })
    .$();
} );