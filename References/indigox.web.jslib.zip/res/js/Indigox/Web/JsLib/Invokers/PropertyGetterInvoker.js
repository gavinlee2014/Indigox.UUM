﻿define("Indigox.Web.JsLib.Invokers.PropertyGetterInvoker",
    [
        "Indigox.Web.JsLib.Invokers.MemberInvoker",
        "Indigox.Web.JsLib.Core"
    ],
function (
        MemberInvoker
    ) {

    var base = MemberInvoker.prototype;

    var PropertyGetterInvoker =
        Namespace("Indigox.Web.JsLib.Invokers")
        .Class("PropertyGetterInvoker")
        .Extend(base)
        .Constructor(
            function (member) {
                base.constructor.apply(this, arguments);
            }
        )
        .Members({
            getMember: function () {
                return this.member;
            },
            hasMember: function (obj) {
                var member = this.getGetter();
                return member in obj;
            },
            invoke: function (obj, args) {
                if (isNullOrUndefined(args)) {
                    return obj[this.getGetter()].apply(obj);
                }
                else {
                    return obj[this.getGetter()].apply(obj, args);
                }
            },
            tryInvoke: function (obj, args) {
                if (this.hasMember(obj)) {
                    return this.invoke(obj, args);
                }
                else {
                    return null;
                }
            },
            getGetter: function () {
                var field = this.getMember();
                if (field) {
                    return "get" + field.replace(/(\w)(\w*)/,
                        function (str, p1, p2) {
                            return (p1.toUpperCase() + (p2.length === 1 ? p2.toUpperCase() : p2));
                        }
                    );
                }
                return null;
            }
        })
    .$();
});