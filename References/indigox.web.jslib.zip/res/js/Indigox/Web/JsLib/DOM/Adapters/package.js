﻿define("Indigox.Web.JsLib.DOM.Adapters",
    [
        "Indigox.Web.JsLib.DOM.Adapters.GeckoAdapter",
        "Indigox.Web.JsLib.DOM.Adapters.OtherAdapter",
        "Indigox.Web.JsLib.DOM.Adapters.WebKitAdapter"
    ],
function (
    GeckoAdapter,
    OtherAdapter,
    WebKitAdapter
) {
    return {
        GeckoAdapter: GeckoAdapter,
        OtherAdapter: OtherAdapter,
        WebKitAdapter: WebKitAdapter
    }
});