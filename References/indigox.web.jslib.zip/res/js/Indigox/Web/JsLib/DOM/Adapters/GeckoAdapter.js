﻿define("Indigox.Web.JsLib.DOM.Adapters.GeckoAdapter",
    [
        "Indigox.Web.JsLib.DOM.BrowserAdapter",
        "Indigox.Web.JsLib.Core"
    ],
function (
        BrowserAdapter
) {
    var base = BrowserAdapter.prototype;

    var instance = null;

    var GeckoAdapter =
        Namespace("Indigox.Web.JsLib.DOM.Adapters")
        .Class("GeckoAdapter")
        .Extend(base)
        .Constructor(
            function () {
            }
        )
        .Static({
            getInstance: function () {
                if (isNullOrUndefined(instance)) {
                    instance = new GeckoAdapter();
                }
                return instance;
            }
        })
        .Members({
        })
    .$();
});