﻿define("Indigox.Web.JsLib.DOM.EventAdapter",
    [
        "Indigox.Web.JsLib.Utils.Callback",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Callback
) {
    var EventAdapter =
        Namespace("Indigox.Web.JsLib.DOM")
        .Class("EventAdapter")
        .Constructor(
            function () {
                this.delegate = null;
                this.callbacks = [];
            }
        )
        .Members({
            getDelegate: function () {
                return this.delegate;
            },
            addListener: function (handler, scope, args) {
                var callback = new Callback(handler, scope, args);
                this.callbacks.push(callback);
            },
            removeListener: function (handler) {
                var callbacks = this.callbacks;
                var i = null,
                    length = null;
                for (i = callbacks.length - 1; i >= 0; i--) {
                    if (callbacks[i].getHandler() === handler) {
                        callbacks.splice(i, 1);
                    }
                }
            },
            hasListener: function (handler) {
                var callbacks = this.callbacks;
                var i = null,
                    length = null;
                for (i = 0, length = callbacks.length; i < length; i++) {
                    if (callbacks[i].getHandler() === handler) {
                        return true;
                    }
                }
                return false;
            },
            createDelegate: function () {
                if (isNullOrUndefined(this.delegate)) {
                    var callbacks = this.callbacks;

                    this.delegate = function (e) {
                        var source = e.target;
                        for (var i = 0, length = callbacks.length; i < length; i++) {
                            callbacks[i].invoke(source, e);
                        }
                    };
                }
                return this.delegate;
            }
        })
    .$();
});