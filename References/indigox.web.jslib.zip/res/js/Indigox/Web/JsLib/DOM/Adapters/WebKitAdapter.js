﻿define("Indigox.Web.JsLib.DOM.Adapters.WebKitAdapter",
    [
        "Indigox.Web.JsLib.DOM.BrowserAdapter",
        "Indigox.Web.JsLib.Core"
    ],
function (
        BrowserAdapter
) {
    var base = BrowserAdapter.prototype;

    var instance = null;

    var WebKitAdapter =
        Namespace("Indigox.Web.JsLib.DOM.Adapters")
        .Class("WebKitAdapter")
        .Extend(base)
        .Constructor(
            function () {
            }
        )
        .Static({
            getInstance: function () {
                if (isNullOrUndefined(instance)) {
                    instance = new WebKitAdapter();
                }
                return instance;
            }
        })
        .Members({
            getClassList: function (element, className) {
                if (element.classList) {
                    return base.getClassList.apply(this, arguments);
                }
                else {
                    var classes = [];
                    var className = element.className;
                    var classList = className.split(/\s+/);
                    var i = null,
                    length = null;
                    for (i = 0, length = classList.length; i < length; i++) {
                        classes.push(classList[i]);
                    }
                    return classes;
                }
            }
        })
    .$();
});