﻿define("Indigox.Web.JsLib.DOM.Effect",
    [
        "Indigox.Web.JsLib.Utils.StringUtil",
        "Indigox.Web.JsLib.Utils.Callback",
        "Indigox.Web.JsLib.DOM.Element",
        "Indigox.Web.JsLib.Core"
    ],
function (
        StringUtil,
        Callback,
        Element
) {
    var El = Element.el;

    var Effect =
        Namespace("Indigox.Web.JsLib.DOM")
        .Class("Effect")
        .Constructor(
            function (element, dumpProps, start, end, callback) {
                this.id = null;
                this.interval = 25;
                this.duration = 500;
                this.times = this.duration / this.interval;
                this.element = element;
                this.dumpProps = dumpProps;
                this.start = start;
                this.end = end;
                this.callback = callback;
                this.snapshot = null;
                this.sign = 1;
                this.step = null;
            }
        )
        .Static({
            DIRECTION_RTL: 'rtl',
            DIRECTION_TTB: 'ttb',
            slideOut: function (element, direction) {
                var el = El(element);
                var property = null;
                var startValue = null;
                if (direction === Effect.DIRECTION_RTL) {
                    property = 'margin-left';
                    startValue = '-' + el.getComputedWidth() + 'px';
                }
                else {
                    property = 'margin-top';
                    startValue = '-' + el.getComputedHeight() + 'px';
                }
                var dumpProps = [], start = {}, end = {};
                dumpProps.push(property);
                start[property] = startValue;
                end[property] = el.getStyle(property) || '0px';
                return new Effect(
                    el,
                    dumpProps,
                    start,
                    end
                );
            },
            slideIn: function (element, direction) {
                var el = El(element);
                var property = null;
                var endValue = null;
                if (direction === Effect.DIRECTION_RTL) {
                    property = 'margin-left';
                    endValue = '-' + el.getComputedWidth() + 'px';
                }
                else {
                    property = 'margin-top';
                    endValue = '-' + el.getComputedHeight() + 'px';
                }
                var dumpProps = [], start = {}, end = {};
                dumpProps.push(property);
                start[property] = el.getStyle(property) || '0px';
                end[property] = endValue;
                return new Effect(
                    el,
                    dumpProps,
                    start,
                    end
                );
            },
            fadeOut: function (element, direction) {
                var el = El(element);
                var property = 'opacity';
                var dumpProps = [], start = {}, end = {};
                dumpProps.push(property);
                start[property] = 0;
                end[property] = 1;
                return new Effect(
                    el,
                    dumpProps,
                    start,
                    end
                );
            },
            fadeIn: function (element, direction) {
                var el = El(element);
                var property = 'opacity';
                var dumpProps = [], start = {}, end = {};
                dumpProps.push(property);
                start[property] = 1;
                end[property] = 0;
                return new Effect(
                    el,
                    dumpProps,
                    start,
                    end
                );
            }
        })
        .Members({
            play: function () {
                this.dump();
                var delegate = this.createDelegate();

                var el = this.element;

                var start = null,
                    end = null,
                    diff = null;

                this.step = {};
                for (var prop in this.end) {
                    start = this.start[prop];
                    if (isString(start)) {
                        start = StringUtil.parseFloat(start);
                    }

                    end = this.end[prop];
                    if (isString(end)) {
                        end = StringUtil.parseFloat(end);
                    }

                    diff = start - end;

                    this.step[prop] = Math.abs(diff) / this.times;
                }

                if (diff === 0) {
                    this.sign = 0;
                }
                else {
                    this.sign = -(diff / Math.abs(diff));
                }

                el.setStyle(this.start);
                el.setStyle({ display: 'block', visibility: 'visible' });
                this.id = setInterval(function () { delegate.invoke(); }, this.interval);
            },
            createDelegate: function () {
                if (isNullOrUndefined(this.delegate)) {
                    this.delegate = new Callback(function () {
                        this.times--;
                        if (this.times) {
                            this.doAnimation();
                        }
                        else {
                            clearInterval(this.id);
                            this.restore();
                            if (this.callback) {
                                this.callback.invoke();
                            }
                        }
                    }, this);
                }
                return this.delegate;
            },
            dump: function () {
                var el = this.element;

                this.snapshot = {};

                this.snapshot.display = el.getStyle('display');
                this.snapshot.visibility = el.getStyle('visibility');

                var dumpProps = this.dumpProps;
                var i = null,
                    length = null;
                for (i = 0, length = dumpProps.length; i < length; i++) {
                    this.snapshot[dumpProps[i]] = el.getStyle(dumpProps[i]);
                }
            },
            restore: function () {
                this.element.setStyle(this.snapshot);
            },
            doAnimation: function () {
                var el = this.element;
                var newStyles = {};
                for (var prop in this.step) {
                    var value = el.getStyle(prop);

                    if (isString(value)) {
                        value = StringUtil.parseFloat(value);
                    }
                    newStyles[prop] = value + this.sign * this.step[prop];
                }
                el.setStyle(newStyles);
            }
        })
    .$();
});