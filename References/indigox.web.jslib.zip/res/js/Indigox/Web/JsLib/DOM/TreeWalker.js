﻿define("Indigox.Web.JsLib.DOM.TreeWalker",
    [
        "Indigox.Web.JsLib.Collection.List",
        "Indigox.Web.JsLib.DOM.NodeType",
        "Indigox.Web.JsLib.DOM.NodeFilter",
        "Indigox.Web.JsLib.Core"
    ],
function (
        List,
        NodeType,
        NodeFilter
) {
    var TreeWalker =
        Namespace("Indigox.Web.JsLib.DOM")
        .Class("TreeWalker")
        .Constructor(
            function (root, whatToShow, filter, entityReferenceExpansion) {
                this.rootNode = root;
                // 当前节点
                this.currentNode = root;

                this.whatToShow = whatToShow;

                this.filter = filter ? filter : { acceptNode: function (node) { return NodeFilter.FILTER_ACCEPT; } };
                this.entityReferenceExpansion = entityReferenceExpansion;
            }
        )
        .Members({
            getCurrentNode: function () {
                return this.currentNode;
            },
            setCurrentNode: function (node) {
                if (!node) {
                    throw new Error("the current node of tree walker can not be set to null!");
                }
                this.currentNode = node;
            },
            parentNode: function () {
                if (this.currentNode == null) {
                    return null;
                }

                var node = this.getParentNode(this.currentNode);
                if (node != null) {
                    this.currentNode = node;
                }
                return node;
            },

            firstChild: function () {
                if (this.currentNode == null) {
                    return null;
                }

                var node = this.getFirstChild(this.currentNode);
                if (node != null) {
                    this.currentNode = node;
                }
                return node;
            },

            lastChild: function () {
                if (this.currentNode == null) {
                    return null;
                }

                var node = this.getLastChild(this.currentNode);
                if (node != null) {
                    this.currentNode = node;
                }
                return node;
            },

            previousSibling: function () {
                if (this.currentNode == null) {
                    return null;
                }

                var node = this.getPreviousSibling(this.currentNode);
                if (node != null) {
                    this.currentNode = node;
                }
                return node;
            },

            nextSibling: function () {
                if (this.currentNode == null) {
                    return null;
                }

                var node = this.getNextSibling(this.currentNode);
                if (node != null) {
                    this.currentNode = node;
                }
                return node;
            },

            previousNode: function () {
                var result;

                if (this.currentNode == null) {
                    return null;
                }

                // get sibling
                result = this.getPreviousSibling(this.currentNode);
                if (result == null) {
                    result = this.getParentNode(this.currentNode);
                    if (result != null) {
                        this.currentNode = result;
                        return this.currentNode;
                    }
                    return null;
                }

                // get the lastChild of result.
                var lastChild = this.getLastChild(result);

                var prev = lastChild;
                while (lastChild != null) {
                    prev = lastChild;
                    lastChild = this.getLastChild(prev);
                }

                lastChild = prev;

                // if there is a lastChild which passes filters return it.
                if (lastChild != null) {
                    this.currentNode = lastChild;
                    return this.currentNode;
                }

                // otherwise return the previous sibling.
                if (result != null) {
                    this.currentNode = result;
                    return this.currentNode;
                }

                // otherwise return null.
                return null;
            },

            nextNode: function () {
                if (this.currentNode == null) {
                    return null;
                }

                var result = this.getFirstChild(this.currentNode);

                if (result != null) {
                    this.currentNode = result;
                    return result;
                }

                result = this.getNextSibling(this.currentNode);

                if (result != null) {
                    this.currentNode = result;
                    return result;
                }

                // return parent's 1st sibling.
                var parent = this.getParentNode(this.currentNode);
                while (parent != null) {
                    result = this.getNextSibling(parent);
                    if (result != null) {
                        this.currentNode = result;
                        return result;
                    }
                    else {
                        parent = this.getParentNode(parent);
                    }
                }

                // end , return null
                return null;
            },

            getParentNode: function (node) {
                if (node == null || node == this.rootNode) {
                    return null;
                }

                var newNode = node.parentNode;
                if (newNode == null) { return null; }

                var accept = this.acceptNode(newNode);

                if (accept == NodeFilter.FILTER_ACCEPT) {
                    return newNode;
                }
                else //if (accept == NodeFilter.SKIP_NODE) // and REJECT too.
                {
                    return this.getParentNode(newNode);
                }
            },

            getNextSibling: function (node, rootNode) {
                if (!rootNode) {
                    rootNode = this.rootNode;
                }
                if (node == null || node == rootNode) {
                    return null;
                }

                var newNode = node.nextSibling;
                if (newNode == null) {
                    newNode = node.parentNode;

                    if (newNode == null || newNode == rootNode) {
                        return null;
                    }

                    var parentAccept = this.acceptNode(newNode);

                    if (parentAccept == NodeFilter.FILTER_SKIP) {
                        return this.getNextSibling(newNode, rootNode);
                    }

                    return null;
                }

                var accept = this.acceptNode(newNode);

                if (accept == NodeFilter.FILTER_ACCEPT) {
                    return newNode;
                }
                else if (accept == NodeFilter.FILTER_SKIP) {
                    var child = this.getFirstChild(newNode);
                    if (child == null) {
                        return this.getNextSibling(newNode, rootNode);
                    }
                    return child;
                }
                else
                //if (accept == NodeFilter.REJECT_NODE)
                {
                    return this.getNextSibling(newNode, rootNode);
                }
            },
            getPreviousSibling: function (node, rootNode) {
                if (!rootNode) {
                    rootNode = this.rootNode;
                }
                if (node == null || node == rootNode) {
                    return null;
                }

                var newNode = node.previousSibling;
                if (newNode == null) {
                    newNode = node.parentNode;
                    if (newNode == null || newNode == rootNode) {
                        return null;
                    }
                    var parentAccept = this.acceptNode(newNode);

                    if (parentAccept == NodeFilter.FILTER_SKIP) {
                        return this.getPreviousSibling(newNode, rootNode);
                    }

                    return null;
                }

                var accept = this.acceptNode(newNode);

                if (accept == NodeFilter.FILTER_ACCEPT) {
                    return newNode;
                }
                else if (accept == NodeFilter.FILTER_SKIP) {
                    var child = this.getLastChild(newNode);
                    if (child == null) {
                        return this.getPreviousSibling(newNode, rootNode);
                    }
                    return child;
                }
                else
                //if (accept == NodeFilter.REJECT_NODE)
                {
                    return this.getPreviousSibling(newNode, rootNode);
                }
            },
            getFirstChild: function (node) {
                if (node == null) {
                    return null;
                }

                if (!this.entityReferenceExpansion && node.nodeType == NodeType.ENTITY_REFERENCE_NODE) {
                    return null;
                }
                var newNode = node.firstChild;
                if (newNode == null) {
                    return null;
                }
                var accept = this.acceptNode(newNode);

                if (accept == NodeFilter.FILTER_ACCEPT) {
                    return newNode;
                }
                else if (accept == NodeFilter.FILTER_SKIP && newNode.hasChildNodes()) {
                    var child = this.getFirstChild(newNode);

                    if (child == null) {
                        return this.getNextSibling(newNode, node);
                    }
                    return child;
                }
                else
                //if (accept == NodeFilter.REJECT_NODE)
                {
                    return this.getNextSibling(newNode, node);
                }
            },
            getLastChild: function (node) {
                if (node == null) {
                    return null;
                }

                if (!this.entityReferenceExpansion && node.nodeType == NodeType.ENTITY_REFERENCE_NODE) {
                    return null;
                }

                var newNode = node.lastChild;
                if (newNode == null) { return null; }

                var accept = this.acceptNode(newNode);

                if (accept == NodeFilter.FILTER_ACCEPT) {
                    return newNode;
                }
                else if (accept == NodeFilter.FILTER_SKIP && newNode.hasChildNodes()) {
                    var child = this.getLastChild(newNode);
                    if (child == null) {
                        return this.getPreviousSibling(newNode, node);
                    }
                    return child;
                }
                else
                //if (accept == NodeFilter.REJECT_NODE)
                {
                    return this.getPreviousSibling(newNode, node);
                }
            },
            acceptNode: function (node) {
                if (this.filter == null) {
                    if ((this.whatToShow & (1 << node.nodeType - 1)) !== 0) {
                        return NodeFilter.FILTER_ACCEPT;
                    } else {
                        return NodeFilter.FILTER_SKIP;
                    }
                }
                else {
                    if ((this.whatToShow & (1 << node.nodeType - 1)) !== 0) {
                        return this.filter.acceptNode(node);
                    }
                    else {
                        // What to show has failed. See above excerpt from spec.
                        // Equivalent to FILTER_SKIP.
                        return NodeFilter.FILTER_SKIP;
                    }
                }
            }
        })
    .$();
});