﻿define("Indigox.Web.JsLib.DOM.Adapters.OtherAdapter",
    [
        "Indigox.Web.JsLib.DOM.BrowserAdapter",
        "Indigox.Web.JsLib.Utils.Browser",
        "Indigox.Web.JsLib.Core"
    ],
function (
        BrowserAdapter,
        Browser
) {
    var base = BrowserAdapter.prototype;

    var Browser = Browser.getInstance();

    var ATTR_FIXES = {
        'htmlFor': 'for',
        'className': 'class'
    };

    var HTML_REGEX = /<[^<]*/g;

    var ATTR_REGEX = /\s+(\w+)=/g;

    var instance = null;

    var OtherAdapter =
        Namespace("Indigox.Web.JsLib.DOM.Adapters")
        .Class("OtherAdapter")
        .Extend(base)
        .Constructor(
            function () {
            }
        )
        .Static({
            getInstance: function () {
                if (isNullOrUndefined(instance)) {
                    instance = new OtherAdapter();
                }
                return instance;
            }
        })
        .Members({
            getViewportHeight: function () {
                if (window.innerHeight) {
                    return base.getViewportHeight.apply(this, arguments);
                }
                else if (document.documentElement && document.documentElement.clientHeight) {
                    return document.documentElement.clientHeight;
                }
                else {
                    return document.body.clientHeight;
                }
            },

            getViewportWidth: function () {
                if (window.innerHeight) {
                    return base.getViewportWidth.apply(this, arguments);
                }
                else if (document.documentElement && document.documentElement.clientWidth) {
                    return document.documentElement.clientWidth;
                }
                else {
                    return document.body.clientWidth;
                }
            },

            isSpecifiedAttribute: function (element, attribute) {
                if (element.hasAttribute) {
                    return base.isSpecifiedAttribute.apply(this, arguments);
                }
                else {
                    var node = element.getAttributeNode(attribute);
                    if (node === null) {
                        node = element.getAttributeNode(ATTR_FIXES[attribute]);
                    }
                    return node !== null;
                }
            },

            getSpecifiedAttributes: function (element) {
                if (Browser.version === '9.0') {
                    return base.getSpecifiedAttributes.apply(this, arguments);
                }
                else {
                    var attribute,
                        attributes = [];
                    var match = /<[^>]*>/g.exec(element.outerHTML);
                    if (match === null) {
                        return attributes;
                    }
                    var html = match[0];

                    while (true) {
                        match = ATTR_REGEX.exec(html);
                        if (match === null) {
                            break;
                        }
                        attribute = element.getAttributeNode(match[1]);
                        if (attribute.expando === false) {
                            attributes.push(attribute.name);
                        }
                        //                        attributes.push( match[1] );
                    }

                    return attributes;
                }
            },

            isSpecifiedStyle: function (element, attribute) {
                if (element.style.length) {
                    return base.isSpecifiedStyle.apply(this, arguments);
                }
                else {
                    var styleText = element.style.cssText;
                    var regex = new RegExp("(^|;)\\s*(" + attribute + ")\\s*:", 'ig');
                    return regex.test(styleText);
                }
            },

            getSpecifiedStyles: function (element) {
                if (element.style.length) {
                    return base.getSpecifiedStyles.apply(this, arguments);
                }
                else {
                    var styles = [];
                    var styleText = element.style.cssText;

                    var match;
                    var styleRegex = /(^|;)\s*(\w+)\s*:/ig;
                    while (true) {
                        match = styleRegex.exec(styleText);
                        if (match === null) {
                            break;
                        }
                        styles.push(match[2].toLowerCase());
                    }

                    return styles;
                }
            },

            getClassList: function (element, className) {
                if (element.classList) {
                    return base.getClassList.apply(this, arguments);
                }
                else {
                    var classes = [];
                    var className = element.className;
                    var classList = className.split(/\s+/);
                    var i = null,
                    length = null;
                    for (i = 0, length = classList.length; i < length; i++) {
                        classes.push(classList[i]);
                    }
                    return classes;
                }
            },

            parentNode: function (element) {
                var parentNode = base.parentNode(element);
                if (parentNode === null) {
                    return null;
                }
                if (parentNode.nodeType === 11) {
                    return null;
                }
                return element.parentNode;
            }
        })
    .$();
});