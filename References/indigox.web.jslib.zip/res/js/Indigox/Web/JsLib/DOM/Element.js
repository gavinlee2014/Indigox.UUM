﻿define("Indigox.Web.JsLib.DOM.Element",
    [
        "Indigox.Web.JsLib.DOM.NodeType",
        "Indigox.Web.JsLib.DOM.DOMAccessor",
        "Indigox.Web.JsLib.DOM.EventManager",
        "Indigox.Web.JsLib.DOM.Accessors.JQueryAccessor",
        "Indigox.Web.JsLib.Core"
    ],
function (
        NodeType,
        DOMAccessor,
        EventManager
) {
    var EMPTY_TEXT_REGEX = /^\s*$/;

    var Element =
        Namespace("Indigox.Web.JsLib.DOM")
        .Class("Element")
        .Constructor(
            function (element) {
                this.accessor = DOMAccessor.getInstance();
                this.element = element;
                this.eventManager = null;
            }
        )
        .Static({
            el: function (element) {
                return new Element(element);
            },
            getViewportHeight: function () {
                return DOMAccessor.getInstance().getViewportHeight();
            },
            getViewportWidth: function () {
                return DOMAccessor.getInstance().getViewportWidth();
            },
            getScrollTop: function () {
                return DOMAccessor.getInstance().getScrollTop(document);
            },
            getScrollLeft: function () {
                return DOMAccessor.getInstance().getScrollLeft(document);
            },
            getDocumentHeight: function () {
                return DOMAccessor.getInstance().getOuterHeight(document.body);
            },
            getDocumentWidth: function () {
                return DOMAccessor.getInstance().getOuterWidth(document.body);
            }
        })
        .Members({
            getAccessor: function () {
                return this.accessor;
            },

            getElement: function () {
                return this.element;
            },

            isText: function () {
                return this.getElement() &&
                       this.getNodeType() === NodeType.TEXT_NODE;
            },

            isEmptyText: function () {
                if (this.isText()) {
                    return EMPTY_TEXT_REGEX.test(this.getNodeValue());
                }
                else {
                    return false;
                }
            },

            isElement: function () {
                return this.getElement() &&
                       this.getNodeType() === NodeType.ELEMENT_NODE;
            },

            getTop: function () {
                return this.getAccessor().getTop(this.getElement());
            },

            getLeft: function () {
                return this.getAccessor().getLeft(this.getElement());
            },

            getScrollTop: function () {
                return this.getAccessor().getScrollTop(this.getElement());
            },

            getScrollLeft: function () {
                return this.getAccessor().getScrollLeft(this.getElement());
            },

            getClientTop: function () {
                return this.getAccessor().getClientTop(this.getElement());
            },

            getClientLeft: function () {
                return this.getAccessor().getClientLeft(this.getElement());
            },

            getOuterHeight: function () {
                return this.getAccessor().getOuterHeight(this.getElement());
            },

            getOuterWidth: function () {
                return this.getAccessor().getOuterWidth(this.getElement());
            },

            getInnerHeight: function () {
                return this.getAccessor().getInnerHeight(this.getElement());
            },

            getInnerWidth: function () {
                return this.getAccessor().getInnerWidth(this.getElement());
            },

            getHeight: function () {
                return this.getAccessor().getHeight(this.getElement());
            },

            getWidth: function () {
                return this.getAccessor().getWidth(this.getElement());
            },

            getComputedHeight: function () {
                return this.getAccessor().getHeight(this.getElement());
            },

            getComputedWidth: function () {
                return this.getAccessor().getWidth(this.getElement());
            },

            setTop: function (value) {
                this.getAccessor().setTop(this.getElement(), value);
            },

            setLeft: function (value) {
                this.getAccessor().setLeft(this.getElement(), value);
            },

            setScrollTop: function (value) {
                this.getAccessor().setScrollTop(this.getElement(), value);
            },

            setScrollLeft: function (value) {
                this.getAccessor().setScrollLeft(this.getElement(), value);
            },

            setWidth: function (value) {
                this.getAccessor().setWidth(this.getElement(), value);
            },

            setHeight: function (value) {
                this.getAccessor().setHeight(this.getElement(), value);
            },

            getText: function () {
                //return this.getElement().data;

                //TODO: ? jquery 找不到 text node
                return this.getAccessor().getText(this.getElement());
            },

            setText: function (value) {
                //this.getElement().data = value;

                //TODO: ? jquery 找不到 text node
                this.getAccessor().setText(this.getElement(), value);
            },

            center: function () {
                var y = Math.floor(Element.getScrollTop() + (Element.getViewportHeight() - this.getOuterHeight()) / 2);
                y = y < 0 ? 0 : y;
                var x = Math.floor(Element.getScrollLeft() + (Element.getViewportWidth() - this.getOuterWidth()) / 2);
                x = x < 0 ? 0 : x;
                this.setTop(y);
                this.setLeft(x);
            },

            top: function () {
                this.setTop(0);
            },

            getNodeType: function () {
                return this.getElement().nodeType;
            },

            getNodeValue: function () {
                return this.getElement().nodeValue;
            },

            setAttribute: function (attribute, value) {
                var args = [this.getElement()];
                args.push.apply(args, arguments);
                this.getAccessor().setAttribute.apply(this.getAccessor(), args);
            },

            getAttribute: function (attribute) {
                return this.getAccessor().getAttribute(this.getElement(), attribute);
            },

            getComputedAttribute: function (attribute) {
                return this.getAccessor().getComputedAttribute(this.getElement(), attribute);
            },

            hasAttribute: function (attribute) {
                return this.getAccessor().hasAttribute(this.getElement(), attribute);
            },

            getSpecifiedAttributes: function () {
                return this.getAccessor().getSpecifiedAttributes(this.getElement());
            },

            setStyle: function (property, value) {
                var args = [this.getElement()];
                args.push.apply(args, arguments);
                this.getAccessor().setStyle.apply(this.getAccessor(), args);
            },

            getStyle: function (property) {
                return this.getAccessor().getStyle(this.getElement(), property);
            },

            getComputedStyle: function (property) {
                return this.getAccessor().getComputedStyle(this.getElement(), property);
            },

            getSpecifiedStyles: function () {
                return this.getAccessor().getSpecifiedStyles(this.getElement());
            },

            addClass: function (className) {
                this.getAccessor().addClass(this.getElement(), className);
            },

            removeClass: function (className) {
                this.getAccessor().removeClass(this.getElement(), className);
            },

            replaceClass: function (oldClassName, newClassName) {
                return this.getAccessor().replaceClass(this.getElement(), oldClassName, newClassName);
            },

            toggleClass: function (className) {
                return this.getAccessor().toggleClass(this.getElement(), className);
            },

            hasClass: function (className) {
                return this.getAccessor().hasClass(this.getElement(), className);
            },

            getClassList: function () {
                return this.getAccessor().getClassList(this.getElement());
            },

            parentNode: function () {
                return this.getAccessor().parentNode(this.getElement());
            },

            previousSibling: function () {
                return this.getAccessor().previousSibling(this.getElement());
            },

            nextSibling: function () {
                return this.getAccessor().nextSibling(this.getElement());
            },

            previousElement: function () {
                return this.getAccessor().previousElement(this.getElement());
            },

            nextElement: function () {
                return this.getAccessor().nextElement(this.getElement());
            },

            firstChild: function () {
                return this.getAccessor().firstChild(this.getElement());
            },

            lastChild: function () {
                return this.getAccessor().lastChild(this.getElement());
            },

            firstChildElement: function () {
                return this.getAccessor().firstChildElement(this.getElement());
            },

            lastChildElement: function () {
                return this.getAccessor().lastChildElement(this.getElement());
            },

            childNodes: function () {
                return this.getAccessor().childNodes(this.getElement());
            },

            children: function () {
                return this.getAccessor().children(this.getElement());
            },

            contains: function (element) {
                return this.getAccessor().contains(this.getElement(), element);
            },

            getEventManager: function () {
                if (isNullOrUndefined(this.eventManager)) {
                    this.eventManager = EventManager.getInstance(this.element);
                }
                if (isNullOrUndefined(this.eventManager)) {
                    this.eventManager = new EventManager(this.accessor, this.element);
                    EventManager.register(this.eventManager);
                }
                return this.eventManager;
            },

            addListener: function (event, handler, scope, args) {
                return this.getEventManager().addListener(event, handler, scope, args);
            },

            removeListener: function (event, handler) {
                return this.getEventManager().removeListener(event, handler);
            },

            clearListeners: function (event) {
                var eventManager = this.getEventManager();
                return eventManager.clearListeners.apply(eventManager, arguments);
            }
        })
    .$();
    window.$El = Element.el;
});