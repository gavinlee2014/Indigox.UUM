﻿define("Indigox.Web.JsLib.DOM.DOMAccessor",
    [
        "Indigox.Web.JsLib.Utils.Browser",
        "Indigox.Web.JsLib.DOM.Adapters",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Browser,
        Adapters
) {
    var Browser = Browser.getInstance();

    var ADAPTERS = {
        WebKit: Adapters.WebKitAdapter.getInstance(),
        Gecko: Adapters.GeckoAdapter.getInstance(),
        Trident: Adapters.OtherAdapter.getInstance(),
        Other: Adapters.OtherAdapter.getInstance()
    };

    var instance = null;

    var DOMAccessor =
        Namespace("Indigox.Web.JsLib.DOM")
        .Class("DOMAccessor")
        .Constructor(
            function () {
                this.browserAdapter = ADAPTERS[Browser.engine];
            }
        )
        .Static({
            setInstance: function (value) {
                instance = value;
            },
            getInstance: function () {
                if (isNullOrUndefined(instance)) {
                    instance = new DOMAccessor();
                }
                return instance;
            }
        })
        .Members({
            getBrowserAdapter: function () {
                return this.browserAdapter;
            },

            getViewportHeight: function () {
                return this.getBrowserAdapter().getViewportHeight();
            },

            getViewportWidth: function () {
                return this.getBrowserAdapter().getViewportWidth();
            },

            getTop: function (element) {
                return this.getBrowserAdapter().getTop(element);
            },

            getLeft: function (element) {
                return this.getBrowserAdapter().getLeft(element);
            },

            getScrollTop: function (element) {
                return this.getBrowserAdapter().getScrollTop(element);
            },

            getScrollLeft: function (element) {
                return this.getBrowserAdapter().getScrollLeft(element);
            },

            getClientTop: function (element) {
                return this.getBrowserAdapter().getClientTop(element);
            },

            getClientLeft: function (element) {
                return this.getBrowserAdapter().getClientLeft(element);
            },

            getOuterHeight: function (element) {
                return this.getBrowserAdapter().getOuterHeight(element);
            },

            getOuterWidth: function (element) {
                return this.getBrowserAdapter().getOuterWidth(element);
            },

            getInnerHeight: function (element) {
                return this.getBrowserAdapter().getInnerHeight(element);
            },

            getInnerWidth: function (element) {
                return this.getBrowserAdapter().getInnerWidth(element);
            },

            getHeight: function (element) {
                return this.getBrowserAdapter().getHeight(element);
            },

            getWidth: function (element) {
                return this.getBrowserAdapter().getWidth(element);
            },

            setTop: function (element, value) {
                this.getBrowserAdapter().setTop(element, value);
            },

            setLeft: function (element, value) {
                this.getBrowserAdapter().setLeft(element, value);
            },

            setScrollTop: function (element, value) {
                this.getBrowserAdapter().setScrollTop(element, value);
            },

            setScrollLeft: function (element, value) {
                this.getBrowserAdapter().setScrollLeft(element, value);
            },

            setHeight: function (element, value) {
                this.getBrowserAdapter().setHeight(element, value);
            },

            setWidth: function (element, value) {
                this.getBrowserAdapter().setWidth(element, value);
            },

            getText: function (element) {
                return this.getBrowserAdapter().getText(element);
            },

            setText: function (element, value) {
                this.getBrowserAdapter().setText(element, value);
            },

            isSpecifiedAttribute: function (element, attribute) {
                this.getBrowserAdapter().isSpecifiedAttribute(element, attribute);
            },

            setAttribute: function (element, attribute, value) {
                this.getBrowserAdapter().setAttribute(element, attribute, value);
            },

            getAttribute: function (element, attribute) {
                return this.getBrowserAdapter().getAttribute(element, attribute);
            },

            getComputedAttribute: function (element, attribute) {
                return this.getBrowserAdapter().getComputedAttribute(element, attribute);
            },

            hasAttribute: function (element, attribute) {
                return this.getBrowserAdapter().hasAttribute(element, attribute);
            },

            getSpecifiedAttributes: function (element) {
                return this.getBrowserAdapter().getSpecifiedAttributes(element);
            },

            setStyle: function (element, property, value) {
                this.getBrowserAdapter().setStyle(element, property, value);
            },

            getStyle: function (element, property) {
                return this.getBrowserAdapter().getStyle(element, property);
            },

            getComputedStyle: function (element, property) {
                return this.getBrowserAdapter().getComputedStyle(element, property);
            },

            getSpecifiedStyles: function (element) {
                return this.getBrowserAdapter().getSpecifiedStyles(element);
            },

            addClass: function (element, className) {
                this.getBrowserAdapter().addClass(element, className);
            },

            removeClass: function (element, className) {
                this.getBrowserAdapter().removeClass(element, className);
            },

            replaceClass: function (element, oldClassName, newClassName) {
                this.getBrowserAdapter().replaceClass(element, oldClassName, newClassName);
            },

            toggleClass: function (element, className) {
                this.getBrowserAdapter().toggleClass(element, className);
            },

            hasClass: function (element, className) {
                return this.getBrowserAdapter().hasClass(element, className);
            },

            getClassList: function (element, className) {
                return this.getBrowserAdapter().getClassList(element);
            },

            parentNode: function (element) {
                return this.getBrowserAdapter().parentNode(element);
            },

            previousSibling: function (element) {
                return this.getBrowserAdapter().previousSibling(element);
            },

            nextSibling: function (element) {
                return this.getBrowserAdapter().nextSibling(element);
            },

            previousElement: function (element) {
                return this.getBrowserAdapter().previousElement(element);
            },

            nextElement: function (element) {
                return this.getBrowserAdapter().nextElement(element);
            },

            firstChild: function (element) {
                return this.getBrowserAdapter().firstChild(element);
            },

            lastChild: function (element) {
                return this.getBrowserAdapter().lastChild(element);
            },

            firstChildElement: function (element) {
                return this.getBrowserAdapter().firstChildElement(element);
            },

            lastChildElement: function (element) {
                return this.getBrowserAdapter().lastChildElement(element);
            },

            childNodes: function (element) {
                return this.getBrowserAdapter().childNodes(element);
            },

            children: function (element) {
                return this.getBrowserAdapter().children(element);
            },

            contains: function (container, contained) {
                return this.getBrowserAdapter().contains(container, contained);
            },

            addListener: function (element, eventName, eventHandler) {
                this.getBrowserAdapter().addListener(element, eventName, eventHandler);
            },

            removeListener: function (element, eventName, eventHandler) {
                this.getBrowserAdapter().removeListener(element, eventName, eventHandler);
            },

            clearListeners: function (element, eventName) {
                this.getBrowserAdapter().clearListeners(element, eventName);
            }
        })
    .$();
});