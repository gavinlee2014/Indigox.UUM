﻿define("Indigox.Web.JsLib.DOM.Accessors.JQueryAccessor",
    [
        "Indigox.Web.JsLib.DOM.DOMAccessor",
        "Indigox.Web.JsLib.Utils.StringUtil",
        "Indigox.Web.JsLib.Utils.ArrayUtil",
        "Indigox.Web.JsLib.Utils.Browser",
        "jquery",
        "Indigox.Web.JsLib.Core"
    ],
    function (
        DOMAccessor,
        StringUtil,
        ArrayUtil,
        Browser,
        jQuery
    ) {
        var base = DOMAccessor.prototype;

        var Browser = Browser.getInstance();

        var ATTR_FIXES = {
            WebKit: {
            },
            Gecko: {
                'innerText': 'textContent'
            },
            Trident: {
                'textContent': 'innerText'
            },
            Other: {
                'textContent': 'innerText'
            }
        };

        var HTML_ATTRIBUTES = {
            'checked': true,
            'class': true,
            'disabled': true,
            'height': true,
            'href': true,
            'id': true,
            'name': true,
            'readonly': true,
            'selected': true,
            'src': true,
            'target': true,
            'title': true,
            'type': true,
            'value': true,
            'width': true
        };

        var ATTR_READONLY = {
            'offsetTop': true,
            'offsetLeft': true,
            'scrollTop': true,
            'scrollLeft': true,
            'clientHeight': true,
            'clientWidth': true,
            'scrollHeight': true,
            'scrollWidth': true
        };

        var JQueryAccessor =
            Namespace("Indigox.Web.JsLib.DOM.Accessors")
            .Class("JQueryAccessor")
            .Extend(base)
            .Constructor(
                function () {
                    base.constructor.apply(this, arguments);
                }
            )
            .Members({
                getTop: function (element) {
                    return jQuery(element).css('top');
                },

                getLeft: function (element) {
                    return jQuery(element).css('left');
                },

                getScrollTop: function (element) {
                    return jQuery(element).scrollTop();
                },

                getScrollLeft: function (element) {
                    return jQuery(element).scrollLeft();
                },

                getClientTop: function (element) {
                    return jQuery(element).offset().top - jQuery().scrollTop();
                },

                getClientLeft: function (element) {
                    return jQuery(element).offset().left - jQuery().scrollLeft();
                },

                getOuterHeight: function (element) {
                    return jQuery(element).outerHeight();
                },

                getOuterWidth: function (element) {
                    return jQuery(element).outerWidth();
                },

                getInnerHeight: function (element) {
                    return jQuery(element).innerHeight();
                },

                getInnerWidth: function (element) {
                    return jQuery(element).innerWidth();
                },

                getHeight: function (element) {
                    return jQuery(element).height();
                },

                getWidth: function (element) {
                    return jQuery(element).width();
                },

                setTop: function (element, value) {
                    jQuery(element).css('top', value);
                },

                setLeft: function (element, value) {
                    jQuery(element).css('left', value);
                },

                setScrollTop: function (element, value) {
                    jQuery(element).scrollTop('top', value);
                },

                setScrollLeft: function (element, value) {
                    jQuery(element).scrollLeft(value);
                },

                setHeight: function (element, value) {
                    jQuery(element).height(value);
                },

                setWidth: function (element, value) {
                    jQuery(element).width(value);
                },

                getText: function (element) {
                    return jQuery(element).text();
                },

                setText: function (element, value) {
                    jQuery(element).text(value);
                },

                supportAttribute: function (attribute) {
                    return !(attribute in ATTR_FIXES[Browser.engine]);
                },
                fixAttribute: function (attribute) {
                    if (this.supportAttribute(attribute)) {
                        return attribute;
                    }
                    else {
                        return ATTR_FIXES[Browser.name][attribute];
                    }
                },

                setAttribute: function (element, attribute, value) {
                    /*
                    the type property is read/write-once, but only when an input element is
                    created with the createElement method and before it is added to the document.
                    */
                    var map = null;
                    if (arguments.length === 3) {
                        map = {};
                        map[attribute] = value;
                    }
                    else {
                        map = attribute;
                    }
                    var val = null;
                    var attrMap = {};
                    var propMap = {};
                    for (var attr in map) {

                        val = map[attr];
                        if (Browser.ie()) {
                            if (isNullOrUndefined(val)) {
                                jQuery(element).removeAttr(attr);
                            }
                        }
                        if (!(attr === "type" && element.parentNode) && !(attr in ATTR_READONLY)) {
                            if (attr in HTML_ATTRIBUTES) {
                                attrMap[attr] = val;
                            }
                            else if (!this.supportAttribute(attr)) {
                                propMap[this.fixAttribute(attr)] = val;
                            }
                            else {
                                propMap[attr] = val;
                            }
                        }
                    }
                    jQuery(element).prop(propMap);
                    jQuery(element).attr(attrMap);
                },

                getAttribute: function (element, attribute) {
                    if (!this.supportAttribute(attribute)) {
                        attribute = this.fixAttribute(attribute);
                    }
                    if (this.getBrowserAdapter().isSpecifiedAttribute(element, attribute)) {
                        return jQuery(element).prop(attribute);
                    }
                    else {
                        return null;
                    }
                },

                getComputedAttribute: function (element, attribute) {
                    if (this.supportAttribute(attribute)) {
                        attribute = this.fixAttribute(attribute);
                    }
                    return jQuery(element).attr(attribute);
                },

                setStyle: function (element, property, value) {
                    var map = null;
                    if (arguments.length === 3) {
                        map = {};
                        map[property] = value;
                    }
                    else {
                        map = property;
                    }
                    if (Browser.ie()) {
                        var val = null;
                        for (var prop in map) {
                            val = map[prop];
                            if (isNullOrUndefined(val)) {
                                map[prop] = '';
                            }
                            if (isNumber(value) && isNaN(val)) {
                                delete map[prop];
                            }
                            if (prop === "opacity") {
                                if (isNullOrUndefined(val)) {
                                    jQuery(element).css('filter', '');
                                }
                                else {
                                    map.filter = /(6\.0)|(7\.0)/.test(Browser.version)
                                        ? ('alpha(opacity=' + Math.round(val * 100) + ')')
                                        : ('"alpha(opacity=' + Math.round(val * 100) + ')"');
                                }
                                delete map[prop];
                            }
                        }
                    }
                    jQuery(element).css(map);
                },

                getStyle: function (element, property) {
                    if (property.toLowerCase() === "width") {
                        return element.style.width;
                    }
                    if (this.getBrowserAdapter().isSpecifiedStyle(element, property)) {
                        return jQuery(element).css(property);
                    }
                    if (Browser.ie() && property === "opacity") {
                        var value = jQuery(element).css('filter');
                        var match = /alpha\s*\(\s*opacity\s*=\s*(\d+)\s*\)/i.exec(value);
                        if (match) {
                            return parseInt(match[1], 10) / 100;
                        }
                        else {
                            return null;
                        }
                    }
                    else {
                        return null;
                    }
                },

                getComputedStyle: function (element, property) {
                    return jQuery(element).css(property);
                },

                addClass: function (element, className) {
                    jQuery(element).addClass(className);
                },

                removeClass: function (element, className) {
                    jQuery(element).removeClass(className);
                },

                toggleClass: function (element, className) {
                    jQuery(element).toggleClass(className);
                },

                replaceClass: function (element, oldClassName, newClassName) {
                    base.replaceClass.apply(this, element);
                },

                hasClass: function (element, className) {
                    return jQuery(element).hasClass(className);
                },

                firstChild: function (element) {
                    var array = jQuery(element).find(":first");
                    return array.length > 0 ? array[0] : null;
                },

                lastChild: function (element) {
                    var array = jQuery(element).find(":last");
                    return array.length > 0 ? array[0] : null;
                },

                children: function (element) {
                    return jQuery(element).children();
                },

                contains: function (container, contained) {
                    return container.contains(contained);
                },

                addListener: function (element, eventName, eventHandler) {
                    jQuery(element).bind(eventName, eventHandler);
                },

                removeListener: function (element, eventName, eventHandler) {
                    jQuery(element).unbind(eventName, eventHandler);
                },

                clearListeners: function (element, eventName) {
                    jQuery(element).unbind(eventName);
                }
            })
        .$();

        //TODO configuration
        DOMAccessor.setInstance(new JQueryAccessor());
    });