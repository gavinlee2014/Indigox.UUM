﻿define("Indigox.Web.JsLib.DOM.EventManager",
    [
        "Indigox.Web.JsLib.DOM.EventAdapter",
        "Indigox.Web.JsLib.Core"
    ],
function (
        EventAdapter
) {
    var instances = [];

    var EventManager =
        Namespace("Indigox.Web.JsLib.DOM")
        .Class("EventManager")
        .Constructor(
            function (accessor, element) {
                this.accessor = accessor;
                this.element = element;
                this.adapters = {};
            }
        )
        .Static({
            getInstance: function (element) {
                var i = null;
                for (i = instances.length - 1; i >= 0; i--) {
                    if (instances[i].element === element) {
                        return instances[i];
                    }
                }
            },
            register: function (instance) {
                var i = null;
                for (i = instances.length - 1; i >= 0; i--) {
                    if (instances[i] === instance) {
                        return;
                    }
                }
                instances.push(instance);
            },
            unregister: function (instance) {
                var i = null;
                for (i = instances.length - 1; i >= 0; i--) {
                    if (instances[i] === instance) {
                        instances.splice(i, 1);
                    }
                }
            }
        })
        .Members({
            addListener: function (event, handler, scope, args) {
                var adapter = null;
                if (!(event in this.adapters)) {
                    adapter = new EventAdapter();
                    this.accessor.addListener(this.element, event, adapter.createDelegate());
                    this.adapters[event] = adapter;
                }
                else {
                    adapter = this.adapters[event];
                }
                adapter.addListener(handler, scope, args);
                // if ( !adapter.hasListener( handler ) ) {
                //     adapter.addListener( handler, scope, args );
                // }
            },
            removeListener: function (event, handler) {
                var adapter = null;
                if (event in this.adapters) {
                    adapter = this.adapters[event];
                }
                else {
                    return;
                }

                if (adapter.hasListener(handler)) {
                    adapter.removeListener(handler);
                }
            },
            clearListeners: function (event) {
                if (event) {
                    this.accessor.clearListeners(this.element, event);
                    delete this.adapters[event];
                }
                else {
                    this.accessor.clearListeners(this.element);
                    this.adapters = {};
                }
            },
            hasListener: function (event, handler) {
                if (event in this.adapters) {
                    var adapter = this.adapters[event];
                    if (adapter.hasListener(handler)) {
                        return true;
                    }
                    else {
                        return false;
                    }
                }
                else {
                    return false;
                }
            }
        })
    .$();
});