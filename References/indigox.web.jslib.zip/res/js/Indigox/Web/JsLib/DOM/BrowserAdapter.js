﻿define("Indigox.Web.JsLib.DOM.BrowserAdapter",
    [
        "Indigox.Web.JsLib.Utils.Browser",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Browser
) {
    var Browser = Browser.getInstance();

    var ATTR_FIXES = {
        'htmlFor': 'for',
        'className': 'class'
    };

    var BrowserAdapter =
        Namespace("Indigox.Web.JsLib.DOM")
        .Class("BrowserAdapter")
        .Constructor(
            function () {
            }
        )
        .Static({
            getInstance: function () {
            }
        })
        .Members({
            getViewportHeight: function () {
                return window.innerHeight;
            },

            getViewportWidth: function () {
                return window.innerWidth;
            },

            getTop: function (element) {
            },

            getLeft: function (element) {
            },

            getScrollTop: function (element) {
            },

            getScrollLeft: function (element) {
            },

            getClientTop: function (element) {
            },

            getClientLeft: function (element) {
            },

            getOuterHeight: function (element) {
            },

            getOuterWidth: function (element) {
            },

            getInnerHeight: function (element) {
            },

            getInnerWidth: function (element) {
            },

            getHeight: function (element) {
            },

            getWidth: function (element) {
            },

            setTop: function (element, value) {
            },

            setLeft: function (element, value) {
            },

            setScrollTop: function (element, value) {
            },

            setScrollLeft: function (element, value) {
            },

            setHeight: function (element, value) {
            },

            setWidth: function (element, value) {
            },

            getText: function (element) {
            },

            setText: function (element, value) {
            },

            setAttribute: function (element, attribute, value) {
            },

            getAttribute: function (element, attribute) {
            },

            getComputedAttribute: function (element, attribute) {
            },

            hasAttribute: function (element, attribute) {
                if (isNullOrUndefined(element)) {
                    throw new Error('element is null or undefined.');
                }
                var result = attribute in element;
                if (result === false) {
                    result = ATTR_FIXES[attribute] in element;
                }
                return result;
            },

            isSpecifiedAttribute: function (element, attribute) {
                var result = element.hasAttribute(attribute);
                if (result === false) {
                    result = element.hasAttribute(ATTR_FIXES[attribute]);
                }
                return result;
            },

            getSpecifiedAttributes: function (element) {
                var attrNames = [];
                var attributes = element.attributes;
                var i = null,
                    length = null;
                for (i = 0, length = attributes.length; i < length; i++) {
                    attrNames.push(attributes.item(i).name);
                }
                return attrNames;
            },

            setStyle: function (element, property, value) {
            },

            getStyle: function (element, property) {
            },

            getComputedStyle: function (element, property) {
            },

            isSpecifiedStyle: function (element, attribute) {
                var style = element.style;
                if (style) {
                    var i = null,
                        length = null;
                    for (i = 0, length = style.length; i < length; i++) {
                        if (attribute === style.item(i)) {
                            return true;
                        }
                    }
                }
                return false;
            },

            getSpecifiedStyles: function (element) {
                var styles = [];
                var style = element.style;
                if (style) {
                    var i = null,
                        length = null;
                    for (i = 0, length = style.length; i < length; i++) {
                        styles.push(style.item(i));
                    }
                }
                return styles;
            },

            addClass: function (element, className) {
            },

            removeClass: function (element, className) {
            },

            replaceClass: function (element, oldClassName, newClassName) {
            },

            toggleClass: function (element, className) {
            },

            hasClass: function (element, className) {
            },

            getClassList: function (element, className) {
                var classes = [];
                var classList = element.classList;
                var i = null,
                    length = null;
                for (i = 0, length = classList.length; i < length; i++) {
                    classes.push(classList.item(i));
                }
                return classes;
            },

            parentNode: function (element) {
                if (isNullOrUndefined(element)) {
                    return null;
                }
                if (isNullOrUndefined(element.parentNode)) {
                    return null;
                }
                return element.parentNode;
            },

            previousSibling: function (element) {
                throw new Error('the method "previousSibling" is not implemented');
            },

            nextSibling: function (element) {
                throw new Error('the method "nextSibling" is not implemented');
            },

            previousElement: function (element) {
                throw new Error('the method "previousElement" is not implemented');
            },

            nextElement: function (element) {
                throw new Error('the method "nextElement" is not implemented');
            },

            firstChild: function (element) {
                throw new Error('the method "firstChild" is not implemented');
            },

            lastChild: function (element) {
                throw new Error('the method "lastChild" is not implemented');
            },

            firstChildElement: function (element) {
                throw new Error('the method "firstChildElement" is not implemented');
            },

            lastChildElement: function (element) {
                throw new Error('the method "lastChildElement" is not implemented');
            },

            childNodes: function (element) {
                throw new Error('the method "childNodes" is not implemented');
            },

            children: function (element) {
                throw new Error('the method "children" is not implemented');
            },

            contains: function (container, contained) {
            },

            addListener: function (element, eventName, eventHandler) {
            },

            removeListener: function (element, eventName, eventHandler) {
            },

            clearListeners: function (element, eventName) {
            }
        })
    .$();
});