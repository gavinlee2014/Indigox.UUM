define("Indigox.Web.JsLib.DOM.NodeFilter",
    [
        "Indigox.Web.JsLib.Core"
    ],
function (

) {
    var NodeFilter =
        Namespace("Indigox.Web.JsLib.DOM")
        .Class("NodeFilter")
        .Static({
            FILTER_ACCEPT: 1,
            FILTER_REJECT: 2,
            FILTER_SKIP: 3,

            SHOW_ALL: 0xFFFFFFFF,
            SHOW_ELEMENT: 0x00000001, //Node.ELEMENT_NODE == 1
            SHOW_ATTRIBUTE: 0x00000002, //Node.ATTRIBUTE_NODE == 2
            SHOW_TEXT: 0x00000004, //Node.TEXT_NODE == 3
            SHOW_CDATA_SECTION: 0x00000008, //Node.CDATA_SECTION_NODE == 4
            SHOW_ENTITY_REFERENCE: 0x00000010, //Node.ENTITY_REFERENCE_NODE == 5
            SHOW_ENTITY: 0x00000020, //Node.ENTITY_NODE == 6
            SHOW_PROCESSING_INSTRUCTION: 0x00000040, //Node.PROCESSING_INSTRUCTION_NODE == 7
            SHOW_COMMENT: 0x00000080, //Node.COMMENT_NODE == 8
            SHOW_DOCUMENT: 0x00000100, //Node.DOCUMENT_NODE == 9
            SHOW_DOCUMENT_TYPE: 0x00000200, //Node.DOCUMENT_TYPE_NODE == 10
            SHOW_DOCUMENT_FRAGMENT: 0x00000400, //Node.DOCUMENT_FRAGMENT_NODE == 11
            SHOW_NOTATION: 0x00000800, //Node.NOTATION_NODE == 12
            // custom nodetype
            SHOW_PLACEHOLDER: 0x00001000 //Node.PLACEHOLDER_NODE == 13
        })
    .$();
});