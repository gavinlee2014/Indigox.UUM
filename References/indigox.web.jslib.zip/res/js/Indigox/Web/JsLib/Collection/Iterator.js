﻿define("Indigox.Web.JsLib.Collection.Iterator",
    [
        "Indigox.Web.JsLib.Core"
    ],
function (

) {

    var Iterator =
        Namespace("Indigox.Web.JsLib.Collection")
        .Class("Iterator")
        .Constructor(
            function (range) {
                this.elements = range || [];
                this.offset = this.elements.length;
            }
        )
        .Members({
            current: function () {
                if (this.offset === this.elements.length) {
                    throw new Error("The Iterator is positioned before the first element of the collection");
                }
                return this.elements[this.elements.length - this.offset - 1];
            },

            hasNext: function (element) {
                return this.offset > 0;
            },

            index: function () {
                return this.elements.length - this.offset - 1;
            },

            next: function () {
                return this.elements[this.elements.length - this.offset--];
            },

            remove: function () {
                this.elements.splice(this.elements.length - this.offset - 1, 1);
            }
        })
    .$();

});