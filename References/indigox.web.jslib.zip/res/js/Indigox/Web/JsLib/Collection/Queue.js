﻿define("Indigox.Web.JsLib.Collection.Queue",
    [
        "Indigox.Web.JsLib.Collection.List",
        "Indigox.Web.JsLib.Core"
    ],
function (
        List
) {

    var base = List.prototype;

    var Queue =
        Namespace("Indigox.Web.JsLib.Collection")
        .Class("Queue")
        .Extend(base)
        .Constructor(
            function (range) {
                base.constructor.apply(this, arguments);
            }
        )
        .Members({
            offer: function (element) {
                /// <summary>
                ///     插入一个元素
                /// </summary>
                /// <param name="element"></param>

                this.elements.push(element);
            },

            poll: function () {
                /// <summary>
                ///     取出一个元素，并将其从 Queue 中移除
                /// </summary>
                /// <returns type="Object"></returns>

                return this.elements.shift();
            },

            peek: function () {
                /// <summary>
                ///     取出一个元素
                /// </summary>
                /// <returns type="Object"></returns>

                return this.get(0);
            }
        })
    .$();

});