﻿define("Indigox.Web.JsLib.Collection.Stack",
    [
        "Indigox.Web.JsLib.Collection.List",
        "Indigox.Web.JsLib.Core"
    ],
function (
        List
) {

    var base = List.prototype;

    var Stack =
        Namespace("Indigox.Web.JsLib.Collection")
        .Class("Stack")
        .Extend(base)
        .Constructor(
            function (range) {
                base.constructor.apply(this, arguments);
            }
        )
        .Members({
            push: function (element) {
                this.elements.push(element);
            },

            pop: function () {
                return this.elements.pop();
            },

            peek: function () {
                return this.get(this.size() - 1);
            }
        })
    .$();

});