﻿define("Indigox.Web.JsLib.Collection.Hashtable",
    [
        "Indigox.Web.JsLib.Collection.List",
        "Indigox.Web.JsLib.Core"
    ],
function (
        List
) {



    var Hashtable =
        Namespace("Indigox.Web.JsLib.Collection")
        .Class("Hashtable")
        .Constructor(
            function () {
                this.elements = new List();
                this._keys = new List();
                this._values = new List();
            }
        )
        .Members({
            /**
            * 清空 elements
            */
            clear: function () {
                this.elements.clear();
                this._keys.clear();
                this._values.clear();
            },

            containsKey: function (key) {
                return this._keys.contains(key);
            },

            containsValue: function (value) {
                return this._values.contains(value);
            },

            iterator: function () {
                return this.elements.iterator();
            },

            /**
            * 获取 Hashtable 中 keys 的集合
            * @return {Array}
            */
            keys: function () {
                return this._keys.toArray();
            },

            /**
            * 获取 Hashtable 中 values 的集合
            * @return {Array}
            */
            values: function () {
                return this._values.toArray();
            },

            /**
            * 获取 Hashtable 中项目的总数
            */
            size: function () {
                return this.elements.size();
            },

            /**
            * 获取 key 对应的 value
            */
            get: function (key) {
                var value = null;
                var elements = this.elements.toArray(),
                    length = elements.length,
                    element = null;
                for (var i = 0; i < length; i++) {
                    element = elements[i];
                    if (element.key === key) {
                        value = element.value;
                        break;
                    }
                }
                return value;
            },

            /**
            * 添加 key/value 对，如果 key 已经存在则覆盖 key 对应的 value
            */
            put: function (key, value) {
                if (this.containsKey(key)) {
                    var index = this._keys.indexOf(key);
                    this._values.set(index, value);
                    this.elements.get(index).value = value;
                }
                else {
                    this._keys.add(key);
                    this._values.add(value);
                    this.elements.add({ key: key, value: value });
                }
            },

            /**
            * 移除 key 对应的 key 和 value
            */
            remove: function (key) {
                var index = this._keys.indexOf(key);
                var element = this.elements.get(index);
                if (element.key !== key) {
                    throw new Error("The hashtable have invalid data members!");
                }
                var value = element.value;

                this._keys.removeAt(index);
                this._values.removeAt(index);
                this.elements.removeAt(index);

                return value;
            }
        })
    .$();

});