﻿define("Indigox.Web.JsLib.Collection.List",
    [
        "Indigox.Web.JsLib.Collection.Iterator",
        "Indigox.Web.JsLib.Core"
    ],
function (
        IteratorEx
) {



    var List =
        Namespace("Indigox.Web.JsLib.Collection")
        .Class("List")
        .Constructor(
            function (range) {
                if (range) {
                    this.elements = range.slice(0);
                }
                else {
                    this.elements = [];
                }
            }
        )
        .Members({
            add: function (element) {
                this.elements.push(element);
            },

            addRange: function (elements) {
                if (elements instanceof List) {
                    elements = elements.toArray();
                }
                var length = elements.length,
                    element;
                for (var i = 0; i < length; i++) {
                    element = elements[i];
                    this.elements.push(element);
                }
            },

            clear: function () {
                while (this.elements[0]) {
                    this.elements.shift();
                }
            },

            clone: function () {
                var clonedList = new this.constructor();
                clonedList.elements = this.toArray();
                return clonedList;
            },

            contains: function (element) {
                var index = this.indexOf(element);
                if (index < 0) {
                    return false;
                }
                return true;
            },

            /**
            * JavaScript 1.6
            *
            * array.forEach(callback[, thisArg])
            * 参数
            *
            * callback
            * 为每个数组元素执行的函数.
            * thisArg
            * 在执行callback函数时指定的this值.
            * 描述
            *
            * forEach 方法为数组中的每个有值的元素执行一次给定的callback函数,只有在那些有值的索引上才会调用callback函数,
            * 那些被删除掉的索引或者从未赋值过的索引将会被跳过.
            *
            * callback函数会被依次传入三个参数:
            *
            * 元素值
            * 元素索引
            * 被遍历的数组对象本身
            *
            * References:
            * https://developer.mozilla.org/zh-CN/docs/JavaScript/Reference/Global_Objects/Array/forEach
            */
            forEach: function (fn) {
                var elements = this.elements,
                    length = elements.length,
                    element = null;
                for (var i = 0; i < length; i++) {
                    element = elements[i];
                    if (fn.call(this, element, i, this) === false) {
                        return element;
                    }
                }
            },

            equals: function (obj) {
                var equals = true;
                if (obj.size() !== this.size()) {
                    equals = false;
                }

                var elements = obj.elements,
                    length = elements.length,
                    element = null;
                for (var i = 0; i < length; i++) {
                    element = elements[i];
                    if (element !== this.get(i)) {
                        return false;
                    }
                }
                return true;
            },

            get: function (index) {
                if (-1 < index && index < this.size()) {
                    return this.elements[index];
                }
                return null;
            },

            indexOf: function (element) {
                var elements = this.elements,
                    length = elements.length;
                for (var i = 0; i < length; i++) {
                    if (elements[i] === element) {
                        return i;
                    }
                }
                return -1;
            },

            insert: function (index, element) {
                this.elements.splice(index, 0, element);
            },

            insertRange: function (index, elements) {
                if (elements instanceof List) {
                    elements = elements.toArray();
                }
                var length = elements.length,
                    element = null;
                for (var i = 0; i < length; i++) {
                    element = elements[i];
                    this.elements.splice(index + i, 0, element);
                }
            },

            iterator: function () {
                return new IteratorEx(this.elements);
            },

            remove: function (element) {
                var index = this.indexOf(element);
                this.removeAt(index);
            },

            removeAt: function (index) {
                if (index >= 0) {
                    this.elements.splice(index, 1);
                }
            },

            removeRange: function (index, count) {
                if (index >= 0) {
                    this.elements.splice(index, count);
                }
            },

            set: function (index, element) {
                var oldElement = this.get(index);
                this.elements.splice(index, 1, element);
                return oldElement;
            },

            toArray: function () {
                return this.elements.slice(0);
            },

            size: function () {
                return this.elements.length;
            }
        })
    .$();

});