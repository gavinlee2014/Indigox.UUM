﻿define("Indigox.Web.JsLib.Formatters",
      [
        "Indigox.Web.JsLib.Formatters.ArrayFormatter",
        "Indigox.Web.JsLib.Formatters.DateTimeFormatter",
        "Indigox.Web.JsLib.Formatters.FlagsFormatter",
        "Indigox.Web.JsLib.Formatters.Formatter",
        "Indigox.Web.JsLib.Formatters.StringFormatter",
        "Indigox.Web.JsLib.Formatters.UserNameFormatter",
        "Indigox.Web.JsLib.Formatters.ValueTextFormatter",
        "Indigox.Web.JsLib.Formatters.NumberFormatter"
      ],
function (
        ArrayFormatter,
        DateTimeFormatter,
        FlagsFormatter,
        Formatter,
        StringFormatter,
        UserNameFormatter,
        ValueTextFormatter,
        NumberFormatter
) {
    return {
        ArrayFormatter: ArrayFormatter,
        DateTimeFormatter: DateTimeFormatter,
        FlagsFormatter: FlagsFormatter,
        Formatter: Formatter,
        StringFormatter: StringFormatter,
        UserNameFormatter: UserNameFormatter,
        ValueTextFormatter: ValueTextFormatter,
        NumberFormatter: NumberFormatter
    };
});