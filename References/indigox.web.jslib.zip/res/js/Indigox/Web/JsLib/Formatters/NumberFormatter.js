﻿define("Indigox.Web.JsLib.Formatters.NumberFormatter",
    [
        "Indigox.Web.JsLib.Utils.Util",
        "Indigox.Web.JsLib.Utils.StringUtil",
        "Indigox.Web.JsLib.Utils.EncodeUtil",
        "Indigox.Web.JsLib.Formatters.Formatter",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Util,
        StringUtil,
        EncodeUtil,
        Formatter
    ) {
    var base = Formatter.prototype;

    var StringFormatter =
        Namespace("Indigox.Web.JsLib.Formatters")
        .Class("NumberFormatter")
        .Extend(base)
        .Constructor(
            function (option) {
                base.constructor.apply(this, arguments);
                option = Util.copyExist({
                    separator: ','
                }, option);
                this.configure(option);
            }
        )
        .Members({
            getText: function (number) {

                var separator = this.getSeparator();
                var re = /(\d{1,3})(?=(\d{3})+(?:$|\D))/g
                var arr = ('' + number).split('.');
                var pre = arr[0];
                var r = pre.replace(re, "$1" + separator);
                if (arr.length > 1) {
                    r += '.' + arr[1];
                }
                return r;
            },

            getSeparator: function () {
                return this.separator;
            },

            setSeparator: function (value) {
                return this.separator=value;
            }
        })
    .$();
});