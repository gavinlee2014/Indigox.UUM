﻿define("Indigox.Web.JsLib.Formatters.UserNameFormatter",
    [
        "Indigox.Web.JsLib.Formatters.StringFormatter",
        "Indigox.Web.JsLib.Utils.Util",
        "Indigox.Web.JsLib.Core"
    ],
function (
        StringFormatter,
        Util
) {
    var base = StringFormatter.prototype;

    var UserNameFormatter =
        Namespace("Indigox.Web.JsLib.Formatters")
        .Class("UserNameFormatter")
        .Extend(base)
        .Constructor(
            function (option) {
                base.constructor.apply(this, arguments);
            }
        )
        .Members({
            getText: function (value) {
                if (!value || !value[0]) {
                    return value;
                }
                var user = value[0];
                return base.getText.call(this, user.Name);
            }
        })
    .$();
});