﻿define("Indigox.Web.JsLib.Formatters.DateTimeFormatter",
    [
        "Indigox.Web.JsLib.Utils.Util",
        "Indigox.Web.JsLib.Formatters.Formatter",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Util,
        Formatter
    ) {

    var base = Formatter.prototype;

    var standardDateTimeFormat = /^(?:(\d{4})[-\/](\d{1,2})[-\/](\d{1,2}))?(?:[ ](?:(\d{1,2}):(\d{1,2}):(\d{1,2}))(\.\d{0,3})?)?$/;    

    var DateTimeFormatter =
        Namespace("Indigox.Web.JsLib.Formatters")
        .Class("DateTimeFormatter")
        .Extend(base)
        .Constructor(
            function (option) {
                base.constructor.apply(this, arguments);
                option = Util.copyExist({
                    format: 'yyyy-MM-dd'
                }, option);
                this.configure(option);
            }
        )
        .Members({
            getText: function (value) {
                var date = this.convertDateFromString(value);
                //debug.log(value, date);
                if (date) {
                    return this.convertDateToString(date, this.format);
                }
                else {
                    return '';
                }
            },

            getFormat: function () {
                return this.format;
            },

            setFormat: function (value) {
                this.format = value;
            },

            //@private
            convertDateFromString: function (value) {
                if (isNullOrUndefined(value) || value.length === 0) {
                    return null;
                }
                if (value instanceof Date) {
                    return value;
                }
                var groups = standardDateTimeFormat.exec(value);
                var d = new Date();
                if (groups[1]) { d.setFullYear(parseInt(groups[1], 10)); }
                if (groups[2]) { d.setMonth(parseInt(groups[2], 10) - 1); }
                if (groups[3]) { d.setDate(parseInt(groups[3], 10)); }
                if (groups[4]) { d.setHours(parseInt(groups[4], 10)); }
                if (groups[5]) { d.setMinutes(parseInt(groups[5], 10)); }
                if (groups[6]) { d.setSeconds(parseInt(groups[6], 10)); }
                return d;
            },

            //@private
            convertDateToString: function (date, format) {
                return format.replace('yyyy', date.getFullYear().toString())
                             .replace('yy', date.getFullYear().toString().substring(2, 4))
                             .replace('MM', this.padLeft((date.getMonth() + 1).toString(), '00'))
                             .replace('dd', this.padLeft(date.getDate().toString(), '00'))
                             .replace('HH', this.padLeft(date.getHours().toString(), '00'))
                             .replace('mm', this.padLeft(date.getMinutes().toString(), '00'))
                             .replace('ss', this.padLeft(date.getSeconds().toString(), '00'))
                             .replace('M', (date.getMonth() + 1).toString())
                             .replace('d', date.getDate().toString())
                             .replace('H', date.getHours().toString())
                             .replace('m', date.getMinutes().toString())
                             .replace('s', date.getSeconds().toString());
            },

            //@private
            padLeft: function (text, mask) {
                if (text.length < mask.length) {
                    return mask.substring(0, mask.length - text.length) + text;
                }
                return text;
            }
        })
    .$();
});