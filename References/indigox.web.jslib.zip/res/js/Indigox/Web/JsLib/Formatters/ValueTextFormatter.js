﻿define("Indigox.Web.JsLib.Formatters.ValueTextFormatter",
    [
        "Indigox.Web.JsLib.Utils.Util",
        "Indigox.Web.JsLib.Formatters.Formatter",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Util,
        Formatter
    ) {

    var base = Formatter.prototype;

    var ValueTextFormatter =
        Namespace("Indigox.Web.JsLib.Formatters")
        .Class("ValueTextFormatter")
        .Extend(base)
        .Constructor(
            function (option) {
                base.constructor.apply(this, arguments);
                option = Util.copyExist({
                    mapping: [],
                    valueField: "value",
                    textField: "text"
                }, option);
                this.configure(option);
            }
        )
        .Members({
            getText: function (value) {
                for (var i = 0, length = this.mapping.length; i < length; i++) {
                    if (this.mapping[i][this.valueField] === value) {
                        return this.mapping[i][this.textField];
                    }
                }
                return null;
            },

            //getValue: function (text) {
            //    for (var i = 0, length = this.mapping.length; i < length; i++) {
            //        if (this.mapping[this.textField] === text) {
            //            return this.mapping[this.valueField];
            //        }
            //    }
            //    return null;
            //},

            getMapping: function () {
                return this.mapping;
            },

            setMapping: function (value) {
                if (!(value instanceof Array)) {
                    this.mapping = this.convertObjectToMapping(value);
                }
                else {
                    this.mapping = value;
                }
            },

            getValueField: function () {
                return this.valueField;
            },

            setValueField: function (value) {
                this.valueField = value;
            },

            getTextField: function () {
                return this.textField;
            },

            setTextField: function (value) {
                this.textField = value;
            },

            //@private
            convertObjectToMapping: function (obj) {
                var mapping = [];
                for (var p in obj) {
                    if (obj.hasOwnProperty(p)) {
                        var item = {};
                        item[this.valueField] = p;
                        item[this.textField] = obj[p];
                        mapping.push(item);
                    }
                }
                return mapping;
            }
        })
    .$();
});