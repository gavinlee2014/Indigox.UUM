﻿define("Indigox.Web.JsLib.Formatters.Formatter",
    [
        "Indigox.Web.JsLib.Utils.Configurable",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Configurable
    ) {
    var base = Configurable.prototype;

    var Formatter =
        Namespace("Indigox.Web.JsLib.Formatters")
        .Class("Formatter")
        .Extend(base)
        .Constructor(
            function (option) {
                base.constructor.apply(this, arguments);
            }
        )
        .Members({
            getText: function (value) {
                return value;
            }
        })
    .$();
});