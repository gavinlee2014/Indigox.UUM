﻿define("Indigox.Web.JsLib.Formatters.FlagsFormatter",
    [
        "Indigox.Web.JsLib.Utils.Util",
        "Indigox.Web.JsLib.Formatters.Formatter",
        "Indigox.Web.JsLib.Core"
    ],
    function (
        Util,
        Formatter
    ) {

    var base = Formatter.prototype;

    var FlagsFormatter =
        Namespace("Indigox.Web.JsLib.Formatters")
        .Class("FlagsFormatter")
        .Extend(base)
        .Constructor(
            function (option) {
                base.constructor.apply(this, arguments);
                option = Util.copyExist({
                    mapping: {}
                }, option);
                this.configure(option);
            }
        )
        .Members({
            getText: function (value) {
                var matchs = [];
                for (var i = 0, length = this.mapping.length; i < length; i++) {
                    if ((this.mapping[this.valueField] & value) === value) {
                        matchs.push(this.mapping[this.textField]);
                    }
                }
                return matchs.join(',');
            },

            setMapping: function (mapping) {
                this.mapping = mapping;
            },

            getMapping: function () {
                return this.mapping;
            }
        })
    .$();
});