﻿define("Indigox.Web.JsLib.Formatters.StringFormatter",
    [
        "Indigox.Web.JsLib.Utils.Util",
        "Indigox.Web.JsLib.Utils.StringUtil",
        "Indigox.Web.JsLib.Utils.EncodeUtil",
        "Indigox.Web.JsLib.Formatters.Formatter",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Util,
        StringUtil,
        EncodeUtil,
        Formatter
    ) {
    var base = Formatter.prototype;

    var StringFormatter =
        Namespace("Indigox.Web.JsLib.Formatters")
        .Class("StringFormatter")
        .Extend(base)
        .Constructor(
            function (option) {
                base.constructor.apply(this, arguments);
                option = Util.copyExist({
                    maxLength: -1,
                    clearHTML: false,
                    ellipsis: '...'
                }, option);
                this.configure(option);
            }
        )
        .Members({
            getText: function (value) {
                if (StringUtil.isNullOrEmpty(value)) {
                    return value;
                }
                if (this.getClearHTML()) {
                    value = EncodeUtil.clearHTML(value);
                }
                if (this.maxLength >= 0 && value.length > this.maxLength) {
                    return [value.substring(0, this.maxLength), this.ellipsis].join('');
                }
                return value;
            },

            getMaxLength: function () {
                return this.maxLength;
            },

            setMaxLength: function (value) {
                this.maxLength = value;
            },

            getClearHTML: function () {
                return this.clearHTML;
            },

            setClearHTML: function (value) {
                this.clearHTML = value;
            },

            getEllipsis: function () {
                return this.ellipsis;
            },

            setEllipsis: function (value) {
                this.ellipsis = value;
            },

            clearHTML: function (value) {
                return value;
            }
        })
    .$();
});