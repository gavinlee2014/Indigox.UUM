﻿define("Indigox.Web.JsLib.Formatters.ArrayFormatter",
    [
        "Indigox.Web.JsLib.Utils.Util",
        "Indigox.Web.JsLib.Formatters.Formatter",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Util,
        Formatter
    ) {

    var base = Formatter.prototype;
    
    var ArrayFormatter =
        Namespace("Indigox.Web.JsLib.Formatters")
        .Class("ArrayFormatter")
        .Extend(base)
        .Constructor(
            function (option) {
                base.constructor.apply(this, arguments);
                option = Util.copyExist({
                    seperator: ',',
                    empty: ''
                }, option);
                this.configure(option);
            }
        )
        .Members({
            getText: function (value) {
                if (value) {
                    return value.join(this.seperator);
                }
                else {
                    return this.empty;
                }
            },

            getSeperator: function () {
                return this.seperator;
            },

            setSeperator: function (value) {
                this.seperator = value;
            },

            getEmpty: function () {
                return this.empty;
            },

            setEmpty: function (value) {
                this.empty = value;
            }
        })
    .$();
});