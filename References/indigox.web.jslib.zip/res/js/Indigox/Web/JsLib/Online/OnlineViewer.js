﻿define("Indigox.Web.JsLib.Online.OnlineViewer",
    [
        "Indigox.Web.JsLib.Utils.UrlUtil",
        "Indigox.Web.JsLib.WebContexts.Context",
        "Indigox.Web.JsLib.Core"
    ],
    function (
        UrlUtil,
        Context
    ) {
        var OnlineViewer =
            Namespace("Indigox.Web.JsLib.Online")
            .Class("OnlineViewer")
            .Constructor(
                function (url) {
                    this.url = url;
                }
            )
            .Members({
                isSupportOnlineView: function () {
                    var url = this.url;
                    var fileTypes = [
                        "doc", "docx", "ppt", "pptx", "xls", "xlsx", "rtf",
                        "htm", "html", "pdf", "jpg", "jpeg", "tif", "tiff", "bmp",
                        "gif", "png", "txt", "odt", "odg", "odp", "odf"
                    ];
                    var r = new RegExp('\\.(?:' + fileTypes.join('|') + ')(?:\\?|$)', 'i');
                    return r.test(url);
                },

                getOnlineViewUrl: function () {
                    var key = Context.getInstance().getSetting("JsLib.UsePreview");
                    if (key != "true") {
                        return this.url;
                    }
                    return UrlUtil.join(Context.getInstance().getSetting("JsLib.PreviewURL"), {
                        "src": this.url
                    });
                }
            })
        .$();
    });