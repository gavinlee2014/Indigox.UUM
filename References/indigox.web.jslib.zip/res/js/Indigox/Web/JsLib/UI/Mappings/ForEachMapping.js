﻿define("Indigox.Web.JsLib.UI.Mappings.ForEachMapping",
    [
        "Indigox.Web.JsLib.UI.Mappings.Mapping",
        "Indigox.Web.JsLib.UI.DomTraversal",
        "Indigox.Web.JsLib.UI.UIManager",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Mapping,
        DomTraversal,
        UIManager   
    ) {
    var base = Mapping.prototype;
    
    var ForEachMapping =
        Namespace("Indigox.Web.JsLib.UI.Mappings")
        .Class("ForEachMapping")
        .Extend(base)
        .Constructor(
            function (element, attribute, tag, iterable) {
                base.constructor.apply(this, arguments);
                this.iterable = iterable;
                this.children = [];
            }
        )
        .Members({
            insert: function (index, element) {
                var parent = this.getElement();
                var children = this.getChildren();
                if (index >= children.length || children.length === 0) {
                    parent.element.appendChild(element);
                }
                else {
                    parent.element.insertBefore(element, children[index]);
                }
            },

            remove: function (index) {
                var parent = this.getElement();
                var children = this.getChildren();
                if (children.length > index) {
                    parent.element.removeChild(children[index]);
                }
            },

            read: function () {
                return this.getChildren();
            },

            getChildren: function () {
                var children = [];
                var parent = this.getElement();
                if (this.iterable == true) {
                    if (this.children.length == 0) {

                        var domTraversal = new DomTraversal(parent.element);
                        var endElement = domTraversal.getLastChild(parent.element);
                        var isBreak = false;
                        domTraversal.nextNode();
                        if (endElement != null) {
                            while (!isBreak && domTraversal.currentNode()) {
                                isBreak = domTraversal.currentNode() === endElement;
                                if (UIManager.getInstance().isMarkAsControl(domTraversal.currentNode())) {
                                    this.children.push(domTraversal.currentNode());
                                }
                                domTraversal.nextNode();
                            }
                        }
                    }
                    children = this.children;
                }
                else {
                    children = parent.children();
                }
                return children;
            }
        })
    .$();
} );