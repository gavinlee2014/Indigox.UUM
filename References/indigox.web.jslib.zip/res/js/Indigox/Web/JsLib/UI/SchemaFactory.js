﻿define("Indigox.Web.JsLib.UI.SchemaFactory",
    [
        "Indigox.Web.JsLib.UI.DomTraversal",
        "Indigox.Web.JsLib.UI.Schema",
        "Indigox.Web.JsLib.DOM.Element",
        "Indigox.Web.JsLib.Core"
    ],
function (
        DomTraversal,
        Schema,
        Element
    ) {

    var El = Element.el;

    var CTRL_CSS_REGEX = /control-([\w|$]\w*)/;

    var FIXED_ATTRIBUTES = {
        'for': 'htmlFor',
        'class': 'className'
    };

    var EXCLUDED_ATTRIBUTES = {
        'id': true,
        'class': true,
        'style': true
    };

    var SchemaFactory =
        Namespace('Indigox.Web.JsLib.UI')
        .Class('SchemaFactory')
        .Constructor(
            function (element) {
                this.element = element;
                this.traversal = new DomTraversal(element);
            }
        )
        .Members({
            isMarkAsControl: function (node) {
                var controlAlias = this.getControlAlias(node);
                return controlAlias !== null;
            },
            getControlAlias: function (node) {
                var css = node.className;
                var match;
                if (match = CTRL_CSS_REGEX.exec(css)) {
                    return match[1];
                }
                return null;
            },
            createSchema: function () {
                var traversal = this.traversal,
                    lastChild = traversal.lastChild(),
                    element = traversal.nextNode();

                var schema = Schema.EL(element.nodeName, [], []);

                var i = null,
                    length = null;

                var name = null,
                    value = null,
                    attributeNode = null,
                    childNode = null;

                var attributes = El(element).getSpecifiedAttributes();
                for (i = 0, length = attributes.length; i < length; i++) {
                    name = attributes[i];
                    if (name in EXCLUDED_ATTRIBUTES) {
                        continue;
                    }
                    if (name in FIXED_ATTRIBUTES) {
                        name = FIXED_ATTRIBUTES[attributes[i]];
                    }
                    value = El(element).getAttribute(name);
                    attributeNode = Schema.ATTR(name, value);
                    schema.setAttributeNode(attributeNode);
                }

                var styles = El(element).getSpecifiedStyles();
                for (i = 0, length = styles.length; i < length; i++) {
                    name = styles[i];
                    value = El(element).getStyle(name);
                    attributeNode = Schema.STYLE(name, value);
                    schema.setAttributeNode(attributeNode);
                }

                var classes = El(element).getClassList();
                var match = null;
                for (i = 0, length = classes.length; i < length; i++) {
                    match = /(^|\s+)(\w+)-(\w+)(\s+|$)/.exec(classes[i]);
                    if (match) {
                        name = match[2];
                        value = match[3];
                    }
                    else {
                        name = classes[i];
                        value = true;
                    }
                    attributeNode = Schema.CSS(name, value);
                    schema.setAttributeNode(attributeNode);
                }

                var node = null;
                for (; lastChild && node !== lastChild; ) {
                    node = traversal.currentNode();
                    if (El(node).isElement()) {
                        if (this.isMarkAsControl(node)) {
                            childNode = Schema.CTRL('${getChild("' + node.id + '")}');
                            traversal.nextNode();
                        }
                        else {
                            childNode = this.createSchema();
                        }
                    }
                    else {
                        childNode = Schema.TEXT(node.nodeValue);
                        traversal.nextNode();
                    }
                    schema.addChild(childNode);
                }

                return schema;
            }
        })
    .$();
});