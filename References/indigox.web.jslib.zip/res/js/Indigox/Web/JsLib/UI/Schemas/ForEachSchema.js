﻿define("Indigox.Web.JsLib.UI.Schemas.ForEachSchema",
    [
        "Indigox.Web.JsLib.UI.NodeSchema",
        "Indigox.Web.JsLib.Core"
    ],
function (
        NodeSchema
    ) {
    var base = NodeSchema.prototype;

    var ForEachSchema =
        Namespace('Indigox.Web.JsLib.UI.Schemas')
        .Class('ForEachSchema')
        .Extend(base)
        .Constructor(
            function (variable, iterable, childNodes) {
                base.constructor.call(this, childNodes);
                this.variable = variable;
                this.iterable = iterable;
            }
        )
        .Members({
            getVariable: function () {
                return this.variable;
            },
            getIterable: function () {
                return this.iterable;
            },
            accept: function (visitor, data) {
                return visitor.visitForEach(this, data);
            }
        })
    .$();
} );