﻿define("Indigox.Web.JsLib.UI.ControlUIs.AutoCompleteItemUI",
    [
        "Indigox.Web.JsLib.UI.UIManager",
        "Indigox.Web.JsLib.UI.DomWriter",
        "Indigox.Web.JsLib.UI.ControlUI",
        "jquery",
        "Indigox.Web.JsLib.Core"
    ],
function (
        UIManager,
        DomWriter,
        ControlUI,
        jQuery
) {
    var base = ControlUI.prototype;

    var AutoCompleteItemUI =
        Namespace('Indigox.Web.JsLib.UI.ControlUIs')
        .Class('AutoCompleteItemUI')
        .Extend(base)
        .Constructor(
            function (control) {
                base.constructor.call(this, control);
            }
        )
        .Static({
            createUI: function (control) {
                return new AutoCompleteItemUI(control);
            }
        })
        .Members({

            onPropertyChanged: function (source, property, value, oldValue) {
                base.onPropertyChanged.apply(this, arguments);

                if ((property === "isActive") && (value === true) && (this._hasScroll())) {
                    var el = this.getElement().parentElement;

                    borderTop = parseFloat(jQuery.css(el, "borderTopWidth")) || 0;
                    paddingTop = parseFloat(jQuery.css(el, "paddingTop")) || 0;

                    offset = jQuery(this.getElement()).offset().top - jQuery(el).offset().top - borderTop - paddingTop;
                    scroll = jQuery(el).scrollTop();
                    elementHeight = jQuery(el).height();
                    itemHeight = jQuery(this.getElement()).height();

                    if (offset < 0) {
                        jQuery(el).scrollTop(scroll + offset);
                    } else if (offset + itemHeight > elementHeight) {
                        jQuery(el).scrollTop(scroll + offset - elementHeight + itemHeight);
                    }
                }
            },

            _hasScroll: function () {
                var el = this.getElement().parentElement;
                return jQuery(el).outerHeight() < jQuery(el).prop("scrollHeight");
            }

        })
    .$();
});