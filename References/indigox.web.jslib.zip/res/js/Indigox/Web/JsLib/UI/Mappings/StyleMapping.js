﻿define("Indigox.Web.JsLib.UI.Mappings.StyleMapping",
    [
        "Indigox.Web.JsLib.UI.Mappings.Mapping",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Mapping
    ) {
    var base = Mapping.prototype;

    var StyleMapping =
        Namespace("Indigox.Web.JsLib.UI.Mappings")
        .Class("StyleMapping")
        .Extend(base)
        .Constructor(
            function (element, attribute, tag) {
                base.constructor.apply(this, arguments);
            }
        )
        .Members({
            write: function (value) {
                var element = this.getElement();
                element.setStyle(this.attribute, value);
            },
            read: function () {
                var element = this.getElement();
                return element.getStyle(this.attribute);
            }
        })
    .$();
} );