﻿define("Indigox.Web.JsLib.UI.ControlUIs.EditableRowUI",
    [
        "Indigox.Web.JsLib.Utils.DOMUtil",
        "Indigox.Web.JsLib.UI.UIManager",
        "Indigox.Web.JsLib.Controls.Grid.EditableCell",
        "Indigox.Web.JsLib.UI.ControlUIs.GridRowUI",
        "Indigox.Web.JsLib.Core"
    ],
function (
        DOMUtil,
        UIManager,
        EditableCell,
        GridRowUI
) {
    var base = GridRowUI.prototype;

    var EditableRowUI =
        Namespace("Indigox.Web.JsLib.UI.ControlUIs")
        .Class("EditableRowUI")
        .Extend(base)
        .Constructor(
            function (control) {
                base.constructor.call(this, control);
            }
        )
        .Static({
            createUI: function (control) {
                return new EditableRowUI(control);
            }
        })
        .Members({
            onEdit: function (source, editingRow, values) {
                var uiManager = UIManager.getInstance();

                var sourceElement = uiManager.getUI(editingRow).getElement();
                var axis = DOMUtil.getRelativePosition(sourceElement);
                this.getElement().style.position = "absolute";
                this.getElement().style.top = axis.Y + "px";
                this.getElement().style.left = axis.X + "px";
                //this.getElement().style.height = sourceElement.clientHeight + "px";

                var editingCells = editingRow.getCells();
                var control = this.getControl();

                for (var i = 0, length = editingCells.length; i < length; i++) {
                    var editingCell = editingCells[i];
                    if (!(editingCell instanceof EditableCell)) {
                        var field = editingCell.getColumn().getField();
                        var cell = control.cellMapping[field];
                        var width = uiManager.getUI(editingCell).getElement().clientWidth;
                        uiManager.getUI(cell).getElement().style.width = width + "px";
                    }
                }
            }
        })
    .$();
});