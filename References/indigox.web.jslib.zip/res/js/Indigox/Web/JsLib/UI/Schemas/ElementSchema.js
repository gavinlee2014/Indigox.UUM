﻿define("Indigox.Web.JsLib.UI.Schemas.ElementSchema",
    [
        "Indigox.Web.JsLib.Collection.List",
        "Indigox.Web.JsLib.UI.NodeSchema",
        "Indigox.Web.JsLib.Core"
    ],
function (
        List,
        NodeSchema
    ) {

    var base = NodeSchema.prototype;

    var ElementSchema =
        Namespace('Indigox.Web.JsLib.UI.Schemas')
        .Class('ElementSchema')
        .Extend(base)
        .Constructor(
            function (nodeName, attributes, childNodes) {
                base.constructor.call(this, childNodes);
                this.nodeName = nodeName;
                this.attributes = new List(attributes);
            }
        )
        .Members({
            getNodeName: function () {
                return this.nodeName;
            },
            setAttributeNode: function (attrNode) {
                var attributes = this.getAttributes(),
                    i = null,
                    length = attributes.length;
                for (i = 0; i < length; i++) {
                    if (attributes[i].getName() === attrNode.getName()) {
                        this.attributes.set(i, attrNode);
                        return;
                    }
                }
                this.attributes.add(attrNode);
            },
            getAttributeNode: function (name) {
                var attributes = this.getAttributes(),
                    i = null,
                    length = attributes.length;
                for (i = 0; i < length; i++) {
                    if (attributes[i].getName() === name) {
                        return attributes[i];
                    }
                }
                return null;
            },
            hasAttribute: function (name) {
                return this.getAttributeNode(name) !== null;
            },
            getAttributes: function () {
                return this.attributes.toArray();
            },
            accept: function (visitor, data) {
                return visitor.visitElement(this, data);
            }
        })
    .$();
} );