﻿define("Indigox.Web.JsLib.UI.ControlUI",
    [
        "Indigox.Web.JsLib.Utils.Callback",
        "Indigox.Web.JsLib.DOM.Element",
        "Indigox.Web.JsLib.Utils.Util",
        "Indigox.Web.JsLib.Utils.DelayedTask",
        "Indigox.Web.JsLib.Utils.DOMUtil",
        "Indigox.Web.JsLib.Utils.ListenersSupport",
        "Indigox.Web.JsLib.Expression.ExpressionEvaluator",
        "Indigox.Web.JsLib.Controls.Control",
        "Indigox.Web.JsLib.UI.SchemaRegistry",
        "Indigox.Web.JsLib.UI.UIManager",
        "Indigox.Web.JsLib.UI.DomReader",
        "Indigox.Web.JsLib.UI.DomWriter",
        "Indigox.Web.JsLib.UI.ChangeSet",
        "Indigox.Web.JsLib.UI.Mappings.AttributeMapping",
        "Indigox.Web.JsLib.UI.Mappings.CssMapping",
        "Indigox.Web.JsLib.UI.Mappings.ControlMapping",
        "Indigox.Web.JsLib.UI.Mappings.ForEachMapping",
        "Indigox.Web.JsLib.UI.Mappings.StyleMapping",
        "Indigox.Web.JsLib.UI.Mappings.TextMapping",
        "Indigox.Web.JsLib.UI.PropertyChange",
        "Indigox.Web.JsLib.UI.ChildAddedChange",
        "Indigox.Web.JsLib.UI.ChildRemovedChange",
        "Indigox.Web.JsLib.UI.Visitors.ManipulatorVisitor",
        "Indigox.Web.JsLib.UI.Visitors.MappingVisitor",
        "Indigox.Web.JsLib.UI.Visitors.EventVisitor",
        "Indigox.Web.JsLib.UI.Visitors.BuildRendererVisitor",
        "Indigox.Web.JsLib.UI.Renderer",
        "Indigox.Web.JsLib.UI.RendererCache",
        "Indigox.Web.JsLib.UI.MappingCache",
        "Indigox.Web.JsLib.UI.RenderQueue",
        "Indigox.Web.JsLib.UI.MediatorRegistry",
        "Indigox.Web.JsLib.Manipulators.ControlManipulator",
        "Indigox.Web.JsLib.Manipulators.ForEachManipulator",
        "Indigox.Web.JsLib.Core"
    ],
    function (
        Callback,
        Element,
        Util,
        DelayedTask,
        DOMUtil,
        ListenersSupport,
        ExpressionEvaluator,
        Control,
        SchemaRegistry,
        UIManager,
        DomReader,
        DomWriter,
        ChangeSet,
        AttributeMapping,
        CssMapping,
        ControlMapping,
        ForEachMapping,
        StyleMapping,
        TextMapping,
        PropertyChange,
        ChildAddedChange,
        ChildRemovedChange,
        ManipulatorVisitor,
        MappingVisitor,
        EventVisitor,
        BuildRendererVisitor,
        Renderer,
        RendererCache,
        MappingCache,
        RenderQueue,
        MediatorRegistry,
        ControlManipulator,
        ForEachManipulator
    ) {
        var El = Element.el;

        var STATE_CREATED = 0,
            STATE_INITED = 1,
            STATE_READY = 2,
            STATE_PRERENDERED = 3,
            STATE_RENDERED = 4,
            STATE_DISPOSED = 5;

        var LISTENER_CREATED = "Created",
            LISTENER_INITED = "Inited",
            LISTENER_READY = "Ready",
            LISTENER_PRERENDERED = "Prerendered",
            LISTENER_RENDERED = "Rendered",
            LISTENER_DISPOSED = "Disposed";

        var ControlUI =
            Namespace("Indigox.Web.JsLib.UI")
            .Class("ControlUI")
            .Constructor(
                function (control) {
                    this.control = control;
                    this.schema = null;
                    this.element = null;
                    this.mapping = null;
                    this.changeset = new ChangeSet(this);
                    this.delayedTask = null;
                    this.installed = false;
                    this.state = STATE_CREATED;
                    this.stateText = "created";
                    this.fackupElement = null;
                    this.fackuping = false;
                    this.eventAttached = false;

                    this.initListeners();
                }
            )
            .Static({
                createUI: function (control) {
                    return new ControlUI(control);
                }
            })
            .Members({
                initListeners: function () {
                    this.listeners = new ListenersSupport(this);
                    this.registerListeners();
                },

                registerListeners: function () {
                    this.listeners.registerListeners(
                        LISTENER_CREATED,
                        LISTENER_INITED,
                        LISTENER_READY,
                        LISTENER_PRERENDERED,
                        LISTENER_RENDERED,
                        LISTENER_DISPOSED
                    );
                },

                addListener: function (listener, handlers) {
                    if (this.listeners && listener != null) {
                        this.listeners.addListener(listener, handlers);
                    }
                },

                removeListener: function (listener) {
                    if (this.listeners && listener != null) {
                        this.listeners.removeListener(listener);
                    }
                },

                fireListener: function (method, args) {
                    if (this.listeners) {
                        this.listeners.fire(method, args);
                    }
                },

                getSchema: function () {
                    if (isNullOrUndefined(this.schema)) {
                        var alias = Type.forInstance(this.control).getAlias();
                        this.schema = SchemaRegistry.getInstance().getSchema(alias);
                    }
                    return this.schema;
                },

                getMediator: function () {
                    var alias = Type.forInstance(this.control).getAlias();
                    return MediatorRegistry.getInstance().getMediator(alias);
                },

                getElement: function () {
                    return this.element;
                },

                //@internal
                setElement: function (value) {
                    this.element = value;
                },

                getControl: function () {
                    return this.control;
                },

                getMapping: function () {
                    if (!this.mapping) {
                        //                    if (!window.buildtime) {
                        //                        window.buildtime = 0;
                        //                    }
                        //                    if (!window.buildcount) {
                        //                        window.buildcount = 0;
                        //                    }
                        //                    var start = new Date();
                        this.mapping = this.buildMapping();
                        //                    var end = new Date();
                        //                    var spend = end - start;
                        //                    window.buildtime = window.buildtime + spend;
                        //                    window.buildcount++;
                    }
                    return this.mapping;
                },

                buildMapping: function () {
                    var schema = this.getSchema();
                    var element = this.getElement();
                    //                var visitor = new MappingVisitor(this.getControl(), schema, element);
                    //                mapping = visitor.visit();
                    //                return mapping;
                    var mapping = {};
                    var template = MappingCache.getInstance().get(schema);
                    if (template === null) {
                        var visitor = new MappingVisitor(this.getControl(), schema, element);
                        mapping = visitor.visit();
                        MappingCache.getInstance().put(schema, mapping);
                    }
                    else {
                        for (var key in template) {
                            mapping[key] = [];
                            var mappinglist = template[key];
                            for (var i = 0, length = mappinglist.length; i < length; i++) {
                                var temp = null;
                                var item = mappinglist[i];
                                if (item instanceof AttributeMapping) {
                                    temp = new AttributeMapping(element, item.attribute, item.tag);
                                }
                                else if (item instanceof ControlMapping) {
                                    temp = new ControlMapping(element, item.attribute, item.tag);
                                }
                                else if (item instanceof CssMapping) {
                                    temp = new CssMapping(element, item.attribute, item.tag);
                                }
                                else if (item instanceof ForEachMapping) {
                                    temp = new ForEachMapping(element, item.attribute, item.tag);
                                }
                                else if (item instanceof StyleMapping) {
                                    temp = new StyleMapping(element, item.attribute, item.tag);
                                }
                                else if (item instanceof TextMapping) {
                                    temp = new TextMapping(element, item.attribute, item.tag);
                                }
                                mapping[key].push(temp);
                            }
                        }
                    }

                    return mapping;
                },

                needParseChildren: function () {
                    return true;
                },

                parseElement: function () {
                    this.parseSelf();
                    if (this.needParseChildren()) {
                        this.parseChildren();
                    }
                },

                parseSelf: function () {
                    var control = this.getControl();
                    var mapping = this.getMapping();
                    var reader = new DomReader(mapping);
                    for (var property in mapping) {
                        var manipulator = mapping[property][0];
                        if (!(manipulator instanceof ControlManipulator)
                            && !(manipulator instanceof ForEachManipulator)
                            && !(manipulator instanceof ControlMapping)
                            && !(manipulator instanceof ForEachMapping)) {
                            var expressionEvaluator = new ExpressionEvaluator(property);
                            if (expressionEvaluator.isProperty()) {
                                expressionEvaluator.setProperty(control, reader.read(property));
                            }
                        }
                    }
                },

                parseChildren: function () {
                    var control = this.getControl();
                    var mapping = this.getMapping();
                    for (var property in mapping) {
                        var manipulator = mapping[property][0];
                        var expressionEvaluator = new ExpressionEvaluator(property);
                        if (manipulator instanceof ControlManipulator || manipulator instanceof ControlMapping) {
                            this.parsePropertyChild(control, mapping, manipulator, property, expressionEvaluator);
                        }
                        else if (manipulator instanceof ForEachManipulator || manipulator instanceof ForEachMapping) {
                            this.parseCollectionChild(control, mapping, manipulator, property, expressionEvaluator);
                        }
                    }
                },

                //@private
                parsePropertyChild: function (control, mapping, manipulator, property, expressionEvaluator) {
                    var uiManager = UIManager.getInstance();
                    var element = manipulator.read();
                    if (element) {
                        var child = uiManager.createControl(element);
                        if (element.id) {
                            child.setName(element.id);
                        }

                        //debug.log(child.id + " createUI...");
                        var childUI = uiManager.createUI(child);
                        childUI.element = element;

                        if (expressionEvaluator.isProperty()) {
                            expressionEvaluator.setProperty(control, child);
                        }
                        else if (property.indexOf("getChild") > -1) {
                            this.control.addChild(child);
                        }
                    }
                },

                //@private
                parseCollectionChild: function (control, mapping, manipulator, property, expressionEvaluator) {
                    var uiManager = UIManager.getInstance();
                    var elements = manipulator.read();
                    if (elements.length > 0) {
                        var children = [];
                        for (var k = 0, length = elements.length; k < length; k++) {
                            var element = elements[k];
                            var child = uiManager.createControl(element);
                            if (element.id) {
                                child.setName(element.id);
                            }

                            //debug.log(child.id + " createUI...");
                            var childUI = uiManager.createUI(child);
                            childUI.element = element;

                            children.push(child);
                        }
                        if (expressionEvaluator.isProperty()) {
                            expressionEvaluator.setProperty(control, children);
                        }
                    }
                },

                //@deprecated
                renderHtml: function () {
                    var html = this.buildHtml();
                    this.setElement(DOMUtil.buildElement(html.join("")));
                },

                //@deprecated
                buildHtml: function () {
                    var context = this.control,
                        schema = this.getSchema();

                    var renderer = this.getRenderer(context, schema);
                    var html = [];
                    renderer.renderHtml(context, html);
                    return html;
                },

                getRenderer: function (context, schema) {
                    var renderer = RendererCache.getInstance().get(schema);
                    if (renderer === null) {
                        renderer = new Renderer();
                        var visitor = new BuildRendererVisitor(context, schema, renderer);
                        visitor.visit();
                        RendererCache.getInstance().put(schema, renderer);
                    }
                    return renderer;
                },

                render: function () {
                    if (this.getElement()) {
                        return;
                    }
                    if (this.getState() >= STATE_PRERENDERED) {
                        return;
                    }
                    //debug.log(this.getControl().id + "\'s UI render...");
                    this.markup();
                    this.renderChildren();
                },

                renderChildren: function () {
                    var control = this.getControl();
                    var writer = new DomWriter(control, this.getMapping());
                    var children, child, childUI, i, length;

                    if (control.getChildren) {
                        children = control.getChildren();
                        for (i = 0, length = children.length; i < length; i++) {
                            child = children[i];
                            childUI = UIManager.getInstance().getUI(child);
                            childUI.render();
                            childUI.insertInto(writer, "children", i);
                        }
                    }
                },

                setRendered: function () {
                    if (this.getState() === STATE_PRERENDERED && this.isRenderedToDocument()) {
                        this.attachEvent();
                        this.setState(STATE_RENDERED);
                        this.setChildrenRendered();
                    }
                },

                setChildrenRendered: function () {
                    var control = this.getControl();
                    var children, child, childUI, i, length;

                    if (control.getChildren) {
                        children = control.getChildren();
                        for (i = 0, length = children.length; i < length; i++) {
                            child = children[i];
                            childUI = UIManager.getInstance().getUI(child);
                            childUI.setRendered();
                        }
                    }
                },

                attachEvent: function () {
                    if (this.eventAttached === false) {
                        var visitor = new EventVisitor(this.getControl(), this.getSchema(), this.getElement(), this.getMediator(), this);
                        visitor.visit();
                        this.eventAttached = true;
                    }
                },

                markup: function () {
                    RenderQueue.getInstance().offer(new Callback(this.doMarkup, this));
                },

                doMarkup: function () {
                    this.renderHtml();
                    this.setState(STATE_PRERENDERED);
                },

                insertInto: function (writer, property, index) {
                    RenderQueue.getInstance().offer(new Callback(this.doInsertInto, this, [writer, property, index]));
                },

                doInsertInto: function (writer, property, index) {
                    if (!this.getElement() || El(this.getElement()).parentNode()) {
                        return;
                    }
                    if (this.getState() >= STATE_RENDERED) {
                        return;
                    }
                    //debug.log(this.getControl().id + "\'s UI insertInto...");
                    writer.insert(property, index, this.getElement());
                    this.setRendered();
                },

                replaceWith: function (writer, property) {
                    RenderQueue.getInstance().offer(new Callback(this.doReplaceWith, this, [writer, property]));
                },

                doReplaceWith: function (writer, property) {
                    if (this.getState() !== STATE_PRERENDERED) {
                        return;
                    }
                    //debug.log(this.getControl().id + "\'s UI replaceWith...");
                    writer.writeProperty(property, this.getElement());
                    this.setRendered();
                },

                removeFrom: function (writer, property, index) {
                    RenderQueue.getInstance().offer(new Callback(this.doRemoveFrom, this, [writer, property, index]));
                },

                doRemoveFrom: function (writer, property, index) {
                    if (!this.getElement() || El(this.getElement()).parentNode() === null) {
                        return;
                    }
                    writer.remove(property, index);
                },

                insertChildElement: function (property, index, child) {
                    if (!this.getElement()) {
                        return;
                    }
                    if (this.getState() >= STATE_DISPOSED) {
                        return;
                    }
                    //debug.log(this.getControl().id + "\'s UI insertChildElement...");
                    var childUI = UIManager.getInstance().getUI(child);
                    var writer = new DomWriter(this.getControl(), this.getMapping());
                    childUI.render();
                    childUI.insertInto(writer, property, index);
                },

                removeChildElement: function (property, index, child) {
                    if (!this.getElement()) {
                        return;
                    }
                    if (this.getState() >= STATE_DISPOSED) {
                        return;
                    }
                    var childUI = UIManager.getInstance().getUI(child);
                    var writer = new DomWriter(this.getControl(), this.getMapping());
                    childUI.removeFrom(writer, property, index);
                    childUI.dispose();
                },

                replaceChildElement: function (property, child) {
                    if (!this.getElement()) {
                        return;
                    }
                    if (this.getState() >= STATE_DISPOSED) {
                        return;
                    }
                    var childUI = UIManager.getInstance().getUI(child);
                    childUI.render();
                    var writer = new DomWriter(this.getControl(), this.getMapping());
                    childUI.replaceWith(writer, property);
                },

                updateElement: function (property, value) {
                    if (!this.getElement()) {
                        return;
                    }
                    if (this.getState() >= STATE_DISPOSED) {
                        return;
                    }
                    value = this.getSafeValue(property, value);
                    //debug.log(this.getControl().id + "\'s UI updateElement { property: " + property + ", value: " + value + " } ...");
                    var writer = new DomWriter(this.getControl(), this.getMapping());
                    writer.writeProperty(property, value);
                },

                getSafeValue: function (property, value) {
                    if (property === 'value') {
                        return [value].join('');
                    }
                    return value;
                },

                //@deprecated
                handleChildAdded: function (property, index, child) {
                    debug.warn("call deprecated method: Indigox.Web.JsLib.UI.ControlUI.handleChildAdded()");
                    this.insertChildElement(property, index, child);
                },

                //@deprecated
                handleChildRemoved: function (property, index, child) {
                    debug.warn("call deprecated method: Indigox.Web.JsLib.UI.ControlUI.handleChildRemoved()");
                    this.removeChildElement(property, index, child);
                },

                //@deprecated
                handlePropertyChange: function (property, value) {
                    debug.warn("call deprecated method: Indigox.Web.JsLib.UI.ControlUI.handlePropertyChange()");
                    if (value instanceof Control) {
                        this.replaceChildElement(property, value);
                    }
                    else {
                        this.updateElement(property, value);
                    }
                },

                onPropertyChanging: function (source, property, value, oldValue) {
                    if (this.isControlProperty(value, oldValue)) {
                        var child = value;
                        if (this.getState() < STATE_INITED) {
                            return;
                        }
                        var childUI = UIManager.getInstance().createUI(child);
                        if (child.isInited()) {
                            childUI.onInit();
                        }
                    }
                },

                onPropertyChanged: function (source, property, value, oldValue) {
                    if (this.isControlProperty(value, oldValue)) {
                        var child = value;
                        this.replaceChildElement(property, child);
                    }
                    else {
                        this.updateElement(property, value);
                    }
                },

                isControlProperty: function (value, oldValue) {
                    return (value instanceof Control) || (oldValue instanceof Control);
                },

                onInit: function (source) {
                    //debug.log(this.getControl().id + "\'s UI onInit...");
                    this.init();
                },

                onLoading: function (sources) {
                    //debug.log(this.getControl().id + "\'s UI onLoading...");
                    this.ready();
                },

                onLoaded: function (sources) {
                    //debug.log(this.getControl().id + "\'s UI onLoaded...");
                },

                onUnload: function (source) {
                    //this.dispose();
                },

                onChildAdding: function (source, index, child) {
                    if (this.getState() < STATE_INITED) {
                        return;
                    }
                    var childUI = UIManager.getInstance().createUI(child);
                    if (child.isInited()) {
                        childUI.onInit();
                    }
                },

                onChildAdded: function (source, index, child) {
                    this.insertChildElement("children", index, child);
                },

                onChildRemoving: function (source, index, child) {
                },

                onChildRemoved: function (source, index, child) {
                    if (!this.getElement()) {
                        return;
                    }
                    this.removeChildElement("children", index, child);
                },

                dispose: function () {
                    this.disposeChildren();
                    //debug.log("Dispose Ui for :" + this.getControl().id);
                    this.setState(STATE_DISPOSED);
                    UIManager.getInstance().uninstallUI(this.getControl(), this);
                },

                disposeChildren: function () {
                    var control = this.getControl();
                    var children, child, childUI, i, length;

                    if (control.getChildren) {
                        children = control.getChildren();
                        for (i = 0, length = children.length; i < length; i++) {
                            child = children[i];
                            childUI = UIManager.getInstance().getUI(child);
                            childUI.dispose();
                        }
                    }
                },

                setState: function (value) {
                    this.state = value;

                    switch (value) {
                        case STATE_CREATED:
                            this.stateText = "created";
                            this.fireListener(LISTENER_CREATED, [this]);
                            break;
                        case STATE_INITED:
                            this.stateText = "inited";
                            this.fireListener(LISTENER_INITED, [this]);
                            break;
                        case STATE_READY:
                            this.stateText = "ready";
                            this.fireListener(LISTENER_READY, [this]);
                            break;
                        case STATE_PRERENDERED:
                            this.stateText = "prerendered";
                            this.fireListener(LISTENER_PRERENDERED, [this]);
                            break;
                        case STATE_RENDERED:
                            this.stateText = "rendered";
                            this.fireListener(LISTENER_RENDERED, [this]);
                            break;
                        case STATE_DISPOSED:
                            this.stateText = "disposed";
                            this.fireListener(LISTENER_DISPOSED, [this]);
                            break;
                        default:
                            this.stateText = "unkown";
                            break;
                    }
                },

                getState: function () {
                    return this.state;
                },

                isInited: function () {
                    return (this.getState() >= STATE_INITED);
                },

                isRendered: function () {
                    return (this.getState() === STATE_RENDERED);
                },

                isRenderedToDocument: function () {
                    var element = this.getElement();
                    var body = document.body;
                    var parent = element.parentElement;

                    while (parent) {
                        if (parent == body) {
                            return true;
                        }
                        parent = parent.parentElement;
                    }

                    return false;
                },

                init: function () {
                    if (this.getState() !== STATE_CREATED) {
                        return;
                    }
                    //debug.log(this.getControl().id + "\'s UI init...");
                    this.createChildrenUI();
                    if (this.getElement()) {
                        this.parseElement();
                    }
                    this.setState(STATE_INITED);
                },

                ready: function () {
                    this.setState(STATE_READY);
                    //fireStateReadyListener
                    //mask or fackup

                    if (this.getElement()) {
                        this.setState(STATE_PRERENDERED);

                        if (this.isRenderedToDocument()) {
                            //this.setState(STATE_RENDERED);
                            this.setRendered();
                        }
                    }
                },

                createChildrenUI: function () {
                    var control = this.getControl();
                    var children, child, childUI, i, length;

                    if (control.getChildren) {
                        children = control.getChildren();
                        for (i = 0, length = children.length; i < length; i++) {
                            child = children[i];
                            childUI = UIManager.getInstance().createUI(child);
                            if (child.isInited()) {
                                childUI.init();
                            }
                        }
                    }
                },

                acceptChange: function (change) {
                    this.changeset.add(change);
                    if (this.delayedTask) {
                        this.delayedTask.cancel();
                    }

                    this.delayedTask = new DelayedTask(function () {
                        this.changeset.commit();
                        this.delayedTask = null;
                    }, this, []);

                    this.delayedTask.delay(100);
                },

                fakeup: function () {
                    var control = this.getControl();
                    //debug.log(control.id + " fakeup...");
                    if (!this.fackuping) {
                        var origin = this.getElement();
                        var cloned = origin.cloneNode(true);
                        //debug.log("Cloned HTML: "+cloned.innerHTML);

                        origin.parentElement.replaceChild(cloned, origin);

                        this.fackuping = true;
                        this.fackupElement = cloned;

                        this.setState(STATE_PRERENDERED);
                    }
                    else {
                        //debug.log("refreshMask: widgetzone [" + control.id + "] is fackuping.");
                    }
                },

                swap: function () {
                    var control = this.getControl();
                    //debug.log(control.id + " swap...");
                    if (this.fackuping) {
                        var origin = this.getElement();
                        var cloned = this.getFakeupElement();

                        cloned.parentElement.replaceChild(origin, cloned);
                        this.fackuping = false;
                        this.fackupElement = null;

                        this.setRendered();
                    }
                    else {
                        //debug.log("refreshUnmask: widgetzone [" + control.id + "] is not fackuping.");
                    }
                    RenderQueue.getInstance().removeListener(this);
                },

                getFakeupElement: function () {
                    return this.fackupElement;
                }
            })
        .$();
    });