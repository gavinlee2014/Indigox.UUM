﻿define("Indigox.Web.JsLib.UI.ControlUIs.BadgeLinkMenuItemUI",
    [
        "Indigox.Web.JsLib.UI.UIManager",
        "Indigox.Web.JsLib.Utils.DOMUtil",
        "Indigox.Web.JsLib.UI.Renderer",
        "Indigox.Web.JsLib.UI.RendererCache",
        "Indigox.Web.JsLib.UI.DomReader",
        "Indigox.Web.JsLib.UI.DomWriter",
        "Indigox.Web.JsLib.UI.ControlUIs.NodeControlUI",
        "Indigox.Web.JsLib.Core"
    ],
function (
        UIManager,
        DOMUtil,
        Renderer,
        RendererCache,
        DomReader,
        DomWriter,
        NodeControlUI
) {
    var base = NodeControlUI.prototype;

    var BadgeLinkMenuItemUI =
        Namespace("Indigox.Web.JsLib.UI.ControlUIs")
        .Class("BadgeLinkMenuItemUI")
        .Extend(base)
        .Constructor(
            function (control) {
                base.constructor.call(this, control);
            }
        )
        .Static({
            createUI: function (control) {
                return new BadgeLinkMenuItemUI(control);
            }
        })
        .Members({
            renderHtml: function () {
                var html = this.buildHtml();
                this.setElement(DOMUtil.buildElement(html.join("")));
                var badge = this.getControl().getBadge();
                if (isNullOrUndefined(badge) || badge == 0) {
                    DOMUtil.addClass(DOMUtil.element(" .badge", this.getElement()), "invisible");
                }
            },

            updateElement: function (property, value) {
                base.updateElement.apply(this, arguments);

                if (property == "badge") {
                    if (isNullOrUndefined(value) || value == 0) {
                        DOMUtil.addClass(DOMUtil.element(" .badge", this.getElement()), "invisible");
                    }
                    else {
                        DOMUtil.removeClass(DOMUtil.element(" .badge", this.getElement()), "invisible");
                    }
                }
            }
        })
    .$();
});