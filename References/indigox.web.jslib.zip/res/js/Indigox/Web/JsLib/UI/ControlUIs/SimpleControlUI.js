﻿define("Indigox.Web.JsLib.UI.ControlUIs.SimpleControlUI",
    [
        "Indigox.Web.JsLib.UI.ControlUI",
        "Indigox.Web.JsLib.Core"
    ],
function (
        ControlUI
) {
    var base = ControlUI.prototype;

    var SimpleControlUI =
        Namespace("Indigox.Web.JsLib.UI.ControlUIs")
        .Class("SimpleControlUI")
        .Extend(base)
        .Constructor(
            function (control) {
                base.constructor.call(this, control);
            }
        )
        .Static({
            createUI: function (control) {
                return new SimpleControlUI(control);
            }
        })
        .Members({
        })
    .$();
});