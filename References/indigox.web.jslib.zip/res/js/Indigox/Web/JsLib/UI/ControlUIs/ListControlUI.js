﻿define("Indigox.Web.JsLib.UI.ControlUIs.ListControlUI",
    [
        "Indigox.Web.JsLib.UI.UIManager",
        "Indigox.Web.JsLib.UI.ControlUI",
        "Indigox.Web.JsLib.UI.DomWriter",
        "Indigox.Web.JsLib.UI.RenderQueue",
        "Indigox.Web.JsLib.UI.ChildAddedChange",
        "Indigox.Web.JsLib.UI.ChildRemovedChange",
        "Indigox.Web.JsLib.Core"
    ],
function (
        UIManager,
        ControlUI,
        DomWriter,
        RenderQueue,
        ChildAddedChange,
        ChildRemovedChange
) {
    var base = ControlUI.prototype;

    var ListControlUI =
        Namespace('Indigox.Web.JsLib.UI.ControlUIs')
        .Class('ListControlUI')
        .Extend(base)
        .Constructor(
            function (control) {
                base.constructor.call(this, control);
            }
        )
        .Static({
            createUI: function (control) {
                return new ListControlUI(control);
            }
        })
        .Members({
            onItemAdding: function (source, index, child) {
                if (!this.isInited()) {
                    return;
                }
                var childUI = UIManager.getInstance().createUI(child);
                if (child.isInited()) {
                    childUI.init();
                }
            },

            onItemAdded: function (source, index, child) {
                this.insertChildElement("items", index, child);
            },

            onItemRemoving: function (source, index, child) {
            },

            onItemRemoved: function (source, index, child) {
                this.removeChildElement("items", index, child);
            },

            createChildrenUI: function () {
                var control = this.getControl();
                var children, child, childUI, i, length;

                children = control.getItems();
                for (i = 0, length = children.length; i < length; i++) {
                    child = children[i];
                    childUI = UIManager.getInstance().createUI(child);
                    if (child.isInited()) {
                        childUI.init();
                    }
                }

                //?TODO: create template ui
            },

            renderChildren: function () {
                var control = this.getControl();
                var writer = new DomWriter(control, this.getMapping());
                var children, child, childUI, i, length;

                children = control.getItems();
                for (i = 0, length = children.length; i < length; i++) {
                    child = children[i];
                    childUI = UIManager.getInstance().getUI(child);
                    childUI.render();
                    childUI.insertInto(writer, 'items', i);
                }

                //?TODO: render template
            },

            setChildrenRendered: function () {
                var control = this.getControl();
                var children, child, childUI, i, length;

                children = control.getItems();
                for (i = 0, length = children.length; i < length; i++) {
                    child = children[i];
                    childUI = UIManager.getInstance().getUI(child);
                    childUI.setRendered();
                }

                //?TODO: render template
            },

            disposeChildren: function () {
                var control = this.getControl();
                var children, child, childUI, i, length;

                children = control.getItems();
                for (i = 0, length = children.length; i < length; i++) {
                    child = children[i];
                    childUI = UIManager.getInstance().getUI(child);
                    childUI.dispose();
                }
            }

        })
    .$();
});