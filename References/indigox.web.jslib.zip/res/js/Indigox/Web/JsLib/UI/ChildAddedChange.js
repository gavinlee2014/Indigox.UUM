﻿define("Indigox.Web.JsLib.UI.ChildAddedChange",
    [
        "Indigox.Web.JsLib.Core"
    ],
    function (

    ) {
        var ChildAddedChange =
            Namespace("Indigox.Web.JsLib.UI")
            .Class("ChildAddedChange")
            .Constructor(
                function (property, index, child) {
                    this.property = property;
                    this.index = index;
                    this.child = child;
                }
            )
            .Members({
                process: function (handler) {
                    handler.handleChildAdded(this.property, this.index, this.child);
                }
            })
        .$();
    });