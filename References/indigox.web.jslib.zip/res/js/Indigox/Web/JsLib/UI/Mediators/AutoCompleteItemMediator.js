﻿define("Indigox.Web.JsLib.UI.Mediators.AutoCompleteItemMediator",
    [
        "Indigox.Web.JsLib.UI.ControlMediator",
        "Indigox.Web.JsLib.Core"
    ],
function (
        ControlMediator
    ) {

    var base = ControlMediator.prototype;

    var instance = null;

    var AutoCompleteItemMediator =
        Namespace("Indigox.Web.JsLib.UI.Mediators")
        .Class("AutoCompleteItemMediator")
        .Extend(base)
        .Constructor(
            function () {
            }
        )
        .Static({
            getInstance: function () {
                if (!instance) {
                    instance = new AutoCompleteItemMediator();
                }
                return instance;
            }
        })
        .Members({
            onClicked: function (source, e, ui) {
                ui.getControl().select();
                this.stopBubble(e);
            }
        })
    .$();
});