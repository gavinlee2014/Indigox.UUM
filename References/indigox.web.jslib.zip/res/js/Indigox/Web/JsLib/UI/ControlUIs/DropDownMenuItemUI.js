﻿define("Indigox.Web.JsLib.UI.ControlUIs.DropDownMenuItemUI",
    [
        "Indigox.Web.JsLib.UI.UIManager",
        "Indigox.Web.JsLib.Utils.DOMUtil",
        "Indigox.Web.JsLib.UI.Renderer",
        "Indigox.Web.JsLib.UI.RendererCache",
        "Indigox.Web.JsLib.UI.DomReader",
        "Indigox.Web.JsLib.UI.DomWriter",
        "Indigox.Web.JsLib.DOM.Element",
        "Indigox.Web.JsLib.UI.ControlUIs.NodeControlUI",
        "Indigox.Web.JsLib.Core"
    ],
function (
        UIManager,
        DOMUtil,
        Renderer,
        RendererCache,
        DomReader,
        DomWriter,
        Element,
        NodeControlUI
) {
    var base = NodeControlUI.prototype;

    var El = Element.el;

    var DropDownMenuItemUI =
        Namespace("Indigox.Web.JsLib.UI.ControlUIs")
        .Class("DropDownMenuItemUI")
        .Extend(base)
        .Constructor(
            function (control) {
                base.constructor.call(this, control);
            }
        )
        .Static({
            createUI: function (control) {
                return new DropDownMenuItemUI(control);
            }
        })
        .Members({
            onLoaded: function (sources) {
                var mediator = this.getMediator();
                var element = document.body;                
                El(element).addListener("mousedown", mediator.onMouseDown, mediator, [this]);
                base.onLoaded.apply(this, arguments);
            },

            dispose: function () {
                var mediator = this.getMediator();
                var element = document.body;
                El(element).removeListener("mousedown", mediator.onMouseDown);

                base.dispose.apply(this, arguments);
            }
        })
    .$();
});