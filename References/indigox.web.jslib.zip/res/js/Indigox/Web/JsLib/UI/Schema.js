﻿define("Indigox.Web.JsLib.UI.Schema",
    [
        "Indigox.Web.JsLib.UI.Schemas",
        "Indigox.Web.JsLib.Core"
    ],
    function (

    ) {
        var Schema =
            Namespace("Indigox.Web.JsLib.UI")
            .Class("Schema")
            .Static({
                EL: function (nodeName, attributes, childNodes) {
                    var cls = Type.forFullName("Indigox.Web.JsLib.UI.Schemas.ElementSchema").getClass();
                    return new cls(nodeName, attributes, childNodes);
                },
                EACH: function (variable, iterable, childNodes) {
                    var cls = Type.forFullName("Indigox.Web.JsLib.UI.Schemas.ForEachSchema").getClass();
                    return new cls(variable, iterable, childNodes);
                },
                CTRL: function (variable) {
                    var cls = Type.forFullName("Indigox.Web.JsLib.UI.Schemas.ControlSchema").getClass();
                    return new cls(variable);
                },
                TEXT: function (variable) {
                    var cls = Type.forFullName("Indigox.Web.JsLib.UI.Schemas.TextSchema").getClass();
                    return new cls(variable);
                },
                ATTR: function (name, variable) {
                    var cls = Type.forFullName("Indigox.Web.JsLib.UI.Schemas.AttributeSchema").getClass();
                    return new cls(name, variable);
                },
                CSS: function (name, variable) {
                    var cls = Type.forFullName("Indigox.Web.JsLib.UI.Schemas.CssSchema").getClass();
                    return new cls(name, variable);
                },
                STYLE: function (name, variable) {
                    var cls = Type.forFullName("Indigox.Web.JsLib.UI.Schemas.StyleSchema").getClass();
                    return new cls(name, variable);
                },
                EVENT: function (name, handler) {
                    var cls = Type.forFullName("Indigox.Web.JsLib.UI.Schemas.EventSchema").getClass();
                    return new cls(name, handler);
                }
            })
        .$();

        (function () {
            // HTML 4.01 / XHTML 1.0 tags
            var tags = ["a", "abbr", "acronym", "address", "applet", "area", "b", "base", "basefont",
                    "bdo", "big", "blockquote", "body", "br", "button", "caption", "center", "cite",
                    "code", "col", "colgroup", "dd", "del", "dfn", "dir", "div", "dl", "dt", "em",
                    "fieldset", "font", "form", "frame", "frameset", "head", "h1", "h2", "h3", "h4",
                    "h5", "h6", "hr", "html", "i", "iframe", "img", "input", "ins", "kbd", "label",
                    "legend", "li", "link", "map", "menu", "meta", "noframes", "noscript", "object",
                    "ol", "optgroup", "option", "p", "param", "pre", "q", "s", "samp", "script",
                    "select", "small", "span", "strike", "strong", "sub", "sup", "table", "tbody",
                    "td", "textarea", "tfoot", "th", "thead", "title", "tr", "tt", "u", "ul", "marquee"];
            // disabled tags: "style", "var"

            var i, length, tag;
            for (i = 0, length = tags.length; i < length; i++) {
                tag = tags[i].toUpperCase();
                if (typeof Schema[tag] === 'undefined') {
                    Schema[tag] = (function (tag) {
                        return function (attributes, childNodes) {
                            return Schema.EL(tag.toLowerCase(), attributes, childNodes);
                        };
                    } (tag));
                } else {
                    debug.warn('Element "' + tags[i] + '" has been added, please review the tags array, and remove the duplicated items.');
                }
            }
        } ());
    });