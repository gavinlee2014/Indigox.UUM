﻿define("Indigox.Web.JsLib.UI.ChangeSet",
    [
        "Indigox.Web.JsLib.Utils.DelayedTask",
        "Indigox.Web.JsLib.Core"
    ],
function (
        DelayedTask
) {
    var ChangeSet =
        Namespace("Indigox.Web.JsLib.UI")
        .Class("ChangeSet")
        .Constructor(
            function (controlUI) {
                this.controlUI = controlUI;
                this.changes = [];
            }
        )
        .Members({
            add: function (change) {
                this.changes.push(change);
            },

            commit: function () {
                var changes = this.changes;
                var ui = this.controlUI;
                for (var i = 0, length = changes.length; i < length; i++) {
                    changes[i].process(ui);
                }
                this.changes = [];
            }
        })
    .$();
});