﻿define("Indigox.Web.JsLib.UI.Mediators.PagingMediator",
    [
        "Indigox.Web.JsLib.UI.ControlMediator",
        "Indigox.Web.JsLib.Utils.ArrayUtil",
        "Indigox.Web.JsLib.Core"
    ],
function (
        ControlMediator,
        ArrayUtil
    ) {

    var base = ControlMediator.prototype;
    var instance = null;

    var PagingMediator =
        Namespace("Indigox.Web.JsLib.UI.Mediators")
        .Class("PagingMediator")
        .Extend(base)
        .Constructor(
            function () {
            }
        )
        .Static({
            getInstance: function () {
                if (!instance) {
                    instance = new PagingMediator();
                }
                return instance;
            }
        })
        .Members({
            onClick: function (source, e, ui) {
                var classList = this.getClassList(source);
                if (ArrayUtil.indexOf(classList, "firstpage") != -1){
                    ui.getControl().moveFirst();
                    this.stopBubble(e);
                }
                else if (ArrayUtil.indexOf(classList, "prevpage") != -1) {
                    ui.getControl().previousPage();
                    this.stopBubble(e);
                }
                else if (ArrayUtil.indexOf(classList, "nextpage") != -1){
                    ui.getControl().nextPage();
                    this.stopBubble(e);
                }
                else if (ArrayUtil.indexOf(classList, "lastpage") != -1){
                    ui.getControl().moveLast();
                    this.stopBubble(e);
                }
            },

            onChange: function (source, e, ui) {
                var nodeType = source.nodeName.toLowerCase();
                if (nodeType == "input") {
                    ui.getControl().moveTo(source.value);
                    this.stopBubble(e);
                }
            }
        })
    .$();
} );