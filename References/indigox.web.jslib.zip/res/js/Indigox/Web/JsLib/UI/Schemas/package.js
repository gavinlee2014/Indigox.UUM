﻿define("Indigox.Web.JsLib.UI.Schemas",
      ["Indigox.Web.JsLib.UI.Schemas.AttributeSchema",
       "Indigox.Web.JsLib.UI.Schemas.ControlSchema",
       "Indigox.Web.JsLib.UI.Schemas.CssSchema",
       "Indigox.Web.JsLib.UI.Schemas.ElementSchema",
       "Indigox.Web.JsLib.UI.Schemas.EventSchema",
       "Indigox.Web.JsLib.UI.Schemas.ForEachSchema",
       "Indigox.Web.JsLib.UI.Schemas.StyleSchema",
       "Indigox.Web.JsLib.UI.Schemas.TextSchema"
      ],
function (AttributeSchema,
          ControlSchema,
          CssSchema,
          ElementSchema,
          EventSchema,
          ForEachSchema,
          StyleSchema,
          TextSchema) {
    return {
        AttributeSchema: AttributeSchema,
        ControlSchema: ControlSchema,
        CssSchema: CssSchema,
        ElementSchema: ElementSchema,
        EventSchema: EventSchema,
        ForEachSchema: ForEachSchema,
        StyleSchema: StyleSchema,
        TextSchema: TextSchema
    };
});