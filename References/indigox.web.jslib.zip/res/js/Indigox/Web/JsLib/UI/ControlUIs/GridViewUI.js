﻿define("Indigox.Web.JsLib.UI.ControlUIs.GridViewUI",
    [
        "Indigox.Web.JsLib.UI.Overlay",
        "Indigox.Web.JsLib.UI.ControlUI",
        "Indigox.Web.JsLib.UI.UIManager",
        "Indigox.Web.JsLib.UI.DomWriter",
        "Indigox.Web.JsLib.UI.RenderQueue",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Overlay,
        ControlUI,
        UIManager,
        DomWriter,
        RenderQueue
) {
    var base = ControlUI.prototype;

    var GridViewUI =
        Namespace('Indigox.Web.JsLib.UI.ControlUIs')
        .Class('GridViewUI')
        .Extend(base)
        .Constructor(
            function (control) {
                base.constructor.call(this, control);
            }
        )
        .Static({
            createUI: function (control) {
                return new GridViewUI(control);
            }
        })
        .Members({
            createChildrenUI: function () {
                var control = this.getControl();
                var children, child, childUI, i, length;

                child = control.getHeader();
                if (child) {
                    childUI = UIManager.getInstance().createUI(child);
                    if (child.isInited()) {
                        childUI.init();
                    }
                }

                children = control.getRows();
                for (i = 0, length = children.length; i < length; i++) {
                    child = children[i];
                    childUI = UIManager.getInstance().createUI(child);
                    if (child.isInited()) {
                        childUI.init();
                    }
                }

                children = control.getFooters();
                for (i = 0, length = children.length; i < length; i++) {
                    child = children[i];
                    childUI = UIManager.getInstance().createUI(child);
                    if (child.isInited()) {
                        childUI.init();
                    }
                }
            },

            renderChildren: function () {
                var control = this.getControl();
                var writer = new DomWriter(control, this.getMapping());
                var children, child, childUI, i, length;

                child = control.getHeader();
                if (child) {
                    childUI = UIManager.getInstance().getUI(child);
                    childUI.render();
                    childUI.replaceWith(writer, 'header');
                }

                children = control.getRows();
                for (i = 0, length = children.length; i < length; i++) {
                    child = children[i];
                    childUI = UIManager.getInstance().getUI(child);
                    childUI.render();
                    childUI.insertInto(writer, 'rows', i);
                }

                children = control.getFooters();
                for (i = 0, length = children.length; i < length; i++) {
                    child = children[i];
                    childUI = UIManager.getInstance().getUI(child);
                    childUI.render();
                    childUI.insertInto(writer, 'footers', i);
                }
            },

            setChildrenRendered: function () {
                var control = this.getControl();
                var children, child, childUI, i, length;

                child = control.getHeader();
                if (child) {
                    childUI = UIManager.getInstance().getUI(child);
                    childUI.setRendered();
                }

                children = control.getRows();
                for (i = 0, length = children.length; i < length; i++) {
                    child = children[i];
                    childUI = UIManager.getInstance().getUI(child);
                    childUI.setRendered();
                }

                children = control.getFooters();
                for (i = 0, length = children.length; i < length; i++) {
                    child = children[i];
                    childUI = UIManager.getInstance().getUI(child);
                    childUI.setRendered();
                }
            },

            disposeChildren: function () {
                var control = this.getControl();
                var children, child, childUI, i, length;

                child = control.getHeader();
                if (child) {
                    childUI = UIManager.getInstance().getUI(child);
                    childUI.dispose();
                }

                children = control.getRows();
                for (i = 0, length = children.length; i < length; i++) {
                    child = children[i];
                    childUI = UIManager.getInstance().getUI(child);
                    childUI.dispose();
                }

                children = control.getFooters();
                for (i = 0, length = children.length; i < length; i++) {
                    child = children[i];
                    childUI = UIManager.getInstance().getUI(child);
                    childUI.dispose();
                }
            },

            insertChildElement: function (property, index, child) {
                base.insertChildElement.apply(this, arguments);

                //                if (property == "rows") {
                //                    child.click();
                //                }
            },

            onRowAdding: function (source, index, child) {
                if (!this.isInited()) {
                    return;
                }
                var childUI = UIManager.getInstance().createUI(child);
                if (child.isInited()) {
                    childUI.init();
                }

                //                if (this.getElement() && this.isRenderedToDocument()) {
                //                    RenderQueue.getInstance().addListener(this, {
                //                        onRendered: this.swap
                //                    });
                //                    this.fakeup();
                //                }
            },

            onRowAdded: function (source, index, child) {
                this.insertChildElement("rows", index, child);
            },

            onRowRemoving: function (source, index, child) {
                //                if (this.getElement() && this.isRenderedToDocument()) {
                //                    RenderQueue.getInstance().addListener(this, {
                //                        onRendered: this.swap
                //                    });
                //                    this.fakeup();
                //                }
            },

            onRowRemoved: function (source, index, child) {
                this.removeChildElement("rows", index, child);
            },

            onFooterAdding: function (source, index, child) {
                if (!this.isInited()) {
                    return;
                }
                var childUI = UIManager.getInstance().createUI(child);
                if (child.isInited()) {
                    childUI.init();
                }

                //                if (this.getElement() && this.isRenderedToDocument()) {
                //                    RenderQueue.getInstance().addListener(this, {
                //                        onRendered: this.swap
                //                    });
                //                    this.fakeup();
                //                }
            },

            onFooterAdded: function (source, index, child) {
                this.insertChildElement("footers", index, child);
            },

            onFooterRemoving: function (source, index, child) {
                //                if (this.getElement() && this.isRenderedToDocument()) {
                //                    RenderQueue.getInstance().addListener(this, {
                //                        onRendered: this.swap
                //                    });
                //                    this.fakeup();
                //                }
            },

            onFooterRemoved: function (source, index, child) {
                this.removeChildElement("footers", index, child);
            },

            onLoading: function () {
                base.onLoading.apply(this, arguments);

                //                if (this.getElement() && this.isRenderedToDocument()) {
                //                    RenderQueue.getInstance().addListener(this, {
                //                        onRendered: this.swap
                //                    });
                //                    this.fakeup();
                //                }
            },

            enterFullView: function (source) {
                Overlay.getInstance().overlay(this.getElement());
            },

            leaveFullView: function (source) {
                Overlay.getInstance().restore(this.getElement());
            }
        })
    .$();
});