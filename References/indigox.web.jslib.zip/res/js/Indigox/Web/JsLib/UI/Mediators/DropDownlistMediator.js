﻿define("Indigox.Web.JsLib.UI.Mediators.DropDownlistMediator",
    [
        "Indigox.Web.JsLib.UI.ControlMediator",
        "Indigox.Web.JsLib.Core"
    ],
function (
        ControlMediator
    ) {

    var base = ControlMediator.prototype;

    var instance = null;

    var DropDownlistMediator =
        Namespace("Indigox.Web.JsLib.UI.Mediators")
        .Class("DropDownlistMediator")
        .Extend(base)
        .Constructor(
            function () {
            }
        )
        .Static({
            getInstance: function () {
                if (!instance) {
                    instance = new DropDownlistMediator();
                }
                return instance;
            }
        })
        .Members({
            onChange: function (source, e, ui) {
                ui.getControl().change(source.value);
                this.stopBubble(e);
            }
        })
    .$();
} );