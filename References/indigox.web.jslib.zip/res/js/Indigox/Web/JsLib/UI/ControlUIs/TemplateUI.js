﻿define("Indigox.Web.JsLib.UI.ControlUIs.TemplateUI",
    [
        "Indigox.Web.JsLib.UI.SchemaRegistry",
        "Indigox.Web.JsLib.UI.SchemaFactory",
        "Indigox.Web.JsLib.UI.DomReader",
        "Indigox.Web.JsLib.UI.DomWriter",
        "Indigox.Web.JsLib.UI.Visitors.ManipulatorVisitor",
        "Indigox.Web.JsLib.UI.ControlUI",
        "Indigox.Web.JsLib.Core"
    ],
function (
        SchemaRegistry,
        SchemaFactory,
        DomReader,
        DomWriter,
        ManipulatorVisitor,
        ControlUI
) {
    var base = ControlUI.prototype;

    var TemplateUI =
        Namespace('Indigox.Web.JsLib.UI.ControlUIs')
        .Class('TemplateUI')
        .Extend(base)
        .Constructor(
            function (control) {
                base.constructor.call(this, control);
            }
        )
        .Static({
            createUI: function (control) {
                return new TemplateUI(control);
            }
        })
        .Members({
            getSchema: function () {
                if (this.schema == null) {
                    var factory = new SchemaFactory(this.getElement());
                    var schema = factory.createSchema();
                    this.schema = schema;
                    SchemaRegistry.getInstance().register(this.getControl(), schema);
                }
                return this.schema;
            },

            buildMapping: function () {
                var visitor = new ManipulatorVisitor(this.getControl(), this.getSchema(), this.getElement(), this.getMediator(), this);
                var mapping = visitor.visit();
                return mapping;
                // var visitor = new MappingVisitor(this.getControl(), this.getSchema(), this.getElement());
                // mapping = visitor.visit();
                // return mapping;
            },

            getMediator: function () {
                return null;
            },

            render: function () {
                // do nothing
            },

            insertInto: function () {
                // do nothing
            },

            replaceWith: function () {
                // do nothing
            },

            removeFrom: function () {
                base.removeFrom.apply(this, arguments);
            },

            insertChildElement: function () {
                // do nothing
            },

            removeChildElement: function () {
                // do nothing
            }
        })
    .$();
});