﻿define("Indigox.Web.JsLib.UI.ControlUIs.PagingMobileUI",
    [
        "Indigox.Web.JsLib.Utils.DOMUtil",
        "Indigox.Web.JsLib.UI.RenderQueue",
        "Indigox.Web.JsLib.UI.ControlUIs.PagingUI",
        "Indigox.Web.JsLib.Core"
    ],
function (
        DOMUtil,
        RenderQueue,
        PagingUI
) {
    var base = PagingUI.prototype;

    var PagingMobileUI =
        Namespace('Indigox.Web.JsLib.UI.ControlUIs')
        .Class('PagingMobileUI')
        .Extend(base)
        .Constructor(
            function (control) {
                base.constructor.call(this, control);
                this.working = false;
            }
        )
        .Static({
            createUI: function (control) {
                return new PagingMobileUI(control);
            }
        })
        .Members({
            parseElement: function (element) {
                if (DOMUtil.getAttribute(element, "innerHTML") == "") {
                    var html = this.buildHtml();
                    var innerHtml = DOMUtil.getAttribute(DOMUtil.buildElement(html.join('')), "innerHTML");
                    DOMUtil.setAttribute(element, "innerHTML", innerHtml);
                }

                base.parseElement.apply(this, arguments);
            },

            updateElement: function (property, value) {
                base.updateElement.apply(this, arguments);

                if (property == "isLastPage") {
                    if (value == true) {
                        var element = this.getElement();
                        DOMUtil.setAttribute(DOMUtil.element(".nextpage", element), "innerHTML", "全部数据加载完成");
                    }
                    else {
                        var element = this.getElement();
                        DOMUtil.setAttribute(DOMUtil.element(".nextpage", element), "innerHTML", "更多");
                    }
                }

                if (property == "modelLoading") {
                    if (value == true) {
                        RenderQueue.getInstance().addListener(this, {
                            onRender: this.fakeup,
                            onRendered: this.swap
                        });
                    }
                    else {
                        debug.log(this.working);
                        if (this.working == false) {
                            RenderQueue.getInstance().removeListener(this);
                        }
                    }
                }
            },

            swap: function () {
                base.swap.apply(this, arguments);
                this.working = false;
            },

            fakeup: function () {
                base.fakeup.apply(this, arguments);
                this.working = true;
            }
        })
    .$();
});