﻿define("Indigox.Web.JsLib.UI.ControlUIs.UserSelectMobileUI",
    [
        "Indigox.Web.JsLib.Utils.Callback",
        "Indigox.Web.JsLib.UI.UIManager",
        "Indigox.Web.JsLib.UI.DomReader",
        "Indigox.Web.JsLib.UI.DomWriter",
        "Indigox.Web.JsLib.Controls.Html.Dialog",
        "Indigox.Web.JsLib.Controls.Widgets.WidgetZone",
        "Indigox.Web.JsLib.UI.ControlUIs.SimpleControlUI",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Callback,
        UIManager,
        DomReader,
        DomWriter,
        Dialog,
        WidgetZone,
        SimpleControlUI
) {
    var base = SimpleControlUI.prototype;

    var UserSelectMobileUI =
        Namespace('Indigox.Web.JsLib.UI.ControlUIs')
        .Class('UserSelectMobileUI')
        .Extend(base)
        .Constructor(
            function (control) {
                base.constructor.call(this, control);
            }
        )
        .Static({
            createUI: function (control) {
                return new UserSelectMobileUI(control);
            }
        })
        .Members({
            onOpenDialog: function (source, e) {
                var control = this.getControl();
                openUuvSelcetDialog(
                    control.value,
                    control.mode,
                    control.multi,
                    new Callback(this.onDialogClosed, this));
            },
            onDialogClosed: function (dialogResult, returnValue) {
                var control = this.getControl();
                if (dialogResult === Dialog.DIALOG_RESULT_OK) {
                    var selectedUsers = returnValue;
                    control.setValue(selectedUsers);
                }
            }
        })
    .$();

    function openUuvSelcetDialog(value, mode, multi, callback) {
        var dialog = $.Dialog('userSelectDialog').first();

        if (dialog == null) {
            var zone = new WidgetZone();
            zone.name = 'UserSelectWidgetZone';
            Page().addChild(zone);

            dialog = $.Dialog('userSelectDialog').first();
        }

        if (dialog == null) {
            debug.error('can\'t find dialog.');
            return;
        }

        dialog.open({
            value: value,
            mode: mode,
            multi: multi
        }, callback);
    }
});