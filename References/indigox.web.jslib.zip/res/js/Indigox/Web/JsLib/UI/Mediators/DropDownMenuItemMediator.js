﻿define("Indigox.Web.JsLib.UI.Mediators.DropDownMenuItemMediator",
    [
        "Indigox.Web.JsLib.UI.ControlMediator",
        "Indigox.Web.JsLib.UI.Overlay",
        "Indigox.Web.JsLib.UI.UIManager",
        "Indigox.Web.JsLib.Utils.ArrayUtil",
        "Indigox.Web.JsLib.Core"
    ],
function (
        ControlMediator,
        Overlay,
        UIManager,
        ArrayUtil
    ) {

    var base = ControlMediator.prototype;

    var instance = null;

    var DropDownMenuItemMediator =
        Namespace("Indigox.Web.JsLib.UI.Mediators")
        .Class("DropDownMenuItemMediator")
        .Extend(base)
        .Constructor(
            function () {
            }
        )
        .Static({
            getInstance: function () {
                if (!instance) {
                    instance = new DropDownMenuItemMediator();
                }
                return instance;
            }
        })
        .Members({

            onClick: function (source, e, ui) {

                var classList = this.getClassList(source);
                if (ArrayUtil.indexOf(classList, "dropdownbutton") != -1){
                    ui.getControl().toggleChildMenu();
                    this.stopBubble(e);
                }
                else if (ArrayUtil.indexOf(classList, "actionbutton") != -1){
                    var control = ui.getControl();
                    if (!control.hasChildNodes()) {
                        control.setSelected(true);
                    }
                    control.click();

                    this.hideAll(control);
                    this.stopBubble(e);
                }
            },

            onMouseDown: function (source, e, ui) {
                var control = ui.getControl();
                var root = control.getRoot();
                //debug.log("onMouseDown : " + control.id);

                if (this.isParent(source, document.getElementById(root.id))) {
                    return false;
                }

                this.hideAll(control);
                //this.stopBubble(e);
            },

            hideAll: function (control) {
                var parent = control.getParent(),
                    root = control.getRoot();

                while (parent != root) {
                    parent.hideChildMenu();
                    parent = parent.parent;
                }
            },

            isParent: function (element, parentElement) {
                while (!isNullOrUndefined(element) && element.tagName.toUpperCase() != 'BODY') {
                    if (element == parentElement || element.id.toUpperCase() == 'UI-DATEPICKER-DIV') {
                        return true;
                    }
                    element = element.parentNode;
                }
                return false;
            }

        })
    .$();
});