﻿
define("Indigox.Web.JsLib.UI.Mediators.MenuMediator",
    [
        "Indigox.Web.JsLib.UI.ControlMediator",
        "Indigox.Web.JsLib.DOM.Element",
        "Indigox.Web.JsLib.UI.Overlay",
        "Indigox.Web.JsLib.Utils.ArrayUtil",
        "Indigox.Web.JsLib.Core"
    ],
function (
        ControlMediator,
        Element,
        Overlay,
        ArrayUtil
    ) {

    var base = ControlMediator.prototype;
    var El = Element.el;

    var base = ControlMediator.prototype;

    var instance = null;

    var MenuMediator =
        Namespace("Indigox.Web.JsLib.UI.Mediators")
        .Class("MenuMediator")
        .Extend(base)
        .Constructor(
            function () {
            }
        )
        .Static({
            getInstance: function () {
                if (!instance) {
                    instance = new MenuMediator();
                }
                return instance;
            }
        })
        .Members({
            onClick: function (source, e, ui) {
                var nodetype = source.nodeName.toLowerCase();
                if (nodetype == "span") {
                    Overlay.getInstance().overlay(ui.getElement());
                    this.stopBubble(e);
                }

                var classList = this.getClassList(source);
                if (ArrayUtil.indexOf(classList, "menu-popout") != -1){
                    Overlay.getInstance().overlay(ui.getElement());
                    this.stopBubble(e);
                }
                else if (ArrayUtil.indexOf(classList, "menu-hide") != -1){
                    Overlay.getInstance().restore(ui.getElement());
                    this.stopBubble(e);
                }
            },

            onTouchStart: function (source, e, ui) {
                var classList = this.getClassList(source);
                if (ArrayUtil.indexOf(classList, "menu-popout") != -1 || ArrayUtil.indexOf(classList, "menu-hide") != -1){
                    El(source).addClass("pressed");
                    this.stopBubble(e);
                }
            },

            onTouchEnd: function (source, e, ui) {
                var classList = this.getClassList(source);
                if (ArrayUtil.indexOf(classList, "menu-popout") != -1 || ArrayUtil.indexOf(classList, "menu-hide") != -1){
                    El(source).removeClass("pressed");
                    this.stopBubble(e);
                }
            }

        })
    .$();
} );