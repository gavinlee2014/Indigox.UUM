﻿define("Indigox.Web.JsLib.UI.SchemaRegistry",
    [
        "Indigox.Web.JsLib.Collection.Hashtable",
        "Indigox.Web.JsLib.Controls.Control",
        "Indigox.Web.JsLib.Utils.ConditionalConfig",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Hashtable  ,      
        Control    ,      
        ConditionalConfig
    ) {
    
    var instance = null;

    var SchemaRegistry =
        Namespace("Indigox.Web.JsLib.UI")
        .Class("SchemaRegistry")
        .Constructor(
            function () {
                this.aliasMappings = {};
                this.controlMappings = new Hashtable();
                this.builtinAttributes = [];
            }
        )
        .Static({
            getInstance: function () {
                if (!instance) {
                    instance = new SchemaRegistry();
                }
                return instance;
            }
        })
        .Members({
            builtinAttribute: function (attributes) {
                var i = null,
                    length = attributes.length;
                for (i = 0; i < length; i++) {
                    this.builtinAttributes.push(attributes[i]);
                }
            },
            applyBuiltinAttributes: function (schema) {
                var attributes = this.builtinAttributes,
                    i = null,
                    length = attributes.length;
                for (var i = 0; i < length; i++) {
                    schema.setAttributeNode(attributes[i]);
                }
            },
            register: function (control, condition, schema) {
                if (arguments.length < 3) {
                    schema = arguments[1];
                    condition = null;
                }
                this.applyBuiltinAttributes(schema);
                if (control instanceof Control) {
                    this.controlMappings.put(control, schema);
                }
                else {
                    if (this.aliasMappings[control] == null) {
                        this.aliasMappings[control] = new ConditionalConfig();
                    }
                    this.aliasMappings[control].addConfig(condition, schema);
                }
            },
            unregister: function (control) {
                if (control instanceof Control) {
                    this.controlMappings.remove(control);
                }
                else {
                    delete this.aliasMappings[control];
                }
            },
            getSchema: function (control) {
                if (control instanceof Control) {
                    return this.controlMappings.get(control);
                }
                if (control in this.aliasMappings) {
                    return this.aliasMappings[control].getConfig();
                }
                return null;
            }
        })
     .$();
});