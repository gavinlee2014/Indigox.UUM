﻿define("Indigox.Web.JsLib.UI.Mediators.CompleteItemMediator",
    [
        "Indigox.Web.JsLib.UI.ControlMediator",
        "Indigox.Web.JsLib.Core"
    ],
function (
        ControlMediator
    ) {

    var base = ControlMediator.prototype;

    var instance = null;

    var CompleteItemMediator =
        Namespace("Indigox.Web.JsLib.UI.Mediators")
        .Class("CompleteItemMediator")
        .Extend(base)
        .Constructor(
            function () {
            }
        )
        .Static({
            getInstance: function () {
                if (!instance) {
                    instance = new CompleteItemMediator();
                }
                return instance;
            }
        })
        .Members({
            onClicked: function (source, e, ui) {
                var nodeType = source.nodeName.toLowerCase();
                if (nodeType == "button") {
                    ui.getControl().remove();
                    this.stopBubble(e);
                }
            }
        })
    .$();
});