﻿define("Indigox.Web.JsLib.UI.UIManager",
    [
        "Indigox.Web.JsLib.Controls.UIEngine",
        "Indigox.Web.JsLib.Utils.ConditionalConfig",
        "Indigox.Web.JsLib.Collection.Hashtable",
        "Indigox.Web.JsLib.Core"
    ],
function (
        UIEngine,
        ConditionalConfig,
        Hashtable
    ) {
    var CTRL_CSS_REGEX = /control-([\w|$]\w*)/;

    var instance = null;

    var UIManager =
        Namespace("Indigox.Web.JsLib.UI")
        .Class("UIManager")
        .Constructor(
            function () {
                this.uiMappings = {};
            }
        )
        .Static({
            getInstance: function () {
                if (!instance) {
                    instance = new UIManager();
                }
                return instance;
            }
        })
        .Members({
            registerUI: function (alias, condition, ui) {
                if (arguments.length < 3) {
                    ui = arguments[1];
                    condition = null;
                }
                if (!this.uiMappings[alias]) {
                    this.uiMappings[alias] = new ConditionalConfig();
                }
                this.uiMappings[alias].addConfig(condition, ui);
            },

            unregisterUI: function (alias) {
                if (alias in this.uiMappings) {
                    delete this.uiMappings[alias];
                }
            },

            createControl: function (element) {
                var control = null;
                if (element === document.body) {
                    control = Page();
                }
                else if (this.isMarkAsControl(element)) {
                    var alias = this.getControlAlias(element);
                    if (alias === "page") {
                        control = Page();
                    }
                    else {
                        control = Type.forAlias(alias).createInstance();
                    }
                }
                else {
                    throw new Error("the root element is not mark as control, please check the program.");
                }
                return control;
            },

            findElement: function (control) {
                var ui = this.getUI(control);
                if (ui) {
                    return ui.getElement();
                }

                return null;
            },

            createUI: function (control) {
                //debug.log(control.id + ' createUI...');
                if (isNullOrUndefined(control)) {
                    throw new Error("control is null.");
                }
                var cls = this.findUIClass(control);
                var ui = cls.createUI(control);
                this.installUI(control, ui);
                return ui;
            },

            getUI: function (control) {
                var listeneres = control.listeners.getListeners();
                for (var i = 0, length = listeneres.length; i < length; i++) {
                    if (listeneres[i] instanceof Type.forFullName("Indigox.Web.JsLib.UI.ControlUI").getClass()) {
                        return listeneres[i];
                    }
                }
                return null;
            },

            installUI: function (control, ui) {
                //debug.log(control.id + ' installUI...');
                control.addListener(ui);
            },

            uninstallUI: function (control, ui) {
                control.removeListener(ui);
                control = null;
                ui = null;
            },

            /** @private */
            isMarkAsControl: function (node) {
                var controlAlias = this.getControlAlias(node);
                return controlAlias !== null;
            },

            /** @private */
            getControlAlias: function (node) {
                var css = node.className;
                var match;
                if (match = CTRL_CSS_REGEX.exec(css)) {
                    return match[1];
                }
                return null;
            },

            /** @private */
            //extractSchema: function (element) {
            //    var extractor = DomExtractor(element);
            //    return extractor.extract();
            //},

            /** @private */
            //createSession: function () {
            //},

            /** @private */
            //currentSession: function () {
            //},

            /** @private */
            findUIClass: function (control) {
                if (!control) {
                    return null;
                }
                var cls;
                if (isObject(control)) {
                    cls = control.constructor;
                }
                else {
                    cls = control;
                }
                var alias = Type.forClass(cls).getAlias();
                var ui = null;
                if (alias in this.uiMappings) {
                    ui = this.uiMappings[alias].getConfig();
                }
                if (isNullOrUndefined(ui)) {
                    return this.findUIClass(cls.superclass);
                }

                return ui;
            },

            /** @private */
            isParentUILoaded: function (control) {
                var parent = control.getParent();
                if (!parent) {
                    return false;
                }

                var parentUI = UIManager.getInstance().getUI(parent);
                if (!parentUI) {
                    return false;
                }

                return parentUI.isLoaded();
            }
        })
    .$();
});