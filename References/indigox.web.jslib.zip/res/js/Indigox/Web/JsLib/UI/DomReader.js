﻿define("Indigox.Web.JsLib.UI.DomReader",
    [
        "Indigox.Web.JsLib.Expression.Expression",
        "Indigox.Web.JsLib.Expression.ExpressionEvaluator",
        "Indigox.Web.JsLib.Mappings.MappingFactory",
        "Indigox.Web.JsLib.Manipulators.ControlManipulator",
        "Indigox.Web.JsLib.Manipulators.ForEachManipulator",
        "Indigox.Web.JsLib.Invokers.FieldSetterInvoker",
        "Indigox.Web.JsLib.Invokers.PropertySetterInvoker",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Expression,
        ExpressionEvaluator,
        MappingFactory,
        ControlManipulator,
        ForEachManipulator,
        FieldSetterInvoker,
        PropertySetterInvoker
) {
    var DomReader =
        Namespace("Indigox.Web.JsLib.UI")
        .Class("DomReader")
        .Constructor(
            function (mapping) {
                this.mapping = mapping;
            }
        )
        .Members({
            read: function (property) {
                if (property in this.mapping) {
                    var manipulator = this.mapping[property][0];
                    if (!(manipulator instanceof ControlManipulator) && !(manipulator instanceof ForEachManipulator)) {
                        return this.getMappedValue(property, manipulator.read());
                    }
                    else {
                        return manipulator.read();
                    }
                }
            },

            //
            readSelf: function () {
                var property = null,
                    manipulatorlist = [];

                for (property in this.mapping) {
                    manipulatorlist = this.mapping[property];

                    var manipulator = manipulatorlist[0];
                    if (!(manipulator instanceof ControlManipulator) && !(manipulator instanceof ForEachManipulator)) {
                        var expression = new ExpressionEvaluator(property);
                        if (expression.isProperty()) {
                            expression.setProperty(this.control, this.getMappedValue(property, manipulator.read()));
                        }
                    }
                }
            },

            readChidren: function () {
                var property = null,
                    manipulatorlist = [];

                for (property in this.mapping) {
                    manipulatorlist = this.mapping[property];

                    var manipulator = manipulatorlist[0];
                    if (manipulator instanceof ControlManipulator || manipulator instanceof ForEachManipulator) {
                        var expression = new ExpressionEvaluator(property);
                        if (expression.isProperty()) {
                            expression.setProperty(this.control, manipulator.read());
                        }
                        else if (property.indexOf("getChild") > -1) {
                            this.control.addChild(manipulator.read());
                        }
                    }
                }
            },

            getMappedValue: function (property, value) {
                var mapping = MappingFactory.getInstance().getMapping(property.replace(/\$\{([^\}]+)\}/, "$1"));
                if (mapping != MappingFactory.getInstance().getDefaultMapping()) {
                    return mapping.unmap(value);
                }
                else {
                    return value;
                }
            }
        })
    .$();
});