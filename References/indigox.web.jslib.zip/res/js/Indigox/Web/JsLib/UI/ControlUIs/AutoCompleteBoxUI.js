﻿define("Indigox.Web.JsLib.UI.ControlUIs.AutoCompleteBoxUI",
    [
        "Indigox.Web.JsLib.UI.UIManager",
        "Indigox.Web.JsLib.UI.DomWriter",
        "Indigox.Web.JsLib.UI.ControlUIs.ListControlUI",
        "Indigox.Web.JsLib.UI.ControlUIs.AutoCompleteBoxCursor",
        "Indigox.Web.JsLib.Core"
    ],
function (
        UIManager,
        DomWriter,
        ListControlUI,
        AutoCompleteBoxCursor

) {
    var base = ListControlUI.prototype;

//    var MoveCursor =
//        Namespace('Indigox.Web.JsLib.UI.ControlUIs.AutoCompleteBoxUI')
//        .Class('MoveCursor')
//        .Constructor(
//            function (control) {
//                this.control = control;
//                this.activeIndex = -1;
//                this.increment = 0;
//            }
//        )
//        .Members({
//            activeItemIndex: function (increment) {
//                this.increase(increment);
//                if (this.isMovePrevious() && this.cannotMovePrevious()) { return; }
//                if (this.isMoveNext() && this.cannotMoveNext()) { return; }
//                if (this.isEmptyItems()) { return; }
//                this.control.deactiveItem(this.activeIndex);
//                this.activeIndex += this.increment;
//                this.control.activeItem(this.activeIndex);
//            },
//            selectItem: function () {
//                var flag = this.activeIndex;
//                this.activeIndex = (flag == -1 ? 0 : flag);
//                if (!this.isEmptyItems()) {
//                    this.control.onSelectedChanged(this.control.getItems()[this.activeIndex]);
//                }
//                this.activeIndex = -1;
//            },
//            removePreviousCompeleteItem: function () {
//                var items = this.control.getCompleteItems();
//                if (items.length===0) { return; }
//                this.control.removeCompleteItem(items[items.length - 1]);
//            },
//            reset: function () {
//                this.activeIndex = -1;
//            },
//            increase: function (i) {
//                this.increment = i;
//            },
//            isMovePrevious: function () {
//                return this.increment < 0;
//            },
//            cannotMovePrevious: function () {
//                return this.activeIndex <= 0;
//            },
//            isMoveNext: function () {
//                return this.increment > 0;
//            },
//            cannotMoveNext: function () {
//                return this.activeIndex >= this.control.getItems().length - 1;
//            },
//            isEmptyItems: function () {
//                return this.control.getItems().length === 0;
//            }
//        })
//    .$();

    var AutoCompleteBoxUI =
        Namespace('Indigox.Web.JsLib.UI.ControlUIs')
        .Class('AutoCompleteBoxUI')
        .Extend(base)
        .Constructor(
            function (control) {
                base.constructor.call(this, control);
                this.moveCursor = new AutoCompleteBoxCursor(control);
            }
        )
        .Static({
            createUI: function (control) {
                return new AutoCompleteBoxUI(control);
            }
        })
        .Members({
            activeItemIndex: function (increment) {
                this.moveCursor.activeItemIndex(increment);
            },
            selectItem: function () {
                this.moveCursor.selectItem();
            },
            removePreviousCompeleteItem: function () {
                this.moveCursor.removePreviousCompeleteItem();
            },
            onCompleteItemAdding: function (source, index, child) {
                if (!this.isInited()) {
                    return;
                }
                var childUI = UIManager.getInstance().createUI(child);
                if (child.isInited()) {
                    childUI.init();
                }
            },

            onCompleteItemAdded: function (source, index, child) {
                this.insertChildElement("completeItems", index, child);
            },

            onCompleteItemRemoving: function (source, index, child) {
            },

            onCompleteItemRemoved: function (source, index, child) {
                this.removeChildElement("completeItems", index, child);
            },
            onIndexReset: function (source) {
                this.moveCursor.reset();
            },
            createChildrenUI: function () {
                base.createChildrenUI.apply(this, arguments);

                var control = this.getControl();
                var children, child, childUI, i, length;

                children = control.getCompleteItems();
                for (i = 0, length = children.length; i < length; i++) {
                    child = children[i];
                    childUI = UIManager.getInstance().createUI(child);
                    if (child.isInited()) {
                        childUI.init();
                    }
                }
            },

            renderChildren: function () {
                base.renderChildren.apply(this, arguments);
                var control = this.getControl();
                var writer = new DomWriter(control, this.getMapping());
                var children, child, childUI, i, length;

                children = control.getCompleteItems();
                for (i = 0, length = children.length; i < length; i++) {
                    child = children[i];
                    childUI = UIManager.getInstance().getUI(child);
                    childUI.render();
                    childUI.insertInto(writer, 'items', i);
                }
            },

            setChildrenRendered: function () {
                base.setChildrenRendered.apply(this, arguments);
                var control = this.getControl();
                var children, child, childUI, i, length;

                children = control.getCompleteItems();
                for (i = 0, length = children.length; i < length; i++) {
                    child = children[i];
                    childUI = UIManager.getInstance().getUI(child);
                    childUI.setRendered();
                }
            },

            disposeChildren: function () {
                base.disposeChildren.apply(this, arguments);
                var control = this.getControl();
                children = control.getCompleteItems();
                for (i = 0, length = children.length; i < length; i++) {
                    child = children[i];
                    childUI = UIManager.getInstance().getUI(child);
                    childUI.dispose();
                }
            }

        })
    .$();
});