﻿define("Indigox.Web.JsLib.UI.ControlUIs.WidgetResourceLoader",
    [
        "Indigox.Web.JsLib.Utils.Deferred",
        "Indigox.Web.JsLib.Utils.ErrorHandler",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Deferred,
        ErrorHandler
) {
    var WidgetResourceLoader =
        Namespace("Indigox.Web.JsLib.UI.ControlUIs")
        .Class("WidgetResourceLoader")
        .Constructor(
            function (widget) {
                this.widget = widget;
            }
        )
        .Members({
            getWidget: function () {
                return this.widget;
            },

            loadResources: function () {
                var widget = this.getWidget();
                var dfd = new Deferred();
                widget.setPending(dfd);

                var resources = widget.getResources();
                //debug.log("Load widget [" + widget.name + "] resources... ", resources)
                if (resources) {
                    var me = this;
                    require(resources, function () {
                        var callbacks = [].slice.call(arguments);
                        me.afterLoadResources(callbacks);
                        //TODO: 什么时候调用 reject?
                        dfd.resolve();
                    });
                }

                dfd.done(function () {
                    widget.setPending(null);
                });

                return dfd.promise();
            },

            //@private
            afterLoadResources: function (callbacks) {
                var widget = this.getWidget();
                var resources = widget.getResources();
                //debug.log("Load widget [" + widget.name + "] resources completed. ", resources)

                this.invokeCallbacks(widget, resources, callbacks);
            },

            //@private
            invokeCallbacks: function (widget, resources, callbacks) {
                for (var i = 0, length = callbacks.length; i < length; i++) {
                    var callback = callbacks[i];

                    if (typeof (callback) !== "function") {
                        debug.error("widget [" + widget.name + "] resource [" + resources[i] + "] is not a callback function.");
                    }
                    else {
                        //debug.log("on widget [" + widget.name + "] resources loaded...");
                        try {
                            callback(widget);
                        }
                        catch (ex) {
                            debug.error("Load widget [" + widget.name + "] failed.");
                            ErrorHandler.log(ex);
                        }
                    }
                }
            }
        })
    .$();
});