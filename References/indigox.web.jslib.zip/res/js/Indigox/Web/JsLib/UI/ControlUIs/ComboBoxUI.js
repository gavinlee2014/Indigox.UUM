﻿define("Indigox.Web.JsLib.UI.ControlUIs.ComboBoxUI",
    [
        "Indigox.Web.JsLib.UI.UIManager",
        "Indigox.Web.JsLib.UI.DomWriter",
        "Indigox.Web.JsLib.UI.ControlUIs.ListControlUI",
        "Indigox.Web.JsLib.Core"
    ],
function (
        UIManager,
        DomWriter,
        ListControlUI
) {
    var base = ListControlUI.prototype;

    var ComboBoxUI =
        Namespace('Indigox.Web.JsLib.UI.ControlUIs')
        .Class('ComboBoxUI')
        .Extend(base)
        .Constructor(
            function (control) {
                base.constructor.call(this, control);
            }
        )
        .Static({
            createUI: function (control) {
                return new ComboBoxUI(control);
            }
        })
        .Members({

            onNodeAdding: function (source, index, child) {
                if (!this.isInited()) {
                    return;
                }
                var childUI = UIManager.getInstance().createUI(child);
                if (child.isInited()) {
                    childUI.init();
                }
            },

            onNodeAdded: function (source, index, child) {
                this.insertChildElement("nodes", index, child);
            },

            onNodeRemoving: function (source, index, child) {
            },

            onNodeRemoved: function (source, index, child) {
                this.removeChildElement("nodes", index, child);
            },

            createChildrenUI: function () {
                base.createChildrenUI.apply(this, arguments);

                var control = this.getControl();
                var children, child, childUI, i, length;

                children = control.getNodes();
                for (i = 0, length = children.length; i < length; i++) {
                    child = children[i];
                    childUI = UIManager.getInstance().createUI(child);
                    if (child.isInited()) {
                        childUI.init();
                    }
                }
            },

            renderChildren: function () {
                base.renderChildren.apply(this, arguments);
                var control = this.getControl();
                var writer = new DomWriter(control, this.getMapping());
                var children, child, childUI, i, length;

                children = control.getNodes();
                for (i = 0, length = children.length; i < length; i++) {
                    child = children[i];
                    childUI = UIManager.getInstance().getUI(child);
                    childUI.render();
                    childUI.insertInto(writer, 'items', i);
                }
            },

            setChildrenRendered: function () {
                base.setChildrenRendered.apply(this, arguments);
                var control = this.getControl();
                var children, child, childUI, i, length;

                children = control.getNodes();
                for (i = 0, length = children.length; i < length; i++) {
                    child = children[i];
                    childUI = UIManager.getInstance().getUI(child);
                    childUI.setRendered();
                }
            },

            disposeChildren: function () {
                base.disposeChildren.apply(this, arguments);

                children = control.getNodes();
                for (i = 0, length = children.length; i < length; i++) {
                    child = children[i];
                    childUI = UIManager.getInstance().getUI(child);
                    childUI.dispose();
                }
            }

        })
    .$();
});