﻿define("Indigox.Web.JsLib.UI.DomWriter",
    [
        "Indigox.Web.JsLib.DOM.NodeFilter",
        "Indigox.Web.JsLib.Mappings.MappingFactory",
        "Indigox.Web.JsLib.Core"
    ],
function (
        NodeFilter,
        MappingFactory
) {
    var WHAT_TO_SHOW = NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT;

    var DomWriter =
        Namespace("Indigox.Web.JsLib.UI")
        .Class("DomWriter")
        .Constructor(
            function (control, mapping) {
                this.control = control;
                this.mapping = mapping;
            }
        )
        .Members({
            writeProperty: function (property, value) {
                value = this.getMappedValue(property, value);
                var propertyExp = ["${", property, "}"].join("");
                if (propertyExp in this.mapping) {
                    var manipulatorlist = this.mapping[propertyExp];
                    for (var i = 0, length = manipulatorlist.length; i < length; i++) {
                        manipulatorlist[i].write(value);
                    }
                }
            },

            insert: function (property, index, element) {
                var propertyExp = ["${", property, "}"].join("");
                if (propertyExp in this.mapping) {
                    var manipulatorlist = this.mapping[propertyExp];
                    for (var i = 0, length = manipulatorlist.length; i < length; i++) {
                        manipulatorlist[i].insert(index, element);
                    }
                }
            },

            remove: function (property, index) {
                var propertyExp = ["${", property, "}"].join("");
                if (propertyExp in this.mapping) {
                    var manipulatorlist = this.mapping[propertyExp];
                    for (var i = 0, length = manipulatorlist.length; i < length; i++) {
                        manipulatorlist[i].remove(index);
                    }
                }
            },

            getMappedValue: function (property, value) {
                var mapping = MappingFactory.getInstance().getMapping(property);
                if (mapping != MappingFactory.getInstance().getDefaultMapping()) {
                    return mapping.map(value);
                }
                else {
                    return value;
                }
            }
        })
    .$();
});