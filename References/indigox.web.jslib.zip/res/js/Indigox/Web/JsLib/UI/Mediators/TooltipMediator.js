﻿define("Indigox.Web.JsLib.UI.Mediators.TooltipMediator",
    [
        "Indigox.Web.JsLib.UI.ControlMediator",
        "Indigox.Web.JsLib.Core"
    ],
function (
        ControlMediator
    ) {

    var base = ControlMediator.prototype;
    var instance = null;

    var TooltipMediator =
        Namespace("Indigox.Web.JsLib.UI.Mediators")
        .Class("TooltipMediator")
        .Extend(base)
        .Constructor(
            function () {
            }
        )
        .Static({
            getInstance: function () {
                if (!instance) {
                    instance = new TooltipMediator();
                }
                return instance;
            }
        })
        .Members({
            onMouseOver: function (source, e, ui, control) {
                ui.show(control, e.pageX, e.pageY);
                this.stopBubble(e);
            },
            onMouseOut: function (source, e, ui, control) {
                ui.hide(control);
                this.stopBubble(e);
            }
        })
    .$();
} );