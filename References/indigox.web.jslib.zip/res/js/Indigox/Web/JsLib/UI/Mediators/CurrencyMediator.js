﻿define("Indigox.Web.JsLib.UI.Mediators.CurrencyMediator",
    [
        "Indigox.Web.JsLib.UI.ControlMediator",
        "Indigox.Web.JsLib.Core"
    ],
function (
        ControlMediator
    ) {

    var base = ControlMediator.prototype;

    var instance = null;

    var CurrencyMediator =
        Namespace("Indigox.Web.JsLib.UI.Mediators")
        .Class("CurrencyMediator")
        .Extend(base)
        .Constructor(
            function () {
            }
        )
        .Static({
            getInstance: function () {
                if (!instance) {
                    instance = new CurrencyMediator();
                }
                return instance;
            }
        })
        .Members({
            onChange: function (source, e, ui) {
                var nodetype = source.nodeName.toLowerCase();
                if (nodetype == "input") {
                    ui.getControl().setValue(e.target.value);
                    this.stopBubble(e);
                }
            }

        })
    .$();
} );