﻿define("Indigox.Web.JsLib.UI.Mediators.TextBoxMediator",
    [
        "Indigox.Web.JsLib.UI.ControlMediator",
        "Indigox.Web.JsLib.Core"
    ],
function (
        ControlMediator
    ) {

    var base = ControlMediator.prototype;

    var instance = null;

    var TextBoxMediator =
        Namespace("Indigox.Web.JsLib.UI.Mediators")
        .Class("TextBoxMediator")
        .Extend(base)
        .Constructor(
            function () {
            }
        )
        .Static({
            getInstance: function () {
                if (!instance) {
                    instance = new TextBoxMediator();
                }
                return instance;
            }
        })
        .Members({
            onChange: function (source, e, ui) {
                ui.getControl().setValue(e.target.value);
                this.stopBubble(e);
            },
            onClicked: function (source, e, ui) {
                ui.getControl().click(e);
                this.stopBubble(e);
            }
        })
    .$();
} );