﻿define("Indigox.Web.JsLib.UI.ControlUIs.DataListUI",
    [
        "Indigox.Web.JsLib.UI.ControlUIs.ListControlUI",
        "Indigox.Web.JsLib.UI.RenderQueue",
        "Indigox.Web.JsLib.Core"
    ],
function (
        ListControlUI,
        RenderQueue
) {
    var base = ListControlUI.prototype;

    var DataListUI =
        Namespace("Indigox.Web.JsLib.UI.ControlUIs")
        .Class("DataListUI")
        .Extend(base)
        .Constructor(
            function (control) {
                base.constructor.call(this, control);
            }
        )
        .Static({
            createUI: function (control) {
                return new DataListUI(control);
            }
        })
        .Members({
            onItemAdding: function (source, index, child) {
                base.onItemAdding.apply(this, arguments);

                if (this.getElement() && this.isRenderedToDocument()) {
                    RenderQueue.getInstance().addListener(this, {
                        onRendered: this.swap
                    });
                    this.fakeup();
                }
            },

            onItemRemoving: function (source, index, child) {
                base.onItemRemoving.apply(this, arguments);

                if (this.getElement() && this.isRenderedToDocument()) {
                    RenderQueue.getInstance().addListener(this, {
                        onRendered: this.swap
                    });
                    this.fakeup();
                }
            },

            onLoading: function () {
                base.onLoading.apply(this, arguments);

                if (this.getElement() && this.isRenderedToDocument()) {
                    RenderQueue.getInstance().addListener(this, {
                        onRendered: this.swap
                    });
                    this.fakeup();
                }
            }
        })
    .$();
});