﻿define("Indigox.Web.JsLib.UI.Mediators.PagingMobileMediator",
    [
        "Indigox.Web.JsLib.UI.Mediators.PagingMediator",
        "Indigox.Web.JsLib.DOM.Element",
        "Indigox.Web.JsLib.Core"
    ],
function (
        PagingMediator,
        Element
    ) {

    var El = Element.el;

    var base = PagingMediator.prototype;

    var instance = null;

    var PagingMobileMediator =
        Namespace("Indigox.Web.JsLib.UI.Mediators")
        .Class("PagingMobileMediator")
        .Extend(base)
        .Constructor(
            function () {
            }
        )
        .Static({
            getInstance: function () {
                if (!instance) {
                    instance = new PagingMobileMediator();
                }
                return instance;
            }
        })
        .Members({

            onTouchStart: function (source, e, ui) {
                var nodetype = source.nodeName.toLowerCase();
                if (nodetype == "a") {
                    El(source).addClass("pressed");
                    this.stopBubble(e);
                }                
            },

            onTouchEnd: function (source, e, ui) {                
                var nodetype = source.nodeName.toLowerCase();
                if (nodetype == "a") {
                    El(source).removeClass("pressed");
                    this.stopBubble(e);
                }
            },

            onClick: function (source, e, ui) {
                var nodetype = source.nodeName.toLowerCase();
                if (nodetype == "a") {
                    ui.getControl().nextPage();
                    this.stopBubble(e);
                }
            }
        })
    .$();
} );