﻿define("Indigox.Web.JsLib.UI.ControlUIs.WidgetZoneUI",
    [
        "Indigox.Web.JsLib.Utils.Callback",
        "Indigox.Web.JsLib.UI.ControlUI",
        "Indigox.Web.JsLib.UI.UIManager",
        "Indigox.Web.JsLib.UI.DomWriter",
        "Indigox.Web.JsLib.UI.ChildAddedChange",
        "Indigox.Web.JsLib.UI.ChildRemovedChange",
        "Indigox.Web.JsLib.UI.RenderQueue",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Callback,
        ControlUI,
        UIManager,
        DomWriter,
        ChildAddedChange,
        ChildRemovedChange,
        RenderQueue
) {
    var STATE_CREATED = 0,
        STATE_INITED = 1,
        STATE_READY = 2,
        STATE_PRERENDERED = 3,
        STATE_RENDERED = 4,
        STATE_DISPOSED = 5;

    var base = ControlUI.prototype;

    var WidgetZoneUI =
        Namespace("Indigox.Web.JsLib.UI.ControlUIs")
        .Class("WidgetZoneUI")
        .Extend(base)
        .Constructor(
            function (control) {
                base.constructor.call(this, control);
            }
        )
        .Static({
            createUI: function (control) {
                return new WidgetZoneUI(control);
            }
        })
        .Members({
            onWidgetAdding: function (source, index, child) {
                if (!this.isInited()) {
                    return;
                }
                var childUI = UIManager.getInstance().createUI(child);
                if (child.isInited()) {
                    childUI.onInit();
                }
            },

            onWidgetAdded: function (source, index, widget) {
                this.insertChildElement("widgets", index, widget);
            },

            onWidgetRemoving: function (source, index, child) {
            },

            onWidgetRemoved: function (source, index, widget) {
                this.removeChildElement("widgets", index, widget);
            },

            onLoading: function (source) {
                this.ready();

                if (this.getElement() && this.isRenderedToDocument()) {
                    RenderQueue.getInstance().addListener(this, {
                        onRendered: this.swap
                    });
                    this.fakeup();
                }
            },

            createChildrenUI: function () {
                var control = this.getControl();
                var children, child, childUI, i, length;

                children = control.getWidgets();
                for (i = 0, length = children.length; i < length; i++) {
                    child = children[i];
                    childUI = UIManager.getInstance().getUI(child);
                    if (child.isInited()) {
                        childUI.init();
                    }
                }
            },

            renderChildren: function () {
                var control = this.getControl();
                var writer = new DomWriter(control, this.getMapping());
                var children, child, childUI, i, length;

                children = control.getWidgets();
                for (i = 0, length = children.length; i < length; i++) {
                    child = children[i];
                    childUI = UIManager.getInstance().createUI(child);
                    childUI.render();
                    childUI.insertInto(writer, "widgets", i);
                }
            },

            setChildrenRendered: function () {
                var control = this.getControl();
                var children, child, childUI, i, length;

                children = control.getWidgets();
                for (i = 0, length = children.length; i < length; i++) {
                    child = children[i];
                    childUI = UIManager.getInstance().getUI(child);
                    childUI.setRendered();
                }
            },

            disposeChildren: function () {
                var control = this.getControl();
                var children, child, childUI, i, length;

                children = control.getWidgets();
                for (i = 0, length = children.length; i < length; i++) {
                    child = children[i];
                    childUI = UIManager.getInstance().getUI(child);
                    childUI.dispose();
                }
            }
        })
    .$();
});