﻿define("Indigox.Web.JsLib.UI.ControlUIs.LyncContactUI",
    [
        "Indigox.Web.JsLib.Utils.LyncUtil",
        "Indigox.Web.JsLib.DOM.Effect",
        "Indigox.Web.JsLib.UI.Mediators.LyncContactMediator",
        "Indigox.Web.JsLib.UI.ControlMediator",
        "Indigox.Web.JsLib.UI.ControlUIs.SimpleControlUI",
        "Indigox.Web.JsLib.Core"
    ],
function (
        LyncUtil,
        Effect,
        LyncContactMediator,
        ControlMediator,
        SimpleControlUI
) {
    var base = SimpleControlUI.prototype;

    var LyncContactUI =
        Namespace('Indigox.Web.JsLib.UI.ControlUIs')
        .Class('LyncContactUI')
        .Extend(base)
        .Constructor(
            function (control) {
                base.constructor.call(this, control);
            }
        )
        .Static({
            createUI: function (control) {
                return new LyncContactUI(control);
            }
        })
        .Members({
            onLoaded: function (sources) {
                base.onLoaded.apply(this, arguments);
                LyncUtil.addListener(this);
                var contact = this.getControl().getValue();
                if (contact) {
                    //LyncUtil.getPresence(contact.Email);
                    this.getControl().setPresence(LyncUtil.getPresence(contact.Email));
                }
            },

            onUnload: function () {
                base.onUnload.apply(this, arguments);
                LyncUtil.removeListener(this);
            },

            onLyncStatusChange: function (source, name, status) {
                //debug.log(name + " change to " + status);
                var contact = this.getControl().getValue();
                if (!contact) {
                    return;
                }

                if (name == contact.Email) {
                    this.getControl().setPresence(status);
                }
            },

            updateElement: function (property, value) {
                var contact = this.getControl().getValue();
                //debug.log("mail:" + contact.Email + ",property:" + property + ",value:" + value);
                if (property === 'value') {
                    if (contact) {
                        this.getControl().setPresence(LyncUtil.getPresence(contact.Email));
                    }
                }
                else {
                    base.updateElement.apply(this, arguments);
                }
            }
        })
    .$();
});