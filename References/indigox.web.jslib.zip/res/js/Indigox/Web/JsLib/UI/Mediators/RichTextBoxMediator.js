﻿define("Indigox.Web.JsLib.UI.Mediators.RichTextBoxMediator",
    [
        "Indigox.Web.JsLib.UI.ControlMediator",
        "Indigox.Web.JsLib.Core"
    ],
function (
        ControlMediator
    ) {

    var base = ControlMediator.prototype;

    var instance = null;

    var RichTextBoxMediator =
        Namespace("Indigox.Web.JsLib.UI.Mediators")
        .Class("RichTextBoxMediator")
        .Extend(base)
        .Constructor(
            function () {
            }
        )
        .Static({
            getInstance: function () {
                if (!instance) {
                    instance = new RichTextBoxMediator();
                }
                return instance;
            }
        })
        .Members({
            onChange: function (source, e, ui) {
                ui.getControl().setValue(e.target.value);
                this.stopBubble(e);
            }
        })
    .$();
} );