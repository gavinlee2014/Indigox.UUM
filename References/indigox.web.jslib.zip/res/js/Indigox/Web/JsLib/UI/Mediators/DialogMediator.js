﻿define("Indigox.Web.JsLib.UI.Mediators.DialogMediator",
    [
        "Indigox.Web.JsLib.UI.ControlMediator",
        "jquery-resize",
        "Indigox.Web.JsLib.Core"
    ],
    function (
        ControlMediator
    ) {
        var base = ControlMediator.prototype;

        var instance = null;

        var DialogMediator =
            Namespace("Indigox.Web.JsLib.UI.Mediators")
            .Class("DialogMediator")
            .Extend(base)
            .Constructor(
                function () {
                }
            )
            .Static({
                getInstance: function () {
                    if (!instance) {
                        instance = new DialogMediator();
                    }
                    return instance;
                }
            })
            .Members({
                onClick: function (source, e, ui) {
                    if (this.isCloseButton(source)) {
                        ui.getControl().close();
                        this.stopBubble(e);
                    }
                },

                onResize: function (source, e, ui) {
                    ui.center();
                },

                isCloseButton: function (element) {
                    var nodeType = element.nodeName.toLowerCase();
                    var parentNodeType = element.parentElement.nodeName.toLowerCase();
                    return (nodeType === "input" && parentNodeType === 'h1');
                }
            })
        .$();
    });