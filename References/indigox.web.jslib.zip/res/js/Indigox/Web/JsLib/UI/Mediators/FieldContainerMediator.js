﻿define("Indigox.Web.JsLib.UI.Mediators.FieldContainerMediator",
    [
        "Indigox.Web.JsLib.UI.ControlMediator",
        "Indigox.Web.JsLib.Core"
    ],
function (
        ControlMediator
    ) {

    var base = ControlMediator.prototype;

    var instance = null;

    var FieldContainerMediator =
        Namespace("Indigox.Web.JsLib.UI.Mediators")
        .Class("FieldContainerMediator")
        .Extend(base)
        .Constructor(
            function () {
            }
        )
        .Static({
            getInstance: function () {
                if (!instance) {
                    instance = new FieldContainerMediator();
                }
                return instance;
            }
        })
        .Members({
            onClick: function (source, e, ui) {
                var nodetype = source.nodeName.toLowerCase();
                var parentnodetype = source.parentNode.nodeName.toLowerCase();
                var collapsible = ui.getControl().getCollapsible();
                if ((nodetype == "dt" || (nodetype == 'label' && parentnodetype == "dt")) && collapsible === true) {
                    ui.getControl().collapse();

                }
                this.stopBubble(e);
            }
        })
    .$();
});