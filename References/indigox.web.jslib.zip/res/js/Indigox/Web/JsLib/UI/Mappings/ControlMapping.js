﻿define("Indigox.Web.JsLib.UI.Mappings.ControlMapping",
    [
        "Indigox.Web.JsLib.UI.Mappings.Mapping",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Mapping
    ) {
    var base = Mapping.prototype;
    var ControlMapping =
        Namespace("Indigox.Web.JsLib.UI.Mappings")
        .Class("ControlMapping")
        .Extend(base)
        .Constructor(
            function (element, attribute, tag) {
                base.constructor.apply(this, arguments);
            }
        )
        .Members({
            write: function (element) {
                var parent = this.getElement();
                
                if (parent.firstChild()) {
                    parent.element.replaceChild(element, parent.firstChild());
                }
                else {
                    parent.element.appendChild(element);
                }
            },

            read: function () {
                return this.getElement().firstChild();
            }
        })
    .$();
} );