﻿define("Indigox.Web.JsLib.UI.ChildRemovedChange",
    [
        "Indigox.Web.JsLib.Core"
    ],
    function (

    ) {
        var ChildRemovedChange =
            Namespace("Indigox.Web.JsLib.UI")
            .Class("ChildRemovedChange")
            .Constructor(
                function (property, index, child) {
                    this.property = property;
                    this.index = index;
                    this.child = child;
                }
            )
            .Members({
                process: function (handler) {
                    handler.handleChildRemoved(this.property, this.index, this.child);
                }
            })
        .$();
    });