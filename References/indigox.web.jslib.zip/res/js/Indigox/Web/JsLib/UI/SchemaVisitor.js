﻿define("Indigox.Web.JsLib.UI.SchemaVisitor",
    [
        "Indigox.Web.JsLib.Expression.ExpressionEvaluator",
        "Indigox.Web.JsLib.Mappings.MappingFactory",
        "Indigox.Web.JsLib.Core"
    ],
function (
        ExpressionEvaluator,
        MappingFactory     
    ) {
    
    var SchemaVisitor =
        Namespace('Indigox.Web.JsLib.UI')
        .Class("SchemaVisitor")
        .Constructor(
            function (context, schema) {
                this.context = context;
                this.schema = schema;
            }
        )
        .Members({
            getMappedValue: function (variable) {
                if (/\$\{([^\}]+)\}/.test(variable)) {
                    var context = this.context;
                    var field = variable.replace(/\$\{([^\}]+)\}/, '$1');
                    var expression = new ExpressionEvaluator(variable);
                    var original = expression.evaluate(context);
                    var mapping = MappingFactory.getInstance().getMapping(field);
                    return mapping.map(original);
                }
                else {
                    return variable;
                }
            },
            setMappedValue: function (field, value) {
                var original = null;
                //var expression = new ExpressionEvaluator(field);
                var mapping = MappingFactory.getInstance().getMapping(field);
                original = mapping.unmap(value);
                //if (expression.isProperty()) {
                //    expression.setProperty(this.context, original);
                //}
                throw 'NotImplementedException';
            },
            visit: function () {
            },
            visitElement: function (schema, data) {
            },
            visitText: function (schema, data) {
            },
            visitForEach: function (schema, data) {
            },
            visitControl: function (schema, data) {
            },
            visitAttribute: function (schema, data) {
            },
            visitStyle: function (schema, data) {
            },
            visitCss: function (schema, data) {
            }
        })
    .$();
} );