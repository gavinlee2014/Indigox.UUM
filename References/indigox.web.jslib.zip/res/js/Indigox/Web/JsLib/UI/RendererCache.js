﻿define("Indigox.Web.JsLib.UI.RendererCache",
    [
        "Indigox.Web.JsLib.Collection.Hashtable",
        "Indigox.Web.JsLib.Core"
    ],
    function (
        Hashtable
    ) {
        var instance = null;

        var RendererCache =
            Namespace("Indigox.Web.JsLib.UI")
            .Class("RendererCache")
            .Constructor(
                function () {
                    this.cache = new Hashtable();
                }
            )
            .Static({
                getInstance: function () {
                    if (!instance) {
                        instance = new RendererCache();
                    }
                    return instance;
                }
            })
            .Members({
                get: function (schema) {
                    return this.cache.get(schema);
                },

                contains: function (schema) {
                    return this.cache.containsKey(schema);
                },

                put: function (schema, renderer) {
                    this.cache.put(schema, renderer);
                }
            })
        .$();
    });