﻿define("Indigox.Web.JsLib.UI.Mediators.ButtonMenuItemMediator",
    [
        "Indigox.Web.JsLib.UI.ControlMediator",
        "Indigox.Web.JsLib.UI.Overlay",
        "Indigox.Web.JsLib.UI.UIManager",
        "Indigox.Web.JsLib.Utils.ArrayUtil",
        "Indigox.Web.JsLib.Core"
    ],
function (
        ControlMediator,
        Overlay,
        UIManager,
        ArrayUtil
    ) {

    var base = ControlMediator.prototype;

    var instance = null;

    var ButtonMenuItemMediator =
        Namespace("Indigox.Web.JsLib.UI.Mediators")
        .Class("ButtonMenuItemMediator")
        .Extend(base)
        .Constructor(
            function () {
            }
        )
        .Static({
            getInstance: function () {
                if (!instance) {
                    instance = new ButtonMenuItemMediator();
                }
                return instance;
            }
        })
        .Members({
            onClick: function (source, e, ui) {
                var classList = this.getClassList(source);
                if (ArrayUtil.indexOf(classList, "actionbutton") != -1){
                    var control = ui.getControl();
                    if (!control.hasChildNodes()) {
                        control.setSelected(true);
                    }
                    control.click();
                    this.stopBubble(e);
                }
                
            }
        })
    .$();
} );