﻿define("Indigox.Web.JsLib.UI.ControlUIs.AutoCompleteBoxCursor",
    [      
        "Indigox.Web.JsLib.Core"
    ],
function (
      
) {
    var AutoCompleteBoxCursorUI =
        Namespace('Indigox.Web.JsLib.UI.ControlUIs')
        .Class('AutoCompleteBoxCursor')
        .Constructor(
            function (control) {
                this.control = control;
                this.activeIndex = -1;
                this.increment = 0;
            }
        )
        .Members({
            activeItemIndex: function (increment) {
                this.increase(increment);
                if (this.isMovePrevious() && this.cannotMovePrevious()) { return; }
                if (this.isMoveNext() && this.cannotMoveNext()) { return; }
                if (this.isEmptyItems()) { return; }
                this.control.deactiveItem(this.activeIndex);
                this.activeIndex += this.increment;
                this.control.activeItem(this.activeIndex);
            },
            selectItem: function () {
                var flag = this.activeIndex;
                this.activeIndex = (flag == -1 ? 0 : flag);
                if (!this.isEmptyItems()) {
                    this.control.onSelectedChanged(this.control.getItems()[this.activeIndex]);
                }
                this.activeIndex = -1;
            },
            removePreviousCompeleteItem: function () {
                var items = this.control.getCompleteItems();
                if (items.length === 0) { return; }
                this.control.removeCompleteItem(items[items.length - 1]);
            },
            reset: function () {
                this.activeIndex = -1;
            },
            increase: function (i) {
                this.increment = i;
            },
            isMovePrevious: function () {
                return this.increment < 0;
            },
            cannotMovePrevious: function () {
                return this.activeIndex <= 0;
            },
            isMoveNext: function () {
                return this.increment > 0;
            },
            cannotMoveNext: function () {
                return this.activeIndex >= this.control.getItems().length - 1;
            },
            isEmptyItems: function () {
                return this.control.getItems().length === 0;
            }
        })
    .$();
});