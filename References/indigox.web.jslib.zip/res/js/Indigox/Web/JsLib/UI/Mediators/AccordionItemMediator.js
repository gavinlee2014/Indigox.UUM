﻿define("Indigox.Web.JsLib.UI.Mediators.AccordionItemMediator",
    [
        "Indigox.Web.JsLib.UI.ControlMediator",
        "Indigox.Web.JsLib.Core"
    ],
function (
        ControlMediator
    ) {

    var base = ControlMediator.prototype;

    var instance = null;

    var AccordionItemMediator =
        Namespace("Indigox.Web.JsLib.UI.Mediators")
        .Class("AccordionItemMediator")
        .Extend(base)
        .Constructor(
            function () {
            }
        )
        .Static({
            getInstance: function () {
                if (!instance) {
                    instance = new AccordionItemMediator();
                }
                return instance;
            }
        })
        .Members({

            onClick: function (source, e, ui) {
                var nodetype = source.nodeName.toLowerCase();
                if (nodetype == "dt") {
                    ui.getControl().toggleCollapse();
                    this.stopBubble(e);
                }
            }

        })
    .$();
} );