﻿define("Indigox.Web.JsLib.UI.ControlUIs.LiteralUI",
    [
        "Indigox.Web.JsLib.Utils.Browser",
        "Indigox.Web.JsLib.DOM.Element",
        "Indigox.Web.JsLib.UI.DomReader",
        "Indigox.Web.JsLib.Utils.DOMUtil",
        "Indigox.Web.JsLib.Utils.ArrayUtil",
        "Indigox.Web.JsLib.UI.Renderer",
        "Indigox.Web.JsLib.UI.RendererCache",
        "Indigox.Web.JsLib.UI.Visitors.BuildRendererVisitor",
        "Indigox.Web.JsLib.UI.UIManager",
        "Indigox.Web.JsLib.Manipulators.HTMLManipulator",
        "Indigox.Web.JsLib.UI.ControlUIs.SimpleControlUI",
        "Indigox.Web.JsLib.Core"
    ],
    function (
        Browser,
        Element,
        DomReader,
        DOMUtil,
        ArrayUtil,
        Renderer,
        RendererCache,
        BuildRendererVisitor,
        UIManager,
        HTMLManipulator,
        SimpleControlUI
    ) {
        var Browser = Browser.getInstance(),
            El = Element.el;

        var base = SimpleControlUI.prototype;

        var LiteralUI =
            Namespace('Indigox.Web.JsLib.UI.ControlUIs')
            .Class('LiteralUI')
            .Extend(base)
            .Constructor(
                function (control) {
                    base.constructor.call(this, control);
                }
            )
            .Static({
                createUI: function (control) {
                    return new LiteralUI(control);
                }
            })
            .Members({
                updateElement: function (property, value) {
                    if (property === 'html') {
                        DOMUtil.setAttribute(this.getElement(), "innerHTML", this.getControl().getHtml());
                    }
                    else {
                        base.updateElement.apply(this, arguments);
                    }
                },

                getMapping: function () {
                    if (!this.mapping) {
                        this.mapping = this.buildMapping();

                        var manipulator = new HTMLManipulator(this.getElement(), "innerHTML");
                        //                    if ("${html}" in this.mapping) {
                        //                        var manipulatorList = this.mapping["${html}"];
                        //                        if (ArrayUtil.indexOf(manipulatorList, manipulator) == -1) {
                        //                            manipulatorList.push(manipulator);
                        //                        }
                        //                    }
                        //                    else {
                        this.mapping["${html}"] = [manipulator];
                        //}
                    }
                    return this.mapping;
                },

                renderHtml: function () {
                    var context = this.control,
                        schema = this.getSchema();

                    var renderer = RendererCache.getInstance().get(schema);
                    if (renderer === null) {
                        renderer = new Renderer();
                        var visitor = new BuildRendererVisitor(context, schema, renderer);
                        visitor.visit();
                        RendererCache.getInstance().put(schema, renderer);
                    }

                    var html = [];
                    renderer.renderHtml(context, html);
                    var length = html.length;
                    html.splice(length - 1, 0, this.getControl().getHtml());
                    this.setElement(DOMUtil.buildElement(html.join('')));
                }
            })
        .$();
    });