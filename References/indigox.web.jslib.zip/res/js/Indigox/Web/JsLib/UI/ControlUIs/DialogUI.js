﻿define("Indigox.Web.JsLib.UI.ControlUIs.DialogUI",
    [
        "Indigox.Web.JsLib.Utils.Browser",
        "Indigox.Web.JsLib.UI.Overlay",
        "Indigox.Web.JsLib.DOM.Element",
        "Indigox.Web.JsLib.UI.ControlUI",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Browser,
        Overlay,
        Element,
        ControlUI
) {
    var Browser = Browser.getInstance(),
        El = Element.el;

    var base = ControlUI.prototype;

    var DialogUI =
        Namespace("Indigox.Web.JsLib.UI.ControlUIs")
        .Class("DialogUI")
        .Extend(base)
        .Constructor(
            function (control) {
                base.constructor.call(this, control);
            }
        )
        .Static({
            createUI: function (control) {
                return new DialogUI(control);
            }
        })
        .Members({
            updateElement: function (property, value) {
                base.updateElement.apply(this, arguments);
                if (property === "visible") {
                    var context = this.getElement();
                    if (value) {
                        this.hideFloat(context);
                        this.center();
                    }
                    else {
                        this.showFloat(context);
                    }
                }
            },

            hideFloat: function (context) {
                if (Browser.name === "IE" && Browser.version === "6.0") {
                    var dialogEl = context;

                    var elements = null, excludes = null;
                    var element = null;
                    var i = null, j = null,
                        length = null, jLength = null;
                    for (var tag in this.elementVisible) {
                        elements = document.getElementsByTagName(tag);
                        excludes = dialogEl.getElementsByTagName(tag);

                        for (i = 0, length = elements.length; i < length; i++) {
                            element = elements.item(i);
                            for (j = 0, jLength = excludes.length; j < jLength; j++) {
                                if (element === excludes.item(j)) {
                                    break;
                                }
                            }
                            if (j === jLength) {
                                this.elementVisible[tag].push(element.style.visibility);
                                element.style.visibility = "hidden";
                            }
                        }
                    }
                }
            },

            showFloat: function (context) {
                if (Browser.name === "IE" && Browser.version === "6.0") {
                    var dialogEl = context;

                    var elements = null, excludes = null;
                    var element = null;
                    for (var tag in this.elementVisible) {
                        elements = document.getElementsByTagName(tag);
                        excludes = dialogEl.getElementsByTagName(tag);

                        for (var i = 0, length = elements.length; i < length; i++) {
                            element = elements.item(i);
                            for (var j = 0, jLength = excludes.length; j < jLength; j++) {
                                if (element === excludes.item(j)) {
                                    break;
                                }
                            }
                            if (j === jLength) {
                                element.style.visibility = this.elementVisible[tag][i];
                            }
                        }
                    }
                }
            },

            center: function () {
                El(this.getElement()).center();
            }
        })
    .$();
});