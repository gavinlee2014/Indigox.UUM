﻿define("Indigox.Web.JsLib.UI.Schemas.ControlSchema",
    [
        "Indigox.Web.JsLib.Collection.List",
        "Indigox.Web.JsLib.UI.NodeSchema",
        "Indigox.Web.JsLib.Core"
    ],
    function (
        List,
        NodeSchema
    ) {
        var base = NodeSchema.prototype;

        var ControlSchema =
            Namespace('Indigox.Web.JsLib.UI.Schemas')
            .Class('ControlSchema')
            .Extend(base)
            .Constructor(
                function (variable) {
                    this.variable = variable;
                }
            )
            .Members({
                getVariable: function () {
                    return this.variable;
                },
                accept: function (visitor, data) {
                    return visitor.visitControl(this, data);
                }
            })
        .$();
    });