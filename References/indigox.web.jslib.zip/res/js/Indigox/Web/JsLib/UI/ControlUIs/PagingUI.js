﻿define("Indigox.Web.JsLib.UI.ControlUIs.PagingUI",
    [
        "Indigox.Web.JsLib.Utils.StringUtil",
        "Indigox.Web.JsLib.Utils.DOMUtil",
        "Indigox.Web.JsLib.DOM.Element",
        "Indigox.Web.JsLib.UI.DomReader",
        "Indigox.Web.JsLib.UI.DomWriter",
        "Indigox.Web.JsLib.UI.Renderer",
        "Indigox.Web.JsLib.UI.Schemas.EventSchema",
        "Indigox.Web.JsLib.UI.RendererCache",
        "Indigox.Web.JsLib.UI.Visitors.MappingVisitor",
        "Indigox.Web.JsLib.UI.Visitors.EventVisitor",
        "Indigox.Web.JsLib.UI.UIManager",
        "Indigox.Web.JsLib.UI.ControlUI",
        "Indigox.Web.JsLib.Core"
    ],
function (
        StringUtil,
        DOMUtil,
        Element,
        DomReader,
        DomWriter,
        Renderer,
        EventSchema,
        RendererCache,
        MappingVisitor,
        EventVisitor,
        UIManager,
        ControlUI
) {
    var STATE_CREATED = 0,
        STATE_INITED = 1,
        STATE_READY = 2,
        STATE_PRERENDERED = 3,
        STATE_RENDERED = 4,
        STATE_DISPOSED = 5;

    var El = Element.el;

    var base = ControlUI.prototype;

    var PagingUI =
        Namespace('Indigox.Web.JsLib.UI.ControlUIs')
        .Class('PagingUI')
        .Extend(base)
        .Constructor(
            function (control) {
                base.constructor.call(this, control);
            }
        )
        .Static({
            createUI: function (control) {
                return new PagingUI(control);
            }
        })
        .Members({
            parseElement: function () {
                var element = this.getElement();
                if (StringUtil.trim(DOMUtil.getAttribute(element, "innerHTML")) == "") {
                    var html = this.buildHtml();
                    var innerHtml = DOMUtil.getAttribute(DOMUtil.buildElement(html.join('')), "innerHTML");
                    DOMUtil.setAttribute(element, "innerHTML", innerHtml);
                }

                base.parseElement.apply(this, arguments);
            },

            buildMapping: function () {
                var visitor = new MappingVisitor(this.getControl(), this.getSchema(), this.getElement());
                var mapping = visitor.visit();
                return mapping;
            }
        })
    .$();
});