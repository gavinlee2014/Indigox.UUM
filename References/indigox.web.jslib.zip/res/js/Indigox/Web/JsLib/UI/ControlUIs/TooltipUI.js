﻿define("Indigox.Web.JsLib.UI.ControlUIs.TooltipUI",
    [
        "Indigox.Web.JsLib.Utils.DOMUtil",
        "Indigox.Web.JsLib.DOM.Element",
        "Indigox.Web.JsLib.UI.UIManager",
        "Indigox.Web.JsLib.Utils.DelayedTask",
        "Indigox.Web.JsLib.UI.ControlUI",
        "Indigox.Web.JsLib.Core"
    ],
function (
        DOMUtil,
        Element,
        UIManager,
        DelayedTask,
        ControlUI
) {
    var El = Element.el;

    var base = ControlUI.prototype;

    var TooltipUI =
        Namespace('Indigox.Web.JsLib.UI.ControlUIs')
        .Class('TooltipUI')
        .Extend(base)
        .Constructor(
            function (control) {
                base.constructor.call(this, control);
                this.showTask = null;
                this.hideTask = null;
                this.hoverControl = null;
            }
        )
        .Static({
            createUI: function (control) {
                return new TooltipUI(control);
            }
        })
        .Members({
            onShown: function (source, x, y) {
                //debug.log("Tip show :" + x + ":" + y);
                this.getElement().style.position = "absolute";
                this.getElement().style.top = y + 3 + "px";
                this.getElement().style.left = x + "px";
            },

            onControlAdded: function (source, control) {
                var ui = UIManager.getInstance().getUI(control);
                if (ui) {
                    var element = ui.getElement();
                    El(element).addListener("mouseover", this.getMediator().onMouseOver, this.getMediator(), [this, control]);
                    El(element).addListener("mouseout", this.getMediator().onMouseOut, this.getMediator(), [this, control]);
                }
                else {
                    var delayedTask = new DelayedTask(function () {
                        this.onControlAdded(source, control);
                    }, this, [source, control]);
                    delayedTask.delay(100);
                }
            },

            show: function (control, x, y) {
                if (this.hoverControl != control) {
                    this.showTask = new DelayedTask(function (control) {
                        //                        if (this.installed === false) {
                        //                            return;
                        //                        }
                        control.showtip(x, y);
                        this.showTask = null;
                        this.hoverControl = control;
                    }, this, [control]);
                    this.showTask.delay(500);
                }
                else {
                    if (this.hideTask) {
                        this.hideTask.cancel();
                        this.hideTask = null;
                    }
                }
            },

            hide: function (control) {
                if (this.hoverControl == control) {
                    this.hideTask = new DelayedTask(function (control) {
                        control.hidetip();
                        this.hideTask = null;
                        this.hoverControl = null;
                    }, this, [control]);
                    this.hideTask.delay(500);
                }
                else {
                    if (this.showTask) {
                        this.showTask.cancel();
                        this.showTask = null;
                    }
                }
            },

            onUnload: function () {
                if (this.showTask) {
                    this.showTask.cancel();
                    this.showTask = null;
                }
                if (this.hideTask) {
                    this.hideTask.cancel();
                    this.hideTask = null;
                }
                //this.installed = false;
            }
        })
    .$();
});