﻿define("Indigox.Web.JsLib.UI.Schemas.EventSchema",
    [
        "Indigox.Web.JsLib.UI.NodeSchema",
        "Indigox.Web.JsLib.Core"
    ],
function (
        NodeSchema
    ) {

    var base = NodeSchema.prototype;
    
    var EventSchema =
        Namespace('Indigox.Web.JsLib.UI.Schemas')
        .Class('EventSchema')
        .Extend(base)
        .Constructor(
            function (name, handler) {
                this.name = name;
                this.handler = handler;
            }
        )
        .Members({
            getName: function () {
                return this.name;
            },
            getHandler: function () {
                return this.handler;
            },
            accept: function (visitor, data) {
                return visitor.visitEvent(this, data);
            }
        })
    .$();
});