﻿define("Indigox.Web.JsLib.UI.Mediators.DatePickerMediator",
    [
        "Indigox.Web.JsLib.UI.ControlMediator",
        "Indigox.Web.JsLib.Utils.ArrayUtil",
        "Indigox.Web.JsLib.Core"
    ],
function (
        ControlMediator,
        ArrayUtil
    ) {

    var base = ControlMediator.prototype;

    var instance = null;

    var DatePickerMediator =
        Namespace("Indigox.Web.JsLib.UI.Mediators")
        .Class("DatePickerMediator")
        .Extend(base)
        .Constructor(
            function () {
            }
        )
        .Static({
            getInstance: function () {
                if (!instance) {
                    instance = new DatePickerMediator();
                }
                return instance;
            }
        })
        .Members({
            onChange: function (source, e, ui) {
                var classList = this.getClassList(source);

                if (ArrayUtil.indexOf(classList, "dateinput") != -1){
                    ui.getControl().setDate(source.value);
                    this.stopBubble(e);
                }
                else if (ArrayUtil.indexOf(classList, "hoursinput") != -1){
                    ui.getControl().setHours(source.value);
                    this.stopBubble(e);
                }
                else if (ArrayUtil.indexOf(classList, "minutesinput") != -1){
                    ui.getControl().setMinutes(source.value);
                    this.stopBubble(e);
                }
                else if (ArrayUtil.indexOf(classList, "secondsinput") != -1){
                    ui.getControl().setSeconds(source.value);
                    this.stopBubble(e);
                }
            },

            onClick: function (source, e, ui) {
                var classList = this.getClassList(source);
                
                if (ArrayUtil.indexOf(classList, "selectdatebutton") != -1){
                    ui.showDatePicker();
                    this.stopBubble(e);
                }
            } //,

            //onHourChange: function (source, e, ui) {
            //    ui.getControl().setHour(e.target.value);
            //},
            //
            //onMinuteChange: function (source, e, ui) {
            //    ui.getControl().setMinute(e.target.value);
            //},
            //
            //onSecondChange: function (source, e, ui) {
            //    ui.getControl().setSecond(e.target.value);
            //}
        })
    .$();
} );