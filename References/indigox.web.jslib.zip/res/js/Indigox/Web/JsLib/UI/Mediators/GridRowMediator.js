﻿define("Indigox.Web.JsLib.UI.Mediators.GridRowMediator",
    [
        "Indigox.Web.JsLib.UI.ControlMediator",
        "Indigox.Web.JsLib.Core"
    ],
function (
        ControlMediator
    ) {

    var base = ControlMediator.prototype;
    var instance = null;

    var GridRowMediator =
        Namespace("Indigox.Web.JsLib.UI.Mediators")
        .Class("GridRowMediator")
        .Extend(base)
        .Constructor(
            function () {
            }
        )
        .Static({
            getInstance: function () {
                if (!instance) {
                    instance = new GridRowMediator();
                }
                return instance;
            }
        })
        .Members({
            onClick: function (source, e, ui) {
                ui.getControl().click();
                this.stopBubble(e);
            }
        })
    .$();
} );