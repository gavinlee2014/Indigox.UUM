﻿define("Indigox.Web.JsLib.UI.Mediators.ButtonMobileMediator",
    [
        "Indigox.Web.JsLib.UI.Mediators.ButtonMediator",
        "Indigox.Web.JsLib.DOM.Element",
        "Indigox.Web.JsLib.Core"
    ],
function (
        ButtonMediator,
        Element
    ) {

    var El = Element.el;
    var base = ButtonMediator.prototype;

    var instance = null;

    var ButtonMobileMediator =
        Namespace("Indigox.Web.JsLib.UI.Mediators")
        .Class("ButtonMobileMediator")
        .Extend(base)
        .Constructor(
            function () {
            }
        )
        .Static({
            getInstance: function () {
                if (!instance) {
                    instance = new ButtonMobileMediator();
                }
                return instance;
            }
        })
        .Members({
            onTouchStart: function (source, e, ui) {
                El(ui.getElement()).addClass("pressed");
                this.stopBubble(e);
            },

            onTouchEnd: function (source, e, ui) {
                El(ui.getElement()).removeClass("pressed");
                this.stopBubble(e);
            }
        })
    .$();
} );