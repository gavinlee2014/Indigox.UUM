﻿define("Indigox.Web.JsLib.UI.ControlUIs.PanelUI",
    [
        "Indigox.Web.JsLib.UI.UIManager",
        "Indigox.Web.JsLib.UI.DomReader",
        "Indigox.Web.JsLib.UI.DomWriter",
        "Indigox.Web.JsLib.UI.RenderQueue",
        "Indigox.Web.JsLib.UI.ControlUI",
        "Indigox.Web.JsLib.Core"
    ],
function (
        UIManager,
        DomReader,
        DomWriter,
        RenderQueue,
        ControlUI
) {
    var base = ControlUI.prototype;

    var PanelUI =
        Namespace('Indigox.Web.JsLib.UI.ControlUIs')
        .Class('PanelUI')
        .Extend(base)
        .Constructor(
            function (control) {
                base.constructor.call(this, control);
            }
        )
        .Static({
            createUI: function (control) {
                return new PanelUI(control);
            }
        })
        .Members({
            onChildAdding: function () {
                base.onChildAdding.apply(this, arguments);

                if (this.getElement() && this.isRenderedToDocument()) {
                    RenderQueue.getInstance().addListener(this, {
                        onRendered: this.swap
                    });
                    this.fakeup();
                }
            },

            onChildRemoving: function () {
                base.onChildRemoving.apply(this, arguments);

                if (this.getElement() && this.isRenderedToDocument()) {
                    RenderQueue.getInstance().addListener(this, {
                        onRendered: this.swap
                    });
                    this.fakeup();
                }
            },

            onLoading: function () {
                base.onLoading.apply(this, arguments);

                if (this.getElement() && this.isRenderedToDocument()) {
                    RenderQueue.getInstance().addListener(this, {
                        onRendered: this.swap
                    });
                    this.fakeup();
                }
            }
        })
    .$();
});