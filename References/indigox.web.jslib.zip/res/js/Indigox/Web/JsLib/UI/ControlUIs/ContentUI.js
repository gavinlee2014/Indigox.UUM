﻿define("Indigox.Web.JsLib.UI.ControlUIs.ContentUI",
    [
        "Indigox.Web.JsLib.DOM.Effect",
        "Indigox.Web.JsLib.UI.Visitors.ManipulatorVisitor",
        "Indigox.Web.JsLib.UI.RenderQueue",
        "Indigox.Web.JsLib.UI.ControlUIs.SimpleControlUI",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Effect,
        ManipulatorVisitor,
        RenderQueue,
        SimpleControlUI
) {
    var base = SimpleControlUI.prototype;

    var ContentUI =
        Namespace("Indigox.Web.JsLib.UI.ControlUIs")
        .Class("ContentUI")
        .Extend(base)
        .Constructor(
            function (control) {
                base.constructor.call(this, control);
            }
        )
        .Static({
            createUI: function (control) {
                return new ContentUI(control);
            }
        })
        .Members({
            onChildAdding: function () {
                base.onChildAdding.apply(this, arguments);

                if (this.getElement() && this.isRenderedToDocument()) {
                    //debug.log("content fakeup ... ");
                    RenderQueue.getInstance().addListener(this, {
                        onRendered: this.swap
                    });
                    this.fakeup();
                }
            },

            onChildRemoving: function () {
                base.onChildRemoving.apply(this, arguments);

                if (this.getElement() && this.isRenderedToDocument()) {
                    //debug.log("content fakeup ... ");
                    RenderQueue.getInstance().addListener(this, {
                        onRendered: this.swap
                    });
                    this.fakeup();
                }
            },

            onLoading: function () {
                base.onLoading.apply(this, arguments);

                if (this.getElement() && this.isRenderedToDocument()) {
                    RenderQueue.getInstance().addListener(this, {
                        onRendered: this.swap
                    });
                    this.fakeup();
                }
            },

            buildMapping: function () {
                var visitor = new ManipulatorVisitor(this.getControl(), this.getSchema(), this.getElement(), this.getMediator(), this);
                var mapping = visitor.visit();
                return mapping;
            }
        })
    .$();
});