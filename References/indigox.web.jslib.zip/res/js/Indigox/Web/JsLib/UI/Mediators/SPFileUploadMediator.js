﻿define("Indigox.Web.JsLib.UI.Mediators.SPFileUploadMediator",
    [
        "Indigox.Web.JsLib.UI.ControlMediator",
        "Indigox.Web.JsLib.Utils.UrlUtil",
        "Indigox.Web.JsLib.Utils.ArrayUtil",
        "Indigox.Web.JsLib.WebContexts.Context",
        "Indigox.Web.JsLib.Core"
    ],
function (
        ControlMediator,
        UrlUtil,
        ArrayUtil,
        Context
    ) {

    // settings
    var enableOnlineEdit = true,
        spSiteUrl = Context.getInstance().getSetting("File.SharePoint.SiteUrl");

    var spWebs = [
            Context.getInstance().getSetting("File.SharePoint.SiteUrl") + "/" + Context.getInstance().getSetting("File.SharePoint.FolderName")
        ],
        spSites = [
            Context.getInstance().getSetting("File.SharePoint.SiteUrl")
        ],
        openDocuments3 = ['doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'txt'],
        openDocuments = ['png', 'jpg', 'jpeg', 'gif', 'bpm'],
        disableCooperationEditDocuments = ['doc', 'xls', 'ppt'],
        officeDocuments = ['doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx'];

    var VerifyHref, OnLink, DispEx; // sps functions

    var addedScripts = {};

    function addScriptBlock(src) {
        if (!isNullOrUndefined(src) && addedScripts[src] !== true) {
            var scriptDom = document.createElement('script');
            scriptDom.type = 'text/javascript';
            scriptDom.src = src;
            // document.head isn't available to IE<9
            var head = document.head || document.getElementsByTagName('head')[0] || document.documentElement;
            head.appendChild(scriptDom);
            addedScripts[src] = true;
        }
    }

    var instance = null;

    var base = ControlMediator.prototype;

    var SPFileUploadMediator =
        Namespace("Indigox.Web.JsLib.UI.Mediators")
        .Class("SPFileUploadMediator")
        .Extend(base)
        .Constructor(
            function () {
                if (enableOnlineEdit) {
                    addScriptBlock(spSiteUrl + '/_layouts/2052/init.js');
                    addScriptBlock(spSiteUrl + '/_layouts/2052/core.js');
                }
            }
        )
        .Static({
            getInstance: function () {
                if (!instance) {
                    instance = new SPFileUploadMediator();
                }
                return instance;
            }
        })
        .Members({
            onChange: function (source, e, ui) {
                var classList = this.getClassList(source);
                if (ArrayUtil.indexOf(classList, "fileupload-fileselect") != -1) {
                    var control = ui.getControl();
                    var patt = /[^\\]+$/g;
                    var selectedfilename = source.value;
                    var filename = patt.exec(selectedfilename)[0];
                    //debug.log('selected filename: ' + selectedfilename + ' ---> ' + filename);
                    control.setText(filename);
                    control.upload();
                    this.stopBubble(e);
                }
            },

            onClick: function (source, e, ui) {
                var control = ui.getControl();

                var classList = this.getClassList(source);
                if (ArrayUtil.indexOf(classList, "fileupload-removebutton") != -1) {
                    control.remove();
                    this.stopBubble(e);
                }
                else if (ArrayUtil.indexOf(classList, "fileupload-cancelbutton") != -1) {
                    control.cancel();
                    this.stopBubble(e);
                }
                else if (ArrayUtil.indexOf(classList, "fileupload-viewbutton") != -1) {
                    this.viewFile(ui);
                    this.stopBubble(e);
                }
                else if (ArrayUtil.indexOf(classList, "fileupload-permissionbutton") != -1) {
                    this.setFilePermission(ui);
                    this.stopBubble(e);
                }
                else if (ArrayUtil.indexOf(classList, "fileupload-filelink") != -1) {
                    this.clickFileLink(source, e, ui);
                    this.stopBubble(e);
                }
            },

            onMousedown: function (source, e, ui) {
                var nodetype = source.nodeName.toLowerCase();
                if (nodetype == "a") {
                    //debug.log('download link mousedown.');
                    if (enableOnlineEdit) {
                        if (SharePointFileLinkUtil.onMousedown(source, e.originalEvent)) {
                            e.preventDefault();
                        }
                    }
                    this.stopBubble(e);
                }
            },

            onFocus: function (source, e, ui) {
                var nodetype = source.nodeName.toLowerCase();
                if (nodetype == "a") {
                    //debug.log('download link focued.');
                    if (enableOnlineEdit) {
                        if (SharePointFileLinkUtil.onFocus(source, e.originalEvent)) {
                            e.preventDefault();
                        }
                    }
                    this.stopBubble(e);
                }
            },

            clickFileLink: function (source, e, ui) {
                //debug.log('download link clicked.');
                //debug.log(source.href);
                if (enableOnlineEdit) {
                    if (SharePointFileLinkUtil.onClick(source, e.originalEvent)) {
                        e.preventDefault();
                    }
                }
            },

            viewFile: function (ui) {
                //debug.log('online view link clicked.');
                var g = new RegExp('^(' + spSites.join('|') + ')', 'ig');
                var originUrl = ui.control.value.fileUrl;
                var spWeb = g.exec(originUrl)[1];

                var page = null;
                if ((/(\.doc|\.docx)$/ig).test(originUrl)) {
                    page = spWeb + '/_layouts/WordViewer.aspx';
                    UrlUtil.open(page, { id: originUrl });
                }
                else if ((/(\.xls|\.xlsx)$/ig).test(originUrl)) {
                    page = spWeb + '/_layouts/xlviewer.aspx';
                    UrlUtil.open(page, { id: originUrl });
                }
                else if ((/(\.ppt|\.pptx)$/ig).test(originUrl)) {
                    page = spWeb + '/_layouts/PowerPoint.aspx';
                    UrlUtil.open(page, {
                        PowerPointView: "ReadingView",
                        PresentationId: originUrl
                    });
                }
                else {
                    alert('仅支持在浏览器中查看 offcice 文档。');
                }
            },

            setFilePermission: function (ui) {
                //debug.log('set permission link clicked.');
                var g = new RegExp('^(' + spWebs.join('|') + ')', 'ig');
                var originUrl = ui.control.value.fileUrl;
                var spWeb = g.exec(originUrl)[1];

                if (originUrl.indexOf(spSiteUrl) !== 0) {
                    alert('仅支持在设置 SharePoint 文档权限。');
                }
                else {
                    var page = spSiteUrl + "/sps/Vtron.BPM.SPWebService/Permission.ashx";
                    UrlUtil.open(page, {
                        web: spWeb,
                        url: originUrl
                    });
                }
            }
        })
    .$();

    var SharePointFileLinkUtil = (function () {
        function isOpenDocument3(ext) {
            for (var i = 0, length = openDocuments3.length; i < length; i++) {
                if (ext == openDocuments3[i]) {
                    return true;
                }
            }
            return false;
        }

        function isOpenDocument(ext) {
            for (var i = 0, length = openDocuments.length; i < length; i++) {
                if (ext == openDocuments[i]) {
                    return true;
                }
            }
            return false;
        }

        function isDisableCooperationEditDocument(ext) {
            for (var i = 0, length = disableCooperationEditDocuments.length; i < length; i++) {
                if (ext == disableCooperationEditDocuments[i]) {
                    return true;
                }
            }
            return false;
        }

        function isOfficeDocument(ext) {
            for (var i = 0, length = officeDocuments.length; i < length; i++) {
                if (ext == officeDocuments[i]) {
                    return true;
                }
            }
            return false;
        }

        function getFileExt(url) {
            var regex = /\.([^\.\?\/]+)(\?|$)/g;
            var ret = regex.exec(url);
            if (ret == null) {
                return '';
            }
            return ret[1].toLowerCase();
        }

        function isInSharePointSite(url) {
            for (var i = 0, length = spSites.length; i < length; i++) {
                if (url.indexOf(spSites[i]) === 0) {
                    return true;
                }
            }
            return false;
        }

        var ret = {
            onClick: function (source, event) {
                var url = source.href;
                if (isInSharePointSite(url)) {
                    var ext = getFileExt(url);
                    if (isOfficeDocument(ext)) {
                        if (isDisableCooperationEditDocument(ext)) {
                            return DispEx(source, event, 'TRUE', 'FALSE', 'TRUE', 'SharePoint.OpenDocuments.3', '1', 'SharePoint.OpenDocuments', '', '', '', '1073741823', '0', '0', '0x7fffffffffffffff', '', '');
                        }
                        else {
                            return DispEx(source, event, 'TRUE', 'FALSE', 'FALSE', 'SharePoint.OpenDocuments.3', '1', 'SharePoint.OpenDocuments', '', '', '', '1073741823', '0', '0', '0x7fffffffffffffff', '', '');
                        }
                    }
                    else {
                        if (isOpenDocument3(ext)) {
                            return DispEx(source, event, 'TRUE', 'FALSE', 'FALSE', 'SharePoint.OpenDocuments.3', '1', 'SharePoint.OpenDocuments', '', '', '', '6', '0', '0', '0x1b03c4312ef', '', '');
                        }
                        else if (isOpenDocument(ext)) {
                            return DispEx(source, event, 'TRUE', 'FALSE', 'FALSE', '', '1', 'SharePoint.OpenDocuments', '', '', '', '6', '0', '0', '0x1b03c4312ef', '', '');
                        }
                        else {
                            return DispEx(source, event, 'TRUE', 'FALSE', 'FALSE', '', '1', '', '', '', '', '6', '0', '0', '0x1b03c4312ef', '', '');
                        }
                    }
                }
            },
            onMousedown: function (source, event) {
                var url = source.href;
                if (isInSharePointSite(url)) {
                    var ext = getFileExt(url);
                    if (isOpenDocument(url) || isOpenDocument3(url)) {
                        return VerifyHref(source, event, '1', 'SharePoint.OpenDocuments', '');
                    }
                    else {
                        return VerifyHref(source, event, '1', '', '');
                    }
                }
            },
            onFocus: function (source, event) {
                var url = source.href;
                if (isInSharePointSite(url)) {
                    OnLink(source);
                }
            }
        };

        return ret;
    } ());
});