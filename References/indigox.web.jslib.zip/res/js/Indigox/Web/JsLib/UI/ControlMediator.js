﻿define("Indigox.Web.JsLib.UI.ControlMediator",
    [
        "Indigox.Web.JsLib.DOM.Element",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Element
) {
    var instance = null;

    var El = Element.el;

    var ControlMediator =
        Namespace("Indigox.Web.JsLib.UI")
        .Class("ControlMediator")
        .Constructor(
            function () {
            }
        )
        .Static({
            getInstance: function () {
                if (!instance) {
                    instance = new ControlMediator();
                }
                return instance;
            }
        })
        .Members({
            getClassList: function (source) {
                var element = El(source);
                return element.getClassList();
            },

            stopBubble: function (e) {
                if (e && e.stopPropagation) {//非IE
                    e.stopPropagation();
                }
                else {//IE
                    window.event.cancelBubble = true;
                }
            }
        })
    .$();
});