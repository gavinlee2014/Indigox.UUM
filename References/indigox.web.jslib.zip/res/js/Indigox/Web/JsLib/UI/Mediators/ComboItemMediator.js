﻿define("Indigox.Web.JsLib.UI.Mediators.ComboItemMediator",
    [
        "Indigox.Web.JsLib.UI.ControlMediator",
        "Indigox.Web.JsLib.Core"
    ],
function (
        ControlMediator
    ) {

    var base = ControlMediator.prototype;

    var instance = null;

    var ComboItemMediator =
        Namespace("Indigox.Web.JsLib.UI.Mediators")
        .Class("ComboItemMediator")
        .Extend(base)
        .Constructor(
            function () {
            }
        )
        .Static({
            getInstance: function () {
                if (!instance) {
                    instance = new ComboItemMediator();
                }
                return instance;
            }
        })
        .Members({
            onClicked: function (source, e, ui) {
                ui.getControl().select();
                this.stopBubble(e);
            }
        })
    .$();
});