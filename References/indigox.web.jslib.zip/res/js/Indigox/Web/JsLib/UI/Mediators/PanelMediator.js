﻿define("Indigox.Web.JsLib.UI.Mediators.PanelMediator",
    [
        "Indigox.Web.JsLib.UI.ControlMediator",
        "Indigox.Web.JsLib.Core"
    ],
function (
        ControlMediator
    ) {

    var base = ControlMediator.prototype;

    var instance = null;

    var PanelMediator =
        Namespace("Indigox.Web.JsLib.UI.Mediators")
        .Class("PanelMediator")
        .Extend(base)
        .Constructor(
            function () {
            }
        )
        .Static({
            getInstance: function () {
                if (!instance) {
                    instance = new PanelMediator();
                }
                return instance;
            }
        })
        .Members({
            onClick: function (source, e, ui) {
                 var nodetype = source.nodeName.toLowerCase();
                 if (nodetype == "h1") {
                     ui.getControl().toggleCollapse();
                     this.stopBubble(e);
                 }
            }
        })
    .$();
} );