﻿define("Indigox.Web.JsLib.UI.ControlUIs.DataItemUI",
    [
        "Indigox.Web.JsLib.Utils.DelayedTask",
        "Indigox.Web.JsLib.UI.DomWriter",
        "Indigox.Web.JsLib.UI.Schema",
        "Indigox.Web.JsLib.UI.Visitors.ManipulatorVisitor",
        "Indigox.Web.JsLib.UI.SchemaRegistry",
        "Indigox.Web.JsLib.UI.UIManager",
        "Indigox.Web.JsLib.UI.ControlUIs.SimpleControlUI",
        "Indigox.Web.JsLib.Core"
    ],
function (
        DelayedTask,
        DomWriter,
        Schema,
        ManipulatorVisitor,
        SchemaRegistry,
        UIManager,
        SimpleControlUI
) {
    var base = SimpleControlUI.prototype;

    var DataItemUI =
        Namespace("Indigox.Web.JsLib.UI.ControlUIs")
        .Class("DataItemUI")
        .Extend(base)
        .Constructor(
            function (control) {
                base.constructor.call(this, control);
            }
        )
        .Static({
            createUI: function (control) {
                return new DataItemUI(control);
            }
        })
        .Members({
            getSchema: function () {
                if (isNullOrUndefined(this.schema)) {
                    //TODO: [Temp solution] the reason maybe: dataitem removed from parent before buildHtml
                    if (!this.control.getParent()) {
                        return Schema.LI([], []);
                    }

                    var templateControl = this.control.getParent().getItemTemplate();
                    this.schema = SchemaRegistry.getInstance().getSchema(templateControl);
                    this.schema.setAttributeNode(Schema.EVENT("mouseover", "${onMouseOver}"));
                    this.schema.setAttributeNode(Schema.EVENT("mouseout", "${onMouseOut}"));
                    this.schema.setAttributeNode(Schema.EVENT("click", "${onClicked}"));
                    this.schema.setAttributeNode(Schema.CSS("selected", "${selected}"));
                }

                return this.schema;
            },

            createChildrenUI: function () {
                base.createChildrenUI.apply(this, arguments);
            },

            renderChildren: function () {
                var control = this.getControl();
                var writer = new DomWriter(control, this.getMapping());
                var children, child, childUI, i, length;

                children = control.getChildren();
                for (i = 0, length = children.length; i < length; i++) {
                    child = children[i];
                    childUI = UIManager.getInstance().getUI(child);
                    childUI.render();
                    //@overrided
                    childUI.replaceWith(writer, "getChild(\"" + child.name + "\")");
                }
            },

            setChildrenRendered: function () {
                base.setChildrenRendered.apply(this, arguments);
            },

            renderHtml: function () {
                return base.renderHtml.apply(this, arguments);
            },

            buildHtml: function () {
                return base.buildHtml.apply(this, arguments);
            },

            onClicked: function () {
                this.getControl().toggleSelected();
            }
            ,

            buildMapping: function () {
                var visitor = new ManipulatorVisitor(this.getControl(), this.getSchema(), this.getElement(), this.getMediator(), this);
                var mapping = visitor.visit();
                return mapping;
            }
        })
    .$();
});