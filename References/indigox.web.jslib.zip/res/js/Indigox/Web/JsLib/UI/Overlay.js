﻿define("Indigox.Web.JsLib.UI.Overlay",
    [
        "Indigox.Web.JsLib.DOM.Element",
        "Indigox.Web.JsLib.Core"
    ],
    function (
        Element
    ) {

    var El = Element.el;

    var instance = null;

    var Overlay =
        Namespace("Indigox.Web.JsLib.UI")
        .Class("Overlay")
        .Constructor(
            function () {
            }
        )
        .Static({
            getInstance: function () {
                if (!instance) {
                    instance = new Overlay();
                }
                return instance;
            }
        })
        .Members({
            overlay: function (element) {
                var body = window.document.body,
                    el = El(element),
                    bodyEl = El(body);

                //*// debug code
                //window.scrollTo(0, 0);
                //el.addClass("overlaying");
                //el.setStyle("position", "absolute");
                //el.setTop(0);
                //el.setLeft(0);
                //el.setWidth(window.innerWidth);
                //el.setHeight(window.innerHeight);
                //el.setStyle("overflow", "auto");
                //el.setStyle("backgroundColor", "#ffffff");
                //el.setStyle("zIndex", 10000)
                //bodyEl.setHeight(el.getHeight());
                //bodyEl.setStyle("overflow", "hidden");
                //return;
                // debug code*/

                bodyEl.addClass("overlaid");
                el.addClass("overlaying");

                // var old = document.querySelector("meta[name=viewport]");
                // document.getElementsByTagName('head')[0].removeChild(old);
                // var viewport = document.createElement('meta');
                // viewport.setAttribute('name', 'viewport');
                // viewport.setAttribute('content', 'width=595;initial-scale=1.0; minimum-scale=0.6; maximum-scale=1.6;user-scalable=yes;target-densityDpi=300;');
                // document.getElementsByTagName('head')[0].appendChild(viewport);

                // var viewport = document.querySelector("meta[name=viewport]");
                // viewport.setAttribute('content', 'width=595,target-densityDpi=300,initial-scale=1, minimum-scale=0.6, maximum-scale=1.6,user-scalable=yes;');

                // var metas = document.getElementsByTagName('meta');
                // var i;
                // for (i = 0; i < metas.length; i++) {
                //     if (metas[i].name == "viewport") {
                //         //metas[i].content = "width=595, minimum-scale=0.1, maximum-scale=1.0, user-scalable=0;";
                //         metas[i].setAttribute('content', 'width=595, minimum-scale=0.1, maximum-scale=1.0, user-scalable=0;');
                //     }
                // }
            },

            restore: function (element) {
                var body = window.document.body,
                    el = El(element),
                    bodyEl = El(body);

                //*// debug code
                //el.removeClass("overlaying");
                //el.setStyle("position", "relative");
                //el.setTop(0);
                //el.setLeft(0);
                //el.setWidth("auto");
                //el.setHeight("auto");
                //el.setStyle("overflow", "auto");
                //el.setStyle("backgroundColor", "#ffffff");
                //el.setStyle("zIndex", "auto");
                //bodyEl.setHeight("auto");
                //bodyEl.setStyle("overflow", "auto");
                //return;
                // debug code*/

                bodyEl.removeClass("overlaid");
                el.removeClass("overlaying");
                // var viewport = document.querySelector("meta[name=viewport]");
                // viewport.setAttribute('content', 'width=device-width,target-densityDpi=160, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no;');
            }
        })
    .$();
});