﻿define("Indigox.Web.JsLib.UI.Mediators.LyncContactMediator",
    [
        "Indigox.Web.JsLib.UI.ControlMediator",
        "Indigox.Web.JsLib.DOM.Element",
        "Indigox.Web.JsLib.Utils.LyncUtil",
        "Indigox.Web.JsLib.Core"
    ],
function (
        ControlMediator,
        Element,
        LyncUtil
) {
    var El = Element.el;

    var base = ControlMediator.prototype;

    var instance = null;

    var LyncContactMediator =
        Namespace("Indigox.Web.JsLib.UI.Mediators")
        .Class("LyncContactMediator")
        .Extend(base)
        .Constructor(
            function () {
            }
        )
        .Static({
            getInstance: function () {
                if (!instance) {
                    instance = new LyncContactMediator();
                }
                return instance;
            }
        })
        .Members({
            onMouseover: function (source, e, ui) {
                var contact = ui.getControl().getValue();
                var el = El(source);
                LyncUtil.showCard(contact.Email, el.getClientLeft() + el.getOuterWidth() + 2, el.getClientTop() + el.getOuterHeight() + 2);
            },
            onMouseout: function (source, e, ui) {
                LyncUtil.hideCard();
            }
        })
    .$();
});