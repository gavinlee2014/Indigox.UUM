﻿define("Indigox.Web.JsLib.UI.Visitors.ManipulatorVisitor",
    [
        "Indigox.Web.JsLib.UI.DomTraversal",
        "Indigox.Web.JsLib.UI.UIManager",
        "Indigox.Web.JsLib.Utils.ArrayUtil",
        "Indigox.Web.JsLib.Collection.Hashtable",
        "Indigox.Web.JsLib.UI.Schemas.ControlSchema",
        "Indigox.Web.JsLib.Manipulators.AttributeManipulator",
        "Indigox.Web.JsLib.Manipulators.ControlManipulator",
        "Indigox.Web.JsLib.Manipulators.CssManipulator",
        "Indigox.Web.JsLib.Manipulators.ForEachManipulator",
        "Indigox.Web.JsLib.Manipulators.StyleManipulator",
        "Indigox.Web.JsLib.Manipulators.TextNodeManipulator",
        "Indigox.Web.JsLib.DOM.Element",
        "Indigox.Web.JsLib.UI.SchemaVisitor",
        "Indigox.Web.JsLib.Core"
    ],
function (
        DomTraversal,
        UIManager,
        ArrayUtil,
        Hashtable,
        ControlSchema,
        AttributeManipulator,
        ControlManipulator,
        CssManipulator,
        ForEachManipulator,
        StyleManipulator,
        TextNodeManipulator,
        Element,
        SchemaVisitor
    ) {

    var El = Element.el;
    var base = SchemaVisitor.prototype;

    var ManipulatorVisitor =
        Namespace("Indigox.Web.JsLib.UI.Visitors")
        .Class("ManipulatorVisitor")
        .Extend(base)
        .Constructor(
            function (context, schema, element, mediator, ui) {
                base.constructor.call(this, context, schema);
                this.domTraversal = new DomTraversal(element);
                this.mapping = {};
                this.element = element;
                this.mediator = mediator;
                this.ui = ui;
            }
        )

        .Members({
            visit: function () {
                this.schema.accept(this, this.element);
                return this.mapping;
            },

            visitElement: function (schema, data) {
                var parent = data,
                    element = this.domTraversal.nextNode();

                var attributes = schema.getAttributes(),
                    childNodes = schema.getChildNodes();

                var i = null,
                    length = null;

                for (i = 0, length = attributes.length; i < length; i++) {
                    attributes[i].accept(this, element);
                }

                for (i = 0, length = childNodes.length; i < length; i++) {
                    //debug.log(element.tagName + ":" + element.className);
                    childNodes[i].accept(this, element);
                }
            },

            visitText: function (schema, data) {
                var parent = data,
                    textNode;

                if (parent.firstChild) { /*hasTextNode(parent)*/
                    if (El(parent.firstChild).isEmptyText()) {
                        textNode = parent.firstChild;
                    }
                    else {
                        textNode = this.domTraversal.nextNode();
                    }
                }
                else {
                    textNode = document.createTextNode("");
                    parent.appendChild(textNode);
                }

                if (El(textNode).isText()) {
                    var variable = schema.getVariable();

                    var manipulator = new TextNodeManipulator(textNode, "");
                    this.addManipulator(variable, manipulator);
                }
            },

            visitForEach: function (schema, data) {
                var parent = data,
                    endElement = this.domTraversal.getLastChild(parent);

                var childNodes = schema.getChildNodes();
                var element = [];

                var isBreak = false;

                var variable = schema.getVariable();

                if (endElement != null) {
                    while (!isBreak && this.domTraversal.currentNode()) {
                        isBreak = this.domTraversal.currentNode() === endElement;
                        if (UIManager.getInstance().isMarkAsControl(this.domTraversal.currentNode())) {
                            element.push(this.domTraversal.currentNode());
                        }
                        this.domTraversal.nextNode();
                    }
                }
                var manipulator = new ForEachManipulator(element, parent);
                this.addManipulator(variable, manipulator);
            },

            visitControl: function (schema, data) {
                var currentElement = this.domTraversal.currentNode();
                var endElement = this.domTraversal.getLastChild(data);
                var parentElement = data;
                var variable = schema.getVariable();
                var manipulator = null;

                if (endElement) {
                    if (currentElement) {
                        if (UIManager.getInstance().isMarkAsControl(currentElement)) {
                            manipulator = new ControlManipulator(currentElement, parentElement);
                        }
                        else {
                            throw new Error("the element can not match the schema for (" + variable + ")");
                        }
                    }
                    else {
                        manipulator = new ControlManipulator(null, parentElement, null);
                    }
                    this.domTraversal.nextNode();
                }
                else {
                    manipulator = new ControlManipulator(null, parentElement, null);
                }

                this.addManipulator(variable, manipulator);
            },

            visitEvent: function (schema, data) {
                //                var element = data;
                //                var event = schema.getName(),
                //                    handler = schema.getHandler().replace('${', '').replace('}', '');
                //                if (!isNullOrUndefined(this.mediator[handler])) {
                //                    if (isNullOrUndefined(window.eventcount)) {
                //                        window.eventcount = 0;
                //                    }
                //                    window.eventcount++;
                //                    //debug.time("BindEvent", true);
                //                    El(element).addListener(event, this.mediator[handler], this.mediator, [this.ui]);
                //                    //debug.timeEnd("BindEvent");
                //                }
            },

            visitAttribute: function (schema, data) {
                var element = data;

                var attribute = schema.getName(),
                    variable = schema.getVariable();
                if (El(element).hasAttribute(attribute)) {
                    var manipulator = new AttributeManipulator(element, attribute);
                    this.addManipulator(variable, manipulator);
                }
            },

            visitStyle: function (schema, data) {
                var element = data;

                var style = schema.getName(),
                    variable = schema.getVariable();

                if (El(element).getStyle(style) != null) {
                    var manipulator = new StyleManipulator(element, style);
                    this.addManipulator(variable, manipulator);
                }
            },

            visitCss: function (schema, data) {
                var element = data;

                var attribute = schema.getName(),
                    variable = schema.getVariable();

                if (attribute === "className") {
                    debug.warn("warning");
                }
                else {
                    if (El(element).hasAttribute('className')) {
                        var manipulator = new CssManipulator(element, attribute);
                        this.addManipulator(variable, manipulator);
                    }
                }
            },

            addManipulator: function (variable, manipulator) {
                if (variable in this.mapping) {
                    var manipulatorList = this.mapping[variable];
                    if (ArrayUtil.indexOf(manipulatorList, manipulator) == -1) {
                        manipulatorList.push(manipulator);
                    }
                }
                else {
                    this.mapping[variable] = [manipulator];
                }
            }
        })
    .$();
});