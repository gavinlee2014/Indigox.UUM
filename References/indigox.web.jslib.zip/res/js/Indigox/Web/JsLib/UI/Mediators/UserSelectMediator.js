﻿define("Indigox.Web.JsLib.UI.Mediators.UserSelectMediator",
    [
        "Indigox.Web.JsLib.UI.ControlMediator",
        "Indigox.Web.JsLib.Core"
    ],
function (
        ControlMediator
    ) {

    var base = ControlMediator.prototype;

    var instance = null;

    var UserSelectMediator =
        Namespace("Indigox.Web.JsLib.UI.Mediators")
        .Class("UserSelectMediator")
        .Extend(base)
        .Constructor(
            function () {
            }
        )
        .Static({
            getInstance: function () {
                if (!instance) {
                    instance = new UserSelectMediator();
                }
                return instance;
            }
        })
        .Members({
            onClick : function (source, e, ui) {
                var nodetype = source.nodeName.toLowerCase();
                if (nodetype == "ul" || nodetype == "input") {
                    ui.getControl().openDialog();
                    this.stopBubble(e);
                }
            }
        })
    .$();
} );