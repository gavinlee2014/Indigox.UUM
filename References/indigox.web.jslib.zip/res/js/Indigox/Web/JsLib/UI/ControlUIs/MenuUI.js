﻿define("Indigox.Web.JsLib.UI.ControlUIs.MenuUI",
    [
        "Indigox.Web.JsLib.UI.UIManager",
        "Indigox.Web.JsLib.Utils.StringUtil",
        "Indigox.Web.JsLib.Utils.DOMUtil",
        "Indigox.Web.JsLib.UI.Renderer",
        "Indigox.Web.JsLib.UI.RendererCache",
        "Indigox.Web.JsLib.UI.DomReader",
        "Indigox.Web.JsLib.UI.DomWriter",
        "Indigox.Web.JsLib.UI.ControlUIs.HierarchyControlUI",
        "Indigox.Web.JsLib.Core"
    ],
function (
        UIManager,
        StringUtil,
        DOMUtil,
        Renderer,
        RendererCache,
        DomReader,
        DomWriter,
        HierarchyControlUI
) {
    var base = HierarchyControlUI.prototype;

    var MenuUI =
        Namespace('Indigox.Web.JsLib.UI.ControlUIs')
        .Class('MenuUI')
        .Extend(base)
        .Constructor(
            function (control) {
                base.constructor.call(this, control);
            }
        )
        .Static({
            createUI: function (control) {
                return new MenuUI(control);
            }
        })
        .Members({
            parseElement: function () {
                var element = this.getElement();
                if (StringUtil.trim(DOMUtil.getAttribute(element, "innerHTML")) == "") {
                    var html = this.buildHtml();
                    var innerHtml = DOMUtil.getAttribute(DOMUtil.buildElement(html.join('')), "innerHTML");
                    DOMUtil.setAttribute(element, "innerHTML", innerHtml);
                }

                base.parseElement.apply(this, arguments);
            }
        })
    .$();
});