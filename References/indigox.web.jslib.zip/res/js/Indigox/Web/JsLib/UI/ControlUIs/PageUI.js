﻿define("Indigox.Web.JsLib.UI.ControlUIs.PageUI",
    [
        "Indigox.Web.JsLib.Utils.Callback",
        "Indigox.Web.JsLib.Utils.Deferred",
        "Indigox.Web.JsLib.Utils.DOMUtil",
        "Indigox.Web.JsLib.UI.RenderQueue",
        "Indigox.Web.JsLib.UI.Visitors.ManipulatorVisitor",
        "Indigox.Web.JsLib.Controls.Html.LoadMask",
        "Indigox.Web.JsLib.UI.ControlUIs.SimpleControlUI",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Callback,
        Deferred,
        DOMUtil,
        RenderQueue,
        ManipulatorVisitor,
        LoadMask,
        SimpleControlUI
) {
    var base = SimpleControlUI.prototype;

    var PageUI =
        Namespace("Indigox.Web.JsLib.UI.ControlUIs")
        .Class("PageUI")
        .Extend(base)
        .Constructor(
            function (control) {
                base.constructor.call(this, control);
            }
        )
        .Static({
            createUI: function (control) {
                return new PageUI(control);
            }
        })
        .Members({
            //            parseElement: function () {
            //                if (this.needParseChildren()) {
            //                    this.parseChildren();
            //                }
            //            },

            onLoading: function (source) {
                base.onLoading.apply(this, arguments);
                debug.time("Page Load");
                RenderQueue.getInstance().begin();
                this.getControl().mask();
            },

            onLoaded: function (source) {
                base.onLoaded.apply(this, arguments);
                RenderQueue.getInstance().end();
                debug.timeEnd("Page Load");
                this.getControl().unmask();
                this.getControl().getLoadMask().setMode(LoadMask.TRANSPARENT);
                //解决手机上不会自动回归顶部的问题
                window.setTimeout('scroll(0,0);', 100);
            },

            onUnload: function (source) {
                this.dispose();
            },

            buildMapping: function () {
                var visitor = new ManipulatorVisitor(this.getControl(), this.getSchema(), this.getElement(), this.getMediator(), this);
                var mapping = visitor.visit();
                return mapping;
            }
        })
    .$();
});