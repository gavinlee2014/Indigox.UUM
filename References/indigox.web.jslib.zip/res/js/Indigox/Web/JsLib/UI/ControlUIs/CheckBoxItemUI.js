﻿define("Indigox.Web.JsLib.UI.ControlUIs.CheckBoxItemUI",
    [
        "Indigox.Web.JsLib.UI.UIManager",
        "Indigox.Web.JsLib.UI.DomWriter",
        "Indigox.Web.JsLib.UI.ControlUIs.SimpleControlUI",
        "Indigox.Web.JsLib.Core"
    ],
function (
        UIManager,
        DomWriter,
        SimpleControlUI
) {
    var base = SimpleControlUI.prototype;

    var CheckBoxItemUI =
        Namespace('Indigox.Web.JsLib.UI.ControlUIs')
        .Class('CheckBoxItemUI')
        .Extend(base)
        .Constructor(
            function (control) {
                base.constructor.call(this, control);
            }
        )
        .Static({
            createUI: function (control) {
                return new CheckBoxItemUI(control);
            }
        })
        .Members({
            createChildrenUI: function () {
                var control = this.getControl();
                var child, childUI, i, length;

                child = control.getCheckBox();
                if (child) {
                    childUI = UIManager.getInstance().createUI(child);
                    if (child.isInited()) {
                        childUI.init();
                    }
                }
            },

            renderChildren: function () {
                var control = this.getControl();
                var writer = new DomWriter(control, this.getMapping());
                var child, childUI, i, length;

                child = control.getCheckBox();
                if (child) {
                    childUI = UIManager.getInstance().getUI(child);
                    childUI.render();
                    childUI.replaceWith(writer, 'checkBox');
                }
            },

            setChildrenRendered: function () {
                var control = this.getControl();
                var child, childUI, i, length;

                child = control.getCheckBox();
                if (child) {
                    childUI = UIManager.getInstance().getUI(child);
                    childUI.setRendered();
                }
            },


            disposeChildren: function () {
                var control = this.getControl();
                var child, childUI, i, length;

                child = control.getCheckBox();
                if (child) {
                    childUI = UIManager.getInstance().getUI(child);
                    childUI.dispose();
                }
            }
        })
    .$();
});