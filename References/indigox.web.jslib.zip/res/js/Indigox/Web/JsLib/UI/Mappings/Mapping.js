﻿define("Indigox.Web.JsLib.UI.Mappings.Mapping",
    [
        "Indigox.Web.JsLib.DOM.Element",
        "jquery",
        "Indigox.Web.JsLib.Core"
    ],
    function (
        Element,
        jQuery
    ) {
        var El = Element.el;

        var Mapping =
            Namespace("Indigox.Web.JsLib.UI.Mappings")
            .Class("Mapping")
            .Constructor(
                function (element, attribute, tag) {
                    this.element = El(element);
                    this.attribute = attribute;
                    this.tag = tag;
                }
            )
            .Members({
                getElement: function () {
                    //if (!window.getElementTime) {
                    //    window.getElementTime = 0;
                    //}
                    //if (!window.getElementCount) {
                    //    window.getElementCount = 0;
                    //}

                    //var start = new Date();
                    var element = this.element;
                    if (this.tag != '') {
                        element = El(jQuery(this.element.element).find(this.tag)[0]);
                        window.getElementCount++;
                    }
                    //var end = new Date();

                    //window.getElementTime += (end - start);
                    return element;
                },
                write: function (value) {
                },
                read: function (element) {
                }
            })
        .$();
    });