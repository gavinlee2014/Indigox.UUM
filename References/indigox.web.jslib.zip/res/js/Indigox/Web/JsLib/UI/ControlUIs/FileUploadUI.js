﻿define("Indigox.Web.JsLib.UI.ControlUIs.FileUploadUI",
    [
        "Indigox.Web.JsLib.Serialization.JsonSerializer",
        "Indigox.Web.JsLib.Connection.Ajax",
        "Indigox.Web.JsLib.UI.UIManager",
        "Indigox.Web.JsLib.UI.DomWriter",
        "Indigox.Web.JsLib.UI.ControlUIs.SimpleControlUI",
        "jquery",
        "Indigox.Web.JsLib.Core"
    ],
    function (
        JsonSerializer,
        Ajax,
        UIManager,
        DomWriter,
        SimpleControlUI,
        jQuery
    ) {
        //#region const
        var emptyState = { progress: 0, fileName: "", uploadedFiles: [], errorFiles: [] },
        frameSurfix = "__uploadFrame__",
        idSurfix = "_identity";
        //#endregion

        var idGenerator = (function () {
            var seed = 0;
            return {
                next: function () {
                    return seed++;
                }
            };
        } ());

        var serializer = new JsonSerializer();

        var base = SimpleControlUI.prototype;

        var FileUploadUI =
        Namespace("Indigox.Web.JsLib.UI.ControlUIs")
        .Class("FileUploadUI")
        .Extend(base)
        .Constructor(
            function (control) {
                base.constructor.call(this, control);
                this.frameName = frameSurfix + idGenerator.next();
            }
        )
        .Static({
            createUI: function (control) {
                return new FileUploadUI(control);
            },

            settings: {
                queryUrl: "/editor/attachments/UploadProgress.ashx",
                uploadUrl: "/editor/attachments/upload.htm"
            }
        })
        .Members({
            createChildrenUI: function () {
                var control = this.getControl();
                var child, childUI, i, length;

                child = control.getProgressBar();
                if (child) {
                    childUI = UIManager.getInstance().createUI(child);
                    if (child.isInited()) {
                        childUI.init();
                    }
                }
            },

            renderChildren: function () {
                var control = this.getControl();
                var writer = new DomWriter(control, this.getMapping());
                var child, childUI, i, length;

                child = control.getProgressBar();
                if (child) {
                    childUI = UIManager.getInstance().getUI(child);
                    childUI.render();
                    childUI.replaceWith(writer, "progressBar");
                }
            },

            setChildrenRendered: function () {
                var control = this.getControl();
                var child, childUI, i, length;

                child = control.getProgressBar();
                if (child) {
                    childUI = UIManager.getInstance().getUI(child);
                    childUI.setRendered();
                }
            },

            disposeChildren: function () {
                var control = this.getControl();
                var child, childUI, i, length;

                child = control.getProgressBar();
                if (child) {
                    childUI = UIManager.getInstance().getUI(child);
                    childUI.dispose();
                }
            },

            // #region properties
            interval: null,
            hidUploadFrameAdded: false,
            frameName: null,
            // #endregion

            // #region events
            onUploadBegin: function (source, e) {
                this.submitForm(source);
                this.createInterval(source, function () {
                    source.fireListener("StateChanged");
                });
                //debug.log("[FileUploadUI] upload begin...");
            },

            onStateChanged: function (source, e) {
                this.queryState(source); // async query state
            },

            onUploadCompleted: function (source, e) {
                this.cancelInterval(source);
                //debug.log("[FileUploadUI] upload completed.");
            },

            onUploadErrorCompleted: function (source, e) {
                this.cancelInterval(source);
                //debug.log("[FileUploadUI] upload occurs some error.");
            },

            onCanceled: function (source, e) {
                this.cancelInterval(source);
                this.stopFrameRequest(source);
                //debug.log("[FileUploadUI] upload canceled.");
            },
            // #endregion

            // #region methods
            createInterval: function (control, fn) {
                if (this.hasInterval(control)) {
                    throw ("the interval already created, please review your code.");
                }
                this.interval = window.setInterval(fn, 1000);
                //debug.log("[FileUploadUI] interval: " + this.interval);
            },

            cancelInterval: function (control) {
                if (this.hasInterval(control)) {
                    this.interval = window.clearInterval(this.interval);
                }
                //debug.log("[FileUploadUI] interval: " + this.interval);
            },

            hasInterval: function (control) {
                return (false || this.interval);
            },

            submitForm: function (control) {
                var element = this.getElement();
                var form = element.getElementsByTagName("form")[0];
                var frameName = this.frameName;
                var hidStr = " style=\"width: 0px; height: 0px; visibility: hidden;\"";
                if (!this.hidUploadFrameAdded) {
                    //debug.log(frameName);
                    jQuery(document.body).append("<iframe id=\"" + frameName + "\" name=\"" + frameName + "\"" + hidStr + "></iframe>");
                    this.hidUploadFrameAdded = true;
                }
                form.target = frameName;
                form.action = FileUploadUI.settings.uploadUrl;
                form.method = "POST";
                form.enctype = "multipart/form-data";
                // IE6-8 must set encoding attribute while dynamic set enctype attribute,
                // see http://www.bennadel.com/blog/1273-Setting-Form-EncType-Dynamically-To-Multipart-Form-Data-In-IE-Internet-Explorer-.htm
                form.encoding = "multipart/form-data";

                var temp = jQuery("<input type=\"hidden\" name=\"uploadProgressIdentity\" value=\"::DJ_UPLOAD_ID::" + control.uniqueIdentifier + "\" />");
                jQuery(form).prepend(temp);
                form.submit();
                temp.remove();
            },

            queryState: function (control) {
                var connection = new Ajax({
                    url: FileUploadUI.settings.queryUrl,
                    data: {
                        "DJUploadStatus": "::DJ_UPLOAD_ID::" + control.uniqueIdentifier,
                        "rnd": Math.random().toString().replace(".", "")
                    }
                });

                connection.send()
                    .done(function (txtdata) {
                        var data = serializer.deserialize(txtdata);
                        //var data = txtdata;
                        if (data.empty) {
                            control.setProgress(0);
                        }
                        else {
                            control.setProgress(data.progress);
                            if (data.uploadedFiles && data.uploadedFiles.length === 1) {
                                var file = data.uploadedFiles[0];
                                //if (file) {
                                control.setValue(file);
                                control.complete();
                                //}
                            }
                            else if (data.errorFiles && data.errorFiles.length === 1) {
                                control.error("upload faild.");
                            }
                        }
                        //debug.log("[FileUploadUI] state changed... " + control.progress);
                        this.isQuerying = false;
                    })
                    .fail(function (error) {
                        control.error("web error: " + error);
                        this.isQuerying = false;
                    });
            },

            stopFrameRequest: function (control) {
                var frameName = this.frameName;
                var frame = window.frames[frameName];
                //debug.log(frameName);
                //debug.log(typeof frame === "undefined");

                /* abort iframe, method 1 */
                frame.location.replace("about:blank");         // frame.stop() not support in IE

                /* abort iframe, method 2 */
                //if (navigator.appName == 'Microsoft Internet Explorer') {
                //    frame.document.execCommand('Stop');
                //} else {
                //    frame.stop();
                //}

                /* abort iframe, method 3 */
                //frame.setAttribute('src', 'javascript:false;');
            }
            // #endregion
        })
    .$();
    });