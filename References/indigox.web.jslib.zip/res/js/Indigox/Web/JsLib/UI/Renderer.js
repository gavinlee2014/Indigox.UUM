﻿define("Indigox.Web.JsLib.UI.Renderer",
    [
        "Indigox.Web.JsLib.UI.UIManager",
        "Indigox.Web.JsLib.Expression.ExpressionEvaluator",
        "Indigox.Web.JsLib.Mappings.MappingFactory",
        "Indigox.Web.JsLib.UI.SchemaRegistry",
        "Indigox.Web.JsLib.Expression.Expression",
        "Indigox.Web.JsLib.Collection.Hashtable",
        "Indigox.Web.JsLib.Core"
    ],
function (
        UIManager,
        ExpressionEvaluator,
        MappingFactory,
        SchemaRegistry,
        Expression,
        Hashtable
    ) {
    window.count = 0;

    var Renderer =
        Namespace("Indigox.Web.JsLib.UI")
        .Class("Renderer")
        .Constructor(
            function () {
                this.staticClasses = {};
                this.staticStyles = {};
                this.staticAttributes = {};
                this.classMapping = {};
                this.styleMapping = {};
                this.attributeMapping = {};
                this.children = [];
                this.endTag = true;
                this.tagName = "";
            }
        )
        .Members({
            setTagName: function (value) {
                if (!isNullOrUndefined(value)) {
                    this.tagName = value;
                }
            },

            setEndTag: function (value) {
                if (!isNullOrUndefined(value)) {
                    this.endTag = value;
                }
            },

            addCss: function (css, variable) {
                this.classMapping[css] = variable;
            },

            addStaticCss: function (css, value) {
                this.staticClasses[css] = value;
            },

            addStyle: function (style, variable) {
                this.styleMapping[style] = variable;
            },

            addStaticStyle: function (style, value) {
                this.staticStyles[style] = value;
            },

            addAttribute: function (attribute, variable) {
                this.attributeMapping[attribute] = variable;
            },

            addStaticAttribute: function (attribute, value) {
                this.staticAttributes[attribute] = value;
            },

            addChild: function (child) {
                this.children.push(child);
            },

            renderHtml: function (control, html) {
                html.push('<' + this.tagName + ' ');

                this.renderAttribute(control, html);
                this.renderCss(control, html);
                this.renderStyle(control, html);

                if (this.endTag === false) {
                    html.push('/>');
                }
                else {
                    html.push('>');
                    this.renderChildren(control, html);
                    html.push('</' + this.tagName + '>');
                }
            },

            renderCss: function (control, html) {
                var classes = [];

                for (var attribute in this.staticClasses) {
                    window.count++;
                    this.putClass(classes, attribute, this.staticClasses[attribute]);
                }

                for (var attribute in this.classMapping) {
                    var value = this.getMappedValue(this.classMapping[attribute], control);
                    this.putClass(classes, attribute, value);
                }

                if (classes.length) {
                    html.push('class="' + classes.join('') + '" ');
                }
            },

            putClass: function (classes, attribute, value) {
                if (value) {
                    if (isBoolean(value)) {
                        classes.push(attribute + ' ');
                    }
                    else {
                        classes.push(attribute + '-' + value + ' ');
                    }
                }
            },

            renderStyle: function (control, html) {
                var styles = [];

                for (var attribute in this.staticStyles) {
                    window.count++;
                    this.putStyle(styles, attribute, this.staticStyles[attribute]);
                }

                for (var attribute in this.styleMapping) {
                    var value = this.getMappedValue(this.styleMapping[attribute], control);
                    this.putStyle(styles, attribute, value);
                }

                if (styles.length) {
                    html.push('style="' + styles.join('') + '" ');
                }
            },

            putStyle: function (styles, attribute, value) {
                if (value) {
                    value = value.toString();
                    styles.push(attribute + ':' + value.replace(/[\"]/g, '\'') + ';');
                }
            },

            renderAttribute: function (control, html) {
                for (var attribute in this.staticAttributes) {
                    window.count++;
                    this.putAttribute(html, attribute, this.staticAttributes[attribute]);
                }

                for (var attribute in this.attributeMapping) {
                    var value = this.getMappedValue(this.attributeMapping[attribute], control);
                    this.putAttribute(html, attribute, value);
                }
            },

            putAttribute: function (html, attribute, value) {
                if (!isNullOrUndefined(value)) {
                    if (isBoolean(value)) {
                        if (value === true) {
                            html.push(attribute + '="' + attribute + '"');
                        }
                    }
                    else {
                        html.push(attribute + '="' + value + '" ');
                    }
                }
            },

            renderChildren: function (control, html) {
                var children = this.children;
                for (var i = 0, length = children.length; i < length; i++) {
                    var child = children[i];

                    if (child instanceof Renderer) {
                        child.renderHtml(control, html);
                    }
                    else {
                        this.renderText(control, child, html);
                    }
                }
            },

            renderText: function (control, variable, html) {
                var text = this.getMappedValue(variable, control);
                html.push(text);
            },

            getMappedValue: function (variable, context) {
                var field = variable.replace(/\$\{([^\}]+)\}/, '$1');
                var expression = new ExpressionEvaluator(variable);
                var original = expression.evaluate(context);
                var mapping = MappingFactory.getInstance().getMapping(field);
                var value = mapping.map(original);
                return value;
            }
        })
    .$();
});