﻿/*globals UUV_UcSelecting_ShowModalDialogSPRoot */
define("Indigox.Web.JsLib.UI.ControlUIs.UUVUserSelectUI",
    [
        "Indigox.Web.JsLib.UI.UIManager",
        "Indigox.Web.JsLib.UI.ChildAddedChange",
        "Indigox.Web.JsLib.UI.ChildRemovedChange",
        "Indigox.Web.JsLib.UI.ControlUIs.SimpleControlUI",
        "/editor/UUV/js/common.js",
        "/editor/UUV/js/UUVSelectedCtrol.js",
        "Indigox.Web.JsLib.Core"
    ],
    function (
        UIManager,
        ChildAddedChange,
        ChildRemovedChange,
        SimpleControlUI
    ) {
        var base = SimpleControlUI.prototype;

        var UUVUserSelectUI =
            Namespace('Indigox.Web.JsLib.UI.ControlUIs')
            .Class('UUVUserSelectUI')
            .Extend(base)
            .Constructor(
                function (control) {
                    base.constructor.call(this, control);
                }
            )
            .Static({
                createUI: function (control) {
                    return new UUVUserSelectUI(control);
                }
            })
            .Members({
                onOpenDialog: function (source, e) {
                    var control = this.control;

                    var selectedUsers = openUuvSelcetDialog(control.value, control.mode, control.multi);
                    if (selectedUsers != null) {
                        control.setValue(selectedUsers);
                    }
                }
            })
        .$();

        function openUuvSelcetDialog(users, mode, multi) {
            /// <summary>open uuv user select dialog, return selected users array.</summary>
            /// <param name="users" type="user array">init selected users</param>
            /// <param name="multi" type="bool">whether allow multi selection in dialog.</param>
            /// <returns type="user array" />
            //debug.log("begin select user ...");
            var values = [];
            var texts = [];
            if (users) {
                for (var i = 0, length = users.length; i < length; i++) {
                    values.push(users[i].UserID);
                    texts.push(users[i].UserName);
                }
            }
            var tabitems = mode;
            var rootorgid = "OR1000000000";
            var width = "600";
            var height = "600";
            var url = "/editor/UUV/SelectUnify.aspx";

            var rObj = UUV_UcSelecting_ShowModalDialogSPRoot(url, rootorgid, values.join(','), texts.join(','), multi, tabitems, width, height);

            if (isNullOrUndefined(rObj) || isNullOrUndefined(rObj.valueValue)) { // return object is null
                return null;
            }
            if ('' + rObj.valueValue === '') { // return empty useres
                return [];
            }
            var selectedValues = rObj.valueValue.split(',');
            var selectedNames = rObj.textValue.split(',');
            var selectedUsers = [];
            for (var i = 0, length = selectedValues.length; i < length; i++) {
                selectedUsers.push({ UserID: selectedValues[i], UserName: selectedNames[i] });
            }
            return selectedUsers;
        }
    });