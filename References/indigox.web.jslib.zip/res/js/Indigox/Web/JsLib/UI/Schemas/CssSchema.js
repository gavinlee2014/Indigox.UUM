﻿define("Indigox.Web.JsLib.UI.Schemas.CssSchema",
    [
        "Indigox.Web.JsLib.UI.NodeSchema",
        "Indigox.Web.JsLib.Core"
    ],
    function (
        NodeSchema
    ) {
        var base = NodeSchema.prototype;

        var CssSchema =
            Namespace('Indigox.Web.JsLib.UI.Schemas')
            .Class('CssSchema')
            .Extend(base)
            .Constructor(
                function (name, variable) {
                    this.name = name;
                    this.variable = variable;
                }
            )
            .Members({
                getName: function () {
                    return this.name;
                },
                getVariable: function () {
                    return this.variable;
                },
                accept: function (visitor, data) {
                    return visitor.visitCss(this, data);
                }
            })
        .$();
    });