﻿define("Indigox.Web.JsLib.UI.ControlUIs.WidgetUI",
    [
        "Indigox.Web.JsLib.Utils.DOMUtil",
        "Indigox.Web.JsLib.Utils.ErrorHandler",
        "Indigox.Web.JsLib.UI.Visitors.ManipulatorVisitor",
        "Indigox.Web.JsLib.UI.UIManager",
        "Indigox.Web.JsLib.UI.ControlUIs.WidgetResourceLoader",
        "Indigox.Web.JsLib.UI.ControlUI",
        "Indigox.Web.JsLib.Core"
    ],
function (
        DOMUtil,
        ErrorHandler,
        ManipulatorVisitor,
        UIManager,
        WidgetResourceLoader,
        ControlUI
) {
    var base = ControlUI.prototype;

    var WidgetUI =
        Namespace("Indigox.Web.JsLib.UI.ControlUIs")
        .Class("WidgetUI")
        .Extend(base)
        .Constructor(
            function (control) {
                base.constructor.call(this, control);
            }
        )
        .Static({
            createUI: function (control) {
                return new WidgetUI(control);
            }
        })
        .Members({
            init: function () {
                this.fillHtml();
                this.loadResources();
                base.init.apply(this, arguments);
            },

            fillHtml: function () {
                var rootHtml = this.buildHtml();
                this.setElement(DOMUtil.buildElement(rootHtml.join("")));

                var innerHtml = this.getControl().getPresentation();
                if (!innerHtml) {
                    return;
                }
                DOMUtil.createElement(innerHtml, this.getElement());
            },

            loadResources: function () {
                var widget = this.getControl();
                var loader = new WidgetResourceLoader(widget);
                loader.loadResources();
            },

            buildMapping: function () {
                var visitor = new ManipulatorVisitor(this.getControl(), this.getSchema(), this.getElement(), this.getMediator(), this);
                var mapping = visitor.visit();
                return mapping;
            }
        })
    .$();
});