﻿define("Indigox.Web.JsLib.UI.Mediators.CheckBoxMediator",
    [
        "Indigox.Web.JsLib.UI.ControlMediator",
        "Indigox.Web.JsLib.Core"
    ],
function (
        ControlMediator
    ) {

    var base = ControlMediator.prototype;

    var instance = null;

    var CheckBoxMediator =
        Namespace("Indigox.Web.JsLib.UI.Mediators")
        .Class("CheckBoxMediator")
        .Extend(base)
        .Constructor(
            function () {
            }
        )
        .Static({
            getInstance: function () {
                if (!instance) {
                    instance = new CheckBoxMediator();
                }
                return instance;
            }
        })
        .Members({
            onClick: function (source, e, ui) {
                var nodetype = source.nodeName.toLowerCase();
                if (nodetype == "input") {
                    ui.getControl().click();
                    this.stopBubble(e);
                }
                
            }
        })
    .$();
} );