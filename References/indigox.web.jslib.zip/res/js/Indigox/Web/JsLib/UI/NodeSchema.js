﻿define("Indigox.Web.JsLib.UI.NodeSchema",
    [
        "Indigox.Web.JsLib.Collection.List",
        "Indigox.Web.JsLib.Core"
    ],
function (
        List
) {
    var NodeSchema =
        Namespace("Indigox.Web.JsLib.UI")
        .Class("NodeSchema")
        .Constructor(
            function (childNodes) {
                this.parentNode = null;
                this.childNodes = new List();

                if (childNodes) {
                    var length = childNodes.length;
                    for (var i = 0; i < length; i++) {
                        this.addChild(childNodes[i]);
                    }
                }
            }
        )
        .Members({
            getParentNode: function () {
                return this.parentNode;
            },

            addChild: function (node) {
                if (isNullOrUndefined(node)) {
                    throw new Error("argument 'node' is null.");
                }
                var childNodes = this.childNodes;
                if (!childNodes.contains(node)) {
                    childNodes.add(node);
                }
                node.parentNode = this;
            },

            removeChild: function (node) {
                if (isNullOrUndefined(node)) {
                    throw new Error("argument 'node' is null.");
                }
                if (node.parentNode !== this) {
                    throw new Error("childNodes does not contains node");
                }
                // set parentNode
                node.parentNode = null;
                var childNodes = this.childNodes;
                if (childNodes.contains(node)) {
                    childNodes.remove(node);
                }
            },

            getChildNodes: function () {
                return this.childNodes.toArray();
            },

            hasChildNodes: function () {
                return this.childNodes.size() > 0;
            },

            accept: function (visitor, data) {
            }
        })
    .$();
});