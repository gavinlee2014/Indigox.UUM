﻿define("Indigox.Web.JsLib.UI.ControlUIs.UUMUserSelectUI",
    [
        "Indigox.Web.JsLib.UI.UIManager",
        "Indigox.Web.JsLib.UI.ChildAddedChange",
        "Indigox.Web.JsLib.UI.ChildRemovedChange",
        "Indigox.Web.JsLib.UI.ControlUIs.SimpleControlUI",
        "Indigox.Web.JsLib.Core"
    ],
function (
        UIManager,
        ChildAddedChange,
        ChildRemovedChange,
        SimpleControlUI
) {
    var base = SimpleControlUI.prototype;

    var UUMUserSelectUI =
        Namespace('Indigox.Web.JsLib.UI.ControlUIs')
        .Class('UUMUserSelectUI')
        .Extend(base)
        .Constructor(
            function (control) {
                base.constructor.call(this, control);
            }
        )
        .Static({
            createUI: function (control) {
                return new UUMUserSelectUI(control);
            }
        })
        .Members({
            onOpenDialog: function (source, e) {
                var control = this.control;

                var selectedUsers = openDialog(control.value, control.mode, control.multi);
                if (selectedUsers != null) {
                    control.setValue(selectedUsers);
                }
            }
        })
    .$();

    function openDialog(users, mode, multi) {
        /// <summary>open uuv user select dialog, return selected users array.</summary>
        /// <param name="users" type="user array">init selected users</param>
        /// <param name="multi" type="bool">whether allow multi selection in dialog.</param>
        /// <returns type="user array" />

        var url = "/UUM/Dialog.htm#/Selection/UserSelect.htm";

        var dialogOption = 'dialogWidth:800px;dialogHeight:560px';

        var dialogArgs = {
            value: users,
            mode: mode,
            multi: multi
        };

        return window.showModalDialog(url, dialogArgs, dialogOption);
    }
});