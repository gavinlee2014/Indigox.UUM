﻿define("Indigox.Web.JsLib.UI.MappingCache",
    [
        "Indigox.Web.JsLib.Collection.Hashtable",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Hashtable
) {
    var instance = null;

    var MappingCache =
        Namespace("Indigox.Web.JsLib.UI")
        .Class("MappingCache")
        .Constructor(
            function () {
                this.cache = new Hashtable();
            }
        )
        .Static({
            getInstance: function () {
                if (!instance) {
                    instance = new MappingCache();
                }
                return instance;
            }
        })
        .Members({
            get: function (schema) {
                return this.cache.get(schema);
            },

            contains: function (schema) {
                return this.cache.containsKey(schema);
            },

            put: function (schema, renderer) {
                this.cache.put(schema, renderer);
            }
        })
    .$();
});