﻿define("Indigox.Web.JsLib.UI.Mediators.AutoCompleteBoxMediator",
    [
        "Indigox.Web.JsLib.UI.ControlMediator",
        "Indigox.Web.JsLib.DOM.Element",
        "Indigox.Web.JsLib.Core"
    ],
function (
        ControlMediator,
        Element
    ) {

    var base = ControlMediator.prototype;
    var instance = null;

    var AutoCompleteBoxMediator =
        Namespace("Indigox.Web.JsLib.UI.Mediators")
        .Class("AutoCompleteBoxMediator")
        .Extend(base)
        .Constructor(
            function () {
            }
        )
        .Static({
            getInstance: function () {
                if (!instance) {
                    instance = new AutoCompleteBoxMediator();
                }
                return instance;
            }
        })
        .Members({
            onBlur: function (source, e, ui) {
                debug.log("onBlur");
                //ui.getControl().clearItems();
            },
            onKeyUp: function (source, e, ui) {

                var nodeType = source.nodeName.toLowerCase();
                if (nodeType == "span") {
                    switch (e.keyCode) {
                        case 38:
                            ui.activeItemIndex(-1);
                            break;
                        case 40:
                            ui.activeItemIndex(1);
                            break;
                        case 9:
                            ui.activeItemIndex(1);
                            break;
                        case 32:
                            if (ui.getControl().getItems().length > 0) {
                                ui.selectItem();
                            } else {
                                var text = Element.el(source).getText();
                                ui.getControl().search(text, autoSelected);
                                this.stopBubble(e);
                            }
                        case 13:
                            ui.selectItem();
                            break;
                        default:
                            var text = Element.el(source).getText();
                            var autoSelected = false;
                            if (e.keyCode == 186) {
                                text = text.substring(0, text.length - 1);
                                autoSelected = true;
                            }
                            ui.getControl().search(text, autoSelected);
                            this.stopBubble(e);
                    }
                }

            },

            onKeyDown: function (source, e, ui) {
                //if (e.keyCode == 186) {
                //    this.stopBubble(e);
                //    ui.getControl().search(Element.el(source).getText(), true);
                //}

                switch (e.keyCode) {
                    case 32:
                    case 13:
                        var nodeType = source.nodeName.toLowerCase();
                        if (nodeType == "span") {
                            e.preventDefault();
                        }
                        this.stopBubble(e);
                        break;
                    case 9:
                        var nodeType = source.nodeName.toLowerCase();
                        var items = ui.getControl().getItems();
                        if (nodeType == "span" && items.length > 0) {
                            e.preventDefault();
                        }
                        this.stopBubble(e);
                        break;
                    case 8:
                        var nodeType = source.nodeName.toLowerCase();
                        var items = ui.getControl().getCompleteItems();
                        var text = Element.el(source).getText();
                        if (nodeType == "span" && items.length > 0 && (text == "" || text == null || text == undefined)) {
                            ui.removePreviousCompeleteItem();
                            e.preventDefault();
                        }
                        this.stopBubble(e);
                        break;
                }

            },

            onClicked: function (source, e, ui) {
                jQuery(ui.getElement()).find("span")[0].focus();
            }
        })
    .$();
});