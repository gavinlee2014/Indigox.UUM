﻿define("Indigox.Web.JsLib.UI.Mediators.MenuItemMediator",
    [
        "Indigox.Web.JsLib.UI.ControlMediator",
        "Indigox.Web.JsLib.UI.Overlay",
        "Indigox.Web.JsLib.UI.UIManager",
        "Indigox.Web.JsLib.Core"
    ],
function (
        ControlMediator,
        Overlay,
        UIManager
) {
    var base = ControlMediator.prototype;

    var instance = null;

    var MenuItemMediator =
        Namespace("Indigox.Web.JsLib.UI.Mediators")
        .Class("MenuItemMediator")
        .Extend(base)
        .Constructor(
            function () {
            }
        )
        .Static({
            getInstance: function () {
                if (!instance) {
                    instance = new MenuItemMediator();
                }
                return instance;
            }
        })
        .Members({
            onMouseover: function (source, e, ui) {
                if (ui.getControl().getRoot().getActionMode() == 1) {
                    return;
                }
                ui.getControl().showChildMenu();
                //this.stopBubble(e);

            },

            onMouseout: function (source, e, ui) {
                if (ui.getControl().getRoot().getActionMode() == 1) {
                    return;
                }
                ui.getControl().hideChildMenu();
                //this.stopBubble(e);
            },

            onClick: function (source, e, ui) {
                var control = ui.getControl();
                if (!control.hasChildNodes()) {
                    control.setSelected(true);
                }

                if (ui.getControl().getRoot().getActionMode() == 1) {
                    ui.getControl().toggleChildMenu();
                }
                this.stopBubble(e);
            }
        })
    .$();
});