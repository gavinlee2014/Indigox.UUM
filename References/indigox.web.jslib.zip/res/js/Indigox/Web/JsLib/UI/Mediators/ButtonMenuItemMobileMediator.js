﻿define("Indigox.Web.JsLib.UI.Mediators.ButtonMenuItemMobileMediator",
    [
        "Indigox.Web.JsLib.UI.Mediators.MenuItemMobileMediator",
        "Indigox.Web.JsLib.UI.Overlay",
        "Indigox.Web.JsLib.UI.UIManager",
        "Indigox.Web.JsLib.DOM.Element",
        "Indigox.Web.JsLib.Core"
    ],
function (
        MenuItemMobileMediator,
        Overlay,
        UIManager,
        Element
) {
    var El = Element.el;

    var base = MenuItemMobileMediator.prototype;

    var instance = null;

    var ButtonMenuItemMobileMediator =
        Namespace("Indigox.Web.JsLib.UI.Mediators")
        .Class("ButtonMenuItemMobileMediator")
        .Extend(base)
        .Constructor(
            function () {
            }
        )
        .Static({
            getInstance: function () {
                if (!instance) {
                    instance = new ButtonMenuItemMobileMediator();
                }
                return instance;
            }
        })
        .Members({
            /* mobile */
            onClick: function (source, e, ui) {
                var control = ui.getControl();
                base.onClick.apply(this, arguments);
                control.click();
                this.stopBubble(e);
            }

//            onTouchStart: function (source, e, ui) {
//                El(source).addClass("pressed");
//                this.stopBubble(e);
//            },

//            onTouchEnd: function (source, e, ui) {
//                El(source).removeClass("pressed");
//                this.stopBubble(e);
//            }
        })
    .$();
});