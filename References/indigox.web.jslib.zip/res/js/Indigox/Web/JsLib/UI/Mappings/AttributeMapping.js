﻿define("Indigox.Web.JsLib.UI.Mappings.AttributeMapping",
    [
        "Indigox.Web.JsLib.UI.Mappings.Mapping",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Mapping
    ) {
    var base = Mapping.prototype;

    var AttributeMapping =
        Namespace("Indigox.Web.JsLib.UI.Mappings")
        .Class("AttributeMapping")
        .Extend(base)
        .Constructor(
            function (element, attribute, tag) {
                base.constructor.apply(this, arguments);
            }
        )
        .Members({
            write: function (value) {
                var element = this.getElement();
                if (element.hasAttribute(this.attribute)) {
                    element.setAttribute(this.attribute, value);
                }
            },
            read: function () {
                var element = this.getElement();
                return element.getAttribute(this.attribute);
            }
        })
    .$();
});