﻿define("Indigox.Web.JsLib.UI.ControlUIs.RadioBoxItemUI",
    [
        "Indigox.Web.JsLib.UI.ControlUIs.SimpleControlUI",
        "Indigox.Web.JsLib.UI.UIManager",
        "Indigox.Web.JsLib.UI.DomWriter",
        "Indigox.Web.JsLib.Core"
    ],
function (
        SimpleControlUI,
        UIManager,
        DomWriter
) {
    var base = SimpleControlUI.prototype;

    var RadioBoxItemUI =
        Namespace('Indigox.Web.JsLib.UI.ControlUIs')
        .Class('RadioBoxItemUI')
        .Extend(base)
        .Constructor(
            function (control) {
                base.constructor.call(this, control);
            }
        )
        .Static({
            createUI: function (control) {
                return new RadioBoxItemUI(control);
            }
        })
        .Members({
            createChildrenUI: function () {
                var control = this.getControl();
                var child, childUI, i, length;

                child = control.getRadioBox();
                if (child) {
                    childUI = UIManager.getInstance().createUI(child);
                    if (child.isInited()) {
                        childUI.init();
                    }
                }
            },

            renderChildren: function () {
                var control = this.getControl();
                var writer = new DomWriter(control, this.getMapping());
                var child, childUI, i, length;

                child = control.getRadioBox();
                if (child) {
                    childUI = UIManager.getInstance().getUI(child);
                    childUI.render();
                    childUI.replaceWith(writer, 'radioBox');
                }
            },

            setChildrenRendered: function () {
                var control = this.getControl();
                var child, childUI, i, length;

                child = control.getRadioBox();
                if (child) {
                    childUI = UIManager.getInstance().getUI(child);
                    childUI.setRendered();
                }
            },

            disposeChildren: function () {
                var control = this.getControl();
                var child, childUI, i, length;

                child = control.getRadioBox();
                if (child) {
                    childUI = UIManager.getInstance().getUI(child);
                    childUI.dispose();
                }
            }

        })
    .$();
});