﻿define("Indigox.Web.JsLib.UI.ControlUIs.HierarchyControlUI",
    [
        "Indigox.Web.JsLib.UI.UIManager",
        "Indigox.Web.JsLib.UI.ControlUI",
        "Indigox.Web.JsLib.UI.DomWriter",
        "Indigox.Web.JsLib.UI.RenderQueue",
        "Indigox.Web.JsLib.UI.ChildAddedChange",
        "Indigox.Web.JsLib.UI.ChildRemovedChange",
        "Indigox.Web.JsLib.Core"
    ],
function (
        UIManager,
        ControlUI,
        DomWriter,
        RenderQueue,
        ChildAddedChange,
        ChildRemovedChange

) {
    var base = ControlUI.prototype;

    var HierarchyControlUI =
        Namespace('Indigox.Web.JsLib.UI.ControlUIs')
        .Class('HierarchyControlUI')
        .Extend(base)
        .Constructor(
            function (control) {
                base.constructor.call(this, control);
            }
        )
        .Static({
            createUI: function (control) {
                return new HierarchyControlUI(control);
            }
        })
        .Members({
            onNodeAdding: function (source, index, child) {
                if (!this.isInited()) {
                    return;
                }
                var childUI = UIManager.getInstance().createUI(child);
                if (child.isInited()) {
                    childUI.init();
                }

                if (this.getElement() && this.isRenderedToDocument()) {
                    RenderQueue.getInstance().addListener(this, {
                        onRendered: this.swap
                    });
                    this.fakeup();
                }
            },

            onNodeAdded: function (source, index, child) {
                this.insertChildElement("childNodes", index, child);
            },

            onNodeRemoving: function (source, index, child) {
                if (this.getElement() && this.isRenderedToDocument()) {
                    RenderQueue.getInstance().addListener(this, {
                        onRendered: this.swap
                    });
                    this.fakeup();
                }
            },

            onNodeRemoved: function (source, index, child) {
                this.removeChildElement("childNodes", index, child);
            },

            onLoading: function () {
                base.onLoading.apply(this, arguments);

                if (this.getElement() && this.isRenderedToDocument()) {
                    RenderQueue.getInstance().addListener(this, {
                        onRendered: this.swap
                    });
                    this.fakeup();
                }
            },

            createChildrenUI: function () {
                var control = this.getControl();
                var children, child, childUI, i, length;

                children = control.getChildNodes();
                for (i = 0, length = children.length; i < length; i++) {
                    child = children[i];
                    childUI = UIManager.getInstance().createUI(child);
                    if (child.isInited()) {
                        childUI.init();
                    }
                }
            },

            renderChildren: function () {
                var control = this.getControl();
                var writer = new DomWriter(control, this.getMapping());
                var children, child, childUI, i, length;

                children = control.getChildNodes();
                for (i = 0, length = children.length; i < length; i++) {
                    child = children[i];
                    childUI = UIManager.getInstance().getUI(child);
                    childUI.render();
                    childUI.insertInto(writer, 'childNodes', i);
                }
            },

            setChildrenRendered: function () {
                var control = this.getControl();
                var children, child, childUI, i, length;

                children = control.getChildNodes();
                for (i = 0, length = children.length; i < length; i++) {
                    child = children[i];
                    childUI = UIManager.getInstance().getUI(child);
                    childUI.setRendered();
                }
            },

            disposeChildren: function () {
                var control = this.getControl();
                var children, child, childUI, i, length;

                children = control.getChildNodes();
                for (i = 0, length = children.length; i < length; i++) {
                    child = children[i];
                    childUI = UIManager.getInstance().getUI(child);
                    childUI.dispose();
                }
            }

        })
    .$();
});