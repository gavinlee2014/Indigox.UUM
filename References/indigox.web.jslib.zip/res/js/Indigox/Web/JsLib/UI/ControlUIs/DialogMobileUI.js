﻿define("Indigox.Web.JsLib.UI.ControlUIs.DialogMobileUI",
    [
        "Indigox.Web.JsLib.Utils.DOMUtil",
        "Indigox.Web.JsLib.UI.Overlay",
        "Indigox.Web.JsLib.DOM.Element",
        "Indigox.Web.JsLib.UI.ControlUI",
        "Indigox.Web.JsLib.Core"
    ],
function (
    DOMUtil,
    Overlay,
    Element,
    ControlUI
) {
    var El = Element.el;

    var base = ControlUI.prototype;

    var DialogMobileUI =
        Namespace("Indigox.Web.JsLib.UI.ControlUIs")
        .Class("DialogMobileUI")
        .Extend(base)
        .Constructor(
            function (control) {
                base.constructor.call(this, control);
            }
        )
        .Static({
            createUI: function (control) {
                return new DialogMobileUI(control);
            }
        })
        .Members({
            updateElement: function (property, value) {
                base.updateElement.apply(this, arguments);
                if (property === "visible") {
                    if (value) {
                        this.floatover();
                    }
                    else {
                        this.restore();
                    }
                }
            },

            /*mobile*/
            floatover: function () {
                //el = El(this.getElement());
                //el.addClass("floatover");
                //仅为解决对话框上浮问题，临时方案，需要改进
                DOMUtil.addClass(DOMUtil.element(" .actionbar", document.body), "invisible");
                DOMUtil.addClass(DOMUtil.element("#viewport", document.body), "floatover");
            },

            restore: function () {
                //el = El(this.getElement());
                //el.removeClass("floatover");
                //仅为解决对话框上浮问题，临时方案，需要改进
                DOMUtil.removeClass(DOMUtil.element(" .actionbar", document.body), "invisible");
                DOMUtil.removeClass(DOMUtil.element("#viewport", document.body), "floatover");
            },

            center: function () { 
              
            }
        })
    .$();
});