﻿define("Indigox.Web.JsLib.UI.Mediators.DataItemMediator",
    [
        "Indigox.Web.JsLib.UI.ControlMediator",
        "Indigox.Web.JsLib.Core"
    ],
function (
        ControlMediator
    ) {

    var base = ControlMediator.prototype;

    var instance = null;

    var DataItemMediator =
        Namespace("Indigox.Web.JsLib.UI.Mediators")
        .Class("DataItemMediator")
        .Extend(base)
        .Constructor(
            function () {
                this.showTask = null;
                this.hideTask = null;
            }
        )
        .Static({
            getInstance: function () {
                if (!instance) {
                    instance = new DataItemMediator();
                }
                return instance;
            }
        })
        .Members({
            onClicked: function (source, e, ui) {
                var control = ui.getControl();
                control.click();
                this.stopBubble(e);
            }
        })
    .$();
} );