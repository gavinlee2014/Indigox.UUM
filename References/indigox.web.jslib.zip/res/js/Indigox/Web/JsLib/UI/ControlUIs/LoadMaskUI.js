﻿define("Indigox.Web.JsLib.UI.ControlUIs.LoadMaskUI",
    [
        "Indigox.Web.JsLib.Utils.Browser",
        "Indigox.Web.JsLib.DOM.Element",
        "Indigox.Web.JsLib.UI.ControlUI",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Browser,
        Element,
        ControlUI
) {
    var Browser = Browser.getInstance(),
        El = Element.el;

    var VERSIONS = {
        '6.0': true,
        '7.0': true
    };

    var base = ControlUI.prototype;

    var LoadMaskUI =
        Namespace('Indigox.Web.JsLib.UI.ControlUIs')
        .Class('LoadMaskUI')
        .Extend(base)
        .Constructor(
            function (control) {
                base.constructor.call(this, control);
            }
        )
        .Static({
            createUI: function (control) {
                return new LoadMaskUI(control);
            }
        })
        .Members({
            onShow: function (source) {
                //解决在IE 6.0或 IE 7.0浏览器下body元素的overflow样式设置为hidden不起效果的问题。
                if (Browser.name === 'IE' && Browser.version in VERSIONS) {
                    document.documentElement.style.overflow = 'visible';
                }
                //El(this.getElement()).setTop(Element.getScrollTop());
            },

            onHide: function (source) {
                //解决在IE 6.0或 IE 7.0浏览器下body元素的overflow样式设置为hidden不起效果的问题。
                if (Browser.name === 'IE' && Browser.version in VERSIONS) {
                    //标准浏览器应使用removeProperty移除style的属性
                    document.documentElement.style.removeAttribute("overflow");
                }
            }
        })
    .$();
});