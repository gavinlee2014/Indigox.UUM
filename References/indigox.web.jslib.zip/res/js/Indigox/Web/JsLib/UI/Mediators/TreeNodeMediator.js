﻿define("Indigox.Web.JsLib.UI.Mediators.TreeNodeMediator",
    [
        "Indigox.Web.JsLib.UI.ControlMediator",
        "Indigox.Web.JsLib.DOM.Element",
        "Indigox.Web.JsLib.Utils.ArrayUtil",
        "Indigox.Web.JsLib.Core"
    ],
function (
        ControlMediator,
        Element,
        ArrayUtil
    ) {

    var base = ControlMediator.prototype;
    var El = Element.el;

    var instance = null;

    var TreeNodeMediator =
        Namespace("Indigox.Web.JsLib.UI.Mediators")
        .Class("TreeNodeMediator")
        .Extend(base)
        .Constructor(
            function () {
            }
        )
        .Static({
            getInstance: function () {
                if (!instance) {
                    instance = new TreeNodeMediator();
                }
                return instance;
            }
        })
        .Members({
            onClick: function (source, e, ui) {
                var classList = this.getClassList(source);

                if (ArrayUtil.indexOf(classList, "hitarea") != -1){
                    ui.getControl().toggleCollapse();
                    this.stopBubble(e);
                }
                else if (ArrayUtil.indexOf(classList, "clickarea") != -1){
                    ui.getControl().click();
                    this.stopBubble(e);
                }
            }
        })
    .$();
} );