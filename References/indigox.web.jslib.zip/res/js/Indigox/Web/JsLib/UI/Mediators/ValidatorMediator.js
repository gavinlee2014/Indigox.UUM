﻿define("Indigox.Web.JsLib.UI.Mediators.ValidatorMediator",
    [
        "Indigox.Web.JsLib.UI.ControlMediator",
        "Indigox.Web.JsLib.Core"
    ],
function (
        ControlMediator
    ) {

    var base = ControlMediator.prototype;

    var instance = null;

    var ValidatorMediator =
        Namespace("Indigox.Web.JsLib.UI.Mediators")
        .Class("ValidatorMediator")
        .Extend(base)
        .Constructor(
            function () {
            }
        )
        .Static({
            getInstance: function () {
                if (!instance) {
                    instance = new ValidatorMediator();
                }
                return instance;
            }
        })
        .Members({
            onClick: function (source, e, ui) {
                var nodetype = source.nodeName.toLowerCase();
                if (nodetype == "input") {
                    ui.getControl().hide();
                    this.stopBubble(e);
                }
            }

        })
    .$();
});