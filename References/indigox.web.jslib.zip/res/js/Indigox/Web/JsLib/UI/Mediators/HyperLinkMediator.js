﻿define("Indigox.Web.JsLib.UI.Mediators.HyperLinkMediator",
    [
        "Indigox.Web.JsLib.UI.ControlMediator",
        "Indigox.Web.JsLib.Core"
    ],
function (
        ControlMediator
    ) {

    var base = ControlMediator.prototype;

    var instance = null;

    var HyperLinkMediator =
        Namespace("Indigox.Web.JsLib.UI.Mediators")
        .Class("HyperLinkMediator")
        .Extend(base)
        .Constructor(
            function () {
            }
        )
        .Static({
            getInstance: function () {
                if (!instance) {
                    instance = new HyperLinkMediator();
                }
                return instance;
            }
        })
        .Members({

            onClick: function (source, e, ui) {
                    this.stopBubble(e);
            }

        })
    .$();
});