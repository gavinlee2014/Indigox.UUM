﻿define("Indigox.Web.JsLib.UI.MediatorRegistry",
    [
        "Indigox.Web.JsLib.Collection.Hashtable",
        "Indigox.Web.JsLib.Controls.Control",
        "Indigox.Web.JsLib.Utils.ConditionalConfig",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Hashtable,
        Control,
        ConditionalConfig
) {
    var instance = null;

    var MediatorRegistry =
        Namespace("Indigox.Web.JsLib.UI")
        .Class("MediatorRegistry")
        .Constructor(
            function () {
                this.aliasMappings = {};
                this.defaultMediator = null;
            }
        )
        .Static({
            getInstance: function () {
                if (!instance) {
                    instance = new MediatorRegistry();
                }
                return instance;
            }
        })
        .Members({
            register: function (control, condition, mediator) {
                if (arguments.length < 3) {
                    mediator = arguments[1];
                    condition = null;
                }
                if (arguments.length < 2) {
                    mediator = arguments[0];
                    condition = null;
                    control = null;
                }
                if (isNullOrUndefined(control)) {
                    this.defaultMediator = mediator;
                }
                else {
                    if (this.aliasMappings[control] == null) {
                        this.aliasMappings[control] = new ConditionalConfig();
                    }
                    this.aliasMappings[control].addConfig(condition, mediator);
                }
            },
            unregister: function (control) {
                delete this.aliasMappings[control];
            },
            getMediator: function (control) {
                var mediator = null;
                if (control in this.aliasMappings) {
                    mediator = this.aliasMappings[control].getConfig();
                }
                if (isNullOrUndefined(mediator)) {
                    mediator = this.defaultMediator;
                }
                if (!isNullOrUndefined(mediator)) {
                    return mediator.getInstance();
                }
            }
        })
     .$();
});