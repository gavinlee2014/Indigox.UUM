﻿define("Indigox.Web.JsLib.UI.ControlUIs.GridRowUI",
    [
        "Indigox.Web.JsLib.UI.ControlUI",
        "Indigox.Web.JsLib.UI.UIManager",
        "Indigox.Web.JsLib.UI.DomWriter",
        "Indigox.Web.JsLib.Core"
    ],
function (
        ControlUI,
        UIManager,
        DomWriter
) {
    var base = ControlUI.prototype;

    var GridRowUI =
        Namespace('Indigox.Web.JsLib.UI.ControlUIs')
        .Class('GridRowUI')
        .Extend(base)
        .Constructor(
            function (control) {
                base.constructor.call(this, control);
            }
        )
        .Static({
            createUI: function (control) {
                return new GridRowUI(control);
            }
        })
        .Members({
            onCellAdding: function (source, index, child) {
                if (!this.isInited()) {
                    return;
                }
                var childUI = UIManager.getInstance().createUI(child);
                if (child.isInited()) {
                    childUI.init();
                }
            },

            onCellAdded: function (source, index, child) {
                this.insertChildElement("cells", index, child);
            },

            onCellRemoving: function (source, index, child) {
            },

            onCellRemoved: function (source, index, child) {
                this.removeChildElement("cells", index, child);
            },

            createChildrenUI: function () {
                var control = this.getControl();
                var children, child, childUI, i, length;

                children = control.getCells();
                for (i = 0, length = children.length; i < length; i++) {
                    child = children[i];
                    childUI = UIManager.getInstance().createUI(child);
                    if (child.isInited()) {
                        childUI.init();
                    }
                }
            },

            renderChildren: function () {
                var control = this.getControl();
                var writer = new DomWriter(control, this.getMapping());
                var children, child, childUI, i, length;

                children = control.getCells();
                for (i = 0, length = children.length; i < length; i++) {
                    child = children[i];
                    childUI = UIManager.getInstance().getUI(child);
                    childUI.render();
                    childUI.insertInto(writer, 'cells', i);
                }
            },

            setChildrenRendered: function () {
                var control = this.getControl();
                var children, child, childUI, i, length;

                children = control.getCells();
                for (i = 0, length = children.length; i < length; i++) {
                    child = children[i];
                    childUI = UIManager.getInstance().getUI(child);
                    childUI.setRendered();
                }
            },

            disposeChildren: function () {
                var control = this.getControl();
                var children, child, childUI, i, length;

                children = control.getCells();
                for (i = 0, length = children.length; i < length; i++) {
                    child = children[i];
                    childUI = UIManager.getInstance().getUI(child);
                    childUI.dispose();
                }
            },

            setRendered: function () {
                base.setRendered.apply(this, arguments);
                /*if (this.getControl().getParent() && this.getControl().getParent().getEditable() == true) {
                    this.getControl().click();
                }*/
            }
        })
    .$();
});