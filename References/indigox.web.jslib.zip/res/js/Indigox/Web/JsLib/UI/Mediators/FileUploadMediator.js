﻿define("Indigox.Web.JsLib.UI.Mediators.FileUploadMediator",
    [
        "Indigox.Web.JsLib.UI.ControlMediator",
        "Indigox.Web.JsLib.Utils.ArrayUtil",
        "Indigox.Web.JsLib.Core"
    ],
    function (
        ControlMediator,
        ArrayUtil
    ) {
        var base = ControlMediator.prototype;

        var instance = null;

        var FileUploadMediator =
            Namespace("Indigox.Web.JsLib.UI.Mediators")
            .Class("FileUploadMediator")
            .Extend(base)
            .Static({
                getInstance: function () {
                    if (!instance) {
                        instance = new FileUploadMediator();
                    }
                    return instance;
                }
            })
            .Members({
                onChange: function (source, e, ui) {
                    var classList = this.getClassList(source);
                    if (ArrayUtil.indexOf(classList, "fileupload-fileselect") != -1){
                        var control = ui.getControl();
                        var patt = /[^\\]+$/g;
                        var selectedfilename = source.value;
                        var filename = patt.exec(selectedfilename)[0];
                        //debug.log('selected filename: ' + selectedfilename + ' ---> ' + filename);
                        control.setText(filename);
                        control.upload();
                        this.stopBubble(e);
                    }
                },

                onClick: function (source, e, ui) {
                    var control = ui.getControl();

                    var classList = this.getClassList(source);
                    if (ArrayUtil.indexOf(classList, "fileupload-removebutton") != -1){
                        control.remove();
                        this.stopBubble(e);
                    }
                    else  if (ArrayUtil.indexOf(classList, "fileupload-cancelbutton") != -1){
                        control.cancel();
                        control.remove();
                        this.stopBubble(e);
                    }
                }
            })
        .$();
    });