﻿define("Indigox.Web.JsLib.UI.Visitors.MappingVisitor",
    [
        "Indigox.Web.JsLib.UI.Schemas.StyleSchema",
        "Indigox.Web.JsLib.UI.Schemas.CssSchema",
        "Indigox.Web.JsLib.UI.Schemas.ControlSchema",
        "Indigox.Web.JsLib.Utils.ArrayUtil",
        "Indigox.Web.JsLib.UI.Schemas.AttributeSchema",
        "Indigox.Web.JsLib.UI.Schemas.ElementSchema",
        "Indigox.Web.JsLib.UI.Schemas.ForEachSchema",
        "Indigox.Web.JsLib.UI.Schemas.EventSchema",
        "Indigox.Web.JsLib.UI.Schemas.TextSchema",
        "Indigox.Web.JsLib.UI.SchemaRegistry",
        "Indigox.Web.JsLib.UI.Mappings.AttributeMapping",
        "Indigox.Web.JsLib.UI.Mappings.CssMapping",
        "Indigox.Web.JsLib.UI.Mappings.ControlMapping",
        "Indigox.Web.JsLib.UI.Mappings.ForEachMapping",
        "Indigox.Web.JsLib.UI.Mappings.StyleMapping",
        "Indigox.Web.JsLib.UI.Mappings.TextMapping",
        "Indigox.Web.JsLib.UI.UIManager",
        "Indigox.Web.JsLib.UI.Renderer",
        "Indigox.Web.JsLib.UI.RendererCache",
        "Indigox.Web.JsLib.UI.SchemaVisitor",
        "Indigox.Web.JsLib.Core"
    ],
function (
        StyleSchema,
        CssSchema,
        ControlSchema,
        ArrayUtil,
        AttributeSchema,
        ElementSchema,
        ForEachSchema,
        EventSchema,
        TextSchema,
        SchemaRegistry,
        AttributeMapping,
        CssMapping,
        ControlMapping,
        ForEachMapping,
        StyleMapping,
        TextMapping,
        UIManager,
        Renderer,
        RendererCache,
        SchemaVisitor
    ) {

    var base = SchemaVisitor.prototype;

    var MappingVisitor =
        Namespace("Indigox.Web.JsLib.UI.Visitors")
        .Class("MappingVisitor")
        .Extend(base)
        .Constructor(
            function (context, schema, element) {
                base.constructor.call(this, context, schema);
                this.element = element;
                this.mapping = {};
            }
        )
        .Members({
            visit: function () {
                this.schema.accept(this, this.context);
                return this.mapping;
            },

            getTag: function (schema) {
                var tag = "";
                if (schema.getParentNode()) {
                    tag = schema.getNodeName();
                    var attributes = schema.getAttributes();
                    for (var i = 0, length = attributes.length; i < length; i++) {
                        if (attributes[i] instanceof CssSchema) {
                            var attribute = attributes[i].getName();
                            var variable = attributes[i].getVariable();

                            if (this.isStaticProperty(variable)) {
                                if (variable == true) {
                                    tag = "." + attribute;
                                }
                                else {
                                    tag = "." + attribute + '-' + variable;
                                }
                            }
                        }
                    }
                }
                return tag;
            },

            visitElement: function (schema, data) {

                var tag = this.getTag(schema);

                var attributes = schema.getAttributes(),
                    childNodes = schema.getChildNodes();

                for (var i = 0, length = attributes.length; i < length; i++) {
                    attributes[i].accept(this, tag);
                }

                for (i = 0, length = childNodes.length; i < length; i++) {
                    childNodes[i].accept(this, tag);
                }
            },

            visitText: function (schema, data) {
                var tag = data;
                var variable = schema.getVariable();
                if (!this.isStaticProperty(variable)) {
                    this.addMapping(variable, new TextMapping(this.element, null, tag));
                }
            },

            visitEvent: function (schema, data) {
            },

            visitForEach: function (schema, data) {
                var tag = data;
                var variable = schema.getVariable();
                var iterable = schema.getIterable();
                if (!this.isStaticProperty(variable)) {
                    this.addMapping(variable, new ForEachMapping(this.element, null, tag, iterable));
                }
            },

            visitControl: function (schema, data) {
                var tag = data;
                var variable = schema.getVariable();
                if (!this.isStaticProperty(variable)) {
                    this.addMapping(variable, new ControlMapping(this.element, null, tag));
                }
            },

            visitAttribute: function (schema, data) {
                var tag = data;
                var attribute = schema.getName();
                var variable = schema.getVariable();
                if (!this.isStaticProperty(variable)) {
                    this.addMapping(variable, new AttributeMapping(this.element, attribute, tag));
                }
            },

            visitStyle: function (schema, data) {
                var tag = data;
                var attribute = schema.getName();
                var variable = schema.getVariable();
                if (!this.isStaticProperty(variable)) {
                    this.addMapping(variable, new StyleMapping(this.element, attribute, tag));
                }
            },

            visitCss: function (schema, data) {

                var tag = data;
                var attribute = schema.getName();
                var variable = schema.getVariable();
                if (!this.isStaticProperty(variable)) {
                    this.addMapping(variable, new CssMapping(this.element, attribute, tag));
                }
            },

            isStaticProperty: function (variable) {
                return !(/\$\{([^\}]+)\}/.test(variable));
            },

            addMapping: function (variable, mapping) {
                if (variable in this.mapping) {
                    var mappinglist = this.mapping[variable];
                    if (ArrayUtil.indexOf(mappinglist, mapping) == -1) {
                        mappinglist.push(mapping);
                    }
                }
                else {
                    this.mapping[variable] = [mapping];
                }
            }
        })
    .$();
});