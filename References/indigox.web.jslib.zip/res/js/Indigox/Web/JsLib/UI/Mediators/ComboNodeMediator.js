﻿define("Indigox.Web.JsLib.UI.Mediators.ComboNodeMediator",
    [
        "Indigox.Web.JsLib.UI.ControlMediator",
        "Indigox.Web.JsLib.Core"
    ],
function (
        ControlMediator
    ) {

    var base = ControlMediator.prototype;

    var instance = null;

    var ComboNodeMediator =
        Namespace("Indigox.Web.JsLib.UI.Mediators")
        .Class("ComboNodeMediator")
        .Extend(base)
        .Constructor(
            function () {
            }
        )
        .Static({
            getInstance: function () {
                if (!instance) {
                    instance = new ComboNodeMediator();
                }
                return instance;
            }
        })
        .Members({
            onClicked: function (source, e, ui) {
                var nodeType = source.nodeName.toLowerCase();
                if (nodeType == "input") {
                    ui.getControl().remove();
                    this.stopBubble(e);
                }
            }
        })
    .$();
});