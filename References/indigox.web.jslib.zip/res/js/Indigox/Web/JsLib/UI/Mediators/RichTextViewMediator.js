﻿define("Indigox.Web.JsLib.UI.Mediators.RichTextViewMediator",
    [
        "Indigox.Web.JsLib.UI.ControlMediator",
        "Indigox.Web.JsLib.DOM.Element",
        "Indigox.Web.JsLib.Utils.ArrayUtil",
        "Indigox.Web.JsLib.Core"
    ],
function (
        ControlMediator,
        Element,
        ArrayUtil
    ) {

    var El = Element.el;
    var base = ControlMediator.prototype;

    var instance = null;

    var RichTextViewMediator =
        Namespace("Indigox.Web.JsLib.UI.Mediators")
        .Class("RichTextViewMediator")
        .Extend(base)
        .Constructor(
            function () {
            }
        )
        .Static({
            getInstance: function () {
                if (!instance) {
                    instance = new RichTextViewMediator();
                }
                return instance;
            }
        })
        .Members({

            onClick: function(source, e, ui) {
                var classList = this.getClassList(source);
                if (ArrayUtil.indexOf(classList, "toolbar-enterfullview") != -1){
                    ui.enterFullView();
                    this.stopBubble(e);
                }
                else if (ArrayUtil.indexOf(classList, "toolbar-leavefullview") != -1){
                    ui.leaveFullView();
                    this.stopBubble(e);
                }
            },

            onTouchStart: function (source, e, ui) {
                var classList = this.getClassList(source);
                if (ArrayUtil.indexOf(classList, "toolbar-enterfullview") != -1 ||
                        ArrayUtil.indexOf(classList, "toolbar-leavefullview") != -1) {
                    El(source).addClass("pressed");
                    this.stopBubble(e);
                }
            },

            onTouchEnd: function (source, e, ui) {
                var classList = this.getClassList(source);
                if (ArrayUtil.indexOf(classList, "toolbar-enterfullview") != -1 ||
                    ArrayUtil.indexOf(classList, "toolbar-leavefullview") != -1) {
                    El(source).removeClass("pressed");
                    this.stopBubble(e);
                }
            }
        })
    .$();
} );