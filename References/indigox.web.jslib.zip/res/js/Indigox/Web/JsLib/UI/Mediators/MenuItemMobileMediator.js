﻿define("Indigox.Web.JsLib.UI.Mediators.MenuItemMobileMediator",
    [
        "Indigox.Web.JsLib.UI.ControlMediator",
        "Indigox.Web.JsLib.DOM.Element",
        "Indigox.Web.JsLib.UI.Overlay",
        "Indigox.Web.JsLib.UI.UIManager",
        "Indigox.Web.JsLib.Utils.AsyncUtil",
        "Indigox.Web.JsLib.Core"
    ],
function (
        ControlMediator,
        Element,
        Overlay,
        UIManager,
        AsyncUtil
) {

    var El = Element.el;
    var base = ControlMediator.prototype;

    var instance = null;

    var MenuItemMobileMediator =
        Namespace("Indigox.Web.JsLib.UI.Mediators")
        .Class("MenuItemMobileMediator")
        .Extend(base)
        .Constructor(
            function () {
            }
        )
        .Static({
            getInstance: function () {
                if (!instance) {
                    instance = new MenuItemMobileMediator();
                }
                return instance;
            }
        })
        .Members({
            /* mobile */
            onClick: function (source, e, ui) {
                var control = ui.getControl();
                if (control.hasChildNodes()) {
                    control.toggleChildMenu();
                }

                if (!control.hasChildNodes()) {
                    var t = this;
                    AsyncUtil.invokeAsync(function () { t.restore(control); }, 100);
                    control.setSelected(true);
                }

                this.stopBubble(e);
            },

            onTouchStart: function (source, e, ui) {
                El(ui.getElement()).addClass("pressed");
                this.stopBubble(e);
            },

            onTouchEnd: function (source, e, ui) {
                El(ui.getElement()).removeClass("pressed");
                this.stopBubble(e);
            },

            restore: function (control) {
                var parent = control.getParent(),
                    root = control.getRoot(),
                    rootElement = UIManager.getInstance().findElement(root);

                while (parent != root) {
                    parent.hideChildMenu();
                    parent = parent.parent;
                }

                Overlay.getInstance().restore(rootElement);
            }
        })
    .$();
});