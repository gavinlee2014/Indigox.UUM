﻿define("Indigox.Web.JsLib.UI.PropertyChange",
    [
        "Indigox.Web.JsLib.Core"
    ],
    function (

    ) {
        var PropertyChange =
            Namespace("Indigox.Web.JsLib.UI")
            .Class("PropertyChange")
            .Constructor(
                function (property, value) {
                    this.property = property;
                    this.value = value;
                }
            )
            .Members({
                process: function (handler) {
                    handler.handlePropertyChange(this.property, this.value);
                }
            })
        .$();
    });