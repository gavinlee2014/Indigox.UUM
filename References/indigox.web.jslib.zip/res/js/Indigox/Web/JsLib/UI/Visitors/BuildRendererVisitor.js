﻿define("Indigox.Web.JsLib.UI.Visitors.BuildRendererVisitor",
    [
        "Indigox.Web.JsLib.UI.Schemas.StyleSchema",
        "Indigox.Web.JsLib.UI.Schemas.CssSchema",
        "Indigox.Web.JsLib.UI.Schemas.ControlSchema",
        "Indigox.Web.JsLib.UI.Schemas.AttributeSchema",
        "Indigox.Web.JsLib.UI.Schemas.ElementSchema",
        "Indigox.Web.JsLib.UI.Schemas.ForEachSchema",
        "Indigox.Web.JsLib.UI.Schemas.EventSchema",
        "Indigox.Web.JsLib.UI.Schemas.TextSchema",
        "Indigox.Web.JsLib.UI.SchemaRegistry",
        "Indigox.Web.JsLib.UI.UIManager",
        "Indigox.Web.JsLib.UI.Renderer",
        "Indigox.Web.JsLib.UI.RendererCache",
        "Indigox.Web.JsLib.UI.SchemaVisitor",
        "Indigox.Web.JsLib.Core"
    ],
function (
        StyleSchema,
        CssSchema,
        ControlSchema,
        AttributeSchema,
        ElementSchema,
        ForEachSchema,
        EventSchema,
        TextSchema,
        SchemaRegistry,
        UIManager,
        Renderer,
        RendererCache,
        SchemaVisitor
    ) {

    var NO_END_TAG = {
        'area': true,
        'base': true,
        'basefont': true,
        'br': true,
        'col': true,
        'frame': true,
        'hr': true,
        'img': true,
        'input': true,
        'isindex': true,
        'link': true,
        'meta': true,
        'param': true
    };

    var base = SchemaVisitor.prototype;

    var BuildRendererVisitor =
        Namespace("Indigox.Web.JsLib.UI.Visitors")
        .Class("BuildRendererVisitor")
        .Extend(base)
        .Constructor(
            function (context, schema, renderer) {
                base.constructor.call(this, context, schema);
                this.renderer = renderer;
            }
        )
        .Members({
            visit: function () {
                var schema = this.schema;
                return schema.accept(this, this.renderer);
            },

            visitElement: function (schema, data) {
                var renderer = data;

                var name = schema.getNodeName(),
                    attributes = schema.getAttributes(),
                    childNodes = schema.getChildNodes();

                renderer.setTagName(name);
                if (name.toLowerCase() in NO_END_TAG) {
                    renderer.setEndTag(false);
                }

                for (var i = 0, length = attributes.length; i < length; i++) {
                    if (!(attributes[i] instanceof EventSchema)) {
                        attributes[i].accept(this, renderer);
                    }
                }

                for (i = 0, length = childNodes.length; i < length; i++) {
                    var childNode = childNodes[i];
                    if (childNode instanceof ElementSchema) {
                        var childRenderer = new Renderer();
                        childNode.accept(this, childRenderer);
                        renderer.addChild(childRenderer);
                    }
                    else {
                        childNode.accept(this, renderer);
                    }
                }

                return null;
            },

            visitText: function (schema, data) {
                var renderer = data;
                var variable = schema.getVariable();
                renderer.addChild(variable);
                return null;
            },

            visitEvent: function (schema, data) {
            },

            visitForEach: function (schema, data) {
            },

            visitControl: function (schema, data) {
            },

            visitAttribute: function (schema, data) {
                var renderer = data;
                var attribute = schema.getName();
                var variable = schema.getVariable();

                if (this.isStaticProperty(variable)) {
                    renderer.addStaticAttribute(attribute, variable);
                }
                else {
                    renderer.addAttribute(attribute, variable);
                }

                return null;
            },

            visitStyle: function (schema, data) {
                var renderer = data;
                var attribute = schema.getName();
                var variable = schema.getVariable();

                if (this.isStaticProperty(variable)) {
                    renderer.addStaticStyle(attribute, variable);
                }
                else {
                    renderer.addStyle(attribute, variable);
                }

                return null;
            },

            visitCss: function (schema, data) {
                var renderer = data;
                var attribute = schema.getName();
                var variable = schema.getVariable();

                if (this.isStaticProperty(variable)) {
                    renderer.addStaticCss(attribute, variable);
                }
                else {
                    renderer.addCss(attribute, variable);
                }

                return null;
            },

            isStaticProperty: function (variable) {
                return !(/\$\{([^\}]+)\}/.test(variable));
            }
        })
    .$();
} );