﻿define("Indigox.Web.JsLib.UI.DomTraversal",
    [
        "Indigox.Web.JsLib.DOM.Element",
        "Indigox.Web.JsLib.DOM.TreeWalker",
        "Indigox.Web.JsLib.DOM.NodeFilter",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Element,
        TreeWalker,
        NodeFilter
) {
    var El = Element.el;

    var CTRL_CSS_REGEX = /control-([\w|$]\w*)/;
    var WHAT_TO_SHOW = NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT;

    var DomTraversal =
        Namespace("Indigox.Web.JsLib.UI")
        .Class("DomTraversal")
        .Constructor(
            function (element) {
                this.treeWalker = new TreeWalker(element, WHAT_TO_SHOW, {
                    acceptNode: function (node) {
                        if (El(node).isEmptyText()) {
                            return NodeFilter.FILTER_REJECT;
                        }
                        return NodeFilter.FILTER_ACCEPT;
                    }
                }, false);
                this.current = element;
            }
        )
        .Members({
            isMarkAsControl: function (node) {
                var controlAlias = this.getControlAlias(node);
                return controlAlias !== null;
            },
            getControlAlias: function (node) {
                var css = node.className;
                var match;
                if (match = CTRL_CSS_REGEX.exec(css)) {
                    return match[1];
                }
                return null;
            },
            parentNode: function () {
                var treeWalker = this.treeWalker;
                var node = treeWalker.getCurrentNode();
                return treeWalker.getParentNode(node);
            },
            firstChild: function () {
                var treeWalker = this.treeWalker;
                var node = treeWalker.getCurrentNode();
                return treeWalker.getFirstChild(node);
            },
            getLastChild: function (node) {
                var treeWalker = this.treeWalker;
                var lastChild = treeWalker.getLastChild(node);
                while (lastChild != null && !this.isMarkAsControl(lastChild) && treeWalker.getLastChild(lastChild) != null) {
                    lastChild = treeWalker.getLastChild(lastChild);
                }
                return lastChild;
            },
            lastChild: function () {
                var treeWalker = this.treeWalker;
                var node = treeWalker.getCurrentNode();
                return treeWalker.getLastChild(node);
            },
            previousSibling: function () {
                var treeWalker = this.treeWalker;
                var node = treeWalker.getCurrentNode();
                return treeWalker.getPreviousSibling(node);
            },
            nextSibling: function () {
                var treeWalker = this.treeWalker;
                var node = treeWalker.getCurrentNode();
                return treeWalker.getNextSibling(node);
            },
            previousNode: function () {
                var treeWalker = this.treeWalker;
                var node = treeWalker.getCurrentNode();
                this.current = treeWalker.previousNode();
                return node;
            },
            nextNode: function () {
                var treeWalker = this.treeWalker;
                var node = treeWalker.getCurrentNode();
                var result = null;
                if (node != treeWalker.rootNode && this.isMarkAsControl(node)) {
                    result = treeWalker.getNextSibling(node);

                    if (isNullOrUndefined(result)) {
                        // return parent"s 1st sibling.
                        var parent = treeWalker.getParentNode(node);
                        while (parent != null) {
                            result = treeWalker.getNextSibling(parent);
                            if (isNullOrUndefined(result)) {
                                parent = treeWalker.getParentNode(parent);
                            }
                            else {
                                break;
                            }
                        }
                    }
                    if (isNullOrUndefined(result)) {
                        this.current = null;
                        return null;
                    }

                    treeWalker.setCurrentNode(result);

                    this.current = treeWalker.getCurrentNode();
                }
                else {
                    this.current = treeWalker.nextNode();
                }
                return node;
            },
            currentNode: function () {
                return this.current;
            },
            isEnd: function () {
                return !this.currentNode();
            }
        })
    .$();
});