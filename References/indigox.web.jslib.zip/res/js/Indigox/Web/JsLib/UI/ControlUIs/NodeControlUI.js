﻿define("Indigox.Web.JsLib.UI.ControlUIs.NodeControlUI",
    [
        "Indigox.Web.JsLib.UI.UIManager",
        "Indigox.Web.JsLib.UI.DomWriter",
        "Indigox.Web.JsLib.UI.ChildAddedChange",
        "Indigox.Web.JsLib.UI.ChildRemovedChange",
        "Indigox.Web.JsLib.DOM.Effect",
        "Indigox.Web.JsLib.UI.ControlUI",
        "Indigox.Web.JsLib.Core"
    ],
function (
        UIManager,
        DomWriter,
        ChildAddedChange,
        ChildRemovedChange,
        Effect,
        ControlUI
) {
    var base = ControlUI.prototype;

    var NodeControlUI =
        Namespace('Indigox.Web.JsLib.UI.ControlUIs')
        .Class('NodeControlUI')
        .Extend(base)
        .Constructor(
            function (control) {
                base.constructor.call(this, control);
            }
        )
        .Static({
            createUI: function (control) {
                return new NodeControlUI(control);
            }
        })
        .Members({
            onNodeAdding: function (source, index, child) {
                if (!this.isInited()) {
                    return;
                }
                var childUI = UIManager.getInstance().createUI(child);
                if (child.isInited()) {
                    childUI.init();
                }
            },

            onNodeAdded: function (source, index, child) {
                this.insertChildElement("childNodes", index, child);
            },

            onNodeRemoving: function (source, index, child) {
            },

            onNodeRemoved: function (source, index, child) {
                this.removeChildElement("childNodes", index, child);
            },

            createChildrenUI: function () {
                var control = this.getControl();
                var children, child, childUI, i, length;

                children = control.getChildNodes();
                for (i = 0, length = children.length; i < length; i++) {
                    child = children[i];
                    childUI = UIManager.getInstance().createUI(child);
                    if (child.isInited()) {
                        childUI.init();
                    }
                }
            },

            renderChildren: function () {
                var control = this.getControl();
                var writer = new DomWriter(control, this.getMapping());
                var children, child, childUI, i, length;

                children = control.getChildNodes();
                for (i = 0, length = children.length; i < length; i++) {
                    child = children[i];
                    childUI = UIManager.getInstance().getUI(child);
                    childUI.render();
                    childUI.insertInto(writer, 'childNodes', i);
                }
            },

            setChildrenRendered: function () {
                var control = this.getControl();
                var children, child, childUI, i, length;

                children = control.getChildNodes();
                for (i = 0, length = children.length; i < length; i++) {
                    child = children[i];
                    childUI = UIManager.getInstance().getUI(child);
                    childUI.setRendered();
                }
            },

            disposeChildren: function () {
                var control = this.getControl();
                var children, child, childUI, i, length;

                children = control.getChildNodes();
                for (i = 0, length = children.length; i < length; i++) {
                    child = children[i];
                    childUI = UIManager.getInstance().getUI(child);
                    childUI.dispose();
                }
            },

            onExpanded: function (source) {
                // var slide = Effect.slideOut(jQuery("ul", this.getElement()).get(0));
                // slide.play();
            },

            onCollapsed: function (source) {
                // var slide = Effect.slideIn(jQuery("ul", this.getElement()).get(0));
                // slide.play();
            }
        })
    .$();
});