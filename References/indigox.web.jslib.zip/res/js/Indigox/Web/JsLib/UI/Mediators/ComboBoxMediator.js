﻿define("Indigox.Web.JsLib.UI.Mediators.ComboBoxMediator",
    [
        "Indigox.Web.JsLib.UI.ControlMediator",
        "Indigox.Web.JsLib.Core"
    ],
function (
        ControlMediator
    ) {

    var base = ControlMediator.prototype;

    var instance = null;

    var ComboBoxMediator =
        Namespace("Indigox.Web.JsLib.UI.Mediators")
        .Class("ComboBoxMediator")
        .Extend(base)
        .Constructor(
            function () {
            }
        )
        .Static({
            getInstance: function () {
                if (!instance) {
                    instance = new ComboBoxMediator();
                }
                return instance;
            }
        })
        .Members({
            onKeyUp: function (source, e, ui) {
                var nodeType = source.nodeName.toLowerCase();
                if (nodeType == "input") {
                    ui.getControl().search(source.value);
                    this.stopBubble(e);
                }
            }
        })
    .$();
});