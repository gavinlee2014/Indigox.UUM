﻿define("Indigox.Web.JsLib.UI.RenderQueue",
    [
        "Indigox.Web.JsLib.Collection.Queue",
        "Indigox.Web.JsLib.Utils.DelayedTask",
        "Indigox.Web.JsLib.Utils.ListenersSupport",
        "Indigox.Web.JsLib.Core"
    ],
    function (
        Queue,
        DelayedTask,
        ListenersSupport
    ) {
        var LISTENER_RENDER = "Render",
            LISTENER_RENDERED = "Rendered";

        var instance = null;
        var total = 0;

        var RenderQueue =
            Namespace("Indigox.Web.JsLib.UI")
            .Class("RenderQueue")
            .Constructor(
                function () {
                    this.initListeners();
                    this.queue = new Queue();
                    this.begun = false;
                    this.executing = false;
                    this.autoBegun = false;
                    this.delayedEnd = null;
                }
            )
            .Static({
                getInstance: function () {
                    if (!instance) {
                        instance = new RenderQueue();
                    }
                    return instance;
                }
            })
            .Members({
                begin: function () {
                    //debug.log("RenderQueue begin...");

                    this.fireListener(LISTENER_RENDER);
                    this.begun = true;
                },

                autoBegin: function () {
                    debug.log("RenderQueue auto begin...");
                    this.fireListener(LISTENER_RENDER);
                    this.begun = true;
                    this.autoBegun = true;
                    this.delayedEnd = new DelayedTask(this.end, this, []);
                },

                end: function () {
                    if (this.queue.size() === 0 && !this.executing) {
                        this.fireListener(LISTENER_RENDERED);
                    }
                    this.begun = false;
                    this.autoBegun = false;

                    debug.log(total + "ms\t" + "RenderQueue");
                    //debug.log(window.eventCount + "\t" + " Event Count ");
                    //debug.log(window.eventTime + "ms\t" + " Event Time ");
                    //debug.log(window.getElementCount + "\t" + " get Element Count ");
                    //debug.log(window.getElementTime + "ms\t" + " get Element Time ");

                    //debug.log(window.buildtime + "ms\t" + "BuildMaping");
                    //debug.log(window.buildcount + "count\t" + "BuildMaping count");
                    //debug.log(window.fakeuptime + "ms\t" + "Fakeup");
                    //debug.log(window.swaptime + "ms\t" + "Swap");

                    //                window.getElementTime = 0;
                    //                window.getElementCount = 0;
                    //                window.eventCount = 0;
                    //                window.eventTime = 0;
                    //                window.buildtime = 0;
                    //                window.buildcount = 0;
                    window.fakeuptime = 0;
                    window.swaptime = 0;

                    total = 0;
                },

                offer: function (callback) {
                    if (!this.begun) {
                        this.autoBegin();
                    }
                    this.queue.offer(callback);
                    //debug.log("queue size after offer: " + this.queue.size());
                    this.execute();

                    if (this.autoBegun) {
                        this.delayedEnd.delay(100);
                    }
                },

                //@private
                execute: function () {
                    if (!this.executing) {
                        this.doExecute();
                    }
                },

                //@private
                doExecute: function () {
                    this.executing = true;
                    try {
                        while (this.queue.size() > 0) {
                            var callback = this.queue.poll();
                            //debug.log("queue size after poll: " + this.queue.size());

                            var beginTime = new Date();
                            callback.invoke();
                            var endTime = new Date();
                            total += endTime.getTime() - beginTime.getTime();
                        }
                    } catch (e) {
                        debug.log(e);
                    }

                    this.executing = false;

                    if (!this.begun) {
                        this.fireListener(LISTENER_RENDERED);
                    }
                },

                //@private
                initListeners: function () {
                    this.listeners = new ListenersSupport(this);
                    this.registerListeners();
                },

                //@private
                registerListeners: function () {
                    this.listeners.registerListeners(
                        LISTENER_RENDER,
                        LISTENER_RENDERED
                    );
                },

                addListener: function (listener, handlers) {
                    if (this.listeners && listener != null) {
                        this.listeners.addListener(listener, handlers);
                    }
                },

                removeListener: function (listener) {
                    if (this.listeners && listener != null) {
                        this.listeners.removeListener(listener);
                    }
                },

                //@private
                fireListener: function (method, args) {
                    if (this.listeners) {
                        this.listeners.fire(method, args);
                    }
                }
            })
        .$();
    });