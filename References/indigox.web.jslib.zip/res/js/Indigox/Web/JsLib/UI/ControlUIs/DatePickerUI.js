﻿define("Indigox.Web.JsLib.UI.ControlUIs.DatePickerUI",
    [
        "Indigox.Web.JsLib.Utils.StringUtil",
        "Indigox.Web.JsLib.Utils.DOMUtil",
        "Indigox.Web.JsLib.UI.UIManager",
        "Indigox.Web.JsLib.UI.DomWriter",
        "Indigox.Web.JsLib.UI.ControlUIs.SimpleControlUI",
        "jquery",
        "jquery-datepicker",
        "jquery-datepicker-lang",
        "Indigox.Web.JsLib.Core"
    ],
    function (
        StringUtil,
        DOMUtil,
        UIManager,
        DomWriter,
        SimpleControlUI,
        jQuery
    ) {
        var base = SimpleControlUI.prototype;

        var DatePickerUI =
            Namespace("Indigox.Web.JsLib.UI.ControlUIs")
            .Class("DatePickerUI")
            .Extend(base)
            .Constructor(
                function (control) {
                    base.constructor.call(this, control);
                }
            )
            .Static({
                createUI: function (control) {
                    return new DatePickerUI(control);
                }
            })
            .Members({
                parseElement: function () {
                    var element = this.getElement();
                    if (StringUtil.trim(DOMUtil.getAttribute(element, "innerHTML")) === "") {
                        var html = this.buildHtml();
                        var innerHtml = DOMUtil.getAttribute(DOMUtil.buildElement(html.join("")), "innerHTML");
                        DOMUtil.setAttribute(element, "innerHTML", innerHtml);
                    }

                    base.parseElement.apply(this, arguments);
                },

                buildHtml: function () {
                    var html = base.buildHtml.apply(this, arguments);
                    var element = DOMUtil.buildElement(html.join(""));
                    this.fillSelectOptions(element);
                    return [element.outerHTML];
                },

                setRendered: function () {
                    base.setRendered.apply(this, arguments);

                    if (this.isRendered()) {
                        this.warpDateInput();
                    }
                },

                warpDateInput: function () {
                    var control = this.getControl();
                    var element = this.getElement();
                    var max = control.getMaxDate();
                    var min = control.getMinDate();

                    var dateInput = jQuery(".dateinput", element);
                    dateInput.datepicker({
                        changeYear: true,
                        changeMonth: true,
                        minDate: min,
                        maxDate: max,
                        showAnim: ""
                    });

                    if (control.getReadonly()) {
                        dateInput.datepicker("disable");
                    }
                    else {
                        dateInput.datepicker("enable");
                    }
                },

                fillSelectOptions: function (element) {
                    var hourInput = jQuery(".hoursinput", element);
                    for (var h = 0; h < 24; h++) {
                        var th = (h < 10) ? ("0" + h.toString()) : h.toString();
                        hourInput.append("<option value=\"" + th + "\">" + th + "</option>");
                    }

                    var minuteInput = jQuery(".minutesinput", element);
                    for (var m = 0; m < 60; m++) {
                        var tm = (m < 10) ? ("0" + m.toString()) : m.toString();
                        minuteInput.append("<option value=\"" + tm + "\">" + tm + "</option>");
                    }

                    //var secondInput = jQuery(".secondsinput", element);
                    //for (var s = 0; s < 60; s++) {
                    //    var ts = (s < 10) ? ("0" + s.toString()) : s.toString();
                    //    secondInput.append("<option value=\"" + ts + "\">" + ts + "</option>");
                    //}
                },

                showDatePicker: function () {
                    jQuery(".dateinput", this.getElement()).datepicker("show");
                },
                onPropertyChanged: function (source, property, value, oldValue) {
                    if (property === "minDate") {
                        var control = this.getControl();
                        var min = control.getMinDate();
                        jQuery(".dateinput", this.getElement()).datepicker('option', 'minDate', new Date(min));
                    }
                    else {
                        base.onPropertyChanged.apply(this, arguments);
                    }
                }
            })
        .$();
    });