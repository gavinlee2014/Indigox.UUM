﻿define("Indigox.Web.JsLib.UI.Mediators.ToolbarMediator",
    [
        "Indigox.Web.JsLib.UI.ControlMediator",
        "Indigox.Web.JsLib.Core"
    ],
function (
        ControlMediator
    ) {

    var base = ControlMediator.prototype;

    var instance = null;

    var ToolbarMediator =
        Namespace("Indigox.Web.JsLib.UI.Mediators")
        .Class("ToolbarMediator")
        .Extend(base)
        .Constructor(
            function () {
            }
        )
        .Static({
            getInstance: function () {
                if (!instance) {
                    instance = new ToolbarMediator();
                }
                return instance;
            }
        })
        .Members({
            onClick: function (source, e, ui) {                
                var nodetype = source.nodeName.toLowerCase();
                if (nodetype == "input") {
                    ui.getControl().addRow();
                    this.stopBubble(e);
                }  
            }
        })
    .$();
} );