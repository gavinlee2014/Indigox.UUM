﻿define("Indigox.Web.JsLib.UI.Mappings.CssMapping",
    [
        "Indigox.Web.JsLib.UI.Mappings.Mapping",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Mapping
    ) {
    var base = Mapping.prototype;

    var CssMapping =
        Namespace("Indigox.Web.JsLib.UI.Mappings")
        .Class("CssMapping")
        .Extend(base)
        .Constructor(
            function (element, attribute, tag) {
                base.constructor.apply(this, arguments);
            }
        )
        .Members({
            write: function (value) {
                var element = this.getElement();

                if (isBoolean(value)) {
                    if (value === true && !element.hasClass(this.attribute)) {
                        element.addClass(this.attribute);
                    }
                    else if (value === false && element.hasClass(this.attribute)) {
                        element.removeClass(this.attribute);
                    }
                }
                else {
                    var oldValue = this.getValue(element);
                    if (value === oldValue) {
                        return;
                    }
                    if (!isNullOrUndefined(oldValue)) {
                        element.removeClass(this.getClass(this.attribute, oldValue));
                    }
                    if (!isNullOrUndefined(value)) {
                        element.addClass(this.getClass(this.attribute, value));
                    }
                }
            },

            read: function () {
                var element = this.getElement();

                var result = this.getValue(element);
                if (isNullOrUndefined(result)) {
                    result = element.hasClass(this.attribute);
                }
                return result;
            },

            getValue: function (element) {
                var classes = element.getAttribute('className');
                var hasAttrRegex = new RegExp("(^|\\s+)" + this.attribute + "-(\\w+)", 'g');
                var attrMatch = hasAttrRegex.exec(classes);
                if (attrMatch) {
                    return attrMatch[2];
                }
                return null;
            },

            getClass: function (attribute, value) {
                return [attribute, '-', value].join('');
            }
        })
    .$();
} );