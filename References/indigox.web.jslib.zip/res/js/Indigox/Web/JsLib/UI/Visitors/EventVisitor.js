﻿define("Indigox.Web.JsLib.UI.Visitors.EventVisitor",
    [
        "Indigox.Web.JsLib.UI.SchemaVisitor",
        "Indigox.Web.JsLib.DOM.Element",
        "Indigox.Web.JsLib.Core"
    ],
function (
        SchemaVisitor,
        Element
    ) {

    var base = SchemaVisitor.prototype;
    var El   = Element.el;

    var EventVisitor =
        Namespace("Indigox.Web.JsLib.UI.Visitors")
        .Class("EventVisitor")
        .Extend(base)
        .Constructor(
            function (context, schema, element, mediator, ui) {
                base.constructor.call(this, context, schema);
                this.element = element;
                this.mediator = mediator;
                this.ui = ui;
            }
        )
        .Members({
            visit: function () {
                this.schema.accept(this, this.element);
                return this.mapping;
            },

            visitElement: function (schema, data) {
                var attributes = schema.getAttributes();

                for (var i = 0, length = attributes.length; i < length; i++) {
                    attributes[i].accept(this, data);
                }
            },

            visitEvent: function (schema, data) {
                //                var start = new Date();
                var element = data;
                var event = schema.getName(),
                    handler = schema.getHandler().replace('${', '').replace('}', '');
                if (!isNullOrUndefined(this.mediator[handler])) {
                    El(element).addListener(event, this.mediator[handler], this.mediator, [this.ui]);
                }
                //                var end = new Date();
                //                if (!window.eventCount) {
                //                    window.eventCount = 0;
                //                }
                //                if (!window.eventTime) {
                //                    window.eventTime = 0;
                //                }
                //                window.eventCount++;
                //                window.eventTime += (end - start);
            }
        })
    .$();
});