﻿/*globals tinyMCE*/
define("Indigox.Web.JsLib.UI.ControlUIs.TinyMceUI",
    [
        "Indigox.Web.JsLib.Utils.DelayedTask",
        "Indigox.Web.JsLib.UI.ControlUIs.SimpleControlUI",
        "tinymce",
        "Indigox.Web.JsLib.Core"
    ],
    function (
        DelayedTask,
        SimpleControlUI
    ) {
        var document = window.document;

        var editorJsIncluded = (typeof tinyMCE !== 'undefined');

        var base = SimpleControlUI.prototype;

        function myFileBrowser(field_name, url, type, win) {
            /* If you work with sessions in PHP and your client doesn't accept cookies you might need to carry
            the session name and session ID in the request string (can look like this: "?PHPSESSID=88p0n70s9dsknra96qhuk6etm5").
            These lines of code extract the necessary parameters and add them back to the filebrowser URL again. */
            var cmsURL = "/editor/tinymce/customfileupload.htm";    // script URL - use an absolute path!
            if (cmsURL.indexOf("?") < 0) {
                //add the type as the only query parameter
                cmsURL = cmsURL + "?type=" + type;
            }
            else {
                //add the type as an additional query parameter
                // (PHP session ID is now included if there is one at all)
                cmsURL = cmsURL + "&type=" + type;
            }

            tinyMCE.activeEditor.windowManager.open({
                file: cmsURL,
                title: 'File Upload',
                width: 320,  // Your dimensions may differ - toy around with them!
                height: 200,
                resizable: "yes",
                inline: "yes",  // This parameter only has an effect if you use the inlinepopups plugin!
                close_previous: "no",
                popup_css: false // Disable TinyMCE's default popup CSS
            }, {
                window: win,
                input: field_name
            });
            return false;
        }

        tinyMCE.init({
            mode: "none",
            // plugin, button, toolbar, statusbar
            theme: "advanced",
            plugins: "autolink,lists,table,inlinepopups,preview,media,searchreplace,contextmenu,paste,fullscreen,noneditable,xhtmlxtras,advlist",
            theme_advanced_buttons1: "bold,italic,underline,strikethrough,|,justifyleft,justifycenter,justifyright,justifyfull,formatselect,fontselect,fontsizeselect,removeformat,|,forecolor,backcolor",
            theme_advanced_buttons2: "cut,copy,paste,pastetext,|,bullist,numlist,|,outdent,indent,|,link,unlink,image,|,search,replace,|,charmap,|,fullscreen,code",
            theme_advanced_buttons3: "", // disabled buttons: "tablecontrols,|,sub,sup,|,hr"
            theme_advanced_toolbar_location: "top",
            theme_advanced_toolbar_align: "left",
            theme_advanced_statusbar_location: "none",
            // resize
            theme_advanced_resizing: true,
            theme_advanced_resize_horizontal: false,
            // dialog
            file_browser_callback: myFileBrowser,
            dialog_type: "modal",
            // paste
            paste_auto_cleanup_on_paste: true,
            paste_strip_class_attributes: "all",
            paste_remove_styles_if_webkit: false,
            paste_retain_style_properties: "*",
            extended_valid_elements: "@[id|class|style|title|dir<ltr?rtl|lang],-span[!style],-strong,#td[colspan|rowspan|align|valign|bgcolor|background|bordercolor|scope]",
            // style, font, brush
            content_css: "/editor/tinymce/contents.css",
            theme_advanced_font_sizes:
                "一号=34px,小一=32px,二号=29px,小二=24px,三号=21px,小三=20px,四号=18px,小四=16px,五号=14px,小五=12px,六号=10px,小六=8px",
            theme_advanced_fonts:
                "宋体=宋体;" +
                "楷体=楷体;" +
                "黑体=黑体;" +
                "华文行楷=华文行楷;" +
                "华文细黑=华文细黑;" +
                "华文新魏=华文新魏;" +
                "微软雅黑=微软雅黑;" +
                "Andale Mono=andale mono,times;" +
                "Arial=arial,helvetica,sans-serif;" +
                "Arial Black=arial black,avant garde;" +
                "Book Antiqua=book antiqua,palatino;" +
                "Comic Sans MS=comic sans ms,sans-serif;" +
                "Courier New=courier new,courier;" +
                "Georgia=georgia,palatino;" +
                "Helvetica=helvetica;" +
                "Impact=impact,chicago;" +
                "Symbol=symbol;" +
                "Tahoma=tahoma,arial,helvetica,sans-serif;" +
                "Terminal=terminal,monaco;" +
                "Times New Roman=times new roman,times;" +
                "Trebuchet MS=trebuchet ms,geneva;" +
                "Verdana=verdana,geneva;" +
                "Webdings=webdings;" +
                "Wingdings=wingdings,zapf dingbats",
            theme_advanced_default_foreground_color: "#0000ff", // Blue
            theme_advanced_default_background_color: "#ffff99", // Light Yellow
            // others
            convert_urls: false,
            // language
            language: "cn"
        });

        window.myFileBrowser = myFileBrowser;

        var TinyMceUI =
            Namespace('Indigox.Web.JsLib.UI.ControlUIs')
            .Class('TinyMceUI')
            .Extend(base)
            .Constructor(
                function (control) {
                    base.constructor.call(this, control);
                    this.maxHeight = null;     // int
                    this.interval = null;      // interval object
                    this.updating = false;
                    this.editorLoaded = false;
                }
            )
            .Static({
                createUI: function (control) {
                    return new TinyMceUI(control);
                }
            })
            .Members({
                setRendered: function () {
                    base.setRendered.apply(this, arguments);

                    if (this.isRendered()) {
                        if ((this.getControl().mode.indexOf('html') >= 0) && editorJsIncluded) {
                            //debug.log("TinyMCE load :" + this.getControl().id);
                            this.initEditor();
                        }
                    }
                },

                onUnload: function () {
                    if (this.editorLoaded) {
                        //debug.log("TinyMCE unload :" + this.getControl().id);
                        this.disposeEditor();
                    }
                },

                onPropertyChanged: function (source, property, value, oldValue) {
                    //debug.log("onPropertyChanged", property, value, oldValue);
                    if (this.updating) {
                        //debug.log("un hanlder");
                        return;
                    }
                    base.onPropertyChanged.apply(this, arguments);
                },

                updateElement: function (property, value) {
                    if (property == 'value') {
                        var element = this.getElement();
                        if (isNullOrUndefined(value)) {
                            value = "";
                        }
                        if (this.editorLoaded === true) {
                            var editor = tinyMCE.get(element.id);
                            if (editor) {
                                editor.setContent(value);
                            }
                            else {
                                element.value = value;
                            }
                        }
                        else {
                            element.value = value;
                        }
                    }
                    else if (property == 'mode') {
                        if (this.editorLoaded) {
                            throw new Error("不允许在富文本编辑控件加载后修改 mode 属性");
                        }
                    }
                    else {
                        base.updateElement.apply(this, arguments);
                    }
                },

                /**
                *  create new tinymce editor, and add it to tinymce collection.
                */
                initEditor: function () {
                    // var delayedTask = new DelayedTask(function () {
                    //     if (!this.editorLoaded) {
                    //         this.doInitEditor();
                    //     }
                    //     this.editorLoaded = true;
                    // }, this, []);
                    // // the element id may be changed, delay 1000 ms to init editor can fix this problem.
                    // delayedTask.delay(200);

                    this.doInitEditor();
                },

                doInitEditor: function () {
                    var element = this.getElement();
                    var editor = new tinyMCE.Editor(element.id, tinyMCE.settings);
                    editor.render();
                    this.listenEditorValueChanged(editor);
                    this.editorLoaded = true;
                },

                /**
                *  remove tinymce editor, andd remove it from tinymce collection.
                */
                disposeEditor: function () {
                    var element = this.getElement();
                    var editor = tinyMCE.get(element.id);
                    editor.destroy();
                    this.editorLoaded = false;
                },

                listenEditorValueChanged: function (editor) {
                    var control = this.getControl();
                    var ui = this;
                    editor.onChange.add(function (ed, l) {
                        //console.debug('Editor contents was modified. Contents: ' + l.content);
                        ui.updating = true;
                        control.setValue(l.content);
                        ui.updating = false;
                    });
                }
            })
        .$();
    });