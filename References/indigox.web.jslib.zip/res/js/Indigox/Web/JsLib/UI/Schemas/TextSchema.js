﻿define("Indigox.Web.JsLib.UI.Schemas.TextSchema",
    [
        "Indigox.Web.JsLib.UI.NodeSchema",
        "Indigox.Web.JsLib.Core"
    ],
function (
        NodeSchema
    ) {
    var base = NodeSchema.prototype;

    var TextSchema =
        Namespace('Indigox.Web.JsLib.UI.Schemas')
        .Class('TextSchema')
        .Extend(base)
        .Constructor(
            function (variable) {
                this.variable = variable;
            }
        )
        .Members({
            getVariable: function () {
                return this.variable;
            },
            accept: function (visitor, data) {
                return visitor.visitText(this, data);
            }
        })
    .$();
} );