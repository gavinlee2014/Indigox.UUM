﻿define("Indigox.Web.JsLib.CQRS.Instruction",
    [
        "Indigox.Web.JsLib.Utils.Deferred",
        "Indigox.Web.JsLib.Utils.ErrorHandler",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Deferred,
        ErrorHandler
) {
    var INSTRUCTION_SUCCEED = 0;

    var base = Deferred.prototype;

    var Instruction =
        Namespace("Indigox.Web.JsLib.CQRS")
        .Class("Instruction")
        .Extend(base)
        .Constructor(
            function (options) {
                base.constructor.call(this);

                if (!options) {
                    options = {};
                }

                this.id = options.id || '';
                this.name = options.name || '';
                this.method = options.method || '';
                this.properties = options.properties || {};

                if (options.callback) {
                    this.done(options.callback);
                }
                if (options.errorCallback) {
                    this.fail(options.errorCallback);
                }
            }
        )
        .Members({
            getId: function () {
                return this.id;
            },

            setId: function (value) {
                this.id = value;
            },

            getName: function () {
                return this.name;
            },

            setName: function (value) {
                this.name = value;
            },

            getMethod: function () {
                return this.method;
            },

            setMethod: function (value) {
                this.method = value;
            },

            getProperties: function () {
                return this.properties;
            },

            setProperties: function (value) {
                this.properties = value;
            },

            parseClientInput: function () {
                var input = {
                    ID: this.getId(),
                    Name: this.getName(),
                    Method: this.getMethod(),
                    Properties: this.getProperties()
                };
                return input;
            },

            parseClientOutput: function (output) {
                if (output.Status >= INSTRUCTION_SUCCEED) {
                    this.setState('succed');
                    var data = output.Result;
                    this.resolve(data);
                }
                else {
                    this.setState('error');
                    var error = output.Error;
                    ErrorHandler.log(["instruction ", this.id, " is fail."/*, "  ---> ", error.message*/].join(""));
                    ErrorHandler.log(error);
                    this.reject(error);
                }
            }
        })
    .$();
});