﻿define("Indigox.Web.JsLib.CQRS.InstructionOptionParser",
    [
        "Indigox.Web.JsLib.CQRS.Command",
        "Indigox.Web.JsLib.CQRS.Query",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Command,
        Query
) {
    var instance = null;

    var InstructionOptionParser =
        Namespace("Indigox.Web.JsLib.CQRS")
        .Class("InstructionOptionParser")
        .Static({
            getInstance: function () {
                if (!instance) {
                    instance = new InstructionOptionParser();
                }
                return instance;
            }
        })
        .Members({
            parseQuery: function (options, method) {
                options.id = IdGenerator.next(options.name);
                options.method = method;
                return new Query(options);
            },

            parseCommand: function (options, method) {
                options.id = IdGenerator.next(options.name);
                options.method = method;
                return new Command(options);
            }
        })
    .$();

    var IdGenerator = (function () {
        var idSeed = {};

        return {
            next: function (name) {
                if (!(name in idSeed)) {
                    idSeed[name] = 1;
                }
                return (name || 'instruction') + '_' + (idSeed[name]++);
            }
        };
    } ());
});