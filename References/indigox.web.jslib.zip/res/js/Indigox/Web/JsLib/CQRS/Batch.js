﻿define("Indigox.Web.JsLib.CQRS.Batch",
    [
        "Indigox.Web.JsLib.Collection.List",
        "Indigox.Web.JsLib.Collection.Hashtable",
        "Indigox.Web.JsLib.Utils.Deferred",
        "Indigox.Web.JsLib.Utils.Delegate",
        "Indigox.Web.JsLib.Utils.UrlUtil",
        "Indigox.Web.JsLib.Utils.StringUtil",
        "Indigox.Web.JsLib.CQRS.InstructionOptionParser",
        "Indigox.Web.JsLib.Connection.Ajax",
        "Indigox.Web.JsLib.Serialization.JsonSerializer",
        "Indigox.Web.JsLib.Core"
    ],
function (
        List,
        Hashtable,
        Deferred,
        Delegate,
        UrlUtil,
        StringUtil,
        InstructionOptionParser,
        Ajax,
        JsonSerializer
) {
    var Batch =
        Namespace("Indigox.Web.JsLib.CQRS")
        .Class("Batch")
        .Constructor(
            function (url, method) {
                this.id = idGenerator.next();
                this.url = url || defaultBatchHandlerUrl;
                this.method = method || defaultBatchHandlerMethod;

                // indexed all instructions, get instruction by id
                this.instructions = new Hashtable();
                // instruction is added to batch, but not done
                this.waitingInstructions = new List();
                // instruction is requesting
                this.requestingInstructions = new List();

                this.serializer = new JsonSerializer();
            }
        )
        .Static({
            beginBatch: function (url, method) {
                return new Batch(url, method);
            },
            getCurrentBatch: function () {
                if (currentBatch == null) {
                    currentBatch = new Batch();
                }
                return currentBatch;
            }
        })
        .Members({
            list: function (options) {
                var query = InstructionOptionParser.getInstance().parseQuery(options, 'List');
                this.addInstruction(query);
                return query.promise();
            },

            single: function (options) {
                var query = InstructionOptionParser.getInstance().parseQuery(options, 'Single');
                this.addInstruction(query);
                return query.promise();
            },

            size: function (options) {
                var query = InstructionOptionParser.getInstance().parseQuery(options, 'Size');
                this.addInstruction(query);
                return query.promise();
            },

            execute: function (options) {
                var command = InstructionOptionParser.getInstance().parseCommand(options, 'Execute');
                this.addInstruction(command);
                return command.promise();
            },

            commit: function (callback, errorCallback) {
                this.preCommit();
                var promise = this.doCommit(true);
                if (callback) {
                    promise.done(callback);
                }
                if (errorCallback) {
                    promise.fail(errorCallback);
                }
                return promise;
            },

            syncCommit: function (callback, errorCallback) {
                this.preCommit();
                var promise = this.doCommit(false);
                if (callback) {
                    promise.done(callback);
                }
                if (errorCallback) {
                    promise.fail(errorCallback);
                }
                return promise;
            },

            //@protected
            preCommit: function () {
                var instructions = this.waitingInstructions.toArray();
                for (var i = 0, length = instructions.length; i < length; i++) {
                    var instruction = instructions[i];
                    //debug.log('remove instruction from waitingInstructions: ' + instruction.getId());
                    this.waitingInstructions.remove(instruction);
                    //debug.log('append instruction to requestingInstructions: ' + instruction.getId());
                    this.requestingInstructions.add(instruction);
                }
            },

            isBusing: function () {
                return this.requestingInstructions.size() > 0;
            },

            hasWaitingInstructions: function () {
                return this.waitingInstructions.size() > 0;
            },

            //@protected
            doCommit: function (async) {
                var inputs = [];

                var instructions = this.requestingInstructions.toArray();
                for (var i = 0, length = instructions.length; i < length; i++) {
                    var instruction = instructions[i];
                    var input = instruction.parseClientInput();
                    inputs.push(input);
                }

                //@debugger
                //this._printInstructions();

                var connection = new Ajax({
                    method: this.method,
                    url: UrlUtil.join(this.url, { r: Math.random().toString().replace('.', '') }),
                    async: async,
                    data: this.serializer.serialize(inputs)
                });

                debug.time(this.id);

                var promise = connection.send();

                promise.progress({ handler: this.onRequestProcess, scope: this })
                       .done({ handler: this.onRequestSucceed, scope: this })
                       .fail({ handler: this.onRequestError, scope: this });

                return Deferred.when(instructions);
            },

            //@private
            //@debugger
            _printInstructions: function () {
                var all = [], waitings = [], requestings = [];
                var i, length, instructions;

                instructions = this.instructions.values();
                for (i = 0, length = instructions.length; i < length; i++) {
                    all.push(instructions[i].id);
                }

                instructions = this.waitingInstructions.toArray();
                for (i = 0, length = instructions.length; i < length; i++) {
                    waitings.push(instructions[i].id);
                }

                instructions = this.requestingInstructions.toArray();
                for (i = 0, length = instructions.length; i < length; i++) {
                    requestings.push(instructions[i].id);
                }

                debug.log(requestings, waitings, all);
            },

            //@debugger
            _getInstructionsDebugInfo: function () {
                var array = [];
                var instructions = this.requestingInstructions.toArray();
                for (var i = 0, length = instructions.length; i < length; i++) {
                    array.push(instructions[i].name + ":" + instructions[i].method);
                }
                return array.join(", ");
            },

            //@protected
            onRequestProcess: function (data) {
                var messenger = Page().getLoadMask();
                if ((data.state == 2) && (data.responseLength)) {
                    if (StringUtil.isNullOrEmpty(messenger.getValue())) {
                        messenger.setValue("加载中...");
                    }
                    if (data.responseLength > (100 * 1024)) {
                        messenger.setValue("数据较多,请耐心等候...");
                    }
                }
            },

            //@protected
            onRequestSucceed: function (data) {
                debug.timeEnd(this.id, this._getInstructionsDebugInfo());

                //debug.time("Batch[" + this.id + "] handler");

                var outputs = this.serializer.deserialize(data);

                for (var i = 0, length = outputs.length; i < length; i++) {
                    var output = outputs[i];
                    var instruction = this.getInstruction(output.ID);
                    if (instruction == null) {
                        //throw new Error("Can't find instruction: " + output.ID);
                        debug.warn("Can't find instruction: " + output.ID);
                        continue;
                    }
                    if (!this.requestingInstructions.contains(instruction)) {
                        continue;
                    }

                    var result = instruction.parseClientOutput(output);

                    this.onInstructionComplete(instruction);
                }

                //debug.timeEnd("Batch[" + this.id + "] handler");

                //debug.log("Batch[" + this.id + "] items", this.items);
            },

            //@protected
            onRequestError: function (error) {
                var instructions = this.requestingInstructions.toArray();
                var errorOutput = {
                    Status: -1,
                    Error: error
                };
                for (var i = 0, length = instructions.length; i < length; i++) {
                    var instruction = instructions[i];
                    instruction.parseClientOutput(errorOutput);
                    this.onInstructionComplete(instruction);
                }

                console.error("Batch failed. --->", error);
            },

            //@protected
            onInstructionComplete: function (instruction) {
                //debug.log('remove instruction from requestingInstructions: ' + instruction.getId());
                this.requestingInstructions.remove(instruction);
                this.instructions.remove(instruction.id);
            },

            //@protected
            addInstruction: function (instruction) {
                this.instructions.put(instruction.getId(), instruction);
                this.waitingInstructions.add(instruction);
            },

            //@protected
            getInstruction: function (id) {
                return this.instructions.get(id);
            }
        })
    .$();

    var idGenerator = (function () {
        var idSeed = {};

        return {
            next: function (name) {
                if (!(name in idSeed)) {
                    idSeed[name] = 1;
                }
                return (name || 'batch') + '_' + (idSeed[name]++);
            }
        };
    } ());

    var defaultBatchHandlerUrl = '_remoting/call?_remotingcommand=batch';
    var defaultBatchHandlerMethod = 'CALL';
    var currentBatch = null;
});