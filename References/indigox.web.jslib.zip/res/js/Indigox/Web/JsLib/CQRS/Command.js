﻿define("Indigox.Web.JsLib.CQRS.Command",
    [
        "Indigox.Web.JsLib.CQRS.Instruction",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Instruction
) {
    var base = Instruction.prototype;

    var Command =
        Namespace("Indigox.Web.JsLib.CQRS")
        .Extend(base)
        .Class("Command")
        .Constructor(
            function (options) {
                base.constructor.apply(this, arguments);
            }
        )
    .$();
});