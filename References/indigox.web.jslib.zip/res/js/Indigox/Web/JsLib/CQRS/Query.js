﻿define("Indigox.Web.JsLib.CQRS.Query",
    [
        "Indigox.Web.JsLib.CQRS.Instruction",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Instruction
) {
    var base = Instruction.prototype;

    var Query =
        Namespace("Indigox.Web.JsLib.CQRS")
        .Extend(base)
        .Class("Query")
        .Constructor(
            function (options) {
                base.constructor.apply(this, arguments);
            }
        )
    .$();
});