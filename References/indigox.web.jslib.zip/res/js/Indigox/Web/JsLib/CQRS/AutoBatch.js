﻿define("Indigox.Web.JsLib.CQRS.AutoBatch",
    [
        "Indigox.Web.JsLib.CQRS.Batch",
        "Indigox.Web.JsLib.Utils.DelayedTask",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Batch,
        DelayedTask
) {
    var base = Batch.prototype;

    var AutoBatch =
        Namespace("Indigox.Web.JsLib.CQRS")
        .Extend(base)
        .Class("AutoBatch")
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.id = "Auto" + this.id;
                this.delayedTask = null;
            }
        )
        .Static({
            getCurrentBatch: function () {
                if (currentBatch == null) {
                    currentBatch = new AutoBatch();
                    currentBatch.id = "AutoBatch";
                }
                return currentBatch;
            }
        })
        .Members({
            commit: function () {
                if (this.delayedTask) {
                    this.delayedTask.cancel();
                }

                this.delayedTask = new DelayedTask(function () {
                    base.commit.call(this).always({
                        handler: function () {
                            if (this.hasWaitingInstructions()) {
                                this.commit();
                            }
                        },
                        scope: this
                    });
                    this.delayedTask = null;
                }, this, []);

                this.delayedTask.delay(50);
            },

            //@protected
            addInstruction: function (instruction) {
                base.addInstruction.apply(this, arguments);
                if (!this.isBusing()) {
                    this.commit();
                }
            }
        })
    .$();

    var currentBatch = null;
});