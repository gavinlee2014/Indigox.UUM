﻿define("Indigox.Web.JsLib.Manipulators.Manipulator",
    [
        "Indigox.Web.JsLib.DOM.Element",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Element
    ) {
    var El = Element.el;

    var Manipulator =
        Namespace("Indigox.Web.JsLib.Manipulators")
        .Class("Manipulator")
        .Constructor(
            function (element, attribute) {
                this.element = El(element);
                this.attribute = attribute;
            }
        )
        .Members({
            getElement: function () {
                return this.element;
            },
            getAttribute: function () {
                return this.attribute;
            },
            write: function (value) {
            },
            read: function () {
            }
        })
    .$();
});