﻿define("Indigox.Web.JsLib.Manipulators.TextNodeManipulator",
    [
        "Indigox.Web.JsLib.Manipulators.Manipulator",
        "Indigox.Web.JsLib.Utils.ArrayUtil",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Manipulator,
        ArrayUtil
    ) {

    var base = Manipulator.prototype;
    var TextNodeManipulator =
        Namespace("Indigox.Web.JsLib.Manipulators")
        .Class("TextNodeManipulator")
        .Extend(base)
        .Constructor(
            function (element, attribute) {
                base.constructor.apply(this, arguments);
            }
        )
        .Members({
            write: function (value) {
                if (this.element.element != null) {
                    this.element.setText(value);
                }
            },
            read: function () {
                if (this.element.firstChild != null) {
                    return this.element.getText();
                }
                return null;
            }
        })
    .$();
} );