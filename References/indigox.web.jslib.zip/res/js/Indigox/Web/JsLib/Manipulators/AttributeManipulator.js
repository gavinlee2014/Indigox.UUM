﻿define("Indigox.Web.JsLib.Manipulators.AttributeManipulator",
    [
        "Indigox.Web.JsLib.Manipulators.Manipulator",
        "Indigox.Web.JsLib.Utils.ArrayUtil",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Manipulator,
        ArrayUtil
    ) {

    var base = Manipulator.prototype;
    
    var AttributeManipulator =
        Namespace("Indigox.Web.JsLib.Manipulators")
        .Class("AttributeManipulator")
        .Extend(base)
        .Constructor(
            function (element, attribute) {
                base.constructor.apply(this, arguments);
            }
        )
        .Members({
            write: function (value) {
                if (this.element.hasAttribute(this.attribute)) {
                    this.element.setAttribute(this.attribute, value);
                }
            },
            read: function () {
                return this.element.getAttribute(this.attribute);
            }
        })
    .$();
} );