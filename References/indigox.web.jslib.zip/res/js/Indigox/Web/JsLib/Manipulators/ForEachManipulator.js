﻿define("Indigox.Web.JsLib.Manipulators.ForEachManipulator",
    [
        "Indigox.Web.JsLib.Manipulators.Manipulator",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Manipulator
    ) {

    var base = Manipulator.prototype;

    var ForEachManipulator =
        Namespace("Indigox.Web.JsLib.Manipulators")
        .Class("ForEachManipulator")
        .Extend(base)
        .Constructor(
            function (elements, parent) {
                this.element = elements;
                this.parentElement = parent;
            }
        )
        .Members({
            write: function (value) {
            },

            insert: function (index, element) {
                if (index >= this.element.length || this.element.length === 0) {
                    this.parentElement.appendChild(element);
                    this.element.splice(index, 0, element);
                }
                else {
                    this.parentElement.insertBefore(element, this.element[index]);
                    this.element.splice(index, 0, element);
                }
            },

            remove: function (index) {
                this.parentElement.removeChild(this.element[index]);
                this.element.splice(index, 1);
            },

            read: function () {
                return this.element;

                //var values = [];
                //var i = null, length = null;
                //for (i = 0, length = this.element.length; i < length; i++) {
                //    var element = this.element[i];
                //    var control = Indigox.Web.JsLib.UI.UIManager.getInstance().createControl(element);
                //    if (element.id) {
                //        control.setName(element.id);
                //    }
                //    values.push(control);
                //}
                //return values;
            }
        })
    .$();
} );