﻿define("Indigox.Web.JsLib.Manipulators.StyleManipulator",
    [
        "Indigox.Web.JsLib.Manipulators.Manipulator",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Manipulator
    ) {

    var base = Manipulator.prototype;

    var StyleManipulator =
        Namespace("Indigox.Web.JsLib.Manipulators")
        .Class("StyleManipulator")
        .Extend(base)
        .Constructor(
            function (element, attribute) {
                base.constructor.apply(this, arguments);
            }
        )
        .Members({
            write: function (value) {
                this.element.setStyle(this.attribute, value);
            },
            read: function () {
                return this.element.getStyle(this.attribute);
            }
        })
    .$();
});