﻿define("Indigox.Web.JsLib.Manipulators.ControlManipulator",
    [
        "Indigox.Web.JsLib.Manipulators.Manipulator",
        "jquery",
        "Indigox.Web.JsLib.Core"
    ],
    function (
        Manipulator,
        jQuery
    ) {
        var base = Manipulator.prototype;

        var ControlManipulator =
            Namespace("Indigox.Web.JsLib.Manipulators")
            .Class("ControlManipulator")
            .Extend(base)
            .Constructor(
                function (element, parent, nextSibling) {
                    //base.constructor.call(this, element, "");
                    this.element = element;
                    this.parentElement = parent;
                    this.nextSibling = nextSibling;
                }
            )
            .Members({
                write: function (element) {
                    var newElement = jQuery(element).get(0);
                    if (this.element) {
                        this.parentElement.replaceChild(element, this.element);
                    }
                    else if (this.nextSibling) {
                        this.parentElement.insertBefore(element, this.nextSibling);
                    }
                    else {
                        this.parentElement.appendChild(element);
                    }
                    this.element = element;
                },

                read: function () {
                    return this.element;

                    //if (this.element == null) {
                    //    return null;
                    //}
                    //var element = this.element;
                    //var control = Indigox.Web.JsLib.UI.UIManager.getInstance().createControl(element);
                    //if (element.id) {
                    //    control.setName(element.id);
                    //}
                    //return control;
                }
            })
        .$();
    });