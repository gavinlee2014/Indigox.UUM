﻿define("Indigox.Web.JsLib.Manipulators.HTMLManipulator",
    [
        "Indigox.Web.JsLib.Manipulators.Manipulator",
        "Indigox.Web.JsLib.Utils.DOMUtil",
        "Indigox.Web.JsLib.Utils.ArrayUtil",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Manipulator,
        DOMUtil  ,
        ArrayUtil
    ) {

    var base = Manipulator.prototype;

    var HTMLManipulator =
        Namespace("Indigox.Web.JsLib.Manipulators")
        .Class("HTMLManipulator")
        .Extend(base)
        .Constructor(
            function (element, attribute) {
                base.constructor.apply(this, arguments);
            }
        )
        .Members({
            write: function (value) {
                DOMUtil.setAttribute(this.element.element, "innerHTML", value);
            },
            read: function () {
                return DOMUtil.getAttribute(this.element.element, "innerHTML"); //this.element.getAttribute(this.attribute);
            }
        })
    .$();
} );