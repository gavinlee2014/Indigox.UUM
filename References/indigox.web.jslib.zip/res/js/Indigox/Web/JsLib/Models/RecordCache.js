﻿define("Indigox.Web.JsLib.Models.RecordCache",
    [
        "Indigox.Web.JsLib.Models.Model",
        "Indigox.Web.JsLib.Utils.ObjectUtil",
        "Indigox.Web.JsLib.DOM.Element",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Model,
        ObjectUtil,
        Element
) {



    var base = Model.prototype;

    var LISTENER_FIELD_CHANGED = 'FieldChanged';

    var RecordCache =
        Namespace("Indigox.Web.JsLib.Models")
        .Class("RecordCache")
        .Extend(base)
        .Constructor(
            function (recordManager, name) {
                this.recordManager = recordManager;
                this.name = name;
                this.cache = {};
                /*由于cache是全局的，所以cache中的Record总是会保持所有监听
                但在页面切换时，同一个record可能会被重复监听，所以此时清空cache，让record重新创建，以保证不会被重复监听*/
                Element.el(window).addListener("hashchange", function () { this.clear(); }, this);
            }
        )
        .Members({
            getIdentity: function (record) {
                var schema = this.recordManager.getDataSchema(this.name);
                var primaryKey = schema.getPrimaryKey();
                if (primaryKey) {
                    return primaryKey.toIdentity(record);
                }
                else {
                    return null;
                }
            },
            getRecords: function () {
                return ObjectUtil.getValues(this.cache);
            },
            get: function (identity) {
                return this.cache[identity];
            },
            contains: function (record) {
                var identity = this.getIdentity(record);
                if (identity) {
                    return identity in this.cache;
                }
                else {
                    return false;
                }
            },
            add: function (record) {
                var identity = this.getIdentity(record);
                this.cache[identity] = record;
            },
            remove: function (record) {
                var identity = this.getIdentity(record);
                delete this.cache[identity];
            },
            merge: function (record) {
                var identity = this.getIdentity(record);
                var oldRecord = this.get(identity);
                var schema = this.recordManager.getDataSchema(this.name);
                schema.mergeRecords(oldRecord, record);
                return oldRecord;
            },
            clear: function () {
                this.cache = {};
            }
        })
    .$();

});