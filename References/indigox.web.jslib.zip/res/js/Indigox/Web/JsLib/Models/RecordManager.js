﻿define("Indigox.Web.JsLib.Models.RecordManager",
    [
        "Indigox.Web.JsLib.Collection.List",
        "Indigox.Web.JsLib.Models.DataAdapter",
        "Indigox.Web.JsLib.Models.RecordSet",
        "Indigox.Web.JsLib.Models.DataSchema",
        "Indigox.Web.JsLib.Models.RecordCache",
        "Indigox.Web.JsLib.Core"
    ],
function (
        List,
        DataAdapter,
        RecordSet,
        DataSchema,
        RecordCache
) {



    var instance = null;

    var RecordManager =
        Namespace("Indigox.Web.JsLib.Models")
        .Class("RecordManager")
        .Constructor(
            function () {
                this.dataSchemas = {};
                this.recordCaches = {};
                this.recordSetLists = {};
            }
        )
        .Static({
            getInstance: function () {
                if (isNullOrUndefined(instance)) {
                    instance = new RecordManager();
                }
                return instance;
            }
        })
        .Members({
            register: function (name, schema) {
                this.dataSchemas[name] = new DataSchema(this, name, schema);
                this.recordCaches[name] = new RecordCache(this, name);
                this.recordSetLists[name] = new List();
            },
            unregister: function (name) {
                delete this.dataSchemas[name];
                delete this.recordCaches[name];
                delete this.recordSetLists[name];
            },
            getDataSchema: function (name) {
                return this.dataSchemas[name];
            },
            getRecordCache: function (name) {
                return this.recordCaches[name];
            },
            getRecordSetList: function (name) {
                return this.recordSetLists[name];
            },
            createRecordSet: function (name, config) {
                var recordSetList = this.getRecordSetList(name);
                if (isNullOrUndefined(recordSetList)) {
                    throw new Error(['Can not create new RecordSet. Because the data schema "', name, '" was not registered. '].join(''));
                }
                var recordSet = new RecordSet(this, name);
                recordSet.configure(config);
                recordSet.addListener(this);
                recordSetList.add(recordSet);
                return recordSet;
            },
            destroyRecordSet: function (recordSet) {
                var recordSetList = this.getRecordSetList(name);
                recordSetList.remove(recordSet);
            },
            createDataAdapter: function (recordSets, mapping) {
                var adapter = new DataAdapter(this, recordSets, mapping);
                return adapter;
            },

            destroyRecord: function (name, record) {
                var recordSetList = this.getRecordSetList(name);
                var i = null,
                    length = null;
                for (i = 0, length = recordSetList.size(); i < length; i++) {
                    recordSetList.get(i).removeRecord(record);
                }

                //var recordCache = this.getRecordCache(name);
                //recordCache.remove(record);
            },

            onRecordRemoved: function (source, index, record) {
                var schemaName = source.schemaName;
                this.destroyRecord(schemaName, record);
            }

        })
    .$();

});