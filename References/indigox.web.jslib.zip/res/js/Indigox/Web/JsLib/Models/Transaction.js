﻿define("Indigox.Web.JsLib.Models.Transaction",
    [
        "Indigox.Web.JsLib.Utils.Configurable",
        "Indigox.Web.JsLib.Collection.List",
        "Indigox.Web.JsLib.Utils.Callback",
        "Indigox.Web.JsLib.Core"
    ],
    function (
        Configurable,
        List,
        Callback
    ) {
        var base = Configurable.prototype;

        var COMMIT_SUCCEED = 0,
            COMMIT_ERROR = -1;

        var Transaction =
            Namespace("Indigox.Web.JsLib.Models")
            .Class("Transaction")
            .Extend(base)
            .Constructor(
                function (recordSet) {
                    this.recordSet = recordSet;
                    this.records = new List();
                    this.successed = true;
                }
            )
            .Members({
                process: function (record) {
                    if (this.records.contains(record)) {
                        return;
                    }
                    this.records.add(record);
                },
                commit: function (proxy, callback) {
                    this.successed = true;

                    var recordSet = this.recordSet,
                        record = null,
                        rawData = null,
                        records = this.records.clone();

                    var i = null,
                        length = records.size();
                    if (length > 0) {
                        for (i = 0; i < length; i++) {
                            record = records.get(i);
                            rawData = recordSet.convertRawData(record);
                            var commitCallback = new Callback(this.doCommit, this, [record, callback]);
                            if (record.isDirty()) {
                                if (record.isCreate()) {
                                    proxy.create(rawData, commitCallback);
                                }
                                else if (record.isUpdate()) {
                                    proxy.update(rawData, commitCallback);
                                }
                                else {
                                    proxy.destroy(rawData, commitCallback);
                                }
                            }
                            else {
                                this.doCommit(COMMIT_SUCCEED, record, callback);
                            }
                        }
                    }
                    else {
                        callback = Callback.createInstance(callback);
                        if (callback) {
                            callback.invoke(true);
                        }
                    }
                },

                doCommit: function (state, record, callback) {
                    if (state == COMMIT_SUCCEED) {
                        record.accept();
                    }
                    else {
                        this.successed = false;
                    }
                    this.records.remove(record);
                    if (this.records.size() === 0) {
                        callback = Callback.createInstance(callback);
                        if (callback) {
                            callback.invoke(this.successed);
                        }
                    }
                },

                rollback: function () {
                    var i = null,
                        length = null;

                    var records = this.records,
                        record = null;
                    for (i = 0, length = records.size(); i < length; i++) {
                        record = records.get(i);
                        if (record.isDirty()) {
                            record.reject();
                        }
                    }

                    this.recordSet.setTransaction(null);
                }
            })
        .$();
    });