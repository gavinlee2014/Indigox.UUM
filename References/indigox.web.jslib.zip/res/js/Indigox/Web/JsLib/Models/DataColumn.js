﻿define("Indigox.Web.JsLib.Models.DataColumn",
    [
        "Indigox.Web.JsLib.Models.IncrementGenerator",
        "Indigox.Web.JsLib.Models.GuidGenerator",
        "Indigox.Web.JsLib.Models.IdentifierGenerator",
        "Indigox.Web.JsLib.Core"
    ],
function (
        IncrementGenerator,
        GuidGenerator,
        IdentifierGenerator
) {



    var DataColumn =
        Namespace("Indigox.Web.JsLib.Models")
        .Class("DataColumn")
        .Constructor(
            function (schema, options) {
                this.schema = schema;
                this.name = options.name;
                this.text = options.text;
                this.type = options.type;
                this.readonly = options.readonly;
                this.defaultValue = isNullOrUndefined(options.defaultValue) ? null : options.defaultValue;
                this.generator = DataColumn.createGenerator(options);
            }
        )
        .Static({
            createGenerator: function (options) {
                var generator = null;
                if ('increment' in options) {
                    return new IncrementGenerator(options.increment);
                }
                else if ('guid' in options) {
                    return new GuidGenerator();
                }
            }
        })
        .Members({
            getName: function () {
                return this.name;
            },
            getText: function () {
                return this.text;
            },
            getType: function () {
                return this.type;
            },
            getGenerator: function () {
                return this.generator;
            },
            getDefaultValue: function () {
                return this.defaultValue;
            },
            setDefaultValue: function (value) {
                if (isNullOrUndefined(value)) {
                    return;
                }
                this.defaultValue = value;
            },
            convert: function (value) {
                if (isNullOrUndefined(value)) {
                    if (this.generator) {
                        return this.generator.generate();
                    }
                    else {
                        return this.getDefaultValue();
                    }
                }
                else {
                    if (this.generator) {
                        this.generator.recofigure(value);
                    }
                    return value;
                }
            }
        })
    .$();

});