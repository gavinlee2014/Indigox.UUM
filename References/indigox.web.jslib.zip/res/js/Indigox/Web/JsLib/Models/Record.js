﻿define("Indigox.Web.JsLib.Models.Record",
    [
        "Indigox.Web.JsLib.Models.Model",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Model
) {

    var base = Model.prototype;

    var LISTENER_FIELD_CHANGED = 'FieldChanged';

    var Record =
        Namespace("Indigox.Web.JsLib.Models")
        .Class("Record")
        .Extend(base)
        .Constructor(
            function (recordManager, schemaName) {
                base.constructor.apply(this, arguments);
                this.recordManager = recordManager;
                this.schemaName = schemaName;
                this.data = {};
                this.timestamp = new Date();
                this.dirty = Record.DIRTY_CLEAN;
                this.modified = {};
                this.listeners.registerListeners(
                    LISTENER_FIELD_CHANGED
                );
            }
        )
        .Static({
            DIRTY_CLEAN: 0,
            DIRTY_CREATE: 1,
            DIRTY_UPDATE: 2,
            DIRTY_DELETE: 3
        })
        .Members({
            getSchema: function () {
                return this.recordManager.getDataSchema(this.schemaName);
            },
            contains: function (column) {
                return this.getSchema().contains(column);
            },
            getIdentity: function () {
                var schema = this.recordManager.getDataSchema(this.schemaName);
                var primaryKey = schema.getPrimaryKey();
                if (primaryKey) {
                    return primaryKey.toIdentity(this);
                }
                else {
                    return null;
                }
            },
            set: function (column, value) {
                var oldValue = this.get(column);
                if (oldValue === value) {
                    return;
                }
                if (!this.isDirty()) {
                    this.markForUpdate();
                }
                this.modified[column] = this.get(column);
                this.data[column] = value;
                if (this.modified[column] != value) {
                    this.listeners.fire(LISTENER_FIELD_CHANGED, [column, value, oldValue]);
                }
            },
            get: function (column) {
                return this.data[column];
            },
            getTimestamp: function () {
                return this.timestamp;
            },
            getDirty: function () {
                return this.dirty;
            },
            isDirty: function () {
                return this.dirty !== Record.DIRTY_CLEAN;
            },
            isCreate: function () {
                return this.dirty === Record.DIRTY_CREATE;
            },
            isUpdate: function () {
                return this.dirty === Record.DIRTY_UPDATE;
            },
            isDelete: function () {
                return this.dirty === Record.DIRTY_DELETE;
            },
            isModified: function (column) {
                return column in this.modified;
            },
            mergeFrom: function (record, column) {
                this.timestamp = record.timestamp;
                this.data[column] = record.get(column);
            },
            accept: function () {
                this.dirty = Record.DIRTY_CLEAN;
                this.modified = {};
            },
            reject: function () {
                for (var column in this.modified) {
                    this.data[column] = this.modified[column];
                }
                this.dirty = Record.DIRTY_CLEAN;
                this.modified = {};
            },
            markForCreate: function () {
                this.dirty = Record.DIRTY_CREATE;
            },
            markForUpdate: function () {
                this.dirty = Record.DIRTY_UPDATE;
            },
            markForDelete: function () {
                this.dirty = Record.DIRTY_DELETE;
            },
            markForClean: function () {
                this.dirty = Record.DIRTY_CLEAN;
            }
        })
    .$();

});