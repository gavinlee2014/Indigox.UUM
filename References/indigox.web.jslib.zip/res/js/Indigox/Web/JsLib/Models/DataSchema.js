﻿define("Indigox.Web.JsLib.Models.DataSchema",
    [
        "Indigox.Web.JsLib.Utils.ObjectUtil",
        "Indigox.Web.JsLib.Models.DataColumn",
        "Indigox.Web.JsLib.Models.Constraint",
        "Indigox.Web.JsLib.Models.ForeignKey",
        "Indigox.Web.JsLib.Models.Record",
        "Indigox.Web.JsLib.Core"
    ],
function (
        ObjectUtil,
        DataColumn,
        Constraint,
        ForeignKey,
        Record
) {



    var DataSchema =
        Namespace("Indigox.Web.JsLib.Models")
        .Class("DataSchema")
        .Constructor(
            function (recordManager, name, schema) {
                this.recordManager = recordManager;
                this.name = name;
                this.columns = {};
                this.primaryKey = null;
                this.constraints = [];
                this.foreignKeys = [];
                this.initColumns(schema.columns);

                this.initPrimaryKey(schema.primaryKey);

                if (schema.foreignKeys) {
                    this.initForeignKey(schema.foreignKeys);
                }
                if (schema.constraints) {
                    this.initConstraints(schema.constraints);
                }
            }
        )
        .Members({
            initColumns: function (columns) {
                var i = null,
                    length = null;
                for (i = 0, length = columns.length; i < length; i++) {
                    this.columns[columns[i].name] = new DataColumn(this, columns[i]);
                }
            },
            initPrimaryKey: function (primaryKey) {
                if (isNullOrUndefined(primaryKey) || primaryKey.length === 0) {
                    var primaryKeyID = this.name + "_ID";
                    var column = { name: primaryKeyID, text: primaryKeyID, increment: {} };
                    this.columns[primaryKeyID] = new DataColumn(this, column);
                    this.primaryKey = new Constraint(this, [primaryKeyID]);
                }
                else {
                    this.primaryKey = new Constraint(this, primaryKey);
                }
            },
            initForeignKey: function (foreignKeys) {
                var i = null,
                    length = null;
                for (i = 0, length = foreignKeys.length; i < length; i++) {
                    var foreignKey = new ForeignKey(this, foreignKeys[i]);
                    this.foreignKeys.push(foreignKey);
                }
            },
            initConstraints: function (constraints) {
                var i = null,
                    length = null;
                for (i = 0, length = constraints.length; i < length; i++) {
                    this.constraints.push(new Constraint(this, constraints[i]));
                }
            },
            getName: function () {
                return this.name;
            },
            getColumns: function () {
                return ObjectUtil.getValues(this.columns);
            },
            getColumn: function (name) {
                var column = this.columns[name];
                if (column) {
                    return column;
                }
                else {
                    return null;
                }
            },
            contains: function (column) {
                return column in this.columns;
            },
            getPrimaryKey: function () {
                return this.primaryKey;
            },
            getForeignKeys: function () {
                return this.foreignKeys;
            },
            createRecord: function (data) {
                return this.toRecord(data);
            },

            toRecord: function (rawData) {
                var record = new Record(this.recordManager, this.name);
                var columns = this.columns;
                var column = null,
                    constraint = null,
                    name = null,
                    value = null;
                for (name in columns) {
                    column = columns[name];
                    value = column.convert(rawData[column.getName()]);
                    record.set(column.getName(), value);
                }
                record.accept();

                return record;
            },
            toRawData: function (record) {
                var rawData = {};
                var columns = this.columns;
                var column = null,
                    value = null;
                var i = null,
                    length = null;
                for (column in columns) {
                    value = record.get(column);
                    if (!isNullOrUndefined(value)) {
                        rawData[column] = value;
                    }
                }
                return rawData;
            },
            mergeRecords: function (oldRecord, newRecord) {
                if (oldRecord.getTimestamp() > newRecord.getTimestamp()) {
                    return;
                }
                var columns = this.columns;
                var column = null,
                    name = null,
                    value = null;
                for (name in columns) {
                    column = columns[name];
                    value = newRecord.get(column.getName());
                    if (value !== oldRecord.get(column.getName()) && !oldRecord.isModified(column.getName())) {
                        oldRecord.mergeFrom(newRecord, column.getName());
                    }
                }
            },
            validate: function (record) {
                var primaryKey = this.primaryKey;
                primaryKey.validate(record);

                var constraints = this.constraints, constraint;
                for (var name in constraints) {
                    constraint = this.constraints[name];
                    constraint.validate(record);
                }
            }
        })
    .$();

});