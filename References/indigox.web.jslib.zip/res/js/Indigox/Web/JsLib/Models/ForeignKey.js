﻿define("Indigox.Web.JsLib.Models.ForeignKey",
    [
        "Indigox.Web.JsLib.Models.Constraint",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Constraint
) {

    var base = Constraint.prototype;

    var ForeignKey =
        Namespace("Indigox.Web.JsLib.Models")
        .Class("ForeignKey")
        .Extend(base)
        .Constructor(
            function (schema, foreignKey) {
                this.schema = schema;
                this.columns = [];
                this.referencedColumns = [];
                this.referencedSchema = null;
                this.init(foreignKey);
            }
        )
        .Members({
            init: function (foreignKey) {
                var schema = this.schema;

                var columns = foreignKey.columns;
                for (var i = 0, length = columns.length; i < length; i++) {
                    this.columns.push(schema.getColumn(columns[i]));
                }

                this.referencedSchema = foreignKey.referencedSchema;

                var referencedColumns = foreignKey.referencedColumns;
                for (var i = 0, length = referencedColumns.length; i < length; i++) {
                    this.referencedColumns.push(schema.getColumn(referencedColumns[i]));
                }
            },

            getColumns: function () {
                return this.columns;
            },

            getReferencedColumns: function () {
                return this.referencedColumns;
            },

            getReferencedSchema: function () {
                return this.referencedSchema;
            }
        })
    .$();

});