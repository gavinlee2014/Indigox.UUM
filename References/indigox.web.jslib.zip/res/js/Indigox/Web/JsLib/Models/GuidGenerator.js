﻿define("Indigox.Web.JsLib.Models.GuidGenerator",
    [
        "Indigox.Web.JsLib.Models.IdentifierGenerator",
        "Indigox.Web.JsLib.Utils.StringUtil",
        "Indigox.Web.JsLib.Core"
    ],
function (
        IdentifierGenerator,
        StringUtil
) {



    var base = IdentifierGenerator.prototype;

    var GuidGenerator =
        Namespace("Indigox.Web.JsLib.Models")//
        .Class("GuidGenerator")//
        .Extend(base)
        .Constructor(
            function (options) {
            }
        )
        .Members({
            recofigure: function (value) {
            },
            generate: function () {
                return StringUtil.newGuid();
            }
        })
    .$();

});