﻿define("Indigox.Web.JsLib.Models.Constraint",
    [
        "Indigox.Web.JsLib.Core"
    ],
function (

) {

    var Constraint =
        Namespace("Indigox.Web.JsLib.Models")
        .Class("Constraint")
        .Constructor(
            function (schema, columns) {
                this.schema = schema;
                this.columns = [];
                this.init(columns);
            }
        )
        .Members({
            init: function (columns) {
                var schema = this.schema;
                for (var i = 0, length = columns.length; i < length; i++) {
                    this.columns.push(schema.getColumn(columns[i]));
                }
            },
            validate: function (record) {
                return true;
            },
            toIdentity: function (record) {
                var columns = this.columns;
                var identity = [];
                for (var i = 0, length = columns.length; i < length; i++) {
                    var value = record.get(columns[i].getName());
                    identity.push(value);
                }

                return identity.join('#');
            }
        })
    .$();

});