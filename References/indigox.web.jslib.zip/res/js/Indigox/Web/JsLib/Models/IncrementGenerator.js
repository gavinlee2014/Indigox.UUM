﻿define("Indigox.Web.JsLib.Models.IncrementGenerator",
    [
        "Indigox.Web.JsLib.Models.IdentifierGenerator",
        "Indigox.Web.JsLib.Core"
    ],
function (
        IdentifierGenerator
) {

    var base = IdentifierGenerator.prototype;

    var IncrementGenerator =
        Namespace("Indigox.Web.JsLib.Models")//
        .Class("IncrementGenerator")//
        .Extend(base)
        .Constructor(
            function (options) {
                this.seed = options ? options.seed || 0 : 0;
                this.increment = options ? options.increment || 1 : 1;
            }
        )
        .Members({
            recofigure: function (value) {
                this.seed = Math.max(this.seed, value);
            },
            getSeed: function () {
                return this.seed;
            },
            getIncrement: function () {
                return this.increment;
            },
            generate: function () {
                this.seed += this.increment;
                return this.seed;
            }
        })
    .$();

});