﻿define("Indigox.Web.JsLib.Models.IdentifierGenerator",
    [
        "Indigox.Web.JsLib.Utils.Configurable",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Configurable
) {

    var base = Configurable.prototype;

    var IdentifierGenerator =
        Namespace("Indigox.Web.JsLib.Models")//
        .Class("IdentifierGenerator")//
        .Extend(base)
        .Constructor(
            function (options) {
            }
        )
        .Members({
            recofigure: function (value) {
            },
            generate: function () {
            }
        })
    .$();

});