﻿define("Indigox.Web.JsLib.Models.DataAdapter",
    [
        "Indigox.Web.JsLib.Utils.Configurable",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Configurable
) {

    var base = Configurable.prototype;

    var DataAdapter =
        Namespace("Indigox.Web.JsLib.Models")
        .Class("DataAdapter")
        .Extend(base)
        .Constructor(
            function (recordManager, recordSets, mapping) {
                this.recordManager = recordManager;
                this.recordSets = recordSets;
                this.mapping = mapping;
                this.init(recordSets);
            }
        )
        .Members({
            init: function (recordSets) {
                for (var name in recordSets) {
                    recordSets[name].setAdapter(this);
                }
            },

            toRecord: function (schemaName, rawData) {
                var recordset = this.recordSets[schemaName];
                var schema = recordset.getSchema();
                var record = schema.toRecord(rawData);

                var recordCache = this.recordManager.getRecordCache(schemaName);
                if (recordCache.contains(record)) {
                    record = recordCache.merge(record);
                }
                else {
                    record.addListener(this);
                    recordCache.add(record);
                }

                var property = null;
                for (var name in this.recordSets) {
                    if (this.isReferenced(recordset, this.recordSets[name])) {
                        property = this.mapping[name];
                        if (isNullOrUndefined(property)) {
                            property = name;
                        }
                        this.fillRecordSet(name, rawData[property]);
                    }
                }
                return record;
            },

            toRawData: function (schemaName, record) {
                var recordset = this.recordSets[schemaName];
                var schema = recordset.getSchema();
                var rawData = schema.toRawData(record);

                var property = null;
                for (var name in this.recordSets) {
                    if (this.isReferenced(recordset, this.recordSets[name])) {
                        property = this.mapping[name];
                        if (isNullOrUndefined(property)) {
                            property = name;
                        }
                        rawData[property] = this.buildRawData(name);
                    }
                }

                return rawData;
            },

            fillRecordSet: function (schema, rawData) {
                if (isNullOrUndefined(rawData)) {
                    return;
                }
                var record = null,
                    recordset = this.recordSets[schema];

                var i = null,
                    length = null;
                for (i = 0, length = rawData.length; i < length; i++) {
                    record = this.toRecord(schema, rawData[i]);
                    recordset.addRecord(record);
                    record.accept();
                }
            },

            buildRawData: function (schema) {
                var rawData = [];

                var record = null,
                    recordset = this.recordSets[schema];

                var i = null,
                    length = null;
                for (i = 0, length = recordset.size(); i < length; i++) {
                    record = recordset.getRecord(i);
                    rawData.push(this.toRawData(schema, record));
                }
                return rawData;
            },

            isReferenced: function (referenced, referencing) {
                var referencedSchema = referenced.getSchema().getName();

                if (referencedSchema === referencing.getSchema().getName()) {
                    return false;
                }

                var foreignkeys = referencing.getSchema().getForeignKeys();
                var i = null,
                    length = null;
                for (i = 0, length = foreignkeys.length; i < length; i++) {
                    if (foreignkeys[i].getReferencedSchema() === referencedSchema) {
                        return true;
                    }
                }
                return false;
            },

            clearReference: function (recordset) {
                for (var name in this.recordSets) {
                    if (this.isReferenced(recordset, this.recordSets[name])) {
                        this.recordSets[name].clearRecord();
                    }
                }
            }
        })
    .$();

});