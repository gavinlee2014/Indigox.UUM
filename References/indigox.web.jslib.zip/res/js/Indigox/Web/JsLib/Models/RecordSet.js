﻿define("Indigox.Web.JsLib.Models.RecordSet",
    [
        "Indigox.Web.JsLib.Proxy.Proxy",
        "Indigox.Web.JsLib.Models.Model",
        "Indigox.Web.JsLib.Utils.ArrayUtil",
        "Indigox.Web.JsLib.Models.Transaction",
        "Indigox.Web.JsLib.Models.Record",
        "Indigox.Web.JsLib.Utils.Callback",
        "Indigox.Web.JsLib.Core"
    ],
    function (
        Proxy,
        Model,
        ArrayUtil,
        Transaction,
        Record,
        Callback
    ) {
        var base = Model.prototype;

        var LISTENER_RECORD_ADDED = 'RecordAdded',
            LISTENER_RECORD_REMOVED = 'RecordRemoved';

        var RecordSet =
            Namespace("Indigox.Web.JsLib.Models")
            .Class("RecordSet")
            .Extend(base)
            .Constructor(
                function (recordManager, schemaName) {
                    base.constructor.apply(this, arguments);
                    this.recordManager = recordManager;
                    this.schemaName = schemaName;
                    this.adapter = null;
                    this.proxy = null;
                    this.lastParams = {};
                    this.addRecords = false;
                    this.data = [];
                    this.dataIndexer = {};
                    this.listeners.registerListeners(
                        LISTENER_RECORD_ADDED,
                        LISTENER_RECORD_REMOVED
                    );
                }
            )
            .Members({
                getSchema: function () {
                    return this.recordManager.getDataSchema(this.schemaName);
                },

                setAdapter: function (value) {
                    this.adapter = value;
                },

                getAdapter: function () {
                    if (isNullOrUndefined(this.adapter)) {
                        var recordsets = {};
                        recordsets[this.schemaName] = this;
                        this.adapter = this.recordManager.createDataAdapter(recordsets, {});
                    }
                    return this.adapter;
                },

                getIdentity: function (record) {
                    var schema = this.recordManager.getDataSchema(this.schemaName);
                    var primaryKey = schema.getPrimaryKey();
                    if (primaryKey) {
                        return primaryKey.toIdentity(record);
                    }
                    else {
                        return null;
                    }
                },

                setAddRecords: function (value) {
                    this.addRecords = value;
                },

                getAddRecords: function () {
                    return this.addRecords;
                },

                getTotalCount: function (params, callback) {
                    this.getProxy().size(params, callback);
                },

                load: function (params, callback) {
                    callback = Callback.createInstance(callback);
                    this.lastParams = params;
                    if (this.getProxy()) {
                        this.getProxy().list(params, { handler: this.onProxyLoad, scope: this, args: [callback] });
                    }
                    else {
                        if (callback) {
                            callback.invoke();
                        }
                    }
                },

                reload: function (callback) {
                    this.getProxy().list(this.lastParams, { handler: this.onProxyLoad, scope: this, args: [callback] });
                },

                onProxyLoad: function (data, callback) {
                    this.loadRecords(data, this.addRecords);
                    if (callback) {
                        callback.invoke();
                    }
                },

                createRecord: function (rawData) {
                    var adpater = this.getAdapter();
                    var schema = this.schemaName;
                    var record = adpater.toRecord(schema, rawData);
                    return record;
                },

                /**
                * Load raw data into record set.
                */
                loadRecords: function (rawData, addRecords) {
                    var adpater = this.getAdapter();
                    var schema = this.schemaName;
                    if (!addRecords && this.data.length > 0) {
                        this.clearRecord();
                        /*
                        * 调用 this.setTransaction(null); 以清除 transaction，
                        * 否则提交的时候会将原有记录全部删除。
                        */
                        this.setTransaction(null);
                    }
                    adpater.fillRecordSet(schema, rawData);

                    this.beginTransaction();
                },

                setProxy: function (value) {
                    if ((value) && (!(value instanceof Proxy))) {
                        var proxyInfo = value;
                        value = Type.forAlias(proxyInfo.proxyType).createInstance();
                        value.configure(proxyInfo);
                    }
                    this.proxy = value;
                },

                getProxy: function () {
                    return this.proxy;
                },

                commit: function (callback) {
                    callback = Callback.createInstance(callback);
                    /*if (strategy) {
                    strategy.doCommit(this, callback);
                    }
                    else {*/
                    if (!this.transaction) {
                        throw new Error("recordSet has not loaded data, can't execute commit.");
                    }
                    this.transaction.commit(this.getProxy(), {
                        handler: this.doCommit,
                        scope: this,
                        args: [callback]
                    });
                    //}
                },

                doCommit: function (successed, callback) {
                    this.setTransaction(null);
                    this.beginTransaction();
                    if (callback) {
                        callback.invoke(successed);
                    }
                },

                /**
                * Convert record to raw data.
                */
                convertRawData: function (record) {
                    var adpater = this.getAdapter(),
                        schema = this.schemaName;
                    return adpater.toRawData(schema, record);
                },

                /**
                * Convert all records to raw data
                */
                buildRawData: function () {
                    var adpater = this.getAdapter(),
                        schema = this.schemaName;
                    return adpater.buildRawData(schema);
                },

                getRecords: function () {
                    return this.data;
                },

                getRecord: function (index) {
                    if (isInt(index)) {
                        return this.data[index];
                    }
                    else {
                        return this.dataIndexer[index];
                    }
                },

                addRecord: function (record) {
                    return this.insertRecord(this.size(), record);
                },

                insertRecord: function (index, record) {
                    var rawData = null;
                    var column;
                    this.beginTransaction();
                    if (!(record instanceof Record)) {
                        rawData = record;
                        record = this.createRecord(record);
                        for (column in rawData) {
                            record.set(column, rawData[column]);
                        }
                    }
                    var identity = this.getIdentity(record);
                    if (identity in this.dataIndexer) {
                        return this.dataIndexer[identity];
                    }
                    this.data.splice(index, 0, record);
                    this.dataIndexer[identity] = record;

                    if (record.isDelete()) {
                        record.markForClean();
                    }
                    else {
                        record.markForCreate();
                    }

                    if (rawData != null) {
                        for (column in rawData) {
                            record.set(column, rawData[column]);
                        }
                    }

                    this.fireListener(LISTENER_RECORD_ADDED, [index, record]);
                    if (this.transaction) {
                        this.transaction.process(record);
                    }

                    record.addListener(this);

                    return record;
                },

                removeRecord: function (index) {
                    if (index instanceof Record) {
                        index = ArrayUtil.indexOf(this.data, index);
                    }

                    if (index < 0) {
                        return;
                    }
                    var record = null,
                        records = this.data.splice(index, 1);
                    if (records.length > 0) {
                        record = records[0];
                        var identity = this.getIdentity(record);
                        delete this.dataIndexer[identity];

                        if (record.isCreate()) {
                            record.markForClean();
                        }
                        else {
                            record.markForDelete();
                        }

                        this.fireListener(LISTENER_RECORD_REMOVED, [index, record]);
                        if (this.transaction) {
                            this.transaction.process(record);
                        }
                        record.removeListener(this);
                    }
                    return record;
                },

                clearRecord: function () {
                    if (this.data.length === 0) {
                        return;
                    }
                    var i = null,
                        length = null;
                    for (i = 0, length = this.data.length; i < length; i++) {
                        this.removeRecord(0);
                    }
                    this.getAdapter().clearReference(this);
                },

                reset: function () {
                    if (this.data.length === 0) {
                        return;
                    }
                    for (var i = this.data.length; i > 0; i--) {
                        var record = this.data[0];
                        var identity = this.getIdentity(record);
                        delete this.dataIndexer[identity];
                        this.data.splice(0, 1);
                        record.removeListener(this);
                    }
                },

                size: function () {
                    return this.data.length;
                },

                beginTransaction: function () {
                    if (!isNullOrUndefined(this.transaction)) {
                        return;
                    }

                    this.setTransaction(new Transaction(this));

                    return this.transaction;
                },

                setTransaction: function (value) {
                    if (value) {
                        this.addListener(this);
                    }
                    else {
                        this.removeListener(this);
                    }
                    this.transaction = value;
                },

                getTransaction: function () {
                    return this.transaction;
                },

                onFieldChanged: function (source, column, value) {
                    if (this.transaction) {
                        this.transaction.process(source);
                    }
                }
            })
        .$();
    });