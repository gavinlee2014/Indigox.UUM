﻿define("Indigox.Web.JsLib.Models.Model",
    [
        "Indigox.Web.JsLib.Utils.Configurable",
        "Indigox.Web.JsLib.Utils.ListenersSupport",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Configurable,
        ListenersSupport
) {

    var base = Configurable.prototype;
    
    var LISTENER_PROPERTY_CHANGING = "PropertyChanging",
        LISTENER_PROPERTY_CHANGED = "PropertyChanged";

    var Model =
        Namespace("Indigox.Web.JsLib.Models")//
        .Class("Model")//
        .Extend(base)
        .Constructor(
            function () {
                this.listeners = new ListenersSupport(this);
                this.data = null;
            }
        )
        .Members({
            addListener: function (listener, handlers) {
                if (this.listeners && listener != null) {
                    this.listeners.addListener(listener, handlers);
                }
            },
            removeListener: function (listener) {
                if (this.listeners && listener != null) {
                    this.listeners.removeListener(listener);
                }
            },
            fireListener: function (method, args) {
                if (this.listeners) {
                    this.listeners.fire(method, args);
                }
            }
        })
    .$();

});