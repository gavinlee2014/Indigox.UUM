﻿define("Indigox.Web.JsLib.Utils.Delegate",
    [
        "Indigox.Web.JsLib.Utils.Util",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Util
) {

    // using


    var Delegate =
        Namespace("Indigox.Web.JsLib.Utils")
        .Class("Delegate")
        .Static({
            create: function (handler, scope) {
                /// <summary>
                /// 创建 handler 的委托，以改变 handler 执行时 this 指针指向的对象。
                /// </summary>
                return function () {
                    handler.apply(scope, arguments);
                };
            }
        })
    .$();

});