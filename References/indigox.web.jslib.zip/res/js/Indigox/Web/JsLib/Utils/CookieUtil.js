﻿define("Indigox.Web.JsLib.Utils.CookieUtil",
    [
        "Indigox.Web.JsLib.Core"
    ],
function (

) {

    /*globals escape, unescape */

    var CookieUtil =
        Namespace("Indigox.Web.JsLib.Utils")
        .Class("CookieUtil")
        .Static({
            /**
            * 获取 Cookie 的值
            * @alias Indigox.Web.JsLib.Cookie.get
            * @method
            * @param {String} name Cookie name
            */
            get: function (name) {
                var a_all_cookies = document.cookie.split(';');
                var a_temp_cookie = '';
                var cookie_name = '';
                var cookie_value = '';
                var b_cookie_found = false; // set boolean t/f default f
                var i = '';

                for (i = 0; i < a_all_cookies.length; i++) {
                    a_temp_cookie = a_all_cookies[i].split('=');

                    // trim left/right whitespace while we're at it
                    cookie_name = a_temp_cookie[0].replace(/^\s+|\s+$/g, '');

                    // if the extracted name matches passed check_name
                    if (cookie_name == name) {
                        b_cookie_found = true;
                        // we need to handle case where cookie has no value but exists (no = sign, that is):
                        if (a_temp_cookie.length > 1) {
                            cookie_value = unescape(a_temp_cookie[1].replace(/^\s+|\s+$/g, ''));
                        }
                        // note that in cases where cookie is initialized but no value, null is returned
                        return cookie_value;
                    }
                    a_temp_cookie = null;
                    cookie_name = '';
                }
                if (!b_cookie_found) {
                    return null;
                }
            },

            /**
            * 设置 Cookie 的值
            * @alias Indigox.Web.JsLib.Cookie.set
            * @method
            * @param {String} name Cookie name
            * @param {String} value
            * @param {int} expires
            * @param {String} path
            * @param {String} domain
            * @param {Object} secure
            */
            set: function (name, value, domain, path, expires, secure) {
                var today = new Date();
                today.setTime(today.getTime());

                if (expires) {
                    expires = expires * 1000 * 60 * 60;
                }
                //alert( 'today ' + today.toGMTString() );// this is for testing purpose only
                var expires_date = new Date(today.getTime() + (expires));
                //alert('expires ' + expires_date.toGMTString());// this is for testing purposes only

                document.cookie = name + "=" + escape(value) +
                    ((expires) ? ";expires=" + expires_date.toGMTString() : "") + //expires.toGMTString()
                    ((path) ? ";path=" + path : "") +
                    ((domain) ? ";domain=" + domain : "") +
                    ((secure) ? ";secure" : "");
            },

            /**
            * 移除 Cookie
            * @alias Indigox.Web.JsLib.Cookie.remove
            * @method
            * @param {String} name Cookie name
            * @param {String} domain
            * @param {String} path
            */
            remove: function (name, domain, path) {
                document.cookie = name + "=" +
                    ((path) ? ";path=" + path : "") +
                    ((domain) ? ";domain=" + domain : "") +
                    ";expires=Thu, 01-Jan-1970 00:00:01 GMT";
            }
        })
    .$();

});