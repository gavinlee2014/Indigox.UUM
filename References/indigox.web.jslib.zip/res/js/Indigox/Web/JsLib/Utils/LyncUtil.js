﻿define("Indigox.Web.JsLib.Utils.LyncUtil",
    [
        "Indigox.Web.JsLib.Utils.ListenersSupport",
        "Indigox.Web.JsLib.Utils.Browser",
        "Indigox.Web.JsLib.Core"
    ],
function (
        ListenersSupport,
        Browser
) {

    /*globals ActiveXObject*/

    var Browser = Browser.getInstance();
    var nameCtrl = null;
    if (Browser.name === 'IE') {
        try {
            nameCtrl = new ActiveXObject('Name.NameCtrl.1');
            nameCtrl.onStatusChange = function (name, status, id) {
                console.log(name + " " + status);
                LyncUtil.onStatusChanged(name, status, id);
            }
        }
        catch (err) {
            //do something
        }
    }

    var listenerSupport = new ListenersSupport({});
    listenerSupport.registerListeners("LyncStatusChange");

    //var presence = ['online', 'offline', 'away', 'busy', 'away', 'notdisturb', 'unknown'];
    var presence = {
        '0': 'online',
        '1': 'offline',
        '2': 'away',
        '3': 'busy',
        '4': 'away',
        '9': 'notdisturb',
        '-1': 'unknown'
    };
    var LyncUtil =
        Namespace("Indigox.Web.JsLib.Utils")
        .Class("LyncUtil")
        .Static({
            onStatusChanged: function (name, status, id) {
                var stausName = "";
                stausName = presence[status];
                if (!stausName) {
                    stausName = presence['-1'];
                }

                listenerSupport.fire("LyncStatusChange", [name, stausName]);
            },

            addListener: function (ui) {
                if (ui != null) {
                    var contact = ui.getControl().getValue();
                    if (!contact) {
                        return;
                    }
                    if (nameCtrl) {
                        nameCtrl.GetStatus(contact.Email, '');
                    }
                    listenerSupport.addListener(ui);
                }
            },

            removeListener: function (ui) {
                if (ui != null) {
                    listenerSupport.removeListener(ui);
                }
            },

            getPresence: function (username) {
                //debug.log(username+":try get presence");
                if (Browser.name !== 'IE' || isNullOrUndefined(nameCtrl)) {
                    return presence['-1'];
                }
                var status = null;
                try {
                    status = nameCtrl.GetStatus(username, '');
                    //debug.log(username+":presence getted");
                }
                catch (err) {
                    //do something
                    //debug.log(username+":presence get error: "+err);
                }
                var stausName = "";
                stausName = presence[status];
                if (!stausName) {
                    stausName = presence['-1'];
                }
                //debug.log(username+":presence is "+stausName);
                return stausName;
            },
            showCard: function (username, left, top) {
                if (Browser.name === 'IE' && nameCtrl) {
                    try {
                        nameCtrl.ShowOOUI(username, 0, left, top);
                    }
                    catch (err) {
                        //do something
                    }
                }
            },
            hideCard: function (username) {
                if (Browser.name === 'IE' && nameCtrl) {
                    try {
                        nameCtrl.HideOOUI();
                    }
                    catch (err) {
                        //do something
                    }
                }
            }
        })
    .$();

});