﻿define("Indigox.Web.JsLib.Utils.CompositePromise",
    [
        "Indigox.Web.JsLib.Utils.Promise",
        "Indigox.Web.JsLib.Utils.Callback",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Promise,
        Callback
) {



    var base = Promise.prototype;

    var CompositePromise =
        Namespace("Indigox.Web.JsLib.Utils")
        .Class("CompositePromise")
        .Extend(base)
        .Constructor(
            function (parts) {
                base.constructor.apply(this, []);
                this.parts = [];
                this.returnValue = [];
                this.message = [];
                this.appendRange(parts);

                if (this.parts.length === 0) {
                    this.setResolved();
                }

                for (var i = 0, length = this.parts.length; i < length; i++) {
                    var promise = this.parts[i];
                    promise.progress(new Callback(this.onPartProgress, this, [i, promise]));
                    promise.always(new Callback(this.onPartStateChanged, this, [i, promise]));
                }

                if (this.parts.length === 0) {
                    this.setResolved();
                }
            }
        )
        .Members({
            //@protected
            append: function (promise) {
                if (promise && promise instanceof Promise) {
                    this.parts.push(promise);
                }
                else {
                    this.parts.push(new Promise(promise));
                }
            },

            //@protected
            appendRange: function (parts) {
                for (var i = 0, length = parts.length; i < length; i++) {
                    this.append(parts[i]);
                }
            },

            //@protected
            onPartProgress: function (index, source) {
                index = arguments[arguments.length - 2];
                source = arguments[arguments.length - 1];

                this.message[index] = source.message;

                for (var i = 0, ilength = this.progressCallbacks.length; i < ilength; i++) {
                    var progressCallback = this.progressCallbacks[i];
                    progressCallback.invoke.apply(progressCallback, this.message);
                }
            },

            //@protected
            onPartStateChanged: function (index, source) {
                index = arguments[arguments.length - 2];
                source = arguments[arguments.length - 1];

                this.returnValue[index] = source.returnValue;

                if (source.isRejected()) {
                    this.setRejected();
                }
                else if (source.isResolved()) {
                    for (var i = 0, length = this.parts.length; i < length; i++) {
                        var promise = this.parts[i];
                        if (!promise.isResolved()) {
                            return;
                        }
                    }
                    this.setResolved();
                }
            },

            //@protected
            onStateChanged: function () {
                if (this.isResolved()) {
                    for (var i = 0, ilength = this.doneCallbacks.length; i < ilength; i++) {
                        var doneCallback = this.doneCallbacks[i];
                        doneCallback.invoke.apply(doneCallback, this.returnValue);
                    }
                }
                if (this.isRejected()) {
                    for (var j = 0, jlength = this.failCallbacks.length; j < jlength; j++) {
                        var failCallback = this.failCallbacks[j];
                        failCallback.invoke.apply(failCallback, this.returnValue);
                    }
                }
            }
        })
    .$();

});