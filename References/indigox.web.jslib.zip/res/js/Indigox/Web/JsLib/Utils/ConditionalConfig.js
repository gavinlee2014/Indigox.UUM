﻿define("Indigox.Web.JsLib.Utils.ConditionalConfig",
    [
        "Indigox.Web.JsLib.Core"
    ],
function (

) {

    var ConditionalConfig =
        Namespace("Indigox.Web.JsLib.Utils")
        .Class("ConditionalConfig")
        .Constructor(function () {
            this.configs = [];
            this.defaultConfig = null;
        })
        .Static({
        })
        .Members({
            addConfig: function (condition, config) {
                if ((arguments.length < 2) || (isNullOrUndefined(config))) {
                    config = arguments[0];
                    condition = null;
                }
                if (isNullOrUndefined(condition)) {
                    this.defaultConfig = config;
                }
                else {
                    var exist = false;
                    var i, length;
                    for (i = 0, length = this.configs.length; i < length; i++) {
                        if (this.configs[i].condition === condition) {
                            this.configs[i].config = config;
                            exist = true;
                        }
                    }
                    if (!exist) {
                        this.configs.push({ condition: condition, config: config });
                    }
                }
            },
            getConfig: function () {
                var i, length;
                for (i = 0, length = this.configs.length; i < length; i++) {
                    if (this.configs[i].condition()) {
                        return this.configs[i].config;
                    }
                }
                return this.defaultConfig;
            }
        })
    .$();

});