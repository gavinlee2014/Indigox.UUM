﻿define("Indigox.Web.JsLib.Utils.Listener",
    [
        "Indigox.Web.JsLib.Utils.Util",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Util
) {

    /** @id Indigox.Web.JsLib.Utils */
    var Listener =
        Namespace("Indigox.Web.JsLib.Utils")
        .Class("Listener")
        .Constructor(
    /** @id Indigox.Web.JsLib.Utils.Listener */
            function (target, method) {
                this.target = target;
                this.method = method;
                if (!(method in target) || !isFunction(target[method])) {
                    throw new Error("There is no method \"" + method + "\" in the target Object.");
                }
            }
        )
        .Members({
            invoke: function (args) {
                this.target[this.method].apply(this.target, args);
            }
        }).$();

});