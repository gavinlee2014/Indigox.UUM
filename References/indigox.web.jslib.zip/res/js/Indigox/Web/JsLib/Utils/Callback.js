﻿define("Indigox.Web.JsLib.Utils.Callback",
    [
        "Indigox.Web.JsLib.Utils.Util",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Util
) {

    // using


    /** @id Indigox.Web.JsLib.Utils */
    var Callback =
        Namespace("Indigox.Web.JsLib.Utils")
        .Class("Callback")
        .Constructor(
            function (handler, scope, args) {
                if (arguments.length === 1 && isObject(arguments[0])) {
                    var config = arguments[0];
                    this.handler = config.handler;
                    this.scope = config.scope;
                    this.args = config.args;
                }
                else {
                    this.handler = handler;
                    this.scope = scope;
                    this.args = args;
                }
            }
        )
        .Static({
            createInstance: function (callback) {
                if (isFunction(callback)) {
                    callback = new Callback({ handler: callback });
                }
                else if ((callback) && (!(callback instanceof Callback))) {
                    callback = new Callback(callback);
                }
                return callback;
            }
        })
        .Members({
            getHandler: function () {
                return this.handler;
            },
            getScope: function () {
                return this.scope;
            },
            getArgs: function () {
                return this.args;
            },
            invoke: function () {
                var scope = this.scope;
                if (this.args) {
                    var args = this.args.slice(0);
                    args.unshift.apply(args, arguments);
                    return this.handler.apply(scope, args);
                }
                else {
                    return this.handler.apply(scope, arguments);
                }
            }
        })
    .$();

});