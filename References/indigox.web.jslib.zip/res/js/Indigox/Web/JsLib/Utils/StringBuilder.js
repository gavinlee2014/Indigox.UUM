﻿define("Indigox.Web.JsLib.Utils.StringBuilder",
    [
        "Indigox.Web.JsLib.Utils.Util",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Util
) {




    /** @id Indigox.Web.JsLib.Utils */
    var StringBuilder =
        Namespace("Indigox.Web.JsLib.Utils")
        .Class("StringBuilder")
        .Constructor(
            function () {
            }
        )
        .Members({
            append: function (value) {
            },

            toString: function () {

            }

        }).$();

});