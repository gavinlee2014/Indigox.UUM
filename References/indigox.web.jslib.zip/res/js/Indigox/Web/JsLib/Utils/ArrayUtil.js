﻿define("Indigox.Web.JsLib.Utils.ArrayUtil",
    [
        "Indigox.Web.JsLib.Core"
    ],
    function (

    ) {
        var ArrayUtil =
            Namespace("Indigox.Web.JsLib.Utils")
            .Class("ArrayUtil")
            .Static({
                contains: function (array, item) {
                    return ArrayUtil.indexOf(array, item) > -1;
                },
                indexOf: function (array, item) {
                    if (array.indexOf) {
                        return array.indexOf(item);
                    }
                    var i = null,
                        length = null;
                    for (i = 0, length = array.length; i < length; i++) {
                        if (array[i] === item) {
                            return i;
                        }
                    }
                    return -1;
                },
                remove: function (array, item) {
                    var index = this.indexOf(array, item);
                    array.splice(index, 1);
                },
                removeAt: function (array, index) {
                    array.splice(index, 1);
                },

                equal: function (array1, array2) {
                    if (array1.length != array2.length) {
                        return false;
                    }

                    var equaled = true;
                    var i = null,
                        length = null;
                    for (i = 0, length = array1.length; i < length; ++i) {
                        if (this.indexOf(array2, array1[i]) == -1) {
                            equaled = false;
                            break;
                        }
                    }
                    return equaled;
                }
            })
        .$();
    });