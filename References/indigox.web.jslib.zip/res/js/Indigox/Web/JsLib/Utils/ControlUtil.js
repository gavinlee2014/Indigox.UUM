﻿define("Indigox.Web.JsLib.Utils.ControlUtil",
    [
        "Indigox.Web.JsLib.Core"
    ],
function (

) {

    var ControlUtil =
        Namespace("Indigox.Web.JsLib.Utils")
        .Class("ControlUtil")
        .Static({
            findControlFromNearestParent: function (source, name) {
                var parent = source.parent;

                while (parent != null) {
                    if (parent.find) {
                        var control = parent.find(name);
                        if (control != null) {
                            return control;
                        }
                    }

                    parent = parent.parent;
                }

                return null;
            }
        })
    .$();

});