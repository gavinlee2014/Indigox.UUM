﻿define("Indigox.Web.JsLib.Utils.Callbacks",
    [
        "Indigox.Web.JsLib.Collection.List",
        "Indigox.Web.JsLib.Utils.Callback",
        "Indigox.Web.JsLib.Core"
    ],
    function (
        List,
        Callback
    ) {
        var ApplicationContext =
            Namespace("Indigox.Web.JsLib.Utils")
            .Class("Callbacks")
            .Constructor(
                function () {
                    this.callbacks = new List();
                }
            )
            .Members({
                add: function (callback) {
                    this.callbacks.add(callback);
                },

                addRange: function (callbacks) {
                    this.callbacks.addRange(callbacks);
                },

                remove: function (callback) {
                    this.callbacks.remove(callback);
                },

                invoke: function () {
                    var callbacks = this.callbacks.toArray();
                    for (var i = 0, length = callbacks.length; i < length; i++) {
                        var callback = callbacks[i];
                        callback.invoke.apply(callback, arguments);
                    }
                }
            })
        .$();
    });