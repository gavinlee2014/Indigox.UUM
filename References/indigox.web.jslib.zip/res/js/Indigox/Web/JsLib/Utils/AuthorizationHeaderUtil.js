﻿define("Indigox.Web.JsLib.Utils.AuthorizationHeaderUtil",
    [
        "Indigox.Web.JsLib.Core"
    ],
function (

) {


    var AuthorizationHeaderUtil =
        Namespace("Indigox.Web.JsLib.Utils")
        .Class("AuthorizationHeaderUtil")
        .Static({

            /**
            * 从 AuthorizationHeader 字符串中获取参数
            * @alias Indigox.Web.JsLib.Utils.AuthorizationHeaderUtil.getParam
            * @method
            * @param {String} header
            * @param {String} param 
            * @Authenticate header格式为 Digest param1="value1",param2="value2",param3=value
            */
            getParam: function (header, param) {
                var value = "";
                if (header.split(' ').length > 1) {
                    var sections = header.split(' ')[1].split(',');
                    for (var i = 0, length = sections.length; i < length; i++) {
                        if (sections[i].split('=')[0] == (param)) {
                            value = sections[i].substring(param.length + 1);
                            break;
                        }
                    }
                }
                return value.replace(/\"/g, "");
            }
        })
    .$();

});