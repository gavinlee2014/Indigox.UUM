﻿define("Indigox.Web.JsLib.Utils.DelayedTask",
    [
        "Indigox.Web.JsLib.Utils.Util",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Util
) {



    var DelayedTask =
        Namespace("Indigox.Web.JsLib.Utils")
        .Class("DelayedTask")
        .Constructor(
             function (handler, scope, args) {
                 this.id = null;
                 this.handler = handler;
                 this.scope = scope;
                 this.args = args || []; // IE8 disallow undefined or null args
             }
        )
        .Members({
            call: function () {
                clearTimeout(this.id);
                this.id = null;
                this.handler.apply(this.scope, this.args);
            },

            delay: function (delay, newHandler, newScope, newArgs) {
                this.cancel();
                this.handler = newHandler || this.handler;
                this.scope = newScope || this.scope;
                this.args = newArgs || this.args;
                var me = this;
                this.id = setTimeout(function () { me.call(); }, delay);
            },

            cancel: function () {
                if (this.id) {
                    clearTimeout(this.id);
                    this.id = null;
                }
            }
        })
    .$();

});