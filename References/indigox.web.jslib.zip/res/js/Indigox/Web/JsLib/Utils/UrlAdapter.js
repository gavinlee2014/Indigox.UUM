﻿define("Indigox.Web.JsLib.Utils.UrlAdapter",
    [
        "Indigox.Web.JsLib.Utils.UrlUtil",
        "Indigox.Web.JsLib.Utils.Browser"
    ],
    function (
        UrlUtil,
        Browser
    ) {
        var addEventListener = !!window.addEventListener;

        function on(element, evt, fn) {
            if (addEventListener) {
                element.addEventListener(evt, fn);
            }
            else {
                element.attachEvent('on' + evt, fn);
            }
        }

        if (Browser.name === 'IE' &&
           ((Browser.version === '6.0') || (Browser.version === '7.0') || (Browser.version === '8.0'))) {
           
            on(document, 'mouseover', function () {
                var a = event.srcElement;
                if (typeof (a.tagName) === 'string' && a.tagName.toLowerCase() === 'a') {
                    var url = a.getAttribute("href");
                    if (!!url && url.indexOf('#') > -1) {
                        a.setAttribute("href", UrlUtil.join(url));
                    }
                }
            });
  
        }
    });