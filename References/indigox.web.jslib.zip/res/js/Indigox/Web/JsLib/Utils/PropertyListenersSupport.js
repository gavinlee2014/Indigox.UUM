﻿define("Indigox.Web.JsLib.Utils.PropertyListenersSupport",
    [
        "Indigox.Web.JsLib.Utils.ListenersSupport",
        "Indigox.Web.JsLib.Core"
    ],
function (
        ListenersSupport
) {



    //@deprecated
    var PropertyListenersSupport =
        Namespace("Indigox.Web.JsLib.Utils")
        .Class("PropertyListenersSupport")
        .Constructor(
            function (source) {
                /** @id Indigox.Web.JsLib.Controls.PropertyListenersSupport.prototype.events */
                this.propertyListeners = {};
                this.source = source;
            }
        )
        .Members({
            registerListeners: function () {
                for (var i = 0, property; property = arguments[i]; i++) {
                    this.propertyListeners[property] = new ListenersSupport(this.source);
                }
            },
            addListener: function (property, listener) {
                if (property in this.propertyListeners) {
                    this.propertyListeners[property].addListener(listener);
                }
                else {
                    throw new Error(["there is no the property \"", property, "\" exist! Please check the program."].join(""));
                }
            },
            removeListener: function (property, listener) {
                if (property in this.propertyListeners) {
                    this.propertyListeners[property].removeListener(listener);
                }
                else {
                    throw new Error(["there is no the property \"", property, "\" exist! Please check the program."].join(""));
                }
            },
            findProperty: function (listener) {
            },
            fire: function (property, event, args) {
                if (property in this.propertyListeners) {
                    this.propertyListeners[property].fire(event, args);
                }
                else {
                    throw new Error(["there is no the property \"", property, "\" exist! Please check the program."].join(""));
                }
            }
        })
    .$();

});