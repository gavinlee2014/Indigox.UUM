﻿define("Indigox.Web.JsLib.Utils.Deferred",
    [
        "Indigox.Web.JsLib.Utils.Promise",
        "Indigox.Web.JsLib.Utils.CompositePromise",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Promise,
        CompositePromise
) {



    var base = Promise.prototype;

    var Deferred =
        Namespace("Indigox.Web.JsLib.Utils")
        .Class("Deferred")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, []);
            }
        )
        .Static({
            when: function (promises) {
                if (!isArray(promises)) {
                    promises = [].slice.call(arguments);
                }
                return new CompositePromise(promises);
            }
        })
        .Members({
            promise: function () {
                return new Promise(this);
            },

            resolve: function (returnValue) {
                this.returnValue = returnValue;
                this.setResolved();
            },

            reject: function (returnValue) {
                this.returnValue = returnValue;
                this.setRejected();
            },

            notify: function (message) {
                this.message = message;
                this.onProgress();
            }
        })
    .$();

});