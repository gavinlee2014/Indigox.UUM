﻿define("Indigox.Web.JsLib.Utils.EventsSupport",
    [
        "Indigox.Web.JsLib.Utils.Event",
        "Indigox.Web.JsLib.Utils.ErrorHandler",
        "Indigox.Web.JsLib.Utils.Util",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Event,
        ErrorHandler,
        Util
) {

    // using


    var EventsSupport =
        Namespace("Indigox.Web.JsLib.Utils")
        .Class("EventsSupport")
        .Constructor(
            function (source) {
                /** @id Indigox.Web.JsLib.Utils.EventsSupport.prototype.events */
                this.events = {};
                this.source = source;
            }
        )
        .Members({
            /** @id Indigox.Web.JsLib.Utils.EventsSupport.prototype.registerListeners */
            registerEvents: function () {
                var i = null,
                    length = null;
                for (i = 0, length = arguments.length; i < length; i++) {
                    this.events[arguments[i]] = [];
                }
            },
            attachEvent: function (target, handlers) {
                //重载，判断第二个参数是否为对象
                if (arguments.length == 1) {
                    handlers = arguments[0];
                    target = null;
                }
                else if (arguments.length == 2 && isString(arguments[0]) && isFunction(arguments[1])) {
                    var event = arguments[0], handler = arguments[1];

                    target = null;
                    handlers = {};
                    handlers[event] = handler;
                }
                else if (arguments.length == 3) {
                    var event = arguments[1], handler = arguments[2];
                    handlers = {};
                    handlers[event] = handler;
                }

                for (var e in handlers) {
                    //当key既不是"sender"也不是"args"时，检查在类中是否存在该事件，如果不存在则抛出error
                    if (!this.events[e]) {
                        throw new Error(["there is no event \"", e, "\" exist! Please check the program. If you are control developer, please register the event before using it."].join(""));
                    }
                    if (this.events[e]) {
                        this.events[e].push(new Event(target, handlers[e]));
                    }
                }
            },
            detachEvent: function (handlers) {
                if (arguments.length == 2 && isString(arguments[0]) && isFunction(arguments[1])) {
                    var event = arguments[0], handler = arguments[1];
                    handlers = {};
                    handlers[event] = handler;
                }
                for (var e in handlers) {
                    if (!this.events[e]) {
                        throw new Error(["there is no event \"", e, "\" exist! Please check the program. If you are control developer, please register the event before using it."].join(""));
                    }
                    var events = this.events[e];
                    var i = null,
                        length = null;
                    for (i = events.length - 1; i >= 0; i--) {
                        if (events[i].handler == handlers[e]) {
                            events.splice(i, 1);
                        }
                    }
                }
            },
            clearEvents: function () {
                for (var event in this.events) {
                    this.events[event] = [];
                }
            },
            hasEvent: function (event) {
                return event in this.events;
            },
            fire: function (event, args) {
                var e = event;
                if (!(e in this.events)) {
                    throw new Error(["there is no event \"", e, "\" exist! Please check the program. If you are control developer, please register the event before using it."].join(""));
                }

                args = args || [];
                args.unshift(this.source);

                var events = this.events[e];
                var i = null;
                for (i = events.length - 1; i >= 0; i--) {

                    try {
                        events[i].invoke(args);
                    }
                    catch (ex) {
                        debug.error("fire event [" + event + "] failed.");
                        debug.error(args);
                        ErrorHandler.log(ex);
                    }
                }
            }
        }).$();

});