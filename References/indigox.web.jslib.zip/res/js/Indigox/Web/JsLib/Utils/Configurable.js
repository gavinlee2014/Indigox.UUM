﻿define("Indigox.Web.JsLib.Utils.Configurable",
    [
        "Indigox.Web.JsLib.Utils.StringUtil",
        "Indigox.Web.JsLib.Utils.Deferred",
        "Indigox.Web.JsLib.Utils.Promise",
        "Indigox.Web.JsLib.Core"
    ],
function (
        StringUtil,
        Deferred,
        Promise
) {



    var Configurable =
        Namespace("Indigox.Web.JsLib.Utils")
        .Class("Configurable")
        .Members({
            hasField: function (name) {
                return (name in this);
            },
            hasGetter: function (name) {
                var getter = this.getGetter(name);
                return (getter in this);
            },
            hasSetter: function (name) {
                var setter = this.getSetter(name);
                return (setter in this);
            },
            getGetter: function (name) {
                return ("get" + StringUtil.toPascalCase(name));
            },
            getSetter: function (name) {
                return ("set" + StringUtil.toPascalCase(name));
            },
            getFieldOrProperty: function (name) {
                if (this.hasGetter(name)) {
                    return this[this.getGetter(name)]();
                }
                else if (this.hasField(name)) {
                    return this[name];
                }
            },
            setFieldOrProperty: function (name, value) {
                if (value instanceof Promise) {
                    value.done({
                        handler: function (data) {
                            this.setFieldOrProperty(name, data);
                        },
                        scope: this
                    });
                }
                else {
                    if (this.hasSetter(name)) {
                        this[this.getSetter(name)](value);
                    }
                    else if (this.hasField(name)) {
                        this[name] = value;
                    }
                }
            },
            isConfigurableValue: function (value) {
                return (value instanceof Configurable);
            },
            configureFieldOrProperty: function (key, value) {
                if (!(this.hasField(key) || this.hasGetter(key))) {
                    return;
                }

                var oldValue = this.getFieldOrProperty(key);

                if (!this.isConfigurableValue(value) && this.isConfigurableValue(oldValue)) {
                    oldValue.configure(value);
                }
                else {
                    this.setFieldOrProperty(key, value);
                }
            },
            configure: function (options) {
                for (var key in options) {
                    if (key === undefined) {
                        continue;
                    }
                    this.configureFieldOrProperty(key, options[key]);
                }
            }
        })
    .$();

});