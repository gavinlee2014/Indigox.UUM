﻿define("Indigox.Web.JsLib.Utils.Browser",
    [
        "Indigox.Web.JsLib.Utils.ObjectUtil",
        "Indigox.Web.JsLib.Core"
    ],
    function (
        ObjectUtil
    ) {
        var instance = null;

        function isTablet(userAgent) {
            if (/Pad|Tablet/i.test(userAgent)) {
                return true;
            }
            if (/WebView/i.test(userAgent) && !(/Mobile/i.test(userAgent))) {
                return true;
            }
            // see https://developers.google.com/chrome/mobile/docs/user-agent
            if (/Android/i.test(userAgent)
            //&& /Chrome/i.test(userAgent)
                && !(/Mobile/i.test(userAgent))) {
                return true;
            }
            return false;
        }

        function isMobile(userAgent) {
            if (/Mobi|Mobile|Phone/i.test(userAgent)) {
                return true;
            }
            // 中兴 ZTE Android 4.0 不包含 Mobile 关键字
            if (/Android/i.test(userAgent)) {
                return true;
            }
            return false;
        }

        var Browser =
            Namespace("Indigox.Web.JsLib.Utils")
            .Class("Browser")
            .Constructor(
                function () {
                    this.userAgent = navigator.userAgent;
                    var browserMatch = this.userAgent.match(new RegExp('((?:' + ObjectUtil.getValues(Browser.BROWSER_PREFIXES).join(')|(?:') + '))([\\d\\._]+)'));
                    var engineMatch = this.userAgent.match(new RegExp('((?:' + ObjectUtil.getValues(Browser.ENGINE_PREFIXES).join(')|(?:') + '))([\\d\\._]+)'));
                    this.name = 'Other';
                    this.version = '';
                    this.engine = 'Other';
                    this.engineVersion = '';
                    this.deviceType = Browser.pc;

                    if (browserMatch) {
                        this.name = Browser.BROWSERS[ObjectUtil.getKey(Browser.BROWSER_PREFIXES, browserMatch[1])];
                        this.version = browserMatch[2];
                    }

                    if (engineMatch) {
                        this.engine = Browser.ENGINES[ObjectUtil.getKey(Browser.ENGINE_PREFIXES, engineMatch[1])];
                        this.engineVersion = engineMatch[2];
                    }

                    if (isTablet(this.userAgent)) {
                        this.deviceType = Browser.DEVICE_TYPES.tablet;
                    }
                    else if (isMobile(this.userAgent)) {
                        this.deviceType = Browser.DEVICE_TYPES.mobile;
                    }
                }
            )
            .Static({
                getInstance: function () {
                    if (isNullOrUndefined(instance)) {
                        instance = new Browser();
                    }
                    return instance;
                },
                BROWSERS: {
                    ie: 'IE',
                    firefox: 'Firefox',
                    safari: 'Safari',
                    chrome: 'Chrome',
                    opera: 'Opera',
                    other: 'Other'
                },
                ENGINES: {
                    webkit: 'WebKit',
                    gecko: 'Gecko',
                    presto: 'Presto',
                    trident: 'Trident',
                    other: 'Other'
                },
                DEVICE_TYPES: {
                    mobile: 'mobile',
                    tablet: 'tablet',
                    pc: 'pc'
                },
                BROWSER_PREFIXES: {
                    ie: 'MSIE ',
                    firefox: 'Firefox/',
                    chrome: 'Chrome/',
                    safari: 'Version/',
                    opera: 'Opera/'
                },
                ENGINE_PREFIXES: {
                    webkit: 'AppleWebKit/',
                    gecko: 'Gecko/',
                    presto: 'Presto/',
                    trident: 'Trident/'
                },
                isMobile: function () {
                    return Browser.getInstance().deviceType === Browser.DEVICE_TYPES.mobile;
                },
                isTablet: function (name) {
                    return Browser.getInstance().deviceType === Browser.DEVICE_TYPES.tablet;
                }
            })
            .Members({
                // isGreaterThan: function ( version ) {
                // },
                // isLessThan: function ( version ) {
                // }
            })
        .$();

        var getCheckFunction = function (fn) {
            return function () {
                return this.name === Browser.BROWSERS[fn];
            };
        };

        for (var fn in Browser.BROWSERS) {
            Browser.prototype[fn] = getCheckFunction(fn);
        }

        for (var fn in Browser.ENGINES) {
            if (fn === "other") {
                Browser.prototype.otherEngine = getCheckFunction(fn);
            }
            else {
                Browser.prototype[fn] = getCheckFunction(fn);
            }
        }
    });