﻿define("Indigox.Web.JsLib.Utils.Promise",
    [
        "Indigox.Web.JsLib.Utils.Callback",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Callback
) {



    var STATE_PENDING = 'pending',
        STATE_RESOLVED = 'resolved',
        STATE_REJECTED = 'rejected';

    var Promise =
        Namespace("Indigox.Web.JsLib.Utils")
        .Class("Promise")
        .Constructor(
            function (promise) {
                this.state = STATE_PENDING;
                this.doneCallbacks = [];
                this.failCallbacks = [];
                this.progressCallbacks = [];
                this.returnValue = undefined;
                this.message = undefined;

                if (arguments.length === 1) {
                    if (promise instanceof Promise) {
                        var me = this;

                        promise
                            .done(function (returnValue) {
                                me.returnValue = returnValue;
                                me.setResolved();
                            })
                            .fail(function (returnValue) {
                                me.returnValue = returnValue;
                                me.setRejected();
                            })
                            .progress(function (message) {
                                me.message = message;
                                me.onProgress();
                            });
                    }
                    else {
                        this.state = STATE_RESOLVED;
                        this.returnValue = promise;
                    }
                }
            }
        )
        .Members({
            isResolved: function () {
                return this.state === STATE_RESOLVED;
            },

            isRejected: function () {
                return this.state === STATE_REJECTED;
            },

            then: function (doneCallback, failCallback, progressCallback) {
                doneCallback = Callback.createInstance(doneCallback);
                failCallback = Callback.createInstance(failCallback);
                progressCallback = Callback.createInstance(progressCallback);

                var cls = Type.forFullName("Indigox.Web.JsLib.Utils.Deferred").getClass();
                var dfd = new cls();
                if (doneCallback) {
                    this.done(function () {
                        var returnValue = doneCallback.invoke.apply(doneCallback, arguments);
                        if (returnValue instanceof Promise) {
                            returnValue
                                .done(function (data) {
                                    dfd.resolve(data);
                                })
                                .fail(function (data) {
                                    dfd.reject(data);
                                })
                                .progress(function (data) {
                                    dfd.notify(data);
                                });
                        }
                        else {
                            dfd.resolve(returnValue);
                        }
                    });
                }
                if (failCallback) {
                    this.fail(function () {
                        var returnValue = failCallback.invoke.apply(failCallback, arguments);
                        if (returnValue instanceof Promise) {
                            returnValue
                                .done(function (data) {
                                    dfd.resolve(data);
                                })
                                .fail(function (data) {
                                    dfd.reject(data);
                                })
                                .progress(function (data) {
                                    dfd.notify(data);
                                });
                        }
                        else {
                            dfd.reject(returnValue);
                        }
                    });
                }
                if (progressCallback) {
                    this.progress(function () {
                        var returnValue = progressCallback.invoke.apply(progressCallback, arguments);
                        if (returnValue instanceof Promise) {
                            returnValue
                                .done(function (data) {
                                    dfd.resolve(data);
                                })
                                .fail(function (data) {
                                    dfd.reject(data);
                                })
                                .progress(function (data) {
                                    dfd.notify(data);
                                });
                        }
                        else {
                            dfd.notify(returnValue);
                        }
                    });
                }
                return dfd.promise();
            },

            done: function (callback) {
                callback = Callback.createInstance(callback);
                this.doneCallbacks.push(callback);
                if (this.isResolved()) {
                    callback.invoke.apply(callback, [this.returnValue]);
                }
                return this;
            },

            fail: function (callback) {
                callback = Callback.createInstance(callback);
                this.failCallbacks.push(callback);
                if (this.isRejected()) {
                    callback.invoke.apply(callback, [this.returnValue]);
                }
                return this;
            },

            progress: function (callback) {
                callback = Callback.createInstance(callback);
                this.progressCallbacks.push(callback);
                return this;
            },

            always: function (callback) {
                callback = Callback.createInstance(callback);
                this.doneCallbacks.push(callback);
                this.failCallbacks.push(callback);
                if (this.isResolved() || this.isRejected()) {
                    callback.invoke();
                }
                return this;
            },

            //@protected
            setState: function (state) {
                if (this.state !== state) {
                    this.state = state;
                    this.onStateChanged();
                }
            },

            //@protected
            setResolved: function () {
                this.setState(STATE_RESOLVED);
            },

            //@protected
            setRejected: function () {
                this.setState(STATE_REJECTED);
            },

            //@protected
            onStateChanged: function () {
                if (this.isResolved()) {
                    for (var i = 0, ilength = this.doneCallbacks.length; i < ilength; i++) {
                        var doneCallback = this.doneCallbacks[i];
                        doneCallback.invoke.apply(doneCallback, [this.returnValue]);
                    }
                }
                if (this.isRejected()) {
                    for (var j = 0, jlength = this.failCallbacks.length; j < jlength; j++) {
                        var failCallback = this.failCallbacks[j];
                        failCallback.invoke.apply(failCallback, [this.returnValue]);
                    }
                }
            },

            //@protected
            onProgress: function () {
                for (var i = 0, ilength = this.progressCallbacks.length; i < ilength; i++) {
                    var progressCallback = this.progressCallbacks[i];
                    progressCallback.invoke.apply(progressCallback, [this.message]);
                }
            }
        })
    .$();

});