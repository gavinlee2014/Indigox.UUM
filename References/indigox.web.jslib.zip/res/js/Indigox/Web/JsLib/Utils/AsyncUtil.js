﻿define("Indigox.Web.JsLib.Utils.AsyncUtil",
    [
        "Indigox.Web.JsLib.Utils.Callback",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Callback
) {
    var AsyncUtil =
        Namespace("Indigox.Web.JsLib.Utils")
        .Class("AsyncUtil")
        .Static({
            invokeAsync: function (method, callback, timeout) {
                if (arguments.length === 1) {
                    callback = null;
                    timeout = 0;
                }
                else if (arguments.length === 2) {
                    if (isNumber(arguments[1])) {
                        timeout = arguments[1];
                        callback = null;
                    }
                    else {
                        timeout = 0;
                    }
                }

                if (callback) {
                    if (isFunction(callback)) {
                        callback = new Callback({ handler: callback });
                    }
                    else if (!(callback instanceof Callback)) {
                        callback = new Callback(callback);
                    }
                }

                if (isString(method)) {
                    setTimeout(method, timeout);
                }
                else {
                    if (isFunction(method)) {
                        setTimeout(function () {
                            method();
                            if (callback) { callback.invoke(); }
                        },
                        timeout);
                    }
                    else if (isObject(method)) {
                        if (!(method instanceof Callback)) {
                            method = new Callback(method);
                        }
                        setTimeout(function () {
                            method.invoke();
                            if (callback) { callback.invoke(); }
                        },
                        timeout);
                    }
                }
            },

            until: function (judgment, callback) {
                /// <summary>等待直到 judgment 为真的时候才执行 callback。 </summary>

                if (isNullOrUndefined(callback)) {
                    throw Error("argument 'callback' is null.");
                }

                //debug.log('----AsyncUtil.until----');
                if (isFunction(judgment)) {
                    judgment = new Callback({ handler: judgment });
                }
                else if (!(judgment instanceof Callback)) {
                    judgment = new Callback(judgment);
                }
                var flag = judgment.invoke();
                //debug.log('until flag: ' + flag);

                if (flag) {
                    if (isFunction(callback)) {
                        callback = new Callback({ handler: callback });
                    }
                    else if (!(callback instanceof Callback)) {
                        callback = new Callback(callback);
                    }
                    callback.invoke();
                }
                else {
                    window.setTimeout((function (_callback) {
                        return function () {
                            AsyncUtil.until(judgment, _callback);
                        };
                    } (callback)), 100);
                }
            }
        })
    .$();

});