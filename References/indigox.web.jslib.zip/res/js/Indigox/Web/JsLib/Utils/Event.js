﻿define("Indigox.Web.JsLib.Utils.Event",
    [
        "Indigox.Web.JsLib.Utils.Util",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Util
) {

    // using


    /** @id Indigox.Web.JsLib.Utils */
    var Event =
        Namespace("Indigox.Web.JsLib.Utils")
        .Class("Event")
        .Constructor(
    /** @id Indigox.Web.JsLib.Utils.Event */
            function (target, handler) {
                if (arguments.length == 1 && isObject(arguments[0])) {
                    Util.copy(this, arguments[0]);
                }
                else if (arguments.length == 2) {
                    this.target = target;
                    this.handler = handler;
                }
            }
        )
        .Members({
            getTarget: function () {
                return this.target;
            },
            getHandler: function () {
                return this.handler;
            },
            invoke: function (args) {
                this.handler.apply(this.target, args);
            }
        }).$();

});