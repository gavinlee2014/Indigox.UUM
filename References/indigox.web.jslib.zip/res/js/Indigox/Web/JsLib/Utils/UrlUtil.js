﻿define("Indigox.Web.JsLib.Utils.UrlUtil",
    [
        "jquery",
        "jquery-history",
        "Indigox.Web.JsLib.DOM.Element",
        "Indigox.Web.JsLib.Utils.Browser",
        "Indigox.Web.JsLib.Utils.Callback",
        "Indigox.Web.JsLib.Utils.Callbacks",
        "Indigox.Web.JsLib.Utils.DelayedTask",
        "Indigox.Web.JsLib.Core"
    ],
    function (
        jQuery,
        History,
        Element,
        Browser,
        Callback,
        Callbacks,
        DelayedTask
    ) {
        var Browser = Browser.getInstance(),
            El = Element.el;

        var document_referrer = '' + document.referrer;

        var hashChangeCallbacks = new Callbacks();
        //var urlChangeCallbacks = new Callbacks();

        var delayFireHashChangeCallbacks = new DelayedTask(function () {
            hashChangeCallbacks.invoke();
        });

        jQuery.History.bind(function (state) {
            debug.log(state);
            // this may trigger multi times in IE 8, is a bug?
            delayFireHashChangeCallbacks.delay(100);
        });

        var UrlUtil =
            Namespace("Indigox.Web.JsLib.Utils")
            .Class("UrlUtil")
            .Static({
                /**
                * 从 Url 中获取参数
                * @alias Indigox.Web.JsLib.Utils.UrlUtil.get
                * @method
                * @param {String} name
                * @param {String} url 可以为空，默认取当前 request 的 URL
                * @return {String} Url 中的参数值
                */
                get: function (name, url) {
                    var sValue = null;
                    var reg = new RegExp("(^|&)" + name + "=([^&#]*)(&|#|$)");
                    var query = this.getQueryString(url);
                    var r = query.match(reg);
                    if (r != null) {
                        sValue = r[2];
                        sValue = decodeURIComponent(sValue.replace(/\+/g, ' '));
                    }
                    return sValue;
                },

                getPath: function (url) {
                    if (typeof (url) !== "string") {
                        url = window.location.href;
                    }
                    var ques = url.indexOf('?'), pound = url.indexOf('#');
                    if (ques >= 0) {
                        url = url.substring(0, ques);
                    }
                    else if (pound >= 0) {
                        url = url.substring(0, pound);
                    }
                    return url.replace(/(http(s)?:)?\/\/[^\/]*\//g, '/');
                },

                getParams: function (url) {
                    var query = this.getQueryString(url);
                    var params = {};
                    var sections = query.split('&');
                    for (var i = 0, length = sections.length; i < length; i++) {
                        var section = sections[i];
                        var eq = section.indexOf('=');
                        if (eq > 0) {
                            params[section.substring(0, eq)] = section.substring(eq + 1);
                        }
                        else {
                            params[section] = null;
                        }
                    }
                    return params;
                },

                getQueryString: function (url) {
                    if (typeof (url) !== "string") {
                        url = window.location.href;
                    }
                    var ques = url.indexOf('?'), pound = url.indexOf('#');
                    if (ques >= 0) {
                        if (pound >= 0) {
                            if (pound < ques) {
                                return "";
                            }
                            return url.substring(ques + 1, pound);
                        }
                        return url.substring(ques + 1);
                    }
                    return "";
                },

                /**
                * concate url an path
                * @alias Indigox.Web.JsLib.Utils.UrlUtil.concate
                * @param {String} url   default is window.location
                * @param {String} path  the path concate to url
                * @return {String} concated url
                */
                concate: function (url, path) {
                    if (arguments.length === 1) {
                        path = url;
                        url = window.location;
                    }
                    return path;
                },

                /**
                * 组装 Url
                * @alias Indigox.Web.JsLib.Utils.UrlUtil.join
                * @method
                * @param {String} url
                * @param {Object} args 需要组装到 Url 中的参数
                * @return {String} 组装之后的 Url
                */
                join: function (url, args) {

                    if (isNullOrUndefined(args)) {
                        if (Browser.name === 'IE' &&
                        ((Browser.version === '6.0') || (Browser.version === '7.0') || (Browser.version === '8.0'))) {
                            if (!!url && url.indexOf("#") > -1) {
                                url = url.replace("#", "?page=");
                                var encodeCode = url.substring(url.indexOf("=") + 1);
                                url = url.replace(encodeCode, encodeURIComponent(encodeCode));
                            }
                        }
                        return url;
                    }
                    else {
                        var temp = [url];
                        temp.push((url.indexOf('?') >= 0) ? '&' : '?');
                        for (var p in args) {
                            if ((p != null) && (args[p] != null)) {
                                temp.push(p);
                                temp.push('=');
                                temp.push(encodeURIComponent(args[p]));
                                temp.push('&');
                            }
                        }
                        temp = temp.slice(0, temp.length - 1);
                        url = temp.join('');
                        if (Browser.name === 'IE' &&
                        ((Browser.version === '6.0') || (Browser.version === '7.0') || (Browser.version === '8.0'))) {
                            if (url.indexOf("#") > -1) {
                                url = url.replace("#", "?page=");
                                var encodeCode = url.substring(url.indexOf("=") + 1);
                                url = url.replace(encodeCode, encodeURIComponent(encodeCode));
                            }
                        }
                        return url;
                        //debug.log(url);
                    }

                },

                goBack: function () {
                    //var prev = document_referrer;
                    //var hisLen = window.history.length;
                    ////debug.log('goback (window.history.length = ' + hisLen + '; document.referrer = "' + document_referrer + '")');
                    //if ((hisLen == 1) || (hisLen === 0) || (prev === "") || (prev.toLowerCase().indexOf("login.aspx") > -1)) {
                    //    window.location.assign("/");
                    //    return;
                    //}
                    //window.location.assign(prev);

                    if (window.history.length > 1) {
                        //debug.log('start go (-1)');
                        window.history.go(-1);
                        //debug.log('end go (-1)');
                    }
                    else {
                        window.location.assign("/");
                    }
                },

                goTo: function (url, args) {
                    url = UrlUtil.join(url, args);
                    if (Browser.name === 'IE' &&
                        ((Browser.version === '6.0') || (Browser.version === '7.0') || (Browser.version === '8.0'))) {
                        var referLink = document.createElement('a');
                        referLink.href = url;
                        document.body.appendChild(referLink);
                        referLink.click();
                    }
                    else {
                        window.location.assign(url);
                    }
                },

                reload: function () {
                    window.location.reload();
                },

                open: function (url, args) {
                    url = UrlUtil.join(url, args);
                    window.open(url);
                },

                redirect: function (url, args) {
                    url = UrlUtil.join(url, args);
                    window.location.replace(url);
                },

                /**
                * 当使用回退或前进按钮导致地址栏链接发生变化，
                * 而浏览器又没有刷新页面时触发事件（由 pushState 或 replaceState 增加的 history）
                */
                //onUrlChanged: function (callback) {
                //    callback = Callback.createInstance(callback);
                //    urlChangeCallbacks.add(callback);
                //},

                /**
                * 当前链接的 hash 值（井号'#'后的内容）变化时触发事件，
                * 前进和回退按钮导致 hash 值变化也会触发该事件
                */
                onHashChanged: function (callback) {
                    callback = Callback.createInstance(callback);
                    hashChangeCallbacks.add(callback);
                }
            })
        .$();
    });