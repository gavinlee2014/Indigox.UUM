﻿define("Indigox.Web.JsLib.Utils.DateTimeUtil",
    [
        "Indigox.Web.JsLib.Core"
    ],
function (

) {
    var DateTimeUtil =
        Namespace("Indigox.Web.JsLib.Utils")
        .Class("DateTimeUtil")
        .Static({
            parse: function (text) {
                if (isNullOrUndefined(text) || text === "") {
                    return null;
                }

                var t = text.replace(/-/g, "/"), d = null;
                try {
                    d = new Date(t);
                }
                catch (e) {
                    throw ("Can't parse datetime: " + text);
                }

                return d;
            },

            toShortString: function (y, M, d) {
                if (y instanceof Date) {
                    var date = y;
                    y = date.getFullYear() + "";
                    M = (date.getMonth() + 1) + "";
                    d = date.getDate() + "";
                }
                else {
                    /*y = parseInt(y);
                    M = parseInt(M);
                    d = parseInt(d);*/
                    M = M ? M : "0";
                    d = d ? d : "0";
                }

                return [
                    y, "-",
                    ((M.length == 1) ? "0" : ""), M, "-",
                    ((d.length == 1) ? "0" : ""), d
                ].join("");
            },

            toLongString: function (y, M, d, H, m, s) {
                if (y instanceof Date) {
                    var date = y;
                    y = date.getFullYear();
                    M = date.getMonth() + 1;
                    d = date.getDate();
                    H = date.getHours();
                    m = date.getMinutes();
                    s = date.getSeconds();
                }
                else {
                    y = parseInt(y);
                    M = parseInt(M);
                    d = parseInt(d);
                    H = parseInt(H);
                    m = parseInt(m);
                    s = parseInt(s);
                }

                return [
                    y, "-",
                    ((M < 10) ? "0" : ""), M, "-",
                    ((d < 10) ? "0" : ""), d, " ",
                    ((H < 10) ? "0" : ""), H, ":",
                    ((m < 10) ? "0" : ""), m, ":",
                    ((s < 10) ? "0" : ""), s
                ].join("");
            },
            /*
			    Date对象转换成yyyy年MM月dd日格式的字符串
		    */
		    dateToString : function (date) {
                var y = date.getFullYear(),
                    m = date.getMonth() + 1,
                    d = date.getDate();
                return [y, "年", m, "月", d, "日"].join('');
            },
            /*
        	    获取指定日期上一周的最后一天
            */
		    getPreWeekEndDate: function (d) {
                var now = d;
                now = new Date(now.getTime() - 7 * 1000 * 60 * 60 * 24);
                var dayOfWeek = now.getDay();
                dayOfWeek = dayOfWeek == 0 ? 7 : dayOfWeek;
                now.setDate(now.getDate() + (7 - dayOfWeek)); //now 为本周的上一周的最后一天
                return now;
            },    
            /*
        	    获取y年m月的周的个数，例如2014年1月，返回4周; 2013年12月返回5周
            */
            getWeeksNum : function (y, m) {
                var now = new Date(y, m, 1);
                var dayOfWeek = now.getDay();
                dayOfWeek = dayOfWeek == 0 ? 7 : dayOfWeek;
                if (dayOfWeek != 1) {
                    now = new Date(now.getTime() + (7 - dayOfWeek + 1) * 24 * 60 * 60 * 1000);
                }
                var next = new Date(now.getFullYear(), now.getMonth() + 1, 1);

                var dayOfWeek_1 = next.getDay();
                dayOfWeek_1 = dayOfWeek_1 == 0 ? 7 : dayOfWeek_1;
                if (dayOfWeek_1 != 1) {
                    next = new Date(next.getTime() + (7 - dayOfWeek_1 + 1) * 24 * 60 * 60 * 1000);
                }

                var daysNum = (next.getTime() - now.getTime()) / (1000 * 24 * 60 * 60);
                return Math.ceil(daysNum / 7);
            },
            /*
        	    获取日期在当月的第几周
            */
            getMonthWeek : function (date) {
                var first = new Date(date.getFullYear(), date.getMonth(), 1);
                var dayOfWeek = first.getDay();
                dayOfWeek = dayOfWeek == 0 ? 7 : dayOfWeek;
                if (dayOfWeek != 1) {
                    first = new Date(date.getFullYear(), date.getMonth(), first.getDate() + (7 - dayOfWeek + 1));
                }
                //first 是date所在月的第一周的第一天

                var year=date.getFullYear(), month=date.getMonth(),week;
                if (date.getTime() < first.getTime()) {
            	    month-=1;
            	    if(month<0) {//跳到上一年最后一个月
            		    month=11;
            		    year-=1;
            	    }
                    week= getWeeksNum(year, month);
                }
                else{
	                var w = Math.ceil((date.getDate() - first.getDate()) / 6);
	                week=w == 0 ? 1 : w;
                }
                return {year:year,month:month+1,week:week };
            },
            /*
        	    获取季度的开始时间和结束时间
            */
             getQuarterDateRange :function (year, quarter) {
                var first = new Date(year, (quarter - 1) * 3, 1);
                var nextQuarterFirst = new Date(year, quarter * 3, 1);
                var end = new Date(nextQuarterFirst.setDate(0));
                return [first, end];
            },
            /*
        	    获取日期所在季度
            */
            getCurrentQuarter :function (now) {
                var y = now.getFullYear(), time = now.getTime();
                for (var i = 1; i <= 4; i++) {
                    var arr = this.getQuarterDateRange(y, i);
                    if (time >= arr[0].getTime() && time <= arr[1].getTime()) {
                        return i;
                    }
                }
            },
            /*
        	    获取下一季度
            */
            getNextQuarter : function(y,q){
        	    var quarter=q+1;
        	    var year=y;
        	    if(quarter>4){
        		    year+=1;
        		    quarter=1;
        	    }
        	    return {year:year,quarter:quarter};
            },
            /*
        	    获取上一个季度
            */
            getPreQuarter : function(y,q){
        	    var quarter=q-1;
        	    var year=y;
        	    if(quarter<1){
        		    year-=1;
        		    quarter=4;
        	    }
        	    return {year:year,quarter:quarter};
            },
            /*
                获取周的开始时间和结束时间
            */
            getWeekDateRange : function (y, m, w) {//年，月，第几周
                var date = new Date(y, m, 1); //月份第一天
                var week = date.getDay();
                week = week == 0 ? 7 : week;
                var millisecond = 1000 * 60 * 60 * 24; //一天的毫秒数
                if (week != 1) {
                    date = new Date(date.getTime() + (7 - week + 1) * millisecond);
                }
                var start = new Date(date.getTime() + millisecond * (w - 1) * 7);
                var end = new Date(start.getTime() + millisecond * 6);
           
                return [start, end];
            },
            getShortDate : function (date) {
                var y = date.getFullYear(),
                    m = date.getMonth() + 1,
                    d = date.getDate();
                return [y, "-", m, "-", d].join('');
            },
            /*
                获取上一周
            */
            getPreWeek : function(y,m,w){
                var dr=this.getWeekDateRange(y,m,w);
                var d=new Date(dr[0].getTime() - 1000 * 60 * 60 * 24 * 7);
                return this.getMonthWeek(d);
            },
            /*
                获取下一周
            */
            getNextWeek : function (y, m, w) {
                var dr=this.getWeekDateRange(y,m,w);
                var d=new Date(dr[0].getTime() + 1000 * 60 * 60 * 24 * 7);
                return this.getMonthWeek(d);
            }

        })
    .$();
});