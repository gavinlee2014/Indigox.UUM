﻿define("Indigox.Web.JsLib.Utils.JoinStringBuilder",
    [
        "Indigox.Web.JsLib.Utils.StringBuilder",
        "Indigox.Web.JsLib.Core"
    ],
function (
        StringBuilder
) {
    var base = StringBuilder.prototype;

    /** @id Indigox.Web.JsLib.Utils */
    var JoinStringBuilder =
        Namespace("Indigox.Web.JsLib.Utils")
        .Class("JoinStringBuilder")
        .Extend(base)
        .Constructor(
            function () {
                this.array = [];
            }
        )
        .Members({
            append: function (value) {
                this.array.push(value);
            },

            toString: function () {
                return this.array.join(' ');
            }

        }).$();
});