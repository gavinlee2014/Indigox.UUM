﻿define("Indigox.Web.JsLib.Utils.PlusStringBuilder",
    [
        "Indigox.Web.JsLib.Utils.StringBuilder",
        "Indigox.Web.JsLib.Core"
    ],
function (
        StringBuilder
) {


    var base = StringBuilder.prototype;

    /** @id Indigox.Web.JsLib.Utils */
    var PlusStringBuilder =
        Namespace("Indigox.Web.JsLib.Utils")
        .Class("PlusStringBuilder")
        .Extend(base)
        .Constructor(
            function () {
                this.str = "";
            }
        )
        .Members({
            append: function (value) {
                this.str += value;
            },

            toString: function () {
                return this.str;
            }

        }).$();

});