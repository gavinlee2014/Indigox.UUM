﻿define("Indigox.Web.JsLib.Utils.StringUtil",
    [
        "Indigox.Web.JsLib.Core"
    ],
function (

) {
    //define("Indigox.Web.JsLib.Utils.StringUtil",
    (function () {
        var UNIT_PATTERN = /(px|em|%|en|ex|pt|in|cm|mm|pc)$/i;
        var EMPTY_STRING = '';

        var StringUtil =
        Namespace("Indigox.Web.JsLib.Utils")
        .Class("StringUtil")
        .Static({
            format: function (str) {
                var args = Array.prototype.slice.call(arguments, 1);
                return str.replace(/\{(\d+)\}/g,
                    function (m, i) {
                        return args[i];
                    }
                );
            },
            isNullOrEmpty: function (str) {
                if (isNullOrUndefined(str)) {
                    return true;
                }
                else {
                    return (/^\s*$/g).test(str);
                }
            },
            empty: function () {
                return EMPTY_STRING;
            },
            trim: function (str) {
                return str.replace(/(^\s*)|(\s*$)/g, '');
            },
            trimStart: function (str) {
                var re = /^\s+/g;
                return str.replace(re, "");
            },
            trimEnd: function (str) {
                var re = /\s+$/g;
                return str.replace(re, "");
            },
            parseInt: function (str) {
                str = str.replace(UNIT_PATTERN, "");
                return parseInt(str, 10);
            },
            parseFloat: function (str) {
                str = str.replace(UNIT_PATTERN, "");
                return parseFloat(str);
            },
            newGuid: function () {
                var guid = "";
                for (var i = 1; i <= 32; i++) {
                    var n = Math.floor(Math.random() * 16.0).toString(16);
                    guid += n;
                    if ((i == 8) || (i == 12) || (i == 16) || (i == 20)) {
                        guid += "-";
                    }
                }
                return guid;
            },
            toPascalCase: function (text) {
                if (!text) { return text; }
                if (text.length < 1) { return text; }
                return (text.substring(0, 1).toUpperCase() + text.substring(1));
            },
            toCamalCase: function (text) {
                if (!text) { return text; }
                if (text.length < 1) { return text; }
                return (text.substring(0, 1).toLowerCase() + text.substring(1));
            }
        })
    .$();
    } ());
});