﻿define("Indigox.Web.JsLib.Utils.DOMUtil",
    [
        "jquery",
        "Indigox.Web.JsLib.Core"
    ],
    function (
        jQuery
    ) {
        var emptyTextNodeRegex = /^\s*$/;

        var DOMUtil =
            Namespace("Indigox.Web.JsLib.Utils")
            .Class("DOMUtil")
            .Static({
                /**
                * 创建DOM节点
                * @alias Indigox.Web.JsLib.DOM.createElement
                * @alias createElement
                * @method
                * @param {String} expression HTML字串
                * @param {String} parent 参考 jQuery 查询表达式语法
                */
                createElement: function (expression, parent) {
                    jQuery(expression).appendTo(parent || document.body);
                },

                buildElement: function (expression) {
                    var element = jQuery(expression).get(0);
                    element.parentNode.removeChild(element);
                    return element;
                },

                /* @decprecated */
                createScriptNode: function (srcUrl) {
                    var oHead = document.getElementsByTagName('HEAD').item(0);
                    var oScript = document.createElement("script");
                    oScript.language = "javascript";
                    oScript.type = "text/javascript";
                    oScript.src = srcUrl;
                    oHead.appendChild(oScript);
                    return oScript;
                    //jQuery("<script src='" + srcUrl + "' />").appendTo(document.body);
                },

                isEmptyTextNode: function (node) {
                    return node &&
                           node.nodeType == 3 &&
                           emptyTextNodeRegex.test(node.nodeValue);
                },

                /**
                * 在上下文中查找 DOM 节点，返回第一个匹配结果
                * @alias Indigox.Web.JsLib.DOM.element
                * @alias Indigox.Web.JsLib.DOM.get
                * @alias get
                * @method
                * @param {DOMElement,String} expression 参考 jQuery 查询表达式语法
                * @param {DOMElement,String} context 上下文节点或 expression
                * @return {DOMElement}
                */
                element: function (expression, context) {
                    return jQuery(expression, context).get(0);
                },

                /**
                * 在上下文中查找 DOM 节点，返回所有匹配结果
                * @alias Indigox.Web.JsLib.DOM.elements
                * @alias Indigox.Web.JsLib.DOM.getAll
                * @alias getAll
                * @method
                * @param {DOMElement,String} expression 参考 jQuery 查询表达式语法
                * @param {DOMElement,String} context 上下文节点或 expression
                * @return {Array}
                */
                elements: function (expression, context) {
                    return jQuery(expression, context).get();
                },

                /**
                * 为 DOM 元素添加事件
                * @alias Indigox.Web.JsLib.DOM.attachEvent
                * @method
                * @param {DOMElement,String} element
                * @param {String} event
                * @param {Function} handler
                */
                attachEvent: function (element, event, handler) {
                    jQuery(element).bind(event, handler);
                },

                /**
                * 为 DOM 元素移除事件
                * @alias Indigox.Web.JsLib.DOM.detachEvent
                * @method
                * @param {DOMElement,String} element
                * @param {String} event
                * @param {Function} handler
                */
                detachEvent: function (element, event, handler) {
                    if (isNullOrUndefined(handler)) {
                        jQuery(element).unbind(event);
                    }
                    else {
                        jQuery(element).unbind(event, handler);
                    }
                },

            /**
            * 设置 DOM 元素指定的Attribute的值
            * @alias Indigox.Web.JsLib.DOM.setAttribute
            * @method
            * @param {DOMElement,String} element
            * @param {String} atrributeName
            * @param {Object} atrributeValue
            */
            setAttribute: function (element, attributrName, value) {
                if ((attributrName === "innerText") || (attributrName === "textContent")) {
                    if (jQuery.browser.msie) {
                        attributrName = "innerText";
                    }
                    else {
                        attributrName = "textContent";
                    }
                }
                jQuery(element).prop(attributrName, value);
            },

            /**
            * 获取 DOM 元素指定的Attribute的值
            * @alias Indigox.Web.JsLib.DOM.getAttribute
            * @method
            * @param {DOMElement,String} element
            * @param {String} atrributeName
            * @return {Object}
            */
            getAttribute: function (element, attributrName) {
                if ((attributrName === "innerText") || (attributrName === "textContent")) {
                    if (jQuery.browser.msie) {
                        attributrName = "innerText";
                    }
                    else {
                        attributrName = "textContent";
                    }
                }
                return jQuery(element).prop(attributrName);
            },

                /**
                *
                * @alias Indigox.Web.JsLib.DOM.setStyle
                * @method
                */
                setStyle: function (element, propertyName, value) {
                    if (isNullOrUndefined(value) || /*兼容IE 6.0*/(isNumber(value) && isNaN(value))) {
                        return;
                    }
                    jQuery(element).css(propertyName, value);
                },

                /**
                *
                * @alias Indigox.Web.JsLib.DOM.getStyle
                * @method
                */
                getStyle: function (element, name) {
                    return jQuery(element).css(name);
                },

                getScreenHeight: function () {
                    if (document.documentElement) {
                        return document.documentElement.clientHeight;
                    }
                    else {
                        return document.body.clientHeight;
                    }
                },

                getScreenWidth: function () {
                    if (document.documentElement) {
                        return document.documentElement.clientWidth;
                    }
                    else {
                        return document.body.clientWidth;
                    }
                },

                getScrollTop: function () {
                    if (document.documentElement) {
                        return document.documentElement.scrollTop;
                    }
                    else {
                        return document.body.scrollTop;
                    }
                },

                getScrollLeft: function () {
                    if (document.documentElement) {
                        return document.documentElement.scrollLeft;
                    }
                    else {
                        return document.body.scrollLeft;
                    }
                },

                /**
                *
                * @alias Indigox.Web.JsLib.DOM.addClass
                * @method
                */
                addClass: function (element, className) {
                    jQuery(element).addClass(className);
                },

                /**
                *
                * @alias Indigox.Web.JsLib.DOM.removeClass
                * @method
                */
                removeClass: function (element, className) {
                    jQuery(element).removeClass(className);
                },

                /**
                *
                * @alias Indigox.Web.JsLib.DOM.toggleClass
                * @method
                */
                toggleClass: function (element, className) {
                    jQuery(element).toggleClass(className);
                },

                /**
                *
                * @alias Indigox.Web.JsLib.DOM.toggleClass
                * @method
                */
                getClassList: function (element) {
                    var className = this.getAttribute(element, "className");
                    return className.split(/\s+/);
                },

                /**
                *
                * @alias Indigox.Web.JsLib.DOM.hasClass
                * @method
                */
                hasClass: function (element, className) {
                    return jQuery(element).hasClass(className);
                },

                /**
                *
                * @alias Indigox.Web.JsLib.DOM.getFirstchild
                * @method
                */
                getFirstchild: function (element) {
                    return jQuery(element).children(":first").get(0);
                },

                /**
                *
                * @alias Indigox.Web.JsLib.DOM.getLastchild
                * @method
                */
                getLastchild: function (element) {
                    return jQuery(element).children(":last").get(0);
                },

                /**
                *
                * @alias Indigox.Web.JsLib.DOM.getPrevious
                * @method
                */
                getPrevious: function (element) {
                    return jQuery(element).prev().get(0);
                },

                /**
                *
                * @alias Indigox.Web.JsLib.DOM.getNext
                * @method
                */
                getNext: function (element) {
                    return jQuery(element).next().get(0);
                },

                /**
                * 获取 DOM 元素的位置 (top, left)
                * @alias Indigox.Web.JsLib.DOM.getPosition
                * @method
                * @param {DOMElement,String} element
                * @return {Object}
                */
                getPosition: function (element) {
                    if ((!element) || (!element.nodeName)) { return { left: 0, top: 0 }; }
                    var top = 0, left = 0;
                    if ("getBoundingClientRect" in document.documentElement) {
                        var self = element;
                        //jquery方法
                        var box = element.getBoundingClientRect();
                        var doc = element.ownerDocument;
                        var body = doc.body;
                        var docElem = doc.documentElement;
                        var clientTop = docElem.clientTop || body.clientTop || 0;
                        var clientLeft = docElem.clientLeft || body.clientLeft || 0;
                        top = box.top + (self.pageYOffset || docElem && docElem.scrollTop || body.scrollTop) - clientTop;
                        left = box.left + (self.pageXOffset || docElem && docElem.scrollLeft || body.scrollLeft) - clientLeft;
                    }
                    else {
                        var current = element;
                        do {
                            top += current.offsetTop || 0;
                            left += current.offsetLeft || 0;
                            current = current.offsetParent;
                        } while (current);
                    }
                    return { X: left, Y: top };
                },

                getRelativePosition: function (element) {
                    if ((!element) || (!element.nodeName)) { return { left: 0, top: 0 }; }
                    var top = 0, left = 0, current = element;
                    do {
                        top += current.offsetTop || 0;
                        left += current.offsetLeft || 0;
                        if ((current.offsetParent) && (this.getComputedStyle(current.offsetParent, "position") != "relative")) {
                            current = current.offsetParent;
                        }
                        else {
                            current = null;
                        }
                    } while (current);
                    return { X: left, Y: top };
                },

                getComputedStyle: function (element, style) {
                    var computedStyle;
                    if (typeof element.currentStyle != 'undefined')
                    { computedStyle = element.currentStyle; }
                    else
                    { computedStyle = document.defaultView.getComputedStyle(element, null); }
                    return computedStyle[style];
                },

                /**
                * 获取 DOM 元素的大小 (width, height)
                * @alias Indigox.Web.JsLib.DOM.getSize
                * @method
                * @param {DOMElement,String} element
                * @return {Object}
                */
                getSize: function (element) {
                    //TODO: To implement
                },

                /**
                *
                * @alias Indigox.Web.JsLib.DOM.hasEvent
                * @method
                */
                hasEvent: (function () {
                    var tags = {
                        onsubmit: 'form',
                        onreset: 'form',
                        onselect: 'input',
                        onchange: 'input',
                        onerror: 'img',
                        onload: 'img',
                        onabort: 'img'
                    }, cache = {};

                    return function (element, eventName) {
                        if (arguments.length == 1) {
                            eventName = arguments[0];
                            element = null;
                        }
                        eventName = eventName.indexOf('on') ? 'on' + eventName : eventName;
                        //命中缓存
                        if (!element && eventName in cache) {
                            return cache[eventName];
                        }
                        element = element || document.createElement(tags[eventName] || 'div');
                        var proto = element.__proto__ || {}, supported = eventName in element, temp;
                        //处理显示在元素的__proto__上加属性的情况
                        if (supported && (temp = proto[eventName]) && delete proto[eventName]) {
                            supported = eventName in element;
                            proto[eventName] = temp;
                        }
                        //处理Firefox不给力的情况
                        //Firefox下'onunload' in window是false，但是div有unload事件（OTL）
                        // if (!supported) {
                        //     if (!element.setAttribute || !element.removeAttribute) {
                        //         element = document.createElement('div');
                        //     }
                        //     element.setAttribute(eventName, 'return;');
                        //     supported = typeof element[eventName] == 'function';
                        //     element.removeAttribute(eventName);
                        // }
                        cache[eventName] = supported;
                        return supported;
                    };
                } ())
            })
        .$();

        window.get = DOMUtil.element;
        window.getAll = DOMUtil.elements;
    });