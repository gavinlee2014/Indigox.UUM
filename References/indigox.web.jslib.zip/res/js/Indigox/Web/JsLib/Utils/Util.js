define("Indigox.Web.JsLib.Utils.Util",
    [
        "Indigox.Web.JsLib.Core"
    ],
function (

) {

    var Util =
        Namespace("Indigox.Web.JsLib.Utils")
        .Class("Util")
        .Static({
            /**
            * 将 from 中的所有属性赋值到 to
            * @alias Indigox.Web.JsLib.Util.copy
            * @method
            * @param {Object} to
            * @param {Object} from 可以连续多个 from
            */
            copy: function (to, from) {
                //--------samples---------
                //
                // var a = { name: "box", catalog: "cat" }, b = { name: "fox", type: "cat" };
                // (1) var c = Util.copy(a, b);         // c = a = { name: "fox", catalog: "cat", type: "cat" }
                // (2) var c = Util.copy({}, a, b);     // c = { name: "fox", catalog: "cat", type: "cat" }; // a is not changed.
                //
                //------------------------
                if (!isNullOrUndefined(to)) {
                    var i = null,
                        length = null;
                    for (i = 1, length = arguments.length; i < length; i++) {
                        var f = arguments[i];
                        for (var p in f) {
                            if (p) { // 在遍历属性的时候，p 有一次为 undefined，需要过滤
                                to[p] = f[p];
                            }
                        }
                    }
                }
                return to;
            },

            /**
            * 将 from 中的属性赋值到 to 中，仅复制 to 中原有的属性，若 to 中没有该属性则不复制
            * @alias Indigox.Web.JsLib.Util.copyExist
            * @method
            * @param {Object} to
            * @param {Object} from 可以连续多个 from
            */
            //TODO:rename to copyIfExist
            copyExist: function (to, from) {
                //--------samples---------
                //
                // var a = { name: "box", catalog: "cat" }, b = { name: "fox", type: "cat" };
                // (1) var c = Util.copyExist(a, b);                    // c = a = { name: "fox", catalog: "cat" }
                // (2) var c = Util.copyExist(Util.copy({}, a), b);     // c = { name: "fox", catalog: "cat" }; // a is not changed.
                //
                //------------------------
                if (!isNullOrUndefined(to)) {
                    var i = null,
                        length = null;
                    for (i = 1, length = arguments.length; i < length; i++) {
                        var f = arguments[i];
                        for (var p in f) {
                            //使用p in to代替isUndefined(to[p])，修复HelloWorld.prototype.property = undefined不被复制的问题
                            if (p in to) {
                                to[p] = f[p];
                            }
                        }
                    }
                }
                return to;
            },

            /**
            *
            * @alias Indigox.Web.JsLib.Util.copyNotExist
            * @method
            * @param {Object} to
            * @param {Object} from 可以连续多个 from
            */
            copyNotExist: function (to, from) {
                //--------samples---------
                //
                // var a = { name: "box", catalog: "cat" }, b = { name: "fox", type: "cat" };
                // (1) var c = Util.copyNotExist(a, b);         // c = a = { name: "box", catalog: "cat", type: "cat" }
                // (2) var c = Util.copyNotExist({}, a, b);     // c = { name: "box", catalog: "cat", type: "cat" }; // a is not changed.
                //
                //------------------------
                if (!isNullOrUndefined(to)) {
                    var i = null,
                        length = null;
                    for (i = 1, length = arguments.length; i < length; i++) {
                        var f = arguments[i];
                        for (var p in f) {
                            if (p && !(p in to)) {
                                to[p] = f[p];
                            }
                        }
                    }
                }
                return to;
            },

            /**
            * 创建一个from对象的新副本对象，并将该对象返回。
            * @id Indigox.Web.JsLib.Util.clone
            * @alias Indigox.Web.JsLib.Util.clone
            * @methodd
            * @param {Object} from
            * @return {Object} to
            */
            clone: function (from) {
                //使用cache避免循环引用
                var cache = [];

                var getObjectFromCache = function (key) {
                    var i = null,
                        length = null;
                    for (i = 0, length = cache.length; i < length; i++) {
                        if (cache[i].from === key) {
                            return cache[i].to;
                        }
                    }
                    return null;
                };

                return (function (from) {
                    //如果from等于null或undefined，将to的值设置为from。否则，执行后面的逻辑。
                    if (!from || typeof (from) != 'object') {
                        return from;
                    }

                    //从cache中获取clone的对象，如果cache中缓存clone的对象则直接返回该对象
                    var to = getObjectFromCache(from);
                    if (to !== null) {
                        return to;
                    }

                    to = new from.constructor();
                    //使用from构造函数创建新的副本对象后，立即添加至缓存中，否则可能会导致死循环。
                    cache.push({
                        from: from,
                        to: to
                    });

                    //如果from是一个数组，则遍历数组并递归调用clone函数
                    if (from instanceof Array) {
                        var i = null,
                            length = null;
                        for (i = 0, length = from.length; i < length; i++) {
                            to[i] = arguments.callee(from[i]);
                        }
                    }
                    //如果from是一个对象，则遍历属性并递归调用clone函数
                    else {
                        for (var key in from) {
                            if (typeof (to[key]) !== 'function') {
                                to[key] = arguments.callee(from[key]);
                            }
                        }
                    }

                    return to;
                } (from));
            },

            equals: function (obj1, obj2) {
                //使用cache避免循环引用
                var cache = [];

                var equalsInsideCache = function (obj1, obj2) {
                    for (var i = 0, length = cache.length; i < length; i++) {
                        if ((cache[i].obj1 === obj1 && cache[i].obj2 === obj2) ||
                            (cache[i].obj1 === obj2 && cache[i].obj2 === obj1)) {
                            return true;
                        }
                    }
                    return false;
                };

                return function (obj1, obj2) {
                    if (obj1 == obj2 || equalsInsideCache(obj1, obj2)) {
                        return true;
                    }
                    else if (!(obj1 instanceof Object && obj2 instanceof Object)) {
                        return false;
                    }

                    cache.push({ obj1: obj1, obj2: obj2 });

                    //如果obj1和obj2都是一个数组，则遍历数组并递归调用函数
                    if (obj1 instanceof Array && obj2 instanceof Array && obj1.length === obj2.length) {
                        var i = null,
                            length = null;
                        for (i = 0, length = obj1.length; i < length; i++) {
                            if (!arguments.callee(obj1[i], obj2[i])) {
                                return false;
                            }
                        }
                    }
                    //如果obj1和obj2都是一个对象，则遍历属性并递归调用函数
                    else if (obj1 instanceof Object && obj2 instanceof Object) {
                        var key;
                        var length1 = 0;
                        for (key in obj1) { length1++; }
                        var length2 = 0;
                        for (key in obj2) { length2++; }
                        if (length1 !== length2) {
                            return false;
                        }
                        for (key in obj1) {
                            if (!arguments.callee(obj1[key], obj2[key])) {
                                return false;
                            }
                        }
                    }
                    else {
                        return false;
                    }
                    return true;
                } (obj1, obj2);
            }
        })
    .$();

});