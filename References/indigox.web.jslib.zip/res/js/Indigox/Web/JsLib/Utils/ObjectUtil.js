﻿define("Indigox.Web.JsLib.Utils.ObjectUtil",
    [
        "Indigox.Web.JsLib.Core"
    ],
function (

) {

    var ObjectUtil =
        Namespace("Indigox.Web.JsLib.Utils")
        .Class("ObjectUtil")
        .Static({
            getKey: function (obj, value) {
                for (var key in obj) {
                    if (obj.hasOwnProperty(key) && obj[key] === value) {
                        return key;
                    }
                }
                return null;
            },
            getKeys: function (obj) {
                var keys = [];
                for (var key in obj) {
                    if (obj.hasOwnProperty(key)) {
                        keys.push(key);
                    }
                }
                return keys;
            },
            getValue: function (obj, key) {
                return obj[key];
            },
            getValues: function (obj) {
                var values = [];
                for (var key in obj) {
                    if (obj.hasOwnProperty(key)) {
                        values.push(obj[key]);
                    }
                }
                return values;
            }
        })
    .$();

});