﻿define("Indigox.Web.JsLib.Utils.EncodeUtil",
    [
        "Indigox.Web.JsLib.Core"
    ],
function (

) {

    var EncodeUtil =
        Namespace("Indigox.Web.JsLib.Utils")
        .Class("EncodeUtil")
        .Static({
            markupHTML: function (str) {
                if (str == null || typeof str === 'undefined' || str === '') {
                    return str;
                }
                var div = document.createElement("div");
                div.appendChild(document.createTextNode(str));
                var html = div.innerHTML;
                //delete div; // Variables should not be deleted.
                return html;
            },
            clearHTML: function (str) {
                if (str == null || typeof str === 'undefined' || str === '') {
                    return str;
                }

                // 禁止加载 script 标签
                str = str.replace(/(<script(\s[^>]*)?>)([\s\S]*?)(<\/script\s*>)/g, '');
                // 禁止加载 link 标签
                str = str.replace(/<link [^>]*>/g, '');
                // 禁止加载 img 标签
                str = str.replace(/<img [^>]*>/g, '');

                var div = document.createElement('div');
                div.innerHTML = str;
                var text = div.innerText || div.textContent;
                //delete div; // Variables should not be deleted.
                return text;
            },
            encodeHTML: function (str) {
                if (str == null || typeof str === 'undefined' || str === '') {
                    return str;
                }
                var html = str + "";
                html = html.replace(/&/g, "&gt;");
                html = html.replace(/</g, "&lt;");
                html = html.replace(/>/g, "&gt;");
                html = html.replace(/[ ]/g, "&nbsp;");
                html = html.replace(/\'/g, "'");
                html = html.replace(/\"/g, "&quot;");
                html = html.replace(/\n/g, "<br>");
                return html;
            },
            decodeHTML: function (str) {
                if (str == null || typeof str === 'undefined' || str === '') {
                    return str;
                }
                var text = str + "";
                text = text.replace(/&gt;/g, "&");
                text = text.replace(/&lt;/g, "<");
                text = text.replace(/&gt;/g, ">");
                text = text.replace(/&nbsp;/g, "    ");
                text = text.replace(/\'/g, "\'");
                text = text.replace(/&quot;/g, "\"");
                text = text.replace(/<br>/g, "\n");
                return text;
            }
        })
    .$();

});