﻿define("Indigox.Web.JsLib.Utils.ListenersSupport",
    [
        "Indigox.Web.JsLib.Utils.ArrayUtil",
        "Indigox.Web.JsLib.Utils.ErrorHandler",
        "Indigox.Web.JsLib.Utils.Event",
        "Indigox.Web.JsLib.Core"
    ],
function (
        ArrayUtil,
        ErrorHandler,
        Event
) {

    // using


    var PREFIX = "on";
    var ListenersSupport =
        Namespace("Indigox.Web.JsLib.Utils")
        .Class("ListenersSupport")
        .Constructor(
            function (source) {
                /** @id Indigox.Web.JsLib.Utils.ListenersSupport.prototype.events */
                this.events = {};
                this.source = source;
            }
        )
        .Members({
            /** @id Indigox.Web.JsLib.Utils.ListenersSupport.prototype.registerListeners */
            registerListeners: function () {
                var i = null,
                    length = null;
                for (i = 0, length = arguments.length; i < length; i++) {
                    this.events[PREFIX + arguments[i]] = [];
                }
            },
            addListener: function (listener, handlers) {
                if (this.hasListener(listener)) {
                    return;
                }
                handlers = handlers || listener;
                for (var event in this.events) {
                    if (event in handlers && isFunction(handlers[event])) {
                        this.events[event].push(new Event(listener, handlers[event]));
                    }
                }
            },
            removeListener: function (listener) {
                var events;
                var i = null,
                    length = null;
                for (var event in this.events) {
                    events = this.events[event],
                    length = events.length;
                    for (i = length - 1; i >= 0; i--) {
                        if (events[i].getTarget() === listener) {
                            events.splice(i, 1);
                        }
                    }
                }
            },
            clearListeners: function () {
                for (var event in this.events) {
                    this.events[event] = [];
                }
            },
            getListeners: function () {
                var listeners = [];

                var events = null;
                var i = null,
                    length = null;
                for (var event in this.events) {
                    events = this.events[event];
                    for (i = 0, length = events.length; i < length; i++) {
                        if (!ArrayUtil.contains(listeners, events[i].getTarget())) {
                            listeners.push(events[i].getTarget());
                        }
                    }
                }
                return listeners;
            },
            hasListener: function (listener) {
                var events = null;

                var i = null,
                    length = null;
                for (var event in this.events) {
                    events = this.events[event];
                    for (i = 0, length = events.length; i < length; i++) {
                        if (events[i].getTarget() === listener) {
                            return true;
                        }
                    }
                }
                return false;
            },
            fire: function (event, args) {
                event = PREFIX + event;
                if (!(event in this.events)) {
                    throw new Error(["the listener \"", event, "\" not exist. Please check the program. If you are control developer, please register the event before using it."].join(""));
                }

                args = args || [];
                args.unshift(this.source);

                var events = this.events[event].slice(0);
                var i = null,
                    length = null;
                for (i = 0; i < events.length; i++) {
                    try {
                        events[i].invoke(args);
                    }
                    catch (ex) {
                        debug.error("fire listener [" + event + "] failed.");
                        debug.error(args);
                        ErrorHandler.log(ex);
                    }
                }
            }
        }).$();

});