﻿define("Indigox.Web.JsLib.Utils.ErrorHandler",
    [
        "Indigox.Web.JsLib.Utils.Util",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Util
) {

    // using


    var ErrorHandler =
        Namespace("Indigox.Web.JsLib.Utils")
        .Class("ErrorHandler")
        .Static({
            alert: function (error) {
                //if (typeof (error.Message) !== 'undefined') {
                //    alert(error.Message);
                //}
                //else if (typeof (error.message) !== 'undefined') {
                //    alert(error.message);
                //}
                //else {
                //    alert(error); // Error object has no toString function in IE
                //}
            },
            log: function (error) {
                if (typeof (error.Message) !== 'undefined') {
                    debug.error(error.Message + '\r\n' + error.StackTrace);
                }
                else if (typeof (error.message) !== 'undefined') {
                    // chrome
                    if (typeof (error.stack) !== 'undefined') {
                        debug.error(error.stack);
                    }
                    else {
                        debug.error(error);
                    }
                }
                else {
                    debug.error(error);
                }
            },
            logAlert: function (error) {
                ErrorHandler.log(error);
                ErrorHandler.alert(error);
            }
        })
    .$();

});