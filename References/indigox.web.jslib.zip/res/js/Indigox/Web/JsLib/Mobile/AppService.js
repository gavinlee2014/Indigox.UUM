﻿define("Indigox.Web.JsLib.Mobile.AppService",
    [
        "Indigox.Web.JsLib.Core"
    ],
    function (
    ) {
        var ApplicationContext =
            Namespace("Indigox.Web.JsLib.Mobile")
            .Class("AppService")
            .Constructor(
                function () {
                }
            )
            .Members({
                call: function (name, args) {
                    args = Array.prototype.slice.call(arguments, 1);
                    debug.log("name: " + name + "   args: ", args);
                }
            })
        .$();
    });