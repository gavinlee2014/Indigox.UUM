﻿define("Indigox.Web.JsLib.Mobile.AppServiceFactory",
    [
        "Indigox.Web.JsLib.Mobile.AndroidAppService",
        "Indigox.Web.JsLib.Mobile.IOSAppService",
        "Indigox.Web.JsLib.Mobile.WindowsPhoneAppService",
        "Indigox.Web.JsLib.Core"
    ],
    function (
        AndroidAppService,
        IOSAppService,
        WindowsPhoneAppService
    ) {
        var userAgent = window.navigator.userAgent;

        function isAndroid() {
            return (userAgent.indexOf('Android') >= 0);
        }

        function isIOS() {
            return (userAgent.indexOf('iPhone') >= 0) || (userAgent.indexOf('iPad') >= 0);
        }

        function isWindowsPhone() {
            return (userAgent.indexOf('MSIE') >= 0);
        }

        var instance = null;

        if (isAndroid()) {
            instance = new AndroidAppService();
        }
        else if (isIOS()) {
            instance = new IOSAppService();
        }
        else if (isWindowsPhone()) {
            instance = new WindowsPhoneAppService();
        }

        var ApplicationContext =
            Namespace("Indigox.Web.JsLib.Mobile")
            .Class("AppServiceFactory")
            .Constructor(
                function () {
                }
            )
            .Static({
                getInstance: function () {
                    return instance;
                }
            })
        .$();
    });