﻿define("Indigox.Web.JsLib.Mobile.WindowsPhoneAppService",
    [
        "Indigox.Web.JsLib.Mobile.AppService",
        "Indigox.Web.JsLib.Utils.UrlUtil",
        "Indigox.Web.JsLib.Core"
    ],
    function (
        AppService,
        UrlUtil
    ) {
        var base = AppService.prototype;

        var ApplicationContext =
            Namespace("Indigox.Web.JsLib.Mobile")
            .Class("WindowsPhoneAppService")
            .Extend(base)
            .Constructor(
                function () {
                }
            )
            .Members({
                call: function (name, args) {
                    //var command = UrlUtil.join(name, args);
                    var fragments = [name];
                    if (args) {
                        var i = 0;
                        for (var p in args) {
                            fragments.push((i === 0) ? "?" : "&", p, "=", args[p]);
                            i++;
                        }
                    }
                    var command = fragments.join("");
                    debug.log(command);
                    window.external.notify(command);
                }
            })
        .$();
    });