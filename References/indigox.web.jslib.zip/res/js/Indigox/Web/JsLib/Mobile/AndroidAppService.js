﻿define("Indigox.Web.JsLib.Mobile.AndroidAppService",
    [
        "Indigox.Web.JsLib.Mobile.AppService",
        "Indigox.Web.JsLib.Utils.StringUtil",
        "Indigox.Web.JsLib.Core"
    ],
    function (
        AppService,
        StringUtil
    ) {
        var base = AppService.prototype;

        var ApplicationContext =
            Namespace("Indigox.Web.JsLib.Mobile")
            .Class("AndroidAppService")
            .Extend(base)
            .Constructor(
                function () {
                }
            )
            .Members({
                call: function (name, args) {
                    debug.log("name: " + name);
                    this[StringUtil.toCamalCase(name)].apply(this, args)
                },

                //-------------------------------------------------------
                // AppClient
                //-------------------------------------------------------
                clearCache: function () {
                    AppClient.ClearCache();
                },

                createContact: function (args) {
                    var email = args.email;
                    var name = args.name;
                    var phone = args.phone;
                    var mobile = args.mobile;
                    AppClient.CreateContact(name, mobile, phone, email);
                },

                exit: function () {
                    AppClient.Exit();
                },

                logOut: function () {
                    AppClient.LogOut();
                },

                refresh: function () {
                    AppClient.Reload();
                },

                settings: function () {
                    AppClient.LaunchSetting();
                },

                //-------------------------------------------------------
                // MailClient
                //-------------------------------------------------------
                sendMail: function () {
                    MailClient.launch();
                }
            })
        .$();
    });