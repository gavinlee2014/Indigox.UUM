﻿define("Indigox.Web.JsLib.Connection.Connection",
    [
        "Indigox.Web.JsLib.Utils.Util",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Util
) {

    var Connection =
        Namespace("Indigox.Web.JsLib.Connection")
        .Class("Connection")
        .Constructor(
            function (options) {
                Util.copy(this, Util.copyExist({
                    url: '',
                    data: [],
                    async: true,
                    method: 'GET',
                    callback: function (data) {
                    },
                    errorCallback: function (error) {
                        debug.error(error);
                    }
                }, options));
            }
        )
        .Members({
            send: function () {
            }
        })
    .$();
});