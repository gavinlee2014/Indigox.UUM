﻿define("Indigox.Web.JsLib.Connection.Ajax",
    [
        "Indigox.Web.JsLib.Connection.Connection",
        "Indigox.Web.JsLib.Utils.Deferred",
        "Indigox.Web.JsLib.Utils.Delegate",
        "Indigox.Web.JsLib.Utils.UrlUtil",
        "Indigox.Web.JsLib.Utils.Browser",
        "Indigox.Web.JsLib.Utils.AuthorizationHeaderUtil",
        "jquery",
        "Indigox.Web.JsLib.Core"
    ],
    function (
        Connection,
        Deferred,
        Delegate,
        UrlUtil,
        Browser,
        AuthorizationHeaderUtil,
        jQuery
    ) {
        var Browser = Browser.getInstance();
        var base = Connection.prototype;

        var cons = [];

        var Ajax =
            Namespace("Indigox.Web.JsLib.Connection")
            .Class("Ajax")
            .Extend(base)
            .Constructor(
                function (options) {
                    base.constructor.apply(this, arguments);
                    this.dfd = null;
                }
            )
            .Members({
                send: function () {
                    if (this.dfd != null) {
                        // is busy
                        return;
                    }

                    this.dfd = new Deferred();
                    var promise = this.dfd.promise();

                    var me = this;

                    /**
                    *   ①  when contentType="text/json", jquery return an Object convert from responsed json text.
                    *       set dataType: "text" to force return json text.
                    */

                    jQuery.ajax({
                        url: UrlUtil.join(this.url),
                        async: this.async,
                        data: this.data,
                        dataType: "text", // ①
                        type: this.method,
                        timeout: 300000,
                        success: Delegate.create(this.onSuccess, this),
                        error: Delegate.create(this.onError, this),
                        cache: false,
                        xhr: function () {
                            try {
                                return window.ActiveXObject ? new ActiveXObject("Microsoft.XMLHTTP") : new XMLHttpRequest();
                            } catch (e) {
                                return new XMLHttpRequest();
                            }
                        },
                        beforeSend: function (XMLHttpRequest) {
                            XMLHttpRequest.onreadystatechange = function () {
                                var data = {
                                    state: XMLHttpRequest.readyState
                                };

                                if (((XMLHttpRequest.readyState > 1) && (Browser.name !== 'IE')) ||
                                    (XMLHttpRequest.readyState === 4)) {
                                    if (XMLHttpRequest.readyState > 1) {
                                        data["responseLength"] = XMLHttpRequest.getResponseHeader("X-Content-Length");
                                    }
                                }

                                me.onProgress(data);
                            }
                            XMLHttpRequest.setRequestHeader("Cache-Control", "no-cache");
                            XMLHttpRequest.setRequestHeader("Pragma", "no-cache");
                            XMLHttpRequest.setRequestHeader("If-Modified-Since", "0");
                        }
                    });

                    return promise;
                },

                onProgress: function (data) {
                    if (this.dfd) {
                        this.dfd.notify(data);
                    }
                },

                onSuccess: function (data, textStatus) {
                    this.dfd.resolve(data);
                    this.dfd = null;
                    this.callback.apply(this, [data]);
                },

                onError: function (XMLHttpRequest, textStatus, errorThrown) {
                    //#region debug code
                    //debug.log("ajax onError:");
                    //try {
                    //    debug.log("XMLHttpRequest: " + JSON.stringify(XMLHttpRequest));
                    //}
                    //catch (e) {
                    //    debug.log("XMLHttpRequest: " + XMLHttpRequest);
                    //}
                    //try {
                    //    debug.log("textStatus: " + JSON.stringify(textStatus));
                    //}
                    //catch (e) {
                    //    debug.log("textStatus: " + textStatus);
                    //}
                    //try {
                    //    debug.log("errorThrown: " + JSON.stringify(errorThrown));
                    //}
                    //catch (e) {
                    //    debug.log("errorThrown: " + errorThrown);
                    //}
                    //#endregion

                    if (textStatus === 'timeout') {
                        var error = "Ajax Request Timeout!";
                        this.errorCallback.apply(this, [error]);
                        this.dfd.reject(error);
                        this.dfd = null;
                        return;
                    }

                    var stateCode = XMLHttpRequest.status;
                    var error = "";
                    if (stateCode == 401) {
                        //this.dfd.reject(error);
                        //this.dfd = null;
                        this.redirectToLoginPage(XMLHttpRequest);
                    }
                    else if (stateCode == 403) {
                        //this.dfd.reject(error);
                        //this.dfd = null;
                        this.redirectToForbiddenPage(XMLHttpRequest);
                    }
                    else if (stateCode >= 400) {
                        error = this.getErrorFromXMLHttpRequest(XMLHttpRequest);
                        this.errorCallback.apply(this, [error]);
                        this.dfd.reject(error);
                        this.dfd = null;
                    }
                    else {
                        error = "stateCode=" + stateCode;
                        debug.error(error);
                        this.dfd.reject(error);
                        this.dfd = null;
                    }
                },

                redirectToLoginPage: function (XMLHttpRequest) {
                    var header = XMLHttpRequest.getResponseHeader("WWW-Authenticate");
                    window.location.href = AuthorizationHeaderUtil.getParam(header, "loginUrl");
                },

                redirectToForbiddenPage: function (XMLHttpRequest) {
                    var header = XMLHttpRequest.getResponseHeader("WWW-Authenticate");
                    window.location.href = AuthorizationHeaderUtil.getParam(header, "forbiddenUrl");
                },

                getErrorFromXMLHttpRequest: function (XMLHttpRequest) {
                    var errMsg = "[Code: " + XMLHttpRequest.status + "] ";
                    var r = /^[\s\S]*<html/g;
                    if (r.test(XMLHttpRequest.responseText)) {
                        return errMsg + XMLHttpRequest.statusText;
                    }
                    else {
                        return errMsg + XMLHttpRequest.responseText;
                    }
                }
            })
        .$();
    });