﻿define("Indigox.Web.JsLib.Core",
    [
        "Indigox.Web.JsLib.Core.debug",
        "Indigox.Web.JsLib.Core.is",
        "Indigox.Web.JsLib.Core.Keywords"
    ],
    function (
        debug,
        is,
        Keywords
    ) {
        return {};
    });