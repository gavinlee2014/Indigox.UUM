﻿define("Indigox.Web.JsLib.Core.debug", function () {
    var enableDebug = true;
    window.timer = {};
    window.timespan = {};
    window.out = false;

    var util = {
        encodeHtml: function (msg) {
            var ret = msg.replace(/&/g, '&amp;') // &
                     .replace(/(\s)[ ]/g, '$1&nbsp;') // blank
                     .replace(/\t/g, '&nbsp;&nbsp;&nbsp;&nbsp;') // tab
                     .replace(/</g, '&lt;') // <
                     .replace(/>/g, '&gt;') // >
                     .replace(/\r/g, '') // /r
                     .replace(/\n/g, '<br/>'); // /n
            return ret;
        },

        catchPageError: function () {
            window.onerror = function (e) {
                window.debug.error(e);
            };
        }
    };

    var writers = {
        consoleWriter: function () {
            return console;
        },

        /**
        * 弹出窗显示调试信息
        */
        alertWriter: function () {
            return {
                log: function (msg, level) {
                    level = level || 'debug';
                    alert('[' + level + '] ' + msg);
                },
                error: function (msg) {
                    this.log(msg, 'error');
                },
                warn: function (msg) {
                    this.log(msg, 'warn');
                }
            };
        },

        /**
        * 空的 writer，不输出任何调试信息
        */
        dummyWriter: function () {
            return {
                log: function (msg) {
                },
                error: function (msg) {
                },
                warn: function (msg) {
                }
            };
        },

        /**
        *  在页面上显示调试信息 (default)
        */
        pageWriter: function () {
            /**
            * 日志输出控制台
            */
            var _console = null;
            var _enable = true;
            var _queue = [];
            var _documentReady = true;

            util.catchPageError();

            /**
            * 确认控制台已创建
            */
            function _ensureConsole() {
                if (!_console) {
                    _console = document.getElementById('debug_console');
                    if (!_console) {
                        _createConsole();
                    }
                }
            }

            /**
            * 创建控制台
            */
            function _createConsole() {
                if (document.body) {
                    _documentReady = true;
                    var c = document.createElement('div');
                    c.id = 'debug_console';
                    document.body.appendChild(c);
                    _console = c;
                }
                else {
                    _documentReady = false;
                }
            }

            function writeln(msg, level) {
                if (!_enable) {
                    return;
                }
                try {
                    _ensureConsole();
                    if (_documentReady) {
                        var queueLength = _queue.length;
                        if (queueLength > 0) {
                            var i, item;
                            for (i = 0; i < queueLength; i++) {
                                item = _queue[i];
                                _console.appendChild(createLnElement(item.msg, item.level));
                            }
                            _queue = [];
                        }
                        _console.appendChild(createLnElement(msg, level));
                    }
                    else {
                        _queue.push({ msg: msg, level: level });
                    }
                } catch (e) {
                    alert('debug module error: ' + e.message);
                    _enable = false;
                }
            }

            function createLnElement(msg, level) {
                var node = document.createElement('div');
                node.className = 'node' + ((level) ? " " + level : "");
                node.innerHTML = (typeof msg === 'undefined') ? '[undefined]' : ((msg === null) ? '[null]' : util.encodeHtml(msg.toString()));
                return node;
            }

            return {
                /**
                * 记录调试日志，当启用 firebug 的时候输出到 console，没有则忽略
                * @alias debug.log
                * @param {String} msg
                */
                log: function (msg) {
                    writeln(msg);
                },
                error: function (msg) {
                    writeln(msg, 'error');
                },
                warn: function (msg) {
                    writeln(msg, 'warn');
                }
            };
        },

        popupWriter: function () {
            var options = 'width=800,height=600,resizable=1,scrollbars=1,location=0,status=0,toolbar=0';
            var windowName = 'indigox_web_jslib_debugwindow';
            var _enable = true;

            util.catchPageError();

            function writeln(msg, level) {
                if (!_enable) {
                    return;
                }
                try {
                    var w = window.open('', windowName, options);
                    //w.focus();
                    var d = w.document;
                    //alert(d.body.getElementsByTagName('div').length);
                    if (d.body.getElementsByTagName('div').length === 0) {
                        writedoc(d);
                    }
                    d.body.appendChild(createLnElement(msg, level, d));
                    // auto scroll to page end
                    w.scrollTo(0, d.body.scrollHeight);
                } catch (e) {
                    alert('debug module error: ' + e.message);
                    _enable = false;
                }
            }

            function createLnElement(msg, level, d) {
                var node = d.createElement('div');
                node.className = 'node' + ((level) ? " " + level : "");
                node.innerHTML = (typeof msg === 'undefined') ? '[undefined]' : ((msg === null) ? '[null]' : util.encodeHtml(msg.toString()));
                return node;
            }

            function writedoc(d) {
                //alert(1);
                d.write([
                    '<html>',
                    '<head>',
                    '<title>debug</title>',
                    '<style>',
                    'body {background-color: #DDDDDD;border: 1px solid #3333CC;max-height: 200px;width: auto;overflow: scroll; /*white-space: nowrap;*/}',
                    '.node {text-align: left;padding: 8px;border-bottom: 1px solid #C0C0C0;color: #000000;background-color: #FFFFFF;}',
                    '.warn {background-position: 4px 8px;padding-left: 30px;background-color: #FFFFC8;color: #000000;background-image: url(/res/css/img/warn.gif);background-repeat: no-repeat;background-attachment: fixed;}',
                    '.error {background-position: 4px 8px;padding-left: 30px;background-color: #FFEBEB;color: #FF0000;background-image: url(/res/css/img/error.gif);background-repeat: no-repeat;background-attachment: fixed;}',
                    '</style>',
                    '</head>',
                    '<body>',
                    '<div><input type="button" value="CLOSE" onclick="window.close();" /></div>',
                    '</body>',
                    '</html>'
                ].join(''));
            }

            return {
                /**
                * 记录调试日志，当启用 firebug 的时候输出到 console，没有则忽略
                * @alias debug.log
                * @param {String} msg
                */
                log: function (msg) {
                    writeln(msg);
                },
                error: function (msg) {
                    writeln(msg, 'error');
                },
                warn: function (msg) {
                    writeln(msg, 'warn');
                }
            };
        }
    };

    var times = {};

    var format = function (array) {
        var strs = [];
        for (var i = 0, length = array.length; i < length; i++) {
            var item = array[i];
            if (item === null) {
                strs.push('null');
            }
            else if (typeof (item) === 'undefined') {
                strs.push('undefined');
            }
            else if (typeof (item) === 'object') {
                if (item.toString !== Object.prototype.toString) {
                    strs.push(item.toString());
                } else {
                    //strs.push(JSON.stringify ? JSON.stringify(item) : item);
                    strs.push(item);
                }
            }
            else {
                strs.push(item);
            }
        }
        return strs.join(' ');
    };

    var debug = {
        writer: writers.dummyWriter(),
        log: function (msg) {
            this.writer.log(format(arguments));
        },
        error: function (msg) {
            this.writer.error(format(arguments));
        },
        warn: function (msg) {
            this.writer.warn(format(arguments));
        },
        time: function (name, addUp) {
            window.out = false;
            try {
                if (!times[name]) {
                    times[name] = {
                        beginTime: null,
                        totalSpend: null,
                        addUp: false,
                        count: 0
                    };
                }

                if (times[name].count === 0) {
                    times[name].beginTime = new Date().getTime();
                    times[name].addUp = !!addUp;
                }

                times[name].count++;
            }
            catch (e) {
                debug.warn(e);
            }
        },
        timeEnd: function (name, additional) {
            try {
                var time = times[name];
                if (!time || time.beginTime == null) {
                    debug.warn('time ' + name + ' is not start.');
                    return;
                }
                time.count--;
                if (time.count > 0) {
                    return;
                }
                var spend = new Date().getTime() - time.beginTime;
                window.timespan[name] = spend; //
                time.beginTime = null;
                time.totalSpend = (time.addUp) ? (time.totalSpend + spend) : (spend);
                debug.log(time.totalSpend + "ms\t" + name + ((additional) ? ("\t" + additional) : ""));
                window.timer[name] = time.totalSpend;
                window.out = true;
            }
            catch (e) {
                debug.warn(e);
            }
        },
        trace: function () {
            // only FF/Chrome support console.trace() method to print trace stack info.
        }
    };

    if (window.console && enableDebug) {
        debug.writer = writers.consoleWriter();
        //debug.writer = writers.pageWriter();

        // replace time & timeEnd method,
        // in MIUI browser, those tow methods does not write anything.
        console.time = debug.time;
        console.timeEnd = debug.timeEnd;
        //console.trace = debug.trace;

        debug = console;
    }

    window.debug = debug;
});