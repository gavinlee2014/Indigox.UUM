﻿define("Indigox.Web.JsLib.Core.is", function () {
    /**
    * 判断值对象，所有的 isXXX() 方法都会复制到 window 中，
    * 可以直接用 isXXX() 方法，而不需要 _is.isXXX()
    */
    var _is = {
        /** @id isFunction */
        isFunction: function (o) {
            return (typeof (o) === "function");
        },

        /** @id isNumber */
        isNumber: function (o) {
            return (typeof (o) === "number");
        },

        /** @id isInt */
        isInt: function (x) {
            var y = parseInt(x, 10);
            if (isNaN(y)) {
                return false;
            }
            return x === y && x.toString() === y.toString();
        },

        /** @id isString */
        isString: function (o) {
            return (typeof (o) === "string");
        },

        isBoolean: function (val) {
            return (typeof (val) === "boolean"); //(val instanceof Boolean);
        },

        /** @id isObject */
        isObject: function (o) {
            return (typeof (o) === "object");
        },

        /** @id isArray */
        isArray: function (o) {
            return (!this.isNullOrUndefined(o) && o instanceof Array);
        },

        /** @id isNull */
        isNull: function (o) {
            return (o == null);
        },

        /** @id isUndefined */
        isUndefined: function (o) {
            return (typeof (o) === "undefined");
        },

        /** @id isNullOrUndefined */
        isNullOrUndefined: function (o) {
            return (typeof (o) === "undefined" || o == null);
        },

        /** @id isElement */
        isElement: function (obj) {
            if (isNullOrUndefined(obj)) {
                return false;
            }
            try {
                //Using W3 DOM2 (works for FF, Opera and Chrom)
                return obj instanceof HTMLElement;
            }
            catch (e) {
                //Browsers not supporting W3 DOM2 don't have HTMLElement and
                //an exception is thrown and we end up here. Testing some
                //properties that all elements have. (works on IE7)
                return (typeof obj === "object") &&
                (obj.nodeType === 1) &&
                (typeof obj.style === "object") &&
                (typeof obj.ownerDocument === "object");
            }
        }
    };

    // apply _is to window
    for (var k in _is) {
        window[k] = _is[k];
    }
});