﻿/**
* @author Yi Zhang
*/
define("Indigox.Web.JsLib.Core.Keywords",
    [
        "Indigox.Web.JsLib.Core.debug"
    ],
    function (

    ) {
        /**
        * 此方法定义了Namespace的关键字，用于声明一个命名空间空间范围，在该命名空间下可以组织代码。
        * @method
        * @param {string} namespaces 传入一个命名空间名称
        * @return {Class} 返回一个Class的对象，用于创建类型。
        */
        window.Namespace = function (namespace) {
            return new Class({
                namespace: namespace
            });
        };

        //var system = window;   // 启用 window.Indigox
        var system = {};       // 禁用 window.Indigox

        /**
        * 此方法定义了Class类型，该类型包含Class、Extend、Constructor、Static、Members和$方法。
        * @alias Class
        * @param {Object} classInfo 传入类型信息的对象，包括命名空间、类名、父类、构造函数、静态成员、成员
        */
        var Class = function (classInfo) {
            /**
            * 此方法定义了Class的关键字，用于申明一个类型。
            * @memberOf Class
            * @method
            * @param {String} className 传入一个类型的名称。
            * @param {Boolean} preventEval 当preventEval为true时，不使用eval输出方法，这样就要求不能使用Using和base()
            * @return {Class} 返回一个Class的对象，用于创建类型。
            */
            this.Class = function (className) {
                classInfo.className = className;
                return this;
            };
            /**
            * 此方法定义了Extend的关键字，用于继承一个类型。
            * @memberOf Class
            * @method
            * @param {Object} superclass 传入一个该类型的父类。
            * @return {Class} 返回一个Class的对象，用于创建类型。
            */
            this.Extend = function (superclass) {
                classInfo.superclass = superclass;
                return this;
            };
            /**
            * 此方法定义了Constructor关键字，用于申明该类型的构造函数。
            * @memberOf Class
            * @method
            * @param {Function} constructor 传入一个该类型的构造函数。
            * @return {Class} 返回一个Class的对象，用于创建类型。
            */
            this.Constructor = function (constructor) {
                classInfo._constructor = constructor;
                return this;
            };
            /**
            * 此方法定义了Static关键字，用于申明该类型的静态成员。
            * @memberOf Class
            * @method
            * @param {Object} staticMembers 传入一个该类型的静态成员对象。
            * @return {Class} 返回一个Class的对象，用于创建类型。
            */
            this.Static = function (staticMembers) {
                classInfo.staticMembers = staticMembers;
                return this;
            };

            /**
            * 此方法定义了Members关键字，用于申明该类型的成员。
            * @memberOf Class
            * @method
            * @param {Object} members 传入一个该类型的成员对象。
            * @return {Class} 返回一个Class的对象，用于创建类型。
            */
            this.Members = function (members) {
                classInfo.members = members;
                return this;
            };
            /**
            * 此方法用于返回已申明的类型。在使用依次使用Namespace/Class/Extend(可选)
            * /Constructor/Static(可选)/Members(可选)关键字申明一个类型后，使用该方
            * 法返回已申明的类型。
            * @memberOf Class
            * @method
            * @return {Function} 返回一个申明的类型。
            */
            this.$ = function () {
                return classComplier.declare(classInfo);
            };
        };

        var classComplier = {
            createNamespace: function (namesapce) {
                var i = null, length = null;
                if (namesapce instanceof Array) {
                    for (i = 0, length = namesapce.length; i < length; i++) {
                        this.createNamespace(namesapce[i]);
                    }
                }
                else {
                    var names = namesapce.split('.');
                    var ns = system;
                    for (i = 0, length = names.length; i < length; i++) {
                        ns = ns[names[i]] = ns[names[i]] || {};
                    }
                    return ns;
                }
            },

            createConstructor: function (namespace, className, constructor) {
                //如果参数constructor为空，则使用空函数作为构造函数
                constructor = constructor || function () { };
                //constructor = "function(){return new " + constructor.toString() + ";}"
                var _class = namespace[className] = constructor;
                return _class;
            },

            createExtend: function (_class, superclass) {
                //使用f的空构造函数代替superclass的构造函数，避免使用_class.prototype = new superclass()时将执行一遍superclass的构造函数
                var f = function () { };
                f.prototype = superclass;
                _class.prototype = new f();
                _class.superclass = superclass.constructor;
                _class.prototype.constructor = _class;

                return _class;
            },

            createStatic: function (_class, staticMembers, createMethodWithUsingsAndBase) {
                for (var key in staticMembers) {
                    _class[key] = staticMembers[key];
                }
                return _class;
            },

            createMembers: function (_class, members, createMethodWithUsingsAndBase) {
                for (var key in members) {
                    _class.prototype[key] = members[key];
                }
                return _class;
            },

            declare: function (classInfo) {
                var namespace = this.createNamespace(classInfo.namespace);

                var _class;
                var _fullname = (classInfo.namespace + '.' + classInfo.className);

                //----------------------------------------------------
                // if the class already defined, return the defined class direct.
                //----------------------------------------------------
                if (_fullname in classFullnameMapping) {
                    debug.warn('redefine class: ' + _fullname);
                    return classFullnameMapping[_fullname]._class;
                }
                //----------------------------------------------------

                try {
                    if (classInfo.className) {
                        _class = this.createConstructor(namespace, classInfo.className, classInfo._constructor);
                    }

                    if (classInfo.superclass) {
                        _class = this.createExtend(_class, classInfo.superclass);
                    }
                    if (classInfo.staticMembers) {
                        _class = this.createStatic(_class, classInfo.staticMembers);
                    }
                    if (classInfo.members) {
                        _class = this.createMembers(_class, classInfo.members);
                    }

                    // AMD Support
                    // @author WangXiang
                    if (moduleManager) {
                        if (moduleManager.isDefined(_fullname)) {
                            var module = moduleManager.get(_fullname);
                            if (module.factory) {
                                module.exports = _class;
                            }
                            else {
                                debug.warn("module of clsss '" + _fullname + "' not set factory.");
                            }
                        }
                        else {
                            debug.warn("class '" + _fullname + "' is not used define.");
                            define(_fullname, function () {
                                return _class;
                            });
                        }
                    }

                    register(classInfo.namespace, classInfo.className, _class);
                } catch (e) {
                    debug.log(classInfo);
                    throw "Complie class " + _fullname + " failed.";
                }
                return _class;
            }
        };

        var classes = [],
            classFullnameMapping = {},
            classAliasMapping = {};

        function register(namespace, className, _class) {
            var fullName = [namespace, ".", className].join("");
            if (fullName in classFullnameMapping) {
                throw new Error(["The class \"", fullName, "\" has be declared. please check the program, and make sure there is no duplication of class."].join(""));
            }

            var alias = className.toLowerCase();
            if (alias in classAliasMapping) {
                throw new Error(["The alias:\"", alias, "\" of class \"", fullName, "\" has be declared. please check the program, and make sure there is no duplication of class."].join(""));
            }
            var type = new Type(namespace, className, alias, _class);
            classes.push(type);
            classFullnameMapping[fullName] = type;
            classAliasMapping[alias] = type;
        }

        var Type = function (namespace, className, alias, _class) {
            this.namesapce = namespace;
            this.name = className;
            this.alias = alias;
            this._class = _class;
        };

        Type.forAlias = function (alias) {
            if (!(alias in classAliasMapping)) {
                throw new Error(["The alias:\"", alias, "\" of class has not be declared. please check spelling, or make sure there is class declaration exists."].join(""));
            }
            return classAliasMapping[alias];
        };

        Type.forFullName = function (fullName) {
            if (!(fullName in classFullnameMapping)) {
                throw new Error(["The class \"", fullName, "\" has not be declared. please check spelling, and make sure there is class declaration exists."].join(""));
            }
            return classFullnameMapping[fullName];
        };

        Type.forClass = function (_class) {
            var i = null,
                length = null;
            for (i = 0, length = classes.length; i < length; i++) {
                if (classes[i].getClass() === _class) {
                    return classes[i];
                }
            }
            throw new Error(["The class \"", _class.toString(), "\" has not be declared. please check the program, and make sure there is class declaration exists."].join(""));
        };

        Type.forInstance = function (instance) {
            return Type.forClass(instance.constructor);
        };

        Type.prototype = {
            getFullName: function () {
                return [this.namespace, ".", this.name].join("");
            },
            getNamespace: function () {
                return this.namespace;
            },
            getName: function () {
                return this.name;
            },
            getAlias: function () {
                return this.alias;
            },
            getClass: function () {
                return this._class;
            },
            createInstance: function () {
                return new this._class();
            }
        };

        window.Type = Type;

        // AMD Support
        // @author WangXiang
        var moduleManager;

        require.adapte({
            setModuleManager: function (value) {
                moduleManager = value;
            }
        });

        return {
            Type: Type
        };
    });