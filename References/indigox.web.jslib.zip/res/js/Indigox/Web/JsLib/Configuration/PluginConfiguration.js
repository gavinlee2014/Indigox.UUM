﻿define("Indigox.Web.JsLib.Configuration.PluginConfiguration",
    [
        "Indigox.Web.JsLib.Controls.Plugins.PluginFactory",
        "Indigox.Web.JsLib.Controls.Plugins"
    ],
    function (
        PluginFactory,
        Plugins
    ) {
        var factory = PluginFactory.getInstance();

        factory.registerPlugin('summary', Plugins.SummaryFieldPlugin);
        factory.registerPlugin('calculate', Plugins.CalculatePlugin);
        factory.registerPlugin('timespan', Plugins.TimeSpanPlugin);
        factory.registerPlugin('badge', Plugins.BadgePlugin);
        factory.registerPlugin('permission', Plugins.PermissionPlugin);
        factory.registerPlugin('valuedialog', Plugins.ValueDialogPlugin);
        factory.registerPlugin('visible', Plugins.VisiblePlugin);
    });