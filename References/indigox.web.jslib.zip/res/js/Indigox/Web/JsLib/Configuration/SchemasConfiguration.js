﻿define("Indigox.Web.JsLib.Configuration.SchemasConfiguration",
    [
        "Indigox.Web.JsLib.UI.SchemaRegistry",
        "Indigox.Web.JsLib.UI.Schema",
        "Indigox.Web.JsLib.Utils.Browser",
        "Indigox.Web.JsLib.WebContexts.Context"
    ],
    function (
        SchemaRegistry,
        Schema,
        Browser,
        Context
    ) {
        var schemaRegisterInstance = SchemaRegistry.getInstance();

        schemaRegisterInstance.builtinAttribute([
            Schema.ATTR('id', '${id}'),
            Schema.STYLE('height', '${height}'),
            Schema.STYLE('width', '${width}'),
        //  Schema.STYLE('display', '${visible}'),
            Schema.CSS('invisible', '${visible}'),
            Schema.CSS('control', '${defaultName}'),
            Schema.CSS('readonly', '${readonly}'),
            Schema.CSS('disable', '${enable}')
        ]);

        schemaRegisterInstance.register('page',
            Schema.BODY([Schema.CSS('masked', '${masked}')], [
                Schema.DIV([], [
                    Schema.EACH('${children}', true)
                ]),
                Schema.CTRL('${loadMask}')
            ])
        );

        schemaRegisterInstance.register('loadmask',
            Schema.DIV([], [
                Schema.DIV([Schema.CSS('mask', 'true')], []),
                Schema.SPAN([], [
                    Schema.IMG([Schema.ATTR('src', '/res/css/img/loading.gif')], []),
                    Schema.LABEL([], [
                        Schema.TEXT('${value}')
                    ])
                ])
            ])
        );

        schemaRegisterInstance.register('literal',
            Schema.DIV([], [
        //      Schema.TEXT('${value}')
            ])
        );

        schemaRegisterInstance.register('richtextview',
            Schema.DIV([], [
                Schema.DIV([Schema.CSS('toolbar-container', true)], []),
                Schema.DIV([Schema.CSS('richtextview-content', true)], [
        //          Schema.TEXT('${value}')
                ])
            ])
        );

        schemaRegisterInstance.register('richtextview', function () { return Browser.isMobile(); },
            Schema.DIV([Schema.EVENT('click', '${onClick}'), Schema.EVENT('touchstart', '${onTouchStart}'), Schema.EVENT('touchend', '${onTouchEnd}')], [
                Schema.DIV([Schema.CSS('toolbar-container', true)], [
                    Schema.INPUT([Schema.ATTR('type', 'button'), Schema.ATTR('value', '查看原文'), Schema.CSS('toolbar-enterfullview', true)], []),
                    Schema.INPUT([Schema.ATTR('type', 'button'), Schema.ATTR('value', '返回'), Schema.CSS('toolbar-leavefullview', true)], [])
                ]),
                Schema.DIV([Schema.CSS('richtextview-content', true)], [
        //          Schema.TEXT('${value}')
                ])
            ])
        );

        schemaRegisterInstance.register('content',
            Schema.DIV([], [
                Schema.EACH('${children}', true)
            ])
        );

        schemaRegisterInstance.register('label',
            Schema.LABEL([], [
                Schema.TEXT('${value}')
            ])
        );

        schemaRegisterInstance.register("datepicker",
            Schema.DIV([Schema.CSS("dateonly", "${editHMS}"), Schema.EVENT("change", "${onChange}"), Schema.EVENT("click", "${onClick}")], [
                Schema.DIV([Schema.CSS("dateinputarea", true)], [
                    Schema.INPUT([Schema.CSS("dateinput", true), Schema.ATTR("type", "text"), Schema.ATTR("value", "${date}")]),
                    Schema.INPUT([Schema.CSS("selectdatebutton", true), Schema.ATTR("type", "button"), Schema.ATTR("value", "...")])
                ]),
                Schema.DIV([Schema.CSS("timeinputarea", true)], [
                    Schema.SELECT([Schema.CSS("hoursinput", true), Schema.ATTR("value", "${hours}")]),
                    Schema.SPAN([], [Schema.TEXT(":")]),
                    Schema.SELECT([Schema.CSS("minutesinput", true), Schema.ATTR("value", "${minutes}")])//,
        //          Schema.SPAN([], [Schema.TEXT(":")]),
        //          Schema.SELECT([Schema.CSS("secondsinput", true), Schema.ATTR("value", "${seconds}")])
                ])
            ])
        );

        schemaRegisterInstance.register('button',
            Schema.INPUT([Schema.ATTR('type', 'button'), Schema.ATTR('value', '${value}'), Schema.ATTR('disabled', '${enable}'), Schema.STYLE('background-image', '${icon}'), Schema.EVENT('click', '${onClick}')], [])
        );

        schemaRegisterInstance.register('button', function () { return Browser.isMobile() || Browser.isTablet(); },
            Schema.INPUT([Schema.ATTR('type', 'button'), Schema.ATTR('value', '${value}'), Schema.ATTR('disabled', '${enable}'), Schema.STYLE('background-image', '${icon}'), Schema.EVENT('click', '${onClick}'), Schema.EVENT('touchstart', '${onTouchStart}'), Schema.EVENT('touchend', '${onTouchEnd}')], [])
        );

        schemaRegisterInstance.register('textbox',
            Schema.INPUT([Schema.ATTR('type', 'text'), Schema.ATTR('value', '${value}'), Schema.ATTR('readOnly', '${readonly}'), Schema.EVENT('change', '${onChange}'), Schema.EVENT('click', '${onClicked}')])
        );

        schemaRegisterInstance.register('currency',
            Schema.DIV([Schema.EVENT('change', '${onChange}')], [
                Schema.DIV([], [
                    Schema.TEXT('小写：'),
                    Schema.INPUT([Schema.ATTR('type', 'text'), Schema.ATTR('value', '${value}'), Schema.ATTR('readOnly', '${readonly}')])
                ]),
                Schema.DIV([], [
                    Schema.TEXT('大写：'),
                    Schema.SPAN([], [
                        Schema.TEXT('${amountInWords}')
                    ])
                ])
            ])
        );

        schemaRegisterInstance.register('richtextbox',
            Schema.TEXTAREA([Schema.CSS('richtextboxmode', '${mode}'), Schema.ATTR('readOnly', '${readonly}'), Schema.EVENT('change', '${onChange}')], [
                Schema.TEXT('${value}')
            ])
        );

        schemaRegisterInstance.register('hyperlink',
            Schema.A([Schema.ATTR('href', '${href}'), Schema.ATTR('target', '${target}'), Schema.STYLE('background-image', '${icon}'), Schema.EVENT('click', '${onClick}')], [
                Schema.TEXT('${text}')
            ])
        );

        schemaRegisterInstance.register('checkbox',
            Schema.DIV([Schema.EVENT('click', '${onClick}')], [
                Schema.INPUT([Schema.ATTR('type', 'checkbox'), Schema.ATTR('value', '${rawValue}'), Schema.ATTR('checked', '${checked}'), Schema.ATTR('disabled', '${enable}')]),
                Schema.LABEL([], [
                    Schema.TEXT('${text}')
                ])
            ])
        );

        schemaRegisterInstance.register('radiobox',
            Schema.DIV([Schema.EVENT('click', '${onClick}')], [
                Schema.INPUT([Schema.ATTR('type', 'radio'), Schema.ATTR('value', '${rawValue}'), Schema.ATTR('checked', '${checked}'), Schema.ATTR('disabled', '${enable}')]),
                Schema.LABEL([Schema.ATTR('htmlFor', '${name}')], [
                    Schema.TEXT('${text}')
                ])
            ])
        );

        schemaRegisterInstance.register('paging',
            Schema.DIV([Schema.EVENT('click', '${onClick}'), Schema.EVENT('change', '${onChange}')], [
                Schema.A([Schema.CSS('firstpage', true)], [Schema.TEXT('第一页')]),
                Schema.A([Schema.CSS('prevpage', true)], [Schema.TEXT('上一页')]),
                Schema.LABEL([], [Schema.TEXT('第')]),
                Schema.INPUT([Schema.ATTR('value', '${currentPage}')], []),
                Schema.LABEL([], [Schema.TEXT('页，共')]),
                Schema.LABEL([Schema.CSS('pagecount', true)], [Schema.TEXT('${pageCount}')]),
                Schema.LABEL([], [Schema.TEXT('页')]),
                Schema.A([Schema.CSS('nextpage', true)], [Schema.TEXT('下一页')]),
                Schema.A([Schema.CSS('lastpage', true)], [Schema.TEXT('最后一页')])
            ])
        );

        schemaRegisterInstance.register('paging', function () { return Browser.isMobile() || Browser.isTablet(); },
            Schema.DIV([
                Schema.CSS('paging-modelloading', '${modelLoading}'),
                Schema.EVENT('touchstart', '${onTouchStart}'),
                Schema.EVENT('touchend', '${onTouchEnd}'),
                Schema.EVENT('click', '${onClick}')
            ], [
                Schema.IMG([Schema.ATTR('src', '/res/css/img/loading.gif')], []),
                Schema.A([Schema.CSS('nextpage', true)], [Schema.TEXT('更多')])
            ])
        );

        schemaRegisterInstance.register('datalist',
            Schema.UL([], [
                Schema.EACH('${items}')
            ])
        );

        schemaRegisterInstance.register('animatedlist',
            Schema.MARQUEE([], [
                Schema.EACH('${items}')
            ])
        );

        schemaRegisterInstance.register('fieldset',
            Schema.UL([], [
                Schema.EACH('${items}')
            ])
        );

        schemaRegisterInstance.register('fieldcontainer',
            Schema.LI([Schema.EVENT('click', '${onClick}'), Schema.CSS('fieldcontainer', '${collapsed}'), Schema.CSS('required', '${required}'), Schema.CSS('vertical', '${vertical}')], [
                Schema.DL([], [
                    Schema.DT([], [
                        Schema.LABEL([], [
                            Schema.TEXT('${text}')
                        ])
                    ]),
                    Schema.DD([], [
                        Schema.DIV([Schema.CSS('fieldcontent', true)], [
                            Schema.EACH('${children}')
                        ])
                    ])
                ])
            ])
        );
		
        schemaRegisterInstance.register('userselect',
            Schema.DIV([Schema.EVENT('click', '${onClick}')], [
                Schema.UL([Schema.CSS('multi', '${multi}')], [
                    Schema.EACH('${children}')
                ]),
                Schema.DIV([], [
                    Schema.INPUT([Schema.ATTR('type', 'button'), Schema.ATTR('value', '...'), Schema.CSS('userselect-selectbutton', true)], [])
                ])
            ])
        );

        schemaRegisterInstance.register('usernode',
            Schema.LI([], [
                Schema.LABEL([], [
                    Schema.TEXT('${text}')
                ]),
                Schema.INPUT([Schema.ATTR('type', 'hidden'), Schema.ATTR('value', '${value}')], [])
            ])
        );

        schemaRegisterInstance.register('contact',
            Schema.LABEL([Schema.CSS('presence', '${presence}'), Schema.EVENT('mouseover', '${onMouseover}'), Schema.EVENT('mouseout', '${onMouseout}')], [
                Schema.TEXT('${text}')
            ])
        );

        schemaRegisterInstance.register('checkboxlist',
            Schema.UL([], [
                Schema.EACH('${items}')
            ])
        );

        schemaRegisterInstance.register('checkboxitem',
            Schema.LI([], [
                Schema.CTRL('${checkBox}')
            ])
        );

        schemaRegisterInstance.register('radioboxlist',
            Schema.UL([], [
                Schema.EACH('${items}')
            ])
        );

        schemaRegisterInstance.register('radioboxitem',
            Schema.LI([], [
                Schema.CTRL('${radioBox}')
            ])
        );

        schemaRegisterInstance.register('autocompletebox',
            Schema.DIV([Schema.EVENT('blur', '${onBlur}'), Schema.EVENT('keyup', '${onKeyUp}'), Schema.EVENT('keydown', '${onKeyDown}'), Schema.EVENT('click', '${onClicked}'), Schema.CSS('readonly', '${readonly}')], [
                Schema.DIV([], [
                    Schema.UL([Schema.CSS('complete-items', true)], [
                        Schema.EACH('${completeItems}')
                    ]),
                    Schema.SPAN([Schema.ATTR("contenteditable", 'true')], [Schema.TEXT('${text}')])
                ]),
                Schema.UL([Schema.CSS('items', true), Schema.CSS('invisible', '${showItems}')], [
                    Schema.EACH('${items}')
                ])
            ])
        );

        schemaRegisterInstance.register('autocompleteitem',
            Schema.LI([Schema.CSS('active-item', '${isActive}'), Schema.ATTR('value', '${value}'), Schema.EVENT('click', '${onClicked}')], [
                Schema.TEXT('${text}')
            ])
        );

        schemaRegisterInstance.register('completeitem',
            Schema.LI([Schema.ATTR('value', '${value}'), Schema.EVENT('click', '${onClicked}')], [
                Schema.LABEL([], [
                    Schema.TEXT('${text}')
                ]),
                Schema.BUTTON([Schema.ATTR('type', 'button'), Schema.CSS('complete-item', 'remove')], [])
            ])
        );

        schemaRegisterInstance.register('combobox',
            Schema.DIV([Schema.EVENT('keyup', '${onKeyUp}')], [
                Schema.DIV([], [Schema.EACH('${nodes}')]),
                Schema.DIV([][Schema.INPUT([], [])]),
                Schema.UL([], [Schema.EACH('${items}')])
            ])
        );

        schemaRegisterInstance.register('combonode',
            Schema.DIV([Schema.EVENT('click', '${onClicked}')], [
                Schema.LABEL([], [
                    Schema.TEXT('${text}')
                ]),
                Schema.INPUT([Schema.ATTR('type', 'hidden'), Schema.ATTR('value', '${value}')], []),
                Schema.INPUT([Schema.ATTR('type', 'button'), Schema.CSS('combo-node', 'remove'), Schema.CSS('readonly', '${readonly}')], [])
            ])
        );

        schemaRegisterInstance.register('comboitem',
            Schema.LI([Schema.ATTR('value', '${value}'), Schema.EVENT('click', '${onClicked}')], [
                Schema.TEXT('${text}')
            ])
        );

        schemaRegisterInstance.register('dropdownlist',
            Schema.SELECT([Schema.EVENT('change', '${onChange}'), Schema.ATTR('disabled', '${readonly}')], [
                Schema.EACH('${items}')
            ])
        );

        schemaRegisterInstance.register('dropdownitem',
            Schema.OPTION([Schema.ATTR('value', '${value}'), Schema.ATTR('selected', '${selected}')], [
                Schema.TEXT('${text}')
            ])
        );

        schemaRegisterInstance.register('blankdropdownitem',
            Schema.OPTION([Schema.ATTR('value', '${value}'), Schema.ATTR('selected', '${selected}')], [
                Schema.TEXT('${text}')
            ])
        );

        schemaRegisterInstance.register('panel',
            Schema.DIV([Schema.CSS('panel', '${collapsed}'), Schema.EVENT('click', '${onClick}')], [
                Schema.H1([], [
                    Schema.SPAN([], [
                        Schema.TEXT('${title}')
                    ]),
                    Schema.INPUT([Schema.ATTR('type', 'button')], [])
                ]),
                Schema.DIV([Schema.CSS('body', true)], [
                    Schema.EACH('${children}')
                ])
            ])
        );

        schemaRegisterInstance.register('dialog',
            Schema.DIV([Schema.EVENT('click', '${onClick}'), Schema.EVENT('resize', '${onResize}')], [
                Schema.H1([], [
                    Schema.SPAN([], [
                        Schema.TEXT('${title}')
                    ]),
                    Schema.INPUT([Schema.ATTR('type', 'button')], [])
                ]),
                Schema.DIV([Schema.CSS('body', true)], [
                    Schema.EACH('${children}')
                ])
            ])
        );

        schemaRegisterInstance.register('validator',
            Schema.DIV([Schema.EVENT('click', '${onClick}')], [
                Schema.INPUT([Schema.ATTR('type', 'button')]),
                Schema.DIV([], [
                    Schema.TEXT('${errorMessage}')
                ])
            ])
        );

        schemaRegisterInstance.register('tooltip',
            Schema.DIV([], [
                Schema.EACH('${children}')
            ])
        );

        schemaRegisterInstance.register("fileuploadlist",
            Schema.UL([Schema.CSS('multi', '${multi}')], [
                Schema.EACH('${items}')
            ])
        );

        schemaRegisterInstance.register("fileuploaditem",
            Schema.LI([], [
                Schema.CTRL('${fileUpload}')
            ])
        );

        schemaRegisterInstance.register("fileupload",
            Schema.DIV([Schema.CSS('state', '${uploadState}'), Schema.EVENT('click', '${onClick}'), Schema.EVENT('focus', '${onFocus}'), Schema.EVENT('mousedown', '${onMousedown}'), Schema.EVENT('change', '${onChange}')], [
                Schema.FORM([], [
                    Schema.INPUT([Schema.CSS('fileupload', 'fileselect'), Schema.ATTR('type', 'file'), Schema.ATTR('name', '${name}')]),
                    Schema.SPAN([], [Schema.TEXT('选择上传文件')])
                ]),
                Schema.A([Schema.CSS('fileupload', 'filelink'), Schema.ATTR('href', '${href}'), Schema.ATTR('target', '_blank')], [
                    Schema.TEXT('${text}')
                ]),
                Schema.INPUT([Schema.CSS('fileupload', 'removebutton'), Schema.ATTR('type', 'button'), Schema.ATTR('title', '删除附件'), Schema.ATTR('value', 'Remove'), Schema.CSS('readonly', '${readonly}')], []),
                Schema.INPUT([Schema.CSS('fileupload', 'cancelbutton'), Schema.ATTR('type', 'button'), Schema.ATTR('title', '取消上传'), Schema.ATTR('value', 'Cancel')], []),
                Schema.DIV([Schema.CSS('fileupload', 'progressbar')], [
                    Schema.CTRL('${progressBar}')
                ])
            ])
        );

        schemaRegisterInstance.register("fileupload", function () { return !(Browser.isMobile() || Browser.isTablet()) && Context.getInstance().getSetting("JsLib.IntegrateSharePoint") == "true"; },
            Schema.DIV([Schema.CSS('state', '${uploadState}'), Schema.EVENT('click', '${onClick}'), Schema.EVENT('focus', '${onFocus}'), Schema.EVENT('mousedown', '${onMousedown}'), Schema.EVENT('change', '${onChange}')], [
                Schema.FORM([], [
                    Schema.INPUT([Schema.CSS('fileupload', 'fileselect'), Schema.ATTR('type', 'file'), Schema.ATTR('name', '${name}')]),
                    Schema.SPAN([], [Schema.TEXT('选择上传文件')])
                ]),
                Schema.A([Schema.CSS('fileupload', 'filelink'), Schema.ATTR('href', '${href}'), Schema.ATTR('target', '_blank')], [
                    Schema.TEXT('${text}')
                ]),
                Schema.INPUT([Schema.CSS('fileupload', 'removebutton'), Schema.ATTR('type', 'button'), Schema.ATTR('title', '删除附件'), Schema.ATTR('value', 'Remove'), Schema.CSS('readonly', '${readonly}')], []),
                Schema.INPUT([Schema.CSS('fileupload', 'cancelbutton'), Schema.ATTR('type', 'button'), Schema.ATTR('title', '取消上传'), Schema.ATTR('value', 'Cancel')], []),
                Schema.INPUT([Schema.CSS('fileupload', 'viewbutton'), Schema.ATTR('type', 'button'), Schema.ATTR('title', '查看'), Schema.ATTR('value', 'View'), Schema.CSS('readonly', '${readonly}')], []),
                Schema.INPUT([Schema.CSS('fileupload', 'permissionbutton'), Schema.ATTR('type', 'button'), Schema.ATTR('title', '设置权限'), Schema.ATTR('value', 'SetPermission'), Schema.CSS('readonly', '${readonly}')], []),
                Schema.DIV([Schema.CSS('fileupload', 'progressbar')], [
                    Schema.CTRL('${progressBar}')
                ])
            ])
        );

        schemaRegisterInstance.register("progressbar",
            Schema.SPAN([], [
                Schema.SPAN([], [
                    Schema.TEXT('${text}')
                ])
            ])
        );

        schemaRegisterInstance.register('tree',
            Schema.UL([], [
                Schema.EACH('${childNodes}')
            ])
        );

        schemaRegisterInstance.register('treenode',
            Schema.LI([Schema.CSS("leafnode", "${hasChildNodes()}"), Schema.CSS("lastchild", "${isLastChild()}"), Schema.EVENT('click', '${onClick}')], [
                Schema.DIV([Schema.CSS("treenode", "${collapsed}"), Schema.CSS("treenode-selected", "${selected}")], [
                    Schema.INPUT([Schema.ATTR("type", "button"), Schema.CSS("hitarea", true)], []),
                    Schema.LABEL([], [
                        Schema.TEXT("${text}")
                    ])
                ]),
                Schema.UL([Schema.CSS("treenode", "${collapsed}")], [
                    Schema.EACH('${childNodes}')
                ])
            ])
        );

        schemaRegisterInstance.register('checktreenode',
            Schema.LI([
                Schema.CSS("leafnode", "${hasChildNodes()}"),
                Schema.CSS("lastchild", "${isLastChild()}"),
                Schema.EVENT('click', '${onClick}')
            ], [
                Schema.DIV([Schema.CSS("treenode", "${collapsed}"), Schema.CSS("treenode-selected", "${selected}")], [
                    Schema.INPUT([Schema.ATTR('type', 'button'), Schema.CSS("hitarea", true)], []),
                    Schema.INPUT([Schema.ATTR('type', 'checkbox'), Schema.CSS("clickarea", true), Schema.ATTR('value', '${Value}'), Schema.ATTR('checked', '${checked}')]),
                    Schema.LABEL([], [
                        Schema.TEXT('${text}')
                    ])
                ]),
                Schema.UL([Schema.CSS("treenode", "${collapsed}")], [
                    Schema.EACH('${childNodes}')
                ])
            ])
        );

        //TODO Rename css : clickarea
        schemaRegisterInstance.register('linktreenode',
            Schema.LI([
                Schema.CSS("leafnode", "${hasChildNodes()}"),
                Schema.CSS("lastchild", "${isLastChild()}"),
                Schema.EVENT('click', '${onClick}')
            ], [
                Schema.DIV([Schema.CSS("treenode", "${collapsed}"), Schema.CSS("treenode-selected", "${selected}")], [
                    Schema.INPUT([Schema.ATTR('type', 'button'), Schema.CSS("hitarea", true)], []),
                    Schema.A([Schema.ATTR('href', '${href}'), Schema.CSS("clickarea", true), Schema.ATTR('target', '${target}'), Schema.STYLE('background-image', '${icon}')], [
                            Schema.TEXT('${text}')
                        ])
                ]),
                Schema.UL([Schema.CSS("treenode", "${collapsed}")], [
                    Schema.EACH('${childNodes}')
                ])
            ])
        );

        schemaRegisterInstance.register('menu', function () { return Browser.isMobile() || Browser.isTablet(); },
            Schema.DIV([
                Schema.EVENT('click', '${onClick}'),
                Schema.EVENT('touchstart', '${onTouchStart}'),
                Schema.EVENT('touchend', '${onTouchEnd}')
            ], [
                Schema.DIV([Schema.CSS('topmenu-actionbar', true)], [
                    Schema.SPAN([], [Schema.TEXT('${selectedText}')]),
                    Schema.INPUT([Schema.ATTR('type', 'button'), Schema.ATTR('value', '显示'), Schema.CSS('menu-popout', true)], []),
                    Schema.INPUT([Schema.ATTR('type', 'button'), Schema.ATTR('value', '返回'), Schema.CSS('menu-hide', true)], [])
                 ]),
                Schema.DIV([Schema.CSS('menu-body', true)], [
                    Schema.UL([], [
                        Schema.EACH('${childNodes}')
                    ])
                ])
            ])
        );

        schemaRegisterInstance.register('menu',
            Schema.UL([Schema.CSS('orientation', '${orientation}')], [
                Schema.EACH('${childNodes}')
            ])
        );

        schemaRegisterInstance.register('menuitem', function () { return Browser.isMobile() || Browser.isTablet(); },
            Schema.LI([
                Schema.CSS("menuitem-selected", "${selected}"),
                Schema.CSS('topmenu', '${topMenu}'),
                Schema.EVENT('click', '${onClick}')
            ], [
                Schema.DL([], [
                    Schema.DT([], [
                        Schema.LABEL([], [
                            Schema.TEXT('${value}')
                        ])
                    ]),
                    Schema.DD([Schema.STYLE('display', '${popout}')], [
                        Schema.DIV([], [
                            Schema.DIV([Schema.CSS('menuitem-actionbar', true)], [
                                Schema.INPUT([Schema.ATTR('type', 'button'),
                                Schema.ATTR('value', '返回'),
                                Schema.CSS('menu-hide', true)])
                            ]),
                            Schema.UL([Schema.CSS('orientation', '${orientation}')], [
                                Schema.EACH('${childNodes}')
                            ])
                        ])
                    ])
                ])
            ])
        );

        schemaRegisterInstance.register('menuitem',
            Schema.LI([
                Schema.CSS("menuitem-selected", "${selected}"),
                Schema.CSS('topmenu', '${topMenu}'),
                Schema.EVENT('mouseout', '${onMouseout}'),
                Schema.EVENT('mouseover', '${onMouseover}')
            ], [
                Schema.DL([], [
                    Schema.DT([], [
                        Schema.LABEL([], [
                            Schema.TEXT('${value}')
                        ])
                    ]),
                    Schema.DD([Schema.STYLE('display', '${popout}')], [
                        Schema.UL([Schema.CSS('itmes', true), Schema.CSS('orientation', '${orientation}')], [
                            Schema.EACH('${childNodes}')
                        ])
                    ])
                ])
            ])
        );

        schemaRegisterInstance.register('linkmenuitem', function () { return Browser.isMobile() || Browser.isTablet(); },
            Schema.LI([
                Schema.CSS("menuitem-selected", "${selected}"),
                Schema.CSS('topmenu', '${topMenu}'),
                Schema.EVENT('click', '${onClick}'),
                Schema.EVENT('touchstart', '${onTouchStart}'),
                Schema.EVENT('touchend', '${onTouchEnd}')
            ], [
                Schema.DL([], [
                    Schema.DT([], [
                        Schema.A([Schema.ATTR('href', '${href}'), Schema.ATTR('target', '${target}'), Schema.STYLE('background-image', '${icon}')], [
                            Schema.TEXT('${text}')
                        ])
                    ]),
                    Schema.DD([Schema.STYLE('display', '${popout}')], [
                        Schema.DIV([], [
                            Schema.DIV([Schema.CSS('menuitem-actionbar', true)], [
                                Schema.INPUT([Schema.ATTR('type', 'button'), Schema.ATTR('value', '返回'), Schema.CSS('menu-hide', true)])
                            ]),
                            Schema.DIV([], [
                                Schema.UL([Schema.CSS('itmes', true), Schema.CSS('orientation', '${orientation}')], [
                                    Schema.EACH('${childNodes}')
                                ])
                            ])
                        ])
                    ])
                ])
            ])
        );

        schemaRegisterInstance.register('linkmenuitem',
            Schema.LI([
                Schema.CSS("menuitem-selected", "${selected}"),
                Schema.CSS('topmenu', '${topMenu}'),
                Schema.EVENT('click', '${onClick}'),
                Schema.EVENT('mouseout', '${onMouseout}'),
                Schema.EVENT('mouseover', '${onMouseover}')
            ], [
                Schema.DL([], [
                    Schema.DT([], [
                        Schema.A([Schema.ATTR('href', '${href}'), Schema.ATTR('target', '${target}'), Schema.STYLE('background-image', '${icon}')], [
                            Schema.TEXT('${text}')
                        ])
                    ]),
                    Schema.DD([Schema.STYLE('display', '${popout}')], [
                        Schema.DIV([Schema.CSS('menuitem-actionbar', true)], [
                            Schema.INPUT([Schema.ATTR('type', 'button'), Schema.ATTR('value', '返回'), Schema.CSS('menu-hide', true)])
                        ]),
                        Schema.UL([Schema.CSS('orientation', '${orientation}')], [
                            Schema.EACH('${childNodes}')
                        ])
                    ])
                ])
            ])
        );

        schemaRegisterInstance.register('badgelinkmenuitem',
            Schema.LI([
                Schema.CSS("menuitem-selected", "${selected}"),
                Schema.CSS('topmenu', '${topMenu}'),
                Schema.EVENT('click', '${onClick}'),
                Schema.EVENT('mouseout', '${onMouseout}'),
                Schema.EVENT('mouseover', '${onMouseover}')
            ], [
                Schema.DL([], [
                    Schema.DT([], [
                        Schema.A([Schema.ATTR('href', '${href}'), Schema.ATTR('target', '${target}'), Schema.STYLE('background-image', '${icon}')], [
                            Schema.TEXT('${text}'),
                            Schema.SPAN([Schema.CSS("badge", true)], [
                                Schema.TEXT('${badge}')
                            ])
                        ])

                    ]),
                    Schema.DD([Schema.STYLE('display', '${popout}')], [
                        Schema.DIV([Schema.CSS('menuitem-actionbar', true)], [
                            Schema.INPUT([Schema.ATTR('type', 'button'), Schema.ATTR('value', '返回'), Schema.CSS('menu-hide', true)])
                        ]),
                        Schema.UL([Schema.CSS('orientation', '${orientation}')], [
                            Schema.EACH('${childNodes}')
                        ])
                    ])
                ])
            ])
        );

        schemaRegisterInstance.register('badgelinkmenuitem', function () { return Browser.isMobile() || Browser.isTablet(); },
            Schema.LI([
                Schema.CSS("menuitem-selected", "${selected}"),
                Schema.CSS('topmenu', '${topMenu}'),
                Schema.EVENT('click', '${onClick}'),
                Schema.EVENT('touchstart', '${onTouchStart}'),
                Schema.EVENT('touchend', '${onTouchEnd}')
            ], [
                Schema.DL([], [
                    Schema.DT([], [
                        Schema.A([Schema.ATTR('href', '${href}'), Schema.ATTR('target', '${target}'), Schema.STYLE('background-image', '${icon}')], [
                            Schema.TEXT('${text}')
                        ]),
                        Schema.SPAN([Schema.CSS("badge", true)], [
                            Schema.TEXT('${badge}')
                        ])
                    ]),
                    Schema.DD([Schema.STYLE('display', '${popout}')], [
                        Schema.DIV([Schema.CSS('menuitem-actionbar', true)], [
                            Schema.INPUT([Schema.ATTR('type', 'button'), Schema.ATTR('value', '返回'), Schema.CSS('menu-hide', true)])
                        ]),
                        Schema.UL([Schema.CSS('orientation', '${orientation}')], [
                            Schema.EACH('${childNodes}')
                        ])
                    ])
                ])
            ])
        );

        schemaRegisterInstance.register('buttonmenuitem', function () { return Browser.isMobile() || Browser.isTablet(); },
            Schema.LI([
                Schema.CSS("menuitem-selected", "${selected}"),
                Schema.CSS('topmenu', '${topMenu}'),
                Schema.EVENT('click', '${onClick}'),
                Schema.EVENT('touchstart', '${onTouchStart}'),
                Schema.EVENT('touchend', '${onTouchEnd}')
            ], [
                Schema.DL([], [
                    Schema.DT([], [
                        Schema.INPUT([Schema.ATTR('type', 'button'), Schema.ATTR('value', '${value}'), Schema.ATTR('disabled', '${enable}'), Schema.STYLE('background-image', '${icon}')], [])
                    ]),
                    Schema.DD([Schema.STYLE('display', '${popout}')], [
                        Schema.DIV([], [
                            Schema.DIV([Schema.CSS('menuitem-actionbar', true)], [
                                Schema.INPUT([Schema.ATTR('type', 'button'), Schema.ATTR('value', '返回'), Schema.CSS('menu-hide', true)])
                            ]),
                            Schema.DIV([], [
                                Schema.UL([Schema.CSS('orientation', '${orientation}')], [
                                    Schema.EACH('${childNodes}')
                                ])
                            ])
                        ])
                    ])
                ])
            ])
        );

        schemaRegisterInstance.register('buttonmenuitem',
            Schema.LI([Schema.CSS("menuitem-selected", "${selected}"), Schema.CSS('topmenu', '${topMenu}'), Schema.EVENT('mouseout', '${onMouseout}'), Schema.EVENT('click', '${onClick}'), Schema.EVENT('mouseover', '${onMouseover}')], [
                Schema.DL([], [
                    Schema.DT([], [
                        Schema.INPUT([Schema.ATTR('type', 'button'), Schema.CSS("actionbutton", true), Schema.ATTR('value', '${value}'), Schema.ATTR('disabled', '${enable}'), Schema.STYLE('background-image', '${icon}')], [])
                    ]),
                    Schema.DD([Schema.STYLE('display', '${popout}')], [
                        Schema.UL([Schema.CSS('orientation', '${orientation}')], [
                            Schema.EACH('${childNodes}')
                        ])
                    ])
                ])
            ])
        );

        schemaRegisterInstance.register('dropdownmenuitem',
            Schema.LI([Schema.CSS("menuitem-selected", "${selected}"), Schema.CSS('topmenu', '${topMenu}'), Schema.EVENT('click', '${onClick}')], [
                Schema.DL([], [
                    Schema.DT([Schema.CSS("haschild", "${hasChildMenus()}")], [
                        Schema.INPUT([Schema.ATTR('type', 'button'), Schema.ATTR('value', '${value}'), Schema.ATTR('disabled', '${enable}'), Schema.CSS('actionbutton', true), Schema.STYLE('background-image', '${icon}')], []),
                        Schema.INPUT([Schema.ATTR('type', 'button'), Schema.ATTR('value', '...'), Schema.CSS('dropdownbutton', true)], [])
                    ]),
                    Schema.DD([Schema.STYLE('display', '${popout}')], [
                        Schema.UL([Schema.CSS('orientation', '${orientation}')], [
                            Schema.EACH('${childNodes}')
                        ])
                    ])
                ])
            ])
        );

        schemaRegisterInstance.register('accordion',
            Schema.UL([Schema.CSS('orientation', '${orientation}')], [
                Schema.EACH('${items}')
            ])
        );
        schemaRegisterInstance.register('accordionitem',
            Schema.LI([Schema.CSS('accordionitem', '${collapsed}'), Schema.EVENT('click', '${onClick}')], [
                Schema.DL([], [
                    Schema.DT([], [
                        Schema.TEXT('${text}'),
                        Schema.INPUT([Schema.ATTR('type', 'button'), Schema.ATTR('value', 'toggle')], [])
                    ]),
                    Schema.DD([Schema.CSS('accordionbody', true)], [
                        Schema.EACH('${children}')
                    ])
                ])
            ])
        );

        schemaRegisterInstance.register('widgetzone',
            Schema.DIV([], [
                Schema.EACH('${widgets}')
            ])
        );

        schemaRegisterInstance.register('widget',
            Schema.DIV([], [
                Schema.EACH('${children}', true)
            ])
        );

        schemaRegisterInstance.register('gridview', function () { return Browser.isMobile(); },
            Schema.DIV([Schema.EVENT('click', '${onClick}'), Schema.EVENT('touchstart', '${onTouchStart}'), Schema.EVENT('touchend', '${onTouchEnd}')], [
                Schema.DIV([Schema.CSS('toolbar-container', true)], [
                    Schema.INPUT([Schema.ATTR('type', 'button'), Schema.ATTR('value', '查看表格'), Schema.CSS('toolbar-enterfullview', true)], []),
                    Schema.INPUT([Schema.ATTR('type', 'button'), Schema.ATTR('value', '返回'), Schema.CSS('toolbar-leavefullview', true)], [])
                ]),
                Schema.TABLE([], [
                    Schema.THEAD([], [
                        Schema.CTRL("${header}")
                    ]),
                    Schema.TBODY([], [
                        Schema.EACH('${rows}')
                    ]),
                    Schema.TFOOT([], [
                        Schema.EACH('${footers}')
                    ])
                ])
            ])
        );

        schemaRegisterInstance.register('gridview',
            Schema.TABLE([], [
                Schema.THEAD([], [
                    Schema.CTRL("${header}")
                ]),
                Schema.TBODY([], [
                    Schema.EACH('${rows}')
                ]),
                Schema.TFOOT([], [
                    Schema.EACH('${footers}')
                ])
            ])
        );

        schemaRegisterInstance.register('gridrow',
            Schema.TR([Schema.EVENT('click', '${onClick}'), Schema.CSS('selected', '${selected}')], [
                Schema.EACH('${cells}')
            ])
        );

        schemaRegisterInstance.register('summaryrow',
            Schema.TR([], [
                Schema.EACH('${cells}')
            ])
        );

        schemaRegisterInstance.register('gridheader',
            Schema.TR([], [
                Schema.EACH('${cells}')
            ])
        );
        schemaRegisterInstance.register('gridfooter',
            Schema.TR([], [
                Schema.EACH('${children}')
            ])
        );
        schemaRegisterInstance.register('editablerow',
            Schema.TR([], [
                Schema.EACH('${cells}')
            ])
        );

        schemaRegisterInstance.register('toolbar',
            Schema.TR([Schema.EVENT('click', '${onClick}')], [
                Schema.TD([], [
                    Schema.INPUT([Schema.ATTR('type', 'button'), Schema.CSS('toolbar-add', true), Schema.ATTR('value', '添加')], [])
                 ])
            ])
        );

        schemaRegisterInstance.register('gridcell',
            Schema.TD([], [
                Schema.TEXT('${value}')
            ])
        );

        schemaRegisterInstance.register('editablecell',
            Schema.TD([Schema.CSS('celltype', '${cellType}')], [
                Schema.CTRL('${editingControl}')
            ])
        );
    });