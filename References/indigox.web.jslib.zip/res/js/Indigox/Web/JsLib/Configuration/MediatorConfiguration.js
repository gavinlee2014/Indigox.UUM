﻿define("Indigox.Web.JsLib.Configuration.MediatorConfiguration",
    [
        "Indigox.Web.JsLib.UI.ControlMediator",
        "Indigox.Web.JsLib.UI.MediatorRegistry",
        "Indigox.Web.JsLib.UI.Mediators",
        "Indigox.Web.JsLib.Utils.Browser",
        "Indigox.Web.JsLib.WebContexts.Context"
    ],
    function (
        ControlMediator,
        MediatorRegistry,
        Mediators,
        Browser,
        Context
    ) {
        MediatorRegistry.getInstance().register("accordionitem", Mediators.AccordionItemMediator);
        MediatorRegistry.getInstance().register("autocompletebox", Mediators.AutoCompleteBoxMediator);
        MediatorRegistry.getInstance().register("autocompleteitem", Mediators.AutoCompleteItemMediator);        
        MediatorRegistry.getInstance().register("badgelinkmenuitem", Mediators.MenuItemMediator);
        MediatorRegistry.getInstance().register("badgelinkmenuitem", function () { return Browser.isMobile() || Browser.isTablet(); }, Mediators.MenuItemMobileMediator);
        MediatorRegistry.getInstance().register("button", Mediators.ButtonMediator);
        MediatorRegistry.getInstance().register("button", function () { return Browser.isMobile() || Browser.isTablet(); }, Mediators.ButtonMobileMediator);
        MediatorRegistry.getInstance().register("buttonmenuitem", Mediators.ButtonMenuItemMediator);
        MediatorRegistry.getInstance().register("buttonmenuitem", function () { return Browser.isMobile() || Browser.isTablet(); }, Mediators.ButtonMenuItemMobileMediator);
        MediatorRegistry.getInstance().register("checkbox", Mediators.CheckBoxMediator);
        MediatorRegistry.getInstance().register("completeitem", Mediators.CompleteItemMediator);        
        MediatorRegistry.getInstance().register("checktreenode", Mediators.TreeNodeMediator);
        MediatorRegistry.getInstance().register("contact", function () { return !(Browser.isMobile() || Browser.isTablet()) && Context.getInstance().getSetting("JsLib.IntegrateLync") == "true"; }, Mediators.LyncContactMediator);
        MediatorRegistry.getInstance().register("currency", Mediators.CurrencyMediator);
        MediatorRegistry.getInstance().register("dataitem", Mediators.DataItemMediator);
        MediatorRegistry.getInstance().register("datepicker", Mediators.DatePickerMediator);
        MediatorRegistry.getInstance().register("dialog", Mediators.DialogMediator);
        MediatorRegistry.getInstance().register("dropdownlist", Mediators.DropDownlistMediator);
        MediatorRegistry.getInstance().register("dropdownmenuitem", Mediators.DropDownMenuItemMediator);
        MediatorRegistry.getInstance().register("fileupload", Mediators.FileUploadMediator);
        MediatorRegistry.getInstance().register("fileupload", function () { return !(Browser.isMobile() || Browser.isTablet()) && Context.getInstance().getSetting("JsLib.IntegrateSharePoint") == "true"; }, Mediators.SPFileUploadMediator);
        MediatorRegistry.getInstance().register("fieldcontainer", Mediators.FieldContainerMediator);
        MediatorRegistry.getInstance().register("gridrow", Mediators.GridRowMediator);
        MediatorRegistry.getInstance().register("gridview", Mediators.GridViewMediator);
        MediatorRegistry.getInstance().register("linkmenuitem", Mediators.MenuItemMediator);
        MediatorRegistry.getInstance().register("linkmenuitem", function () { return Browser.isMobile() || Browser.isTablet(); }, Mediators.MenuItemMobileMediator);
        MediatorRegistry.getInstance().register("linktreenode", Mediators.TreeNodeMediator);
        MediatorRegistry.getInstance().register("menu", Mediators.MenuMediator);
        MediatorRegistry.getInstance().register("menuitem", Mediators.MenuItemMediator);
        MediatorRegistry.getInstance().register("menuitem", function () { return Browser.isMobile() || Browser.isTablet(); }, Mediators.MenuItemMobileMediator);
        MediatorRegistry.getInstance().register("paging", Mediators.PagingMediator);
        MediatorRegistry.getInstance().register("paging", function () { return Browser.isMobile() || Browser.isTablet(); }, Mediators.PagingMobileMediator);
        MediatorRegistry.getInstance().register("panel", Mediators.PanelMediator);
        MediatorRegistry.getInstance().register("radiobox", Mediators.RadioBoxMediator);
        MediatorRegistry.getInstance().register("richtextbox", Mediators.RichTextBoxMediator);
        MediatorRegistry.getInstance().register("richtextview", Mediators.RichTextViewMediator);
        MediatorRegistry.getInstance().register("textbox", Mediators.TextBoxMediator);
        MediatorRegistry.getInstance().register("toolbar", Mediators.ToolbarMediator);
        MediatorRegistry.getInstance().register("tooltip", Mediators.TooltipMediator);
        MediatorRegistry.getInstance().register("treenode", Mediators.TreeNodeMediator);
        MediatorRegistry.getInstance().register("userselect", Mediators.UserSelectMediator);
        MediatorRegistry.getInstance().register("validator", Mediators.ValidatorMediator);
        MediatorRegistry.getInstance().register("comboitem", Mediators.ComboItemMediator);
        MediatorRegistry.getInstance().register("combobox", Mediators.ComboBoxMediator);
        MediatorRegistry.getInstance().register("combonode", Mediators.ComboNodeMediator);
        MediatorRegistry.getInstance().register("hyperlink", Mediators.HyperLinkMediator);       
               

        MediatorRegistry.getInstance().register(ControlMediator);
    });