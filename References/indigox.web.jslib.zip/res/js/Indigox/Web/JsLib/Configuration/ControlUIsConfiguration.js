﻿define("Indigox.Web.JsLib.Configuration.ControlUIsConfiguration",
    [
        "Indigox.Web.JsLib.UI.ControlUIs",
        "Indigox.Web.JsLib.UI.UIManager",
        "Indigox.Web.JsLib.Utils.Browser",
        "Indigox.Web.JsLib.WebContexts.Context"
    ],
    function (
        UI,
        UIManager,
        Browser,
        Context
    ) {

        UIManager.getInstance().registerUI('autocompletebox', UI.AutoCompleteBoxUI);
        UIManager.getInstance().registerUI('autocompleteitem', UI.AutoCompleteItemUI);
        UIManager.getInstance().registerUI('badgelinkmenuitem', UI.BadgeLinkMenuItemUI);
        UIManager.getInstance().registerUI('checkboxitem', UI.CheckBoxItemUI);
        UIManager.getInstance().registerUI('combobox', UI.ComboBoxUI);
        UIManager.getInstance().registerUI('contact', function () { return !(Browser.isMobile() || Browser.isTablet()) && Context.getInstance().getSetting("JsLib.IntegrateLync") == "true"; }, UI.LyncContactUI);
        UIManager.getInstance().registerUI('content', UI.ContentUI);
        UIManager.getInstance().registerUI('control', UI.SimpleControlUI);
        UIManager.getInstance().registerUI('dataitem', UI.DataItemUI);
        UIManager.getInstance().registerUI('datalist', UI.DataListUI);
        UIManager.getInstance().registerUI('datepicker', UI.DatePickerUI);
        UIManager.getInstance().registerUI('dialog', UI.DialogUI);
        UIManager.getInstance().registerUI('dialog', function () { return Browser.isMobile() || Browser.isTablet(); }, UI.DialogUI);
        UIManager.getInstance().registerUI('dropdownmenuitem', UI.DropDownMenuItemUI);
        UIManager.getInstance().registerUI('editablecell', UI.EditableCellUI);
        UIManager.getInstance().registerUI('editablerow', UI.EditableRowUI);
        UIManager.getInstance().registerUI('fileupload', UI.FileUploadUI);
        UIManager.getInstance().registerUI('fileuploaditem', UI.FileUploadItemUI);
        UIManager.getInstance().registerUI('gridrow', UI.GridRowUI);
        UIManager.getInstance().registerUI('gridview', UI.GridViewUI);
        UIManager.getInstance().registerUI('hierarchycontrol', UI.HierarchyControlUI);
        UIManager.getInstance().registerUI('listcontrol', UI.ListControlUI);
        UIManager.getInstance().registerUI('literal', UI.LiteralUI);
        UIManager.getInstance().registerUI('loadmask', UI.LoadMaskUI);
        UIManager.getInstance().registerUI('menu', UI.MenuUI);
        UIManager.getInstance().registerUI('nodecontrol', UI.NodeControlUI);
        UIManager.getInstance().registerUI('page', UI.PageUI);
        UIManager.getInstance().registerUI('paging', UI.PagingUI);
        UIManager.getInstance().registerUI('paging', function () { return Browser.isMobile() || Browser.isTablet(); }, UI.PagingMobileUI);
        UIManager.getInstance().registerUI('panel', UI.PanelUI);
        UIManager.getInstance().registerUI('radioboxitem', UI.RadioBoxItemUI);
        UIManager.getInstance().registerUI('richtextbox', UI.TinyMceUI);
        UIManager.getInstance().registerUI('richtextview', UI.RichTextViewUI);
        UIManager.getInstance().registerUI('template', UI.TemplateUI);
        UIManager.getInstance().registerUI('tooltip', UI.TooltipUI);
        UIManager.getInstance().registerUI('userselect', UI.UUMUserSelectUI);
        UIManager.getInstance().registerUI('userselect', function () { return !(Browser.isMobile() || Browser.isTablet()) && Context.getInstance().getSetting("JsLib.IntegrateUUV") == "true"; }, UI.UUVUserSelectUI);
        UIManager.getInstance().registerUI('userselect', function () { return Browser.isMobile() || Browser.isTablet(); }, UI.UserSelectMobileUI);
        UIManager.getInstance().registerUI('validator', UI.ValidatorUI);
        UIManager.getInstance().registerUI('widget', UI.WidgetUI);
        UIManager.getInstance().registerUI('widgetzone', UI.WidgetZoneUI);        
        
    });