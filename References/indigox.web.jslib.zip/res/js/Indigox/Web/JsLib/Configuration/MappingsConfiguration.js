﻿define("Indigox.Web.JsLib.Configuration.MappingsConfiguration",
    [
        "Indigox.Web.JsLib.Mappings.MappingFactory",
        "Indigox.Web.JsLib.Mappings.DefaultMapping",
        "Indigox.Web.JsLib.Mappings.FormatMapping"
    ],
    function (
        MappingFactory,
        DefaultMapping,
        FormatMapping
    ) {
        MappingFactory.getInstance().setDefaultMapping(DefaultMapping.getInstance());
        MappingFactory.getInstance().register("icon", new FormatMapping('url({0})'));
        MappingFactory.getInstance().register("enable",
            new DefaultMapping(
                [true, false],
                [false, true]
            )
        );
        MappingFactory.getInstance().register("visible",
            new DefaultMapping(
                [true, false],
                [false, true]
            )
        );
        MappingFactory.getInstance().register("editHMS",
            new DefaultMapping(
                [true, false],
                [false, true]
            )
        );
        MappingFactory.getInstance().register("editSecond",
            new DefaultMapping(
                [true, false],
                [false, true]
            )
        );
        MappingFactory.getInstance().register("orientation",
            new DefaultMapping(
                [0, 'horizontal'],
                [1, 'vertical']
            )
        );
        MappingFactory.getInstance().register("mode",
            new DefaultMapping(
                ['plaintext', 'plaintext'],
                ['simplehtml', 'simplehtml'],
                ['advancehtml', 'advancehtml'],
                ['simplehtml', false]
            )
        );
        MappingFactory.getInstance().register("popout",
            new DefaultMapping(
                [true, 'block'],
                [false, 'none']
            )
        );
        MappingFactory.getInstance().register("collapsed",
            new DefaultMapping(
                [true, 'collapsed'],
                [false, 'expanded'],
                [true, false]
            )
        );
        MappingFactory.getInstance().register("hasChildNodes()",
            new DefaultMapping(
                [true, false],
                [false, true]
            )
        );
        MappingFactory.getInstance().register("showItems",
            new DefaultMapping(
                [true, false],
                [false, true]
            )
        );
        MappingFactory.getInstance().register("cellType",
            new DefaultMapping(
                [0, 'normal'],
                [1, 'update'],
                [2, 'cancel']
            )
        );
    });