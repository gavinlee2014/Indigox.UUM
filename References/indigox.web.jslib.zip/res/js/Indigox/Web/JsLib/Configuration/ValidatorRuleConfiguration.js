﻿define("Indigox.Web.JsLib.Configuration.ValidatorRuleConfiguration",
    [
        "Indigox.Web.JsLib.Controls.Validation.ValidateRuleFactory",
        "Indigox.Web.JsLib.Controls.Validation.Rules"
    ],
    function (
        ValidateRuleFactory,
        Rules
    ) {
        var factory = ValidateRuleFactory.getInstance();

        factory.registerRule('qt', Rules.GreaterThanRule);
        factory.registerRule('qe', Rules.GreaterOrEqualRule);
        factory.registerRule('eq', Rules.EqualRule);
        factory.registerRule('lt', Rules.LessThanRule);
        factory.registerRule('le', Rules.LessOrEqualRule);

        factory.registerRule('eq2c', Rules.EqualControlRule);
        factory.registerRule('qe2c', Rules.GreaterOrEqualControlRule);
        factory.registerRule('gt2c', Rules.GreaterThanControlRule);
        factory.registerRule('le2c', Rules.LessOrEqualControlRule);
        factory.registerRule('lt2c', Rules.LessThanControlRule);

        factory.registerRule('notblank', Rules.NotBlankRule);
        factory.registerRule('nb', Rules.NotBlankRule);
        factory.registerRule('min', Rules.MinLengthRule);
        factory.registerRule('minlength', Rules.MinLengthRule);
        factory.registerRule('max', Rules.MaxLengthRule);
        factory.registerRule('maxlength', Rules.MaxLengthRule);
        factory.registerRule('rx', Rules.RegxRule);
        factory.registerRule('regex', Rules.RegxRule);
        factory.registerRule('ip', Rules.IPAddressRule);
        factory.registerRule('mail', Rules.MailAddressRule);
        factory.registerRule('phone', Rules.PhoneNumberRule);
        factory.registerRule('num', Rules.NumberRule);
        factory.registerRule('number', Rules.NumberRule);
        factory.registerRule('str', Rules.StringRule);
        factory.registerRule('string', Rules.StringRule);
    });