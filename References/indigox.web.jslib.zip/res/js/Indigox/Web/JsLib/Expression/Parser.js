﻿define("Indigox.Web.JsLib.Expression.Parser",
    [
        "Indigox.Web.JsLib.Expression.Nodes.BooleanLiteralNode",
        "Indigox.Web.JsLib.Expression.Nodes.IdentifierNode",
        "Indigox.Web.JsLib.Expression.Nodes.MethodNode",
        "Indigox.Web.JsLib.Expression.Nodes.NotNode",
        "Indigox.Web.JsLib.Expression.Nodes.NullLiteralNode",
        "Indigox.Web.JsLib.Expression.Nodes.NumberLiteralNode",
        "Indigox.Web.JsLib.Expression.Nodes.StringLiteralNode",
        "Indigox.Web.JsLib.Expression.Tokenizer",
        "Indigox.Web.JsLib.Core"
    ],
function (
        BooleanLiteralNode,
        IdentifierNode,
        MethodNode,
        NotNode,
        NullLiteralNode,
        NumberLiteralNode,
        StringLiteralNode,
        Tokenizer
) {
    var Parser =
        Namespace("Indigox.Web.JsLib.Expression")
        .Class("Parser")
        .Constructor(
            function (text) {
                this.tokenizer = new Tokenizer(text);
                this.token = null;
            }
        )
        .Members({
            parse: function () {
                this.next();
                return this.expression();
            },
            next: function () {
                this.token = this.tokenizer.getNextToken();
            },
            expect: function (value) {
                if (this.token.value === value) {
                    return this.next();
                }
                else {
                    throw new Error("Unexpected token \"" + this.token.value + "\", expected \"" + value + "\"");
                }
            },
            unexpect: function () {
                throw new Error("Unexpected token " + this.token.type + " ( \"" + this.token.value + "\" )");
            },
            expression: function () {
                if (this.token.type === "IDENTIFIER") {
                    var identifier = this.identifier();
                    return this.reference(identifier);
                }
                else if (this.token.type === "NUMBER") {
                    var number = this.numberLiteral();
                    return this.reference(number);
                }
                else if (this.token.type === "BOOLEAN") {
                    var bool = this.booleanLiteral();
                    return this.reference(bool);
                }
                else if (this.token.type === "NULL") {
                    var nul = this.nullLiteral();
                    return this.reference(nul);
                }
                else if (this.token.type === "STRING") {
                    var str = this.stringLiteral();
                    return this.reference(str);
                }
                else {
                    this.unexpect();
                }
            },
            reference: function (expression) {
                if (this.token.type === "PUNCTUATOR") {
                    switch (this.token.value) {
                        case ".":
                            this.next();
                            var indetifier = this.identifier(expression);
                            return this.reference(indetifier);
                        case "[":
                            this.next();
                            var subscript = this.expression();
                            this.expect("]");
                            return this.reference(subscript);
                        case "(":
                            this.next();
                            var method = this.method(expression);
                            this.expect(")");
                            return this.reference(method);
                    }
                }
                return expression;
            },
            identifier: function (reference) {
                var identifier = this.token.value;
                this.next();
                return new IdentifierNode(identifier, reference);
            },
            method: function (reference) {
                var childNodes = [];

                var first = true;
                while (this.token.value !== ")") {
                    if (first) {
                        first = false;
                    }
                    else {
                        this.expect(",");
                    }
                    childNodes.push(this.expression());
                }

                return new MethodNode(reference, childNodes);
            },
            stringLiteral: function () {
                var literal = this.token.value;
                this.next();
                return new StringLiteralNode(literal);
            },
            numberLiteral: function () {
                var literal = Number(this.token.value);
                this.next();
                return new NumberLiteralNode(literal);
            },
            booleanLiteral: function () {
                var literal = Boolean(this.token.value);
                this.next();
                return new BooleanLiteralNode(literal);
            },
            nullLiteral: function () {
                this.next();
                return new NullLiteralNode(null);
            }
        })
    .$();
});