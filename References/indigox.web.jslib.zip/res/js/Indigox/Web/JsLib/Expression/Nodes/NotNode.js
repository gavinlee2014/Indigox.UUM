﻿define("Indigox.Web.JsLib.Expression.Nodes.NotNode",
    [
        "Indigox.Web.JsLib.Expression.ASTNode",
        "Indigox.Web.JsLib.Core"
    ],
function (
        ASTNode
) {
    var base = ASTNode.prototype;

    var NotNode =
        Namespace("Indigox.Web.JsLib.Expression.Nodes")
        .Class("NotNode")
        .Extend(base)
        .Constructor(
            function (reference) {
                this.reference = reference;
            }
        )
        .Members({
            getReference: function () {
                return this.reference;
            },
            accept: function (interpreter, data) {
                return interpreter.visitNot(this, data);
            }
        })
    .$();
});