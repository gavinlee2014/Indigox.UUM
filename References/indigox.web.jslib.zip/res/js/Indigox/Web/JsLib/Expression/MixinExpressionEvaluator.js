﻿define("Indigox.Web.JsLib.Expression.MixinExpressionEvaluator",
    [
        "Indigox.Web.JsLib.Expression.ExpressionEvaluator",
        "Indigox.Web.JsLib.Core"
    ],
function (
        ExpressionEvaluator
) {
    var MixinExpressionEvaluator =
        Namespace("Indigox.Web.JsLib.Expression")
        .Class("MixinExpressionEvaluator")
        .Constructor(
            function (notation) {
                this.notation = notation;
            }
        )
        .Members({
            evaluate: function (context) {
                var patt = /\$\{[^\}]+\}/g;
                return this.notation.replace(patt, function (word) {
                    var evaluator = new ExpressionEvaluator(word);
                    return evaluator.evaluate(context);
                });
            }
        })
    .$();
});