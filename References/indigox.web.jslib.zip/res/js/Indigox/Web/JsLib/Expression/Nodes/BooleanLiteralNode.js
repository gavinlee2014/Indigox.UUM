﻿define("Indigox.Web.JsLib.Expression.Nodes.BooleanLiteralNode",
    [
        "Indigox.Web.JsLib.Expression.ASTNode",
        "Indigox.Web.JsLib.Core"
    ],
function (
        ASTNode
) {
    var base = ASTNode.prototype;

    var BooleanLiteralNode =
        Namespace("Indigox.Web.JsLib.Expression.Nodes")
        .Class("BooleanLiteralNode")
        .Extend(base)
        .Constructor(
            function (literal) {
                this.literal = literal;
            }
        )
        .Members({
            getLiteral: function () {
                return this.literal;
            },
            accept: function (interpreter, data) {
                return interpreter.visitBooleanLiteral(this, data);
            }
        })
    .$();
});