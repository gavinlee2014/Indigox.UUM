﻿define("Indigox.Web.JsLib.Expression.Interpreter",
    [
        "Indigox.Web.JsLib.Invokers.FieldSetterInvoker",
        "Indigox.Web.JsLib.Invokers.FieldGetterInvoker",
        "Indigox.Web.JsLib.Invokers.MethodInvoker",
        "Indigox.Web.JsLib.Invokers.PropertySetterInvoker",
        "Indigox.Web.JsLib.Invokers.PropertyGetterInvoker",
        "Indigox.Web.JsLib.Core"
    ],
function (
        FieldSetterInvoker,
        FieldGetterInvoker,
        MethodInvoker,
        PropertySetterInvoker,
        PropertyGetterInvoker
) {
    var Interpreter =
        Namespace("Indigox.Web.JsLib.Expression")
        .Class("Interpreter")
        .Constructor(
            function (context) {
                this.context = context;
            }
        )
        .Members({
            interpret: function (node) {
                return node.accept(this, null);
            },
            visitBooleanLiteral: function (node, data) {
                return node.getLiteral();
            },
            visitIdentifier: function (node, data) {
                var context = this.context,
                    obj = null,
                    result = null,
                    referenceNode = node.getReference();
                if (referenceNode) {
                    obj = referenceNode.accept(this, null);
                }
                else {
                    obj = context;
                }
                var getter = new PropertyGetterInvoker(node.getIdentifier());
                if (!getter.hasMember(obj)) {
                    getter = new FieldGetterInvoker(node.getIdentifier());
                }
                result = getter.invoke(obj);
                return result;
            },

            visitMethod: function (node, data) {
                var context = this.context,
                    obj = null,
                    args = [],
                    result = null,
                    propertyValue = null,
                    identifierNode = node.getReference(),
                    referenceNode = identifierNode.getReference(),
                    childNodes = node.getChildNodes();

                if (referenceNode) {
                    obj = referenceNode.accept(this, null);
                }
                else {
                    obj = context;
                }

                var i = null,
                    length = null;
                for (i = 0, length = childNodes.length; i < length; i++) {
                    args.push(childNodes[i].accept(this, null));
                }

                var getter = new MethodInvoker(identifierNode.getIdentifier());
                result = getter.invoke(obj, args);
                return result;
            },

            visitNot: function (node, data) {
                var identifierNode = node.getReference();
                var result = identifierNode.accept(this, null);
                return !result;
            },

            visitNullLiteral: function (node, data) {
                return node.getLiteral();
            },

            visitNumberLiteral: function (node, data) {
                return node.getLiteral();
            },

            visitStringLiteral: function (node, data) {
                return node.getLiteral();
            }
        })
    .$();
});