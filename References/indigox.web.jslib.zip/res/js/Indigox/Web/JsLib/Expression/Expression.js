﻿define("Indigox.Web.JsLib.Expression.Expression",
    [
        "Indigox.Web.JsLib.Expression.Parser",
        "Indigox.Web.JsLib.Expression.Interpreter",
        "Indigox.Web.JsLib.Core"
    ],
function (
        Parser,
        Interpreter
) {
    var Expression =
        Namespace("Indigox.Web.JsLib.Expression")
        .Class("Expression")
        .Constructor(
            function (expr) {
                this.exprssion = expr;
                var parser = new Parser(this.exprssion);
                this.node = parser.parse();
            }
        )
        .Members({
            evaluate: function (context) {
                //var start = new Date();
                var node = this.node;
                var interpreter = new Interpreter(context);
                var ret = interpreter.interpret(node);
                //debug.log("expression evaluate spend : " + (new Date() - start));
                return ret;
            }
        })
    .$();
});