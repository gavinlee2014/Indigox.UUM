﻿define("Indigox.Web.JsLib.Expression.Nodes.IdentifierNode",
    [
        "Indigox.Web.JsLib.Expression.ASTNode",
        "Indigox.Web.JsLib.Core"
    ],
function (
        ASTNode
) {
    var base = ASTNode.prototype;

    var IdentifierNode =
        Namespace("Indigox.Web.JsLib.Expression.Nodes")
        .Class("IdentifierNode")
        .Extend(base)
        .Constructor(
            function (identifier, reference) {
                this.identifier = identifier;
                this.reference = reference;
            }
        )
        .Members({
            getIdentifier: function () {
                return this.identifier;
            },
            getReference: function () {
                return this.reference;
            },
            accept: function (interpreter, data) {
                return interpreter.visitIdentifier(this, data);
            }
        })
    .$();
});