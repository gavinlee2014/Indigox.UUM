﻿define("Indigox.Web.JsLib.Expression.Nodes.NullLiteralNode",
    [
        "Indigox.Web.JsLib.Expression.ASTNode",
        "Indigox.Web.JsLib.Core"
    ],
function (
        ASTNode
) {
    var base = ASTNode.prototype;

    var NullLiteralNode =
        Namespace("Indigox.Web.JsLib.Expression.Nodes")
        .Class("NullLiteralNode")
        .Extend(base)
        .Constructor(
            function (literal) {
                this.literal = literal;
            }
        )
        .Members({
            getLiteral: function () {
                return this.literal;
            },
            accept: function (interpreter, data) {
                return interpreter.visitNullLiteral(this, data);
            }
        })
    .$();
});