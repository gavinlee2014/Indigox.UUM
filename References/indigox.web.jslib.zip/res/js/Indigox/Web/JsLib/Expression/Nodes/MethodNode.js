﻿define("Indigox.Web.JsLib.Expression.Nodes.MethodNode",
    [
        "Indigox.Web.JsLib.Expression.ASTNode",
        "Indigox.Web.JsLib.Core"
    ],
function (
        ASTNode
) {
    var base = ASTNode.prototype;

    var MethodNode =
        Namespace("Indigox.Web.JsLib.Expression.Nodes")
        .Class("MethodNode")
        .Extend(base)
        .Constructor(
            function (reference, childNodes) {
                base.constructor.call(this, childNodes);
                this.reference = reference;
            }
        )
        .Members({
            getReference: function () {
                return this.reference;
            },
            accept: function (interpreter, data) {
                return interpreter.visitMethod(this, data);
            }
        })
    .$();
});