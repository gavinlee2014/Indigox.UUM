﻿define("Indigox.Web.JsLib.Expression.ExpressionEvaluator",
    [
        "Indigox.Web.JsLib.Invokers.FieldSetterInvoker",
        "Indigox.Web.JsLib.Invokers.FieldGetterInvoker",
        "Indigox.Web.JsLib.Invokers.MethodInvoker",
        "Indigox.Web.JsLib.Invokers.PropertySetterInvoker",
        "Indigox.Web.JsLib.Invokers.PropertyGetterInvoker",
        "Indigox.Web.JsLib.Expression.Parser",
        "Indigox.Web.JsLib.Expression.Interpreter",
        "Indigox.Web.JsLib.Expression.Expression",
        "Indigox.Web.JsLib.Core"
    ],
function (
        FieldSetterInvoker,
        FieldGetterInvoker,
        MethodInvoker,
        PropertySetterInvoker,
        PropertyGetterInvoker,
        Parser,
        Interpreter,
        Expression
) {
    var ExpressionEvaluator =
        Namespace("Indigox.Web.JsLib.Expression")
        .Class("ExpressionEvaluator")
        .Constructor(
            function (notation) {
                this.notation = notation;
            }
        )
        .Members({
            evaluate: function (context) {
                if (this.isLiteral()) {
                    return this.notation;
                }
                else if (this.isProperty()) {
                    return this.getProperty(context);
                }
                else {
                    var expression = this.parseExpression(this.notation);
                    return expression.evaluate(context);
                }
            },

            parseExpression: function () {
                var expr = this.notation.replace(/^\$\{(.+)\}$/, "$1");
                return new Expression(expr);
            },

            setProperty: function (context, value) {
                var identifier = this.notation.replace(/^\$\{(.+)\}$/, "$1");
                var setter = new PropertySetterInvoker(identifier);
                if (!setter.hasMember(context)) {
                    setter = new FieldSetterInvoker(identifier);
                }
                var result = setter.invoke(context, [value]);
                return result;
            },

            getProperty: function (context) {
                var identifier = this.notation.replace(/^\$\{(.+)\}$/, "$1");
                var getter = new PropertyGetterInvoker(identifier);
                if (!getter.hasMember(context)) {
                    getter = new FieldGetterInvoker(identifier);
                }
                var result = getter.invoke(context);
                return result;
            },

            invoke: function (context, args) {
            },

            isLiteral: function () {
                return !this.isExpression();
            },

            isProperty: function () {
                return (/^\$\{[\$_a-zA-z][\$|_|\w]*\}$/).test(this.notation);
            },

            isMethod: function () {
                return (/^\$\{[\$_a-zA-z][\$|_|\w]*\(\s*\)\s*\}$/).test(this.notation);
            },

            isExpression: function () {
                return (/^\$\{.+\}$/).test(this.notation);
            }
        })
    .$();
});