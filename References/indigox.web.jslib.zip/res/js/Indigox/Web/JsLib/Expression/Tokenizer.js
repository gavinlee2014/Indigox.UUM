﻿define("Indigox.Web.JsLib.Expression.Tokenizer",
    [
        "Indigox.Web.JsLib.Core"
    ],
function (

) {
    var KEYWORDS = {
        'break': true,
        'case': true,
        'catch': true,
        'class': true,
        'continue': true,
        'const': true,
        'debugger': true,
        'default': true,
        'delete': true,
        'do': true,
        'else': true,
        'enum': true,
        'export': true,
        'extends': true,
        'finally': true,
        'for': true,
        'function': true,
        'if': true,
        'in': true,
        'implements': true,
        'import': true,
        'instanceof': true,
        'interface': true,
        'let': true,
        'new': true,
        'package': true,
        'private': true,
        'protected': true,
        'public': true,
        'return': true,
        'static': true,
        'super': true,
        'switch': true,
        'this': true,
        'throw': true,
        'try': true,
        'typeof': true,
        'var': true,
        'void': true,
        'while': true,
        'with': true,
        'yield': true
    };

    var BOOLEAN = {
        'true': true,
        'false': true
    };

    var NULL = {
        'null': true
    };

    var PUNCTUATORS = {
        '{': true,
        '}': true,
        '(': true,
        ')': true,
        '[': true,
        ']': true,
        '.': true,
        ';': true,
        ',': true,
        '<': true,
        '>': true,
        '+': true,
        '-': true,
        '*': true,
        '%': true,
        '&': true,
        '|': true,
        '^': true,
        '!': true,
        '~': true,
        '?': true,
        ':': true,
        '=': true,
        '<=': true,
        '>=': true,
        '==': true,
        '!=': true,
        '===': true,
        '!==': true,
        '++': true,
        '--': true,
        '<<': true,
        '>>': true,
        '>>>': true,
        '&&': true,
        '||': true,
        '+=': true,
        '-=': true,
        '*=': true,
        '%=': true,
        '<<=': true,
        '>>=': true,
        '>>>=': true,
        '&=': true,
        '|=': true,
        '^=': true
    };

    var QUOTE = {
        '"': true,
        "'": false
    };

    var Tokenizer =
        Namespace("Indigox.Web.JsLib.Expression")
        .Class("Tokenizer")
        .Constructor(
            function (text) {
                this.text = text;
                this.position = 0;
                this.ch = this.text.charAt(this.position);
                this.tokenStart = -1;
                this.expecting = false;
            }
        )
        .Members({
            peek: function () {
                return this.ch;
            },
            next: function () {
                var ch = this.text.charAt(this.position++);
                this.ch = this.text.charAt(this.position);
                if (this.expecting && !ch) {
                    throw new Error("Unterminated syntax.");
                }
                return ch;
            },
            expect: function () {
                this.expecting = true;
            },
            signal: function () {
                this.expecting = false;
            },
            eof: function () {
                return !this.peek();
            },
            readWords: function () {
                var words = "", ch;
                while (!this.eof() && (ch = this.peek()) != null) {
                    if (this.isIdentifierChar(ch)) {
                        words += this.next();
                    }
                    else {
                        break;
                    }
                }
                return this.isKeyword(words)
                    ? this.createToken("KEYWORD", words)
                    : this.isBoolean(words)
                    ? this.createToken("BOOLEAN", words)
                    : this.isNull(words)
                    ? this.createToken("NULL", words)
                    : this.createToken("IDENTIFIER", words);
            },
            readPunctuator: function () {
                var punctuator = "", ch;
                while (!this.eof() && (ch = this.peek()) != null) {
                    if (this.isPunctuator(punctuator + ch)) {
                        punctuator += this.next();
                    }
                    else {
                        break;
                    }
                }
                return this.createToken("PUNCTUATOR", punctuator);
            },
            readNumber: function () {
                var str = "", ch;
                var hasDot = false;
                while (!this.eof() && (ch = this.peek()) != null) {
                    if (this.isDigit(ch)) {
                        str += this.next();
                    }
                    else if (!hasDot && this.isDot(ch)) {
                        str += this.next();
                        hasDot = true;
                    }
                    else {
                        break;
                    }
                }
                var number = Number(str);
                if (!isNaN(number)) {
                    return this.createToken("NUMBER", number);
                } else {
                    throw new Error("Invalid syntax: " + str);
                }
            },
            readString: function () {
                this.expect();
                var str = "", quote = this.next(), ch;
                while ((ch = this.next()) != null) {
                    if (this.isBackslash(ch)) {
                        ch = this.readEscapedChar();
                    }
                    else if (ch === quote) {
                        break;
                    }
                    str += ch;
                }
                this.signal();
                return this.createToken("STRING", str);
            },
            readEscapedChar: function () {
                var ch = this.next();
                switch (ch) {
                    case "n": return "\n";
                    case "r": return "\r";
                    case "t": return "\t";
                    case "b": return "\b";
                    case "v": return "\u000b";
                    case "f": return "\f";
                    case "0": return "\0";
                    case "x": return String.fromCharCode(this.readHexBytes(2));
                    case "u": return String.fromCharCode(this.readHexBytes(4));
                    case "\n": return "";
                    default: return ch;
                }
            },
            readHexBytes: function (n) {
                var number = 0;
                for (; n > 0; --n) {
                    var digit = parseInt(this.next(), 16);
                    if (isNaN(digit)) {
                        throw new Error("Invalid hex-character pattern in string");
                    }
                    number = (number << 4) | digit;
                }
                return number;
            },
            skipWhitespace: function () {
                while (/\s/.test(this.peek())) {
                    this.next();
                }
            },
            isIdentifierStart: function (ch) {
                return (/[\$_a-zA-z]/).test(ch);
            },
            isIdentifierChar: function (ch) {
                return (/\$|_|\w/).test(ch);
            },
            isKeyword: function (str) {
                return str in KEYWORDS;
            },
            isBoolean: function (str) {
                return str in BOOLEAN;
            },
            isNull: function (str) {
                return str in NULL;
            },
            isPunctuator: function (str) {
                return str in PUNCTUATORS;
            },
            isDigit: function (ch) {
                ch = ch.charCodeAt(0);
                return ch >= 48 && ch <= 57;
            },
            isDot: function (ch) {
                return ch === '.';
            },
            isQuote: function (ch) {
                return ch in QUOTE;
            },
            isBackslash: function (ch) {
                return ch === '\\';
            },
            startToken: function () {
                this.tokenStart = this.position;
            },
            createToken: function (type, value) {
                return {
                    position: this.tokenStart,
                    type: type,
                    value: value
                };
            },
            getNextToken: function () {
                this.skipWhitespace();
                var ch = this.peek();
                this.startToken();
                if (!ch) {
                    return this.createToken("EOF", null);
                }
                if (this.isIdentifierStart(ch)) {
                    return this.readWords();
                }
                if (this.isPunctuator(ch)) {
                    return this.readPunctuator();
                }
                if (this.isDigit(ch)) {
                    return this.readNumber();
                }
                if (this.isQuote(ch)) {
                    return this.readString();
                }

                throw new Error("Unexpected character '" + ch + "'");
            }
        })
    .$();
});