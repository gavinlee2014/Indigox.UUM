﻿define("Indigox.Web.JsLib.System.Application",
    [
        "Indigox.Web.JsLib.Utils.Callback",
        "Indigox.Web.JsLib.Utils.Deferred",
        "Indigox.Web.JsLib.Utils.ErrorHandler",
        "Indigox.Web.JsLib.Controls.PageUrlMonitor",
        "Indigox.Web.JsLib.UI.UIManager",
        "Indigox.Web.JsLib.Controls.Page",
        "Indigox.Web.JsLib.Core"
    ],
    function (
        Callback,
        Deferred,
        ErrorHandler,
        PageUrlMonitor,
        UIManager
    ) {
        var Application =
            Namespace("Indigox.Web.JsLib.System")
            .Class("Application")
            .Constructor(
                function () {
                }
            )
            .Members({
                onDomReady: function () {
                    var page = Page();
                    var ui = UIManager.getInstance().createUI(page);
                    ui.element = document.body;
                    page.init();
                },

                onDocumentLoad: function () {
                    var app = this;
                    app.loadPage();

                    new PageUrlMonitor().onUrlPathChanged(function () {
                        app.loadPage();
                    });
                },

                onDocumentUnload: function () {
                    var app = this;
                    app.unloadPage();
                },

                loadPage: function () {
                    Page().load();
                },

                unloadPage: function () {
                    Page().unload();
                },

                getWidgetZoneInfo: function (widgetZone) {
                    var pageUrl = Page().getUrlPath();
                    var widgetZoneName = widgetZone.getName();
                    var queryUrl = "/_remoting/PageListQuery/List/jsonp?!callback=define";

                    var dfd = new Deferred();
                    require([queryUrl], function (data) {
                        if (data.Status !== 0) {
                            ErrorHandler.log(data.Error);
                        }

                        var page = findPage(data.Result, pageUrl);
                        var widgetZone = findWidgetZone(page.WidgetZones, widgetZoneName);
                        if (widgetZone) {
                            dfd.resolve(widgetZone.Widgets);
                        }
                        else {
                            dfd.resolve([]);
                        }
                    }, function (err) {
                        console.error(err);
                    });
                    return dfd.promise();
                }
            })
        .$();

        var findPage = function (pages, url) {
            for (var i = 0, length = pages.length; i < length; i++) {
                var page = pages[i];
                if (page.Url.toLowerCase() === url.toLowerCase()) {
                    return page;
                }
            }
            return null;
        };

        var findWidgetZone = function (widgetZones, name) {
            for (var i = 0, length = widgetZones.length; i < length; i++) {
                var widgetZone = widgetZones[i];
                if (widgetZone.Name.toLowerCase() === name.toLowerCase()) {
                    return widgetZone;
                }
            }
            return null;
        };
    });