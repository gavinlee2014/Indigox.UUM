﻿(function () {
    var base = Indigo.remoting.RemotingCallProxy.prototype;

    var RecommendService =
        Namespace("Indigox.CMS.Application.Services")
        .Class("RecommendService")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.Namespace = "Indigox.CMS.Application.Services";
                this.Class = "RecommendService";
                this.Assembly = "Indigox.CMS.Application";
            }
        )
        .Members({
            GetList: function (objID) {
                return this.exec("GetList", objID);
            },

            GetListAsync: function (objID, callback) {
                this.execAsync("GetList", objID, callback);
            },

            Create: function (objID, reason, users) {
                this.exec("Create", objID, reason, users);
            },

            CreateAsync: function (objID, reason, users, callback) {
                this.execAsync("Create", objID, reason, users, callback);
            }
        })
    .$();

    window.RecommendService = new RecommendService();
})();