﻿(function () {
    var base = Indigo.remoting.RemotingCallProxy.prototype;

    var SchemaService =
        Namespace("Indigox.CMS.Application.Services")
        .Class("SchemaService")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.Namespace = "Indigox.CMS.Application.Services";
                this.Class = "SchemaService";
                this.Assembly = "Indigox.CMS.Application";
            }
        )
        .Members({
            GetSchemas: function (tableName) {
                return this.exec("GetSchemas", tableName);
            },

            GetSchemasAsync: function (tableName, callback) {
                this.execAsync("GetSchemas", tableName, callback);
            }
        })
    .$();

    window.SchemaService = new SchemaService();
})();