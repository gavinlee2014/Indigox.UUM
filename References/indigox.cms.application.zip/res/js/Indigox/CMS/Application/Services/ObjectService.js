﻿(function () {
    var base = Indigo.remoting.RemotingCallProxy.prototype;
    
    var ObjectService =
        Namespace("Indigox.CMS.Application.Services")
        .Class("ObjectService")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.Namespace = "Indigox.CMS.Application.Services";
                this.Class = "ObjectService";
                this.Assembly = "Indigox.CMS.Application";
            }
        )
        .Members({
            ReadObject: function (objId) {
                var entity = this.exec("ReadObject", objId);
                return entity;
            },

            ReadObjectAsync: function (objId, callback) {
                this.execAsync("ReadObject", objId, callback);
            },

            GetObjectSummaryInfo: function (id) {
                var ret = this.exec("GetObjectSummaryInfo", id);
                return ret;
            },

            GetObjectSummaryInfoAsync: function (id, callback) {
                this.execAsync("GetObjectSummaryInfo", id, callback);
            },

            Get: function (id, viewName) {
                var ret = this.exec("Get", id, viewName);
                return ret;
            },

            GetAsync: function (id, viewName, callback) {
                this.execAsync("Get", id, viewName, callback);
            },

            GetList: function (query) {
                var ret = this.exec("GetList", query);
                return ret;
            },

            GetListAsync: function (query, callback) {
                this.execAsync("GetList", query, callback);
            },

            Update: function (entity, viewName) {
                var ret = this.exec("Update", entity, viewName);
                return ret;
            },

            UpdateAsync: function (entity, viewName, callback) {
                this.execAsync("Update", entity, viewName, callback);
            },

            Create: function (entity, viewName) {
                var ret = this.exec("Create", entity, viewName);
                return ret;
            },

            CreateAsync: function (entity, viewName, callback) {
                this.execAsync("Create", entity, viewName, callback);
            },

            Delete: function (entity) {
                return this.exec("Delete", entity);
            },

            DeleteAsync: function (entity, callback) {
                this.execAsync("Delete", entity, callback);
            }
        })
    .$();

    window.ObjectService = new ObjectService();
})();