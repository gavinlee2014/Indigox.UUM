﻿(function () {
    var base = Indigo.remoting.RemotingCallProxy.prototype;

    var ContentTypeService =
        Namespace("Indigox.CMS.Application.Services")
        .Class("ContentTypeService")
        .Extend(base)
        .Constructor(
            function () {
                base.constructor.apply(this, arguments);
                this.Namespace = "Indigox.CMS.Application.Services";
                this.Class = "ContentTypeService";
                this.Assembly = "Indigox.CMS.Application";
            }
        )
        .Members({
            GetContentFields: function (tableName) {
                return this.exec("GetContentFields", tableName);
            },

            GetContentFieldsAsync: function (tableName, callback) {
                this.execAsync("GetContentFields", tableName, callback);
            },

            //GetContentTypes: function (callback) {
            //    return this.exec("GetContentTypes", callback);
            //},
            //
            //GetContentTypesAsync: function (callback) {
            //    this.execAsync("GetContentTypes", callback);
            //},

            GetDetailViews: function (tableName) {
                return this.exec("GetDetailViews", tableName);
            },

            GetDetailViewsAsync: function (tableName, callback) {
                this.execAsync("GetDetailViews", tableName, callback);
            }
        })
    .$();

    window.ContentTypeService = new ContentTypeService();
})();