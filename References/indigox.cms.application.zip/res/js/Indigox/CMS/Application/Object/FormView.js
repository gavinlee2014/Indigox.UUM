﻿define("Indigox/CMS/Application/Object/FormView",
    [
        "Indigox.Web.JsLib.Models.RecordManager"
    ],
function (
    RecordManager
) {
    RecordManager.getInstance().register('FormView', {
        columns: [
            { name: 'viewName', text: '视图名称', type: String },
            { name: 'title', text: '视图标题', type: String }
        ],
        primaryKey: ['viewName']
    });
});