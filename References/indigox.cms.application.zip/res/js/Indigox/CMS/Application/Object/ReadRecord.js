﻿define("Indigox/CMS/Application/Object/ReadRecord",
    [
        "Indigox.Web.JsLib.Models.RecordManager"
    ],
function (
    RecordManager
) {
    RecordManager.getInstance().register('ReadRecord', {
        columns: [
            { name: 'ObjID', text: 'ID', type: String },
            { name: 'ReadCount', text: '阅读次数', type: Number },
            { name: 'DocReadUsers', text: '阅读人列表', type: Array },
            { name: 'DefaultReaders', text: '授权阅读者', type: String }
        ],
        primaryKey: ['ObjID']
    });
});