﻿define("Indigox/CMS/Application/Object/FolderInfo",
    [
        "Indigox.Web.JsLib.Models.RecordManager"
    ],
function (
    RecordManager
) {
    RecordManager.getInstance().register('FolderInfo', {
        columns: [
            { name: 'ObjID', text: '文档编号', type: String },
            { name: 'ParentObjID', text: '父文档编号', type: String },
            { name: 'Title', text: '文件名称', type: String },
            { name: 'SubItemType', text: 'SubItemType', type: String }
        ],
        primaryKey: ['ObjID'],
        foreignKeys: [{ columns: ["ParentObjID"], referencedSchema: "FolderInfo", referencedColumns: ["ObjID"]}]
    });
});