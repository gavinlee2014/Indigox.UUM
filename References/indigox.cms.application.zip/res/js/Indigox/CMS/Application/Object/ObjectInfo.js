﻿define("Indigox/CMS/Application/Object/ObjectInfo",
    [
        "Indigox.Web.JsLib.Models.RecordManager"
    ],
function (
    RecordManager
) {
    RecordManager.getInstance().register("ObjectInfo", {
        columns: [
            { name: "TableName", text: "表名", type: String },
            { name: "ObjID", text: "文档ID", type: String },
            { name: "Title", text: "标题", type: String },
            { name: "DispTitle", text: "标题", type: String },
            { name: "CreateUser", text: "创建人", type: Object },
            { name: "CreateTime", text: "创建时间", type: String },
            { name: "LastModifyUser", text: "修改人", type: String },
            { name: "LastModifyTime", text: "修改时间", type: String },
            { name: "ReadCount", text: "阅读次数", type: String },
            { name: "WorkflowState", text: "状态", type: String },

            //
            { name: "ProcessDefinitionID", text: "流程定义编号", type: String },
            { name: "ProcessInstanceID", text: "流程实例编号", type: String },

            //
            { name: "ContractNumber", text: "合同编号", type: String },
            { name: "ContractName", text: "合同名称", type: String },
            { name: "SecondParty", text: "乙方信息", type: String },
            { name: "ContractAmount", text: "合同金额", type: String },
            { name: "FirstParty", text: "FirstParty", type: String },
            { name: "FirstPartyID", text: "FirstPartyID", type: String },

            //
            { name: "ParentProfessionID", text: "ParentProfessionID", type: String }
        ],
        primaryKey: ["ObjID"],
        foreignKeys: [{
            columns: ["ParentProfessionID"],
            referencedSchema: "ObjectInfo",
            referencedColumns: ["ObjID"]
        }]
    });
});