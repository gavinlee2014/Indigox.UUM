﻿define("Indigox/CMS/Application/Object/ContentType",
    [
        "Indigox.Web.JsLib.Models.RecordManager"
    ],
function (
    RecordManager
) {
    RecordManager.getInstance().register('ContentType', {
        columns: [
            { name: 'contentTypeName', text: '内容类型名称', type: String },
            { name: 'tableName', text: '表名', type: String }
        ]
    });
});