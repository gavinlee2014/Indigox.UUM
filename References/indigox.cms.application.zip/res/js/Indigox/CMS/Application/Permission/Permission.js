﻿define("Indigox/CMS/Application/Permission/Permission",
    [
        "Indigox.Web.JsLib.Models.RecordManager"
    ],
function (
    RecordManager
) {
    var identifier = Page().getUrlParam("Identifier");
    var type = Page().getUrlParam("Type");

    RecordManager.getInstance().register('Permission', {
        columns: [
            { name: 'Identifier', text: 'Identifier', type: String, defaultValue: identifier },
            { name: 'Type', text: 'Type', type: String, defaultValue: type },
            { name: 'Title', text: 'Title', type: String },
            { name: 'ID', text: 'AceID', type: String },
            { name: 'PermissionMask', text: 'AceId', type: String },
            { name: 'Permissions', text: '权限', type: String, defaultValue: [] },
            { name: 'PermissionNames', text: '权限名称', type: String },
            { name: 'IsInherited', text: '是否来自继承', type: String },
            { name: 'Granting', text: '授权方式', type: String, defaultValue: [] },
            { name: 'User', text: '授权用户', type: String }
        ],
        primaryKey: ['ID']
    });
});