﻿define("Indigox/CMS/Application/Authority/Authority",
    [
        "Indigox.Web.JsLib.Models.RecordManager"
    ],
function (
    RecordManager
) {
    RecordManager.getInstance().register('Authority', {
        columns: [
            { name: 'GUID', text: 'Authority编号', type: String, guid: "" },
            { name: 'AuthorityID', text: 'Authority编号', type: String },
            { name: 'Name', text: 'Authority名称', type: String },
            { name: 'Description', text: 'Authority描述', type: String},
            { name: 'AuthorizedTo', text: '授予对象', type: String }
        ],
        primaryKey: ['GUID']
    });
});