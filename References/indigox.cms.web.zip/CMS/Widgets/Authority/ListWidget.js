﻿define("/CMS/Widgets/Authority/ListWidget",
    [
        "Indigox.Web.JsLib.Utils.Callback",
        "Indigox.Web.JsLib.Proxy.InstructionProxy",
        "Indigox.Web.JsLib.Models.RecordManager",
        "Indigox.Web.JsLib.Controllers.ListController",
        "Indigox/CMS/Application/Authority/Authority"
    ],
function (
        Callback,
        InstructionProxy,
        RecordManager,
        ListController
) {

    var limit = 10;

    var exports = function (widget) {
        var recordSet = RecordManager.getInstance().createRecordSet('Authority', {
            proxy: new InstructionProxy({
                query: "AuthorityQuery",
                createCommand: "CreateAuthorityCommand",
                updateCommand: "UpdateAuthorityCommand",
                deleteCommand: "DeleteAuthorityCommand"
            })
        });
        configurateAddAuthorityButton(widget, recordSet);
        configurateAuthorityList(widget, recordSet);
    };

    function configurateAddAuthorityButton(widget, recordSet) {
        $(widget).ButtonMenuItem('btnAddAuthority').first().on('clicked', function () {
            var record = recordSet.createRecord({});
            recordSet.addRecord(record);
            $.Dialog("AuthorityEditDialog").first().open({
                CurrentAuthority: record,
                IsNewAuthority: true
            });
        });
    }

    function configurateAuthorityList(widget, recordSet) {
        $(widget).DataList("AuthorityList").first().getItemTemplate().getChild("AuthorizedTo").configure({
            binding: {
                mapping: {
                    value: function (record) {
                        var authorityTo = record.get("AuthorizedTo");
                        if (authorityTo) {
                            var names = [];
                            for (var i = 0, length = authorityTo.length; i < length; i++) {
                                names.push(authorityTo[i].UserName);
                            }
                            return names.join('，');
                        }
                    }
                }
            }
        });

        $(widget).DataList("AuthorityList").on("itemAdded", function (source, index, item) {
            $(item).Button("btnEditAuthority").on("clicked", function (source) {
                var record = source.parent.getRecord();
                $.Dialog("AuthorityEditDialog").first().open({
                    CurrentAuthority: record,
                    IsNewAuthority: false
                });
            });

            $(item).Button("btnDeleteAuthority").on("clicked", function (source) {
                Page().mask();

                if (!confirm("您确认要删除此权限设定吗?")) {
                    Page().unmask();
                    return false;
                }

                var record = source.parent.getRecord();
                var controller = $(widget).DataList("AuthorityList").first().getController();
                controller.removeRecord(record);
                controller.save(function (successed) {
                    Page().unmask();
                    if (!successed) {
                        alert("删除失败!");
                    }
                    controller.load();
                });
            });
        });

        var arrayController = new ListController({
            model: recordSet,
            params: {
                "FetchSize": limit
            }
        });

        $(widget).DataList("AuthorityList").first().configure({
            controller: arrayController
        });

        $(widget).Paging("AuthorityPaging").configure({
            pageSize: limit,
            arrayController: arrayController
        });
    }

    return exports;
});