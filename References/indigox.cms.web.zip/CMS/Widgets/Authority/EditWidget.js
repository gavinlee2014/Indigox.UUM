﻿define("/CMS/Widgets/Authority/EditWidget",
    [
        "Indigox.Web.JsLib.CQRS.Batch",
        "Indigox.Web.JsLib.Proxy.InstructionProxy",
        "Indigox.Web.JsLib.Models.RecordManager",
        "Indigox.Web.JsLib.Controllers.FormController"
    ],
function (
        Batch,
        InstructionProxy,
        RecordManager,
        FormController
) {
    var exports = function (widget) {
        $(widget).Content("AuthorityEditPanel").first().configure({
            controller: new FormController()
        });

        $(widget).Button("btnCancelAuthority").first().on("clicked", function () {
            $(widget).Dialog("AuthorityEditDialog").first().close();
        });

        $(widget).UserSelect("AuthorizedTo").first().setMulti(true);

        $(widget).Button("btnSaveAuthority").first().on("clicked", function () {
            Page().mask();

            if (!checkBusinessData(widget)) {
                Page().unmask();
                return;
            }

            var dialog = $(widget).Dialog("AuthorityEditDialog").first();
            var authorityRecordSet = dialog.getParam("AuthorityRecordSet");
            var currentAuthority = dialog.getParam("CurrentAuthority");
            var isNewAuthority = dialog.getParam("IsNewAuthority");

            var content = $(widget).Content("AuthorityEditPanel").first();
            content.getController().updateRecord(content, currentAuthority);
            authorityRecordSet.commit(function (successed) {
                if (successed) {
                    dialog.close();
                    alert("保存成功！");
                    if (isNewAuthority) {
                        $.Paging("AuthorityPaging").first().reset(); // Paging is in ListWidget
                    }
                    Page().unmask();
                }
                else {
                    alert("保存授权记录失败！");
                    Page().unmask();
                }
            });
        });

        $(widget).TextBox('AuthorityID').first().addValidateRule(['nb', '', '请填写编号！']);
        $(widget).TextBox('AuthorizedTo').first().addValidateRule(['nb', '', '请选择授权对象']);

        $(widget).Dialog('AuthorityEditDialog').first().on('opened', function () {
            var content = $(widget).Content("AuthorityEditPanel").first();
            content.reset();

            var dialog = this;
            var authorityRecordSet = dialog.getParam("AuthorityRecordSet");
            var currentAuthority = dialog.getParam("CurrentAuthority");
            var isNewAuthority = dialog.getParam("IsNewAuthority");

            if (isNewAuthority === true) {
                $(widget).TextBox('AuthorityID').first().setReadonly(false);
            }
            else {
                $(widget).TextBox('AuthorityID').first().setReadonly(true);
            }
            content.getController().bindRecord(content, currentAuthority);
        });

        $(widget).Button("AuthorityEditDialog").first().on("closed", function () {
            var dialog = this;
            var authorityRecordSet = dialog.getParam("AuthorityRecordSet");
            var currentAuthority = dialog.getParam("CurrentAuthority");
            var isNewAuthority = dialog.getParam("IsNewAuthority");

            if (isNewAuthority) {
                authorityRecordSet.removeRecord(authorityRecordSet.size() - 1);
            }
        });
    };

    function checkBusinessData(widget) {
        var form = $(widget).Content("AuthorityEditPanel").first();
        var validator = $(widget).Validator("Validator").first();
        var result = validator.validate(form);
        if (false === result.matched) {
            return false;
        }
        return true;
    }

    return exports;
});