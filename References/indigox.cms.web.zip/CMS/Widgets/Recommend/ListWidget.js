﻿define("/CMS/Widgets/Recommend/ListWidget",
    [
        "Indigox.Web.JsLib.Proxy.InstructionProxy",
        "Indigox.Web.JsLib.Models.RecordManager",
        "Indigox.Web.JsLib.Controllers.ListController",
        "Indigox/BPM/Application/Recommends/Recommend"
    ],
function (
        InstructionProxy,
        RecordManager,
        ListController
) {

        var exports = function (widget) {
            $(widget).Panel("recommendsPanel").first().on("expanded", function () {
                var objID = Page().getUrlParam("ObjID");

                $("recommendList").configure({
                    controller: new ListController({
                        model: RecordManager.getInstance().createRecordSet('Recommend', {
                            proxy: new InstructionProxy({
                                query: "DocumentRecommendAllQuery"
                            })
                        }),
                        params: {
                            "ObjID": objID
                        }
                    })
                });

                this.un('expanded', arguments.callee);
            });
        };

        return exports;
    });