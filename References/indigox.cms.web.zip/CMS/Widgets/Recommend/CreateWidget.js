﻿define("/CMS/Widgets/Recommend/CreateWidget",
    [
        "Indigox.Web.JsLib.Utils.ErrorHandler",
        "Indigox.Web.JsLib.CQRS.Batch"
    ],
function (
        ErrorHandler,
        Batch
) {

        var exports = function (widget) {
            $(widget).Dialog('recommendDialog').first().on('closed', function () {
                $('toolbar').ButtonMenuItem().setEnable(true);
            });

            $(widget).Button("btnCancelRecommend").first().on("clicked", function () {
                $.Dialog("recommendDialog").get(0).close();
            });

            $(widget).Button("btnCreateRecomend").first().on("clicked", function () {
                var recommendUser = $(widget).Dialog("recommendDialog").UserSelect("RecommendTo").first().getValue();
                if (isNullOrUndefined(recommendUser) || recommendUser.length === 0) {
                    alert("请至少选择一个推荐人员!");
                    return;
                }

                Page().mask();

                var objID = Page().getUrlParam("ObjID");
                var reason = $(widget).TextBox("RecommendReason").first().getValue();
                var batch = Batch.beginBatch();
                batch.execute({
                    name: 'DocumentRecommendCommand',
                    properties: {
                        ObjID: objID,
                        RecommendTo: recommendUser,
                        Reason: reason
                    },
                    callback: function (data) {
                        alert("推荐成功!");
                        $(widget).Dialog("recommendDialog").close();
                        Page().unmask();
                    },
                    errorCallback: function (error) {
                        ErrorHandler.logAlert(error);
                        Page().unmask();
                    }
                });
                batch.commit();
            });
        };

        return exports;
    });