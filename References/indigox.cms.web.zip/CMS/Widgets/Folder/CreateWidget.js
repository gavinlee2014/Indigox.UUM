﻿define("/CMS/Widgets/Folder/CreateWidget",
    [
        "Indigox.Web.JsLib.Utils.UrlUtil",
        "Indigox.Web.JsLib.Proxy.InstructionProxy",
        "Indigox.Web.JsLib.Models.RecordManager",
        "Indigox.Web.JsLib.Controllers.FormController",
        "/CMS/Widgets/Folder/FolderSchema"
    ],
function (
        UrlUtil,
        InstructionProxy,
        RecordManager,
        FormController
) {

        var exports = function (widget) {
            $(widget).Content("FolderCreatePanel").first().configure({
                controller: new FormController({
                    model: RecordManager.getInstance().createRecordSet('Folder', {
                        proxy: new InstructionProxy({
                            createCommand: "CreateFolderCommand"
                        })
                    }),
                    autoLoad: false
                })
            });

            $(widget).Dialog('FolderCreateDialog').first().on('opened', function () {
                var folderId = Page().getUrlParam("FolderID") || 0;
                $(widget).Content("FolderCreatePanel").first().getController().insertRecord(0, { ParentObjID: folderId });
            });

            $(widget).Button("btnCreateFolder").first().on("clicked", function () {
                Page().mask();
                var form = $(widget).Content("FolderCreatePanel").first();

                form.on("submit", function (source, successed) {
                    if (successed) {
                        alert("新建文件夹成功!");
                        $(widget).Dialog("FolderCreateDialog").first().close();
                        Page().unmask();
                    }
                    else {
                        alert("新建文件夹失败!");
                        Page().unmask();
                    }
                    this.un('submit', arguments.callee);
                });

                form.submit();
            });

            $(widget).Button("btnCancelCreate").first().on("clicked", function () {
                $(widget).Dialog("FolderCreateDialog").first().close();
            });
        };

        return exports;
    });