﻿define("/CMS/Widgets/Folder/EditWidget",
    [
        "Indigox.Web.JsLib.Utils.UrlUtil",
        "Indigox.Web.JsLib.Proxy.InstructionProxy",
        "Indigox.Web.JsLib.Models.RecordManager",
        "Indigox.Web.JsLib.Controllers.FormController",
        "/CMS/Widgets/Folder/FolderSchema"
    ],
function (
        UrlUtil,
        InstructionProxy,
        RecordManager,
        FormController
) {

        var exports = function (widget) {

            $(widget).Content("FolderEditPanel").first().configure({
                controller: new FormController({
                    model: RecordManager.getInstance().createRecordSet('Folder', {
                        proxy: new InstructionProxy({
                            query: "ObjectQuery",
                            updateCommand: "UpdateFolderCommand"
                        })
                    }),
                    autoLoad: false
                })
            });

            $(widget).Dialog('FolderEditDialog').first().on('opened', function () {
                var folderID = Page().getUrlParam("FolderID") || 0;
                var controller = $(widget).Content("FolderEditPanel").first().getController();
                controller.setParam("ObjID", folderID);
                if (controller.getModel()) {
                    controller.getModel().reset();
                }
                controller.load();

            });

            $(widget).Button("btnSaveFolder").first().on("clicked", function () {
                Page().mask();
                var form = $(widget).Content("FolderEditPanel").first();

                form.on("submit", function (source, successed) {
                    if (successed) {
                        alert("修改文件夹成功!");
                        $(widget).Dialog("FolderEditDialog").first().close();
                        Page().unmask();
                    }
                    else {
                        alert("修改文件夹失败!");
                        Page().unmask();
                    }
                    this.un('submit', arguments.callee);
                });

                form.submit();

            });

            $(widget).Button("btnCancelEdit").first().on("clicked", function () {
                $(widget).Dialog("FolderEditDialog").first().close();
            });
        };


        return exports;
    });