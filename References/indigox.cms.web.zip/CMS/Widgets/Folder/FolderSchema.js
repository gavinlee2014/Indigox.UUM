﻿define("/CMS/Widgets/Folder/FolderSchema",
    [
        "Indigox.Web.JsLib.Models.RecordManager"
    ],
function (
    RecordManager
) {
    RecordManager.getInstance().register("Folder", {
        "columns": [
            { name: 'ObjID', text: '编号', type: String },
            { name: 'ParentObjID', text: '父编号', type: String },
            { name: 'SubItemType', text: '内容类型', type: String, defaultValue: 'Document' },
            { name: 'Title', text: '标题', type: String },
            { name: 'OrderNum', text: '排序值', type: String, defaultValue: 0 }
        ],
        primaryKey: ['ObjID'],
        foreignKeys: [{
            columns: ["ParentObjID"],
            referencedSchema: "Folder",
            referencedColumns: ["ObjID"]
        }]
    });
});