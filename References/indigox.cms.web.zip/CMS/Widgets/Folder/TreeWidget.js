﻿define("/CMS/Widgets/Folder/TreeWidget",
    [
        "Indigox.Web.JsLib.Utils.UrlUtil",
        "Indigox.Web.JsLib.CQRS.Batch",
        "Indigox.Web.JsLib.Proxy.ArrayProxy",
        "Indigox.Web.JsLib.Models.RecordManager",
        "Indigox.Web.JsLib.Controllers.HierarchyController",
        "/CMS/Widgets/Folder/FolderSchema"
    ],
function (
        UrlUtil,
        Batch,
        ArrayProxy,
        RecordManager,
        HierarchyController
) {
    var maxInteger = 0x7FFFFFFF;

    var exports = function (widget) {
        var rootID = widget.getParam("root") || 0;
        var linkUrl = widget.getParam("LinkUrl") || "#/Content/List.htm";
        var folderData = null;
        var folderID = Page().getUrlParam("FolderID");

        var hierarchyController = new HierarchyController({
            model: RecordManager.getInstance().createRecordSet('Folder', {
                proxy: new ArrayProxy(),
                addRecords: true
            }),
            rootValue: rootID,
            nodeOptions: {
                binding: {
                    mapping: {
                        value: "ObjID",
                        text: "Title",
                        href: function (record) {
                            return UrlUtil.join(linkUrl, {
                                FolderID: record.get("ObjID")
                            });
                        }
                    }
                }
            }
        });

        $(widget).Tree("FolderTree").first().configure({
            mode: "SINGLE",
            treeNodeType: "linktreenode",
            valueField: "ObjID",
            expandLevel: 1,
            controller: hierarchyController
        });

        Page().listenUrlParamChanged(["FolderID"], { container: widget }, function () {
            var folderID = Page().getUrlParam("FolderID");
            $(widget).Tree("FolderTree").first().expandPath(
                    getPath(folderData, folderID, "ObjID", "ParentObjID", rootID)
                );
        });

        var batch = new Batch.beginBatch();
        batch.list({
            name: "ObjectListQuery",
            properties: {
                TableName: "Folder",
                OrderClause: "isnull(OrderNum," + maxInteger + ")",
                WhereClause: "ObjID > 0 ",
                ParentObjID: 0
            },
            callback: function (data) {
                folderData = data;
                var tree = $(widget).Tree("FolderTree").first();
                tree.getController().getModel().getProxy().setArray(data);
                tree.getController().load();

                var path = getPath(data, folderID, "ObjID", "ParentObjID", rootID);
                tree.expandPath(path);
            }
        });
        batch.commit();
    };

    function getPath(datalist, value, idField, parentidField, rootValue) {
        var path = "";
        var parent = null;
        var i = null,
            length = null;
        for (i = 0, length = datalist.length; i < length; i++) {
            var data = datalist[i];
            if (data[idField] == value) {
                parent = data[parentidField];
                break;
            }
        }
        if (parent != null && parent != rootValue) {
            path = getPath(datalist, parent, idField, parentidField, rootValue) + "/" + value;
        }
        else {
            path = value;
        }
        return path;
    }

    return exports;
});