﻿define("/CMS/Widgets/Permission/ListWidget",
    [
        "Indigox.Web.JsLib.Utils.UrlUtil",
        "Indigox.Web.JsLib.Utils.Callback",
        "Indigox.Web.JsLib.Utils.StringUtil",
        "Indigox.Web.JsLib.Proxy.InstructionProxy",
        "Indigox.Web.JsLib.Models.RecordManager",
        "Indigox.Web.JsLib.Controllers.ListController",
        "Indigox/CMS/Application/Permission/Permission"
    ],
    function (
        UrlUtil,
        Callback,
        StringUtil,
        InstructionProxy,
        RecordManager,
        ListController
    ) {

        var limit = 5;

        var exports = function (widget) {
            bindList(widget);
        };

        function bindList(widget) {
            var identifier = Page().getUrlParam("Identifier");
            var type = Page().getUrlParam("Type");

            var listControl = $(widget).DataList("PermissionList").first();
            var paging = $(widget).Paging("Paging").first();

            configurateItemTemplate(listControl);

            listControl.on("itemAdded", function (source, index, item) {
                if (item.getRecord().get("IsInherited") === true) {
                    $(item).Button("btnEditPermission").first().setEnable(false);
                    $(item).Button("btnDeletePermission").first().setEnable(false);
                    $(item).Button("btnEditPermission").first().setVisible(false);
                    $(item).Button("btnDeletePermission").first().setVisible(false);
                }
                else {
                    $(item).Button("btnEditPermission").first().on("clicked", function (source) {
                        $.Dialog("PermissionEditDialog").first().open({
                            Option: 'edit',
                            Record: source.parent.getRecord()
                        });
                    });
                    $(item).Button("btnDeletePermission").first().on("clicked", function (source) {
                        if (!confirm("您确认要删除此权限设定吗?")) {
                            return false;
                        }

                        Page().mask();

                        var record = source.parent.getRecord();
                        var controller = $(widget).DataList("PermissionList").first().getController();
                        controller.removeRecord(record);
                        controller.save(function (successed) {
                            Page().unmask();
                            if (!successed) {
                                alert("删除失败!");
                            }
                            controller.load();
                        });
                    });
                }
            });

            var arrayController = new ListController({
                model: RecordManager.getInstance().createRecordSet('Permission', {
                    proxy: new InstructionProxy({
                        query: "ObjectPermissionsQuery",
                        deleteCommand: "RemovePermissionCommand"
                    })
                }),
                params: {
                    "Identifier": identifier,
                    "Type": type,
                    "FetchSize": limit
                }
            });

            paging.configure({
                pageSize: limit,
                arrayController: arrayController
            });

            listControl.configure({
                controller: arrayController
            });

            Page().listenUrlParamChanged(['Identifier', 'Type'], { container: widget }, function () {
                var identifier = Page().getUrlParam("Identifier");
                var type = Page().getUrlParam("Type");

                var paging = $(widget).Paging("Paging").first();
                var controller = paging.getArrayController();
                controller.setParam("Identifier", identifier);
                controller.setParam("Type", type);
                paging.reset();
            });
        }

        function configurateItemTemplate(listControl) {
            var template = listControl.getItemTemplate();

            template.getChild("PermissionNames").configure({
                binding: {
                    mapping: {
                        value: function (record) {
                            return getItemValues(record.get("PermissionNames"));
                        }
                    }
                }
            });

            template.getChild("Granting").configure({
                binding: {
                    mapping: {
                        value: function (record) {
                            if (record.get("Granting")[0] === true) {
                                return "允许";
                            }
                            else {
                                return "禁止";
                            }
                        }
                    }
                }
            });

            template.getChild("UserName").configure({
                binding: {
                    mapping: {
                        value: function (record) {
                            if (record.get("User")) {
                                return record.get("User")[0].UserName;
                            }
                        }
                    }
                }
            });

            template.getChild("InheriteFrom").configure({
                binding: {
                    mapping: {
                        value: function (record) {
                            if (record.get("IsInherited") === true) {
                                var url = UrlUtil.join("#/Admin/Permission/List.htm", {
                                    Identifier: record.get("Identifier"),
                                    Type: record.get("Type")
                                });
                                return '<a href="' + url + '">' + (record.get("Title") || "无标题") + '</a>';
                            }
                            else {
                                return "无"; // record.get("Title");
                            }
                        }
                    }
                }
            });
        }

        function getItemValues(items) {
            var text = "";
            if (items.length > 0) {
                for (var i = 0; i < items.length; i++) {
                    text += items[i] + ",";
                }
                text = text.substring(0, text.length - 1);
            }
            return text;
        }

        return exports;
    });