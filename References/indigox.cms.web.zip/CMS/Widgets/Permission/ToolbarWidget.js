﻿define("/CMS/Widgets/Permission/ToolbarWidget",
    [
        "Indigox.Web.JsLib.Utils.UrlUtil",
        "Indigox.Web.JsLib.Utils.ErrorHandler",
        "Indigox.Web.JsLib.CQRS.Batch",
        "Indigox.Web.JsLib.CQRS.AutoBatch",
        "Indigox.Web.JsLib.Controls.Html.Dialog",
        "Indigox.Web.JsLib.Controls.Html.Menu"
    ],
    function (
        UrlUtil,
        ErrorHandler,
        Batch,
        AutoBatch,
        Dialog,
        Menu
    ) {
        var exports = function (widget) {
            $(widget).Menu("toolbar").first().configure({
                menuItemType: "buttonmenuitem",
                orientation: Menu.ORIENTATION_HORIZONTAL,
                staticDisplayLevels: 1,
                childNodes: [{
                    name: "btnAddPermission",
                    value: "新建权限",
                    events: {
                        clicked: function (source, e) {
                            $.Dialog("PermissionEditDialog").first().open({
                                Option: 'create',
                                Identifier: Page().getUrlParam("Identifier"),
                                Type: Page().getUrlParam("Type")
                            });
                        }
                    }
                }, {
                    name: "btnBreakInheritance",
                    value: "断开继承",
                    events: {
                        clicked: function (source, e) {
                            Page().mask();
                            var batch = Batch.beginBatch();
                            batch.execute({
                                name: "BreakPermissionInheritanceCommand",
                                properties: {
                                    Identifier: Page().getUrlParam("Identifier"),
                                    Type: Page().getUrlParam("Type")
                                },
                                callback: function () {
                                    $(widget).Menu("toolbar").ButtonMenuItem("btnResetInheritance").first().setVisible(true);
                                    $(widget).Menu("toolbar").ButtonMenuItem("btnBreakInheritance").first().setVisible(false);
                                    $.Paging("Paging").first().reset();
                                    Page().unmask();
                                },
                                errorCallback: function (error) {
                                    ErrorHandler.logAlert(error);
                                    Page().unmask();
                                }
                            });
                            batch.commit();
                        }
                    }
                }, {
                    name: "btnResetInheritance",
                    value: "恢复继承",
                    events: {
                        clicked: function (source, e) {
                            Page().mask();
                            var batch = Batch.beginBatch();
                            batch.execute({
                                name: "ResetPermissionInheritanceCommand",
                                properties: {
                                    Identifier: Page().getUrlParam("Identifier"),
                                    Type: Page().getUrlParam("Type")
                                },
                                callback: function () {
                                    $(widget).Menu("toolbar").ButtonMenuItem("btnResetInheritance").first().setVisible(false);
                                    $(widget).Menu("toolbar").ButtonMenuItem("btnBreakInheritance").first().setVisible(true);
                                    $.Paging("Paging").first().reset();
                                    Page().unmask();
                                },
                                errorCallback: function (error) {
                                    ErrorHandler.logAlert(error);
                                    Page().unmask();
                                }
                            });
                            batch.commit();
                        }
                    }
                }, {
                    name: "btnReturn",
                    value: "返回列表",
                    events: {
                        clicked: function (source, e) {
                            UrlUtil.goBack();
                        }
                    }
                }]
            });

            var batch = AutoBatch.getCurrentBatch();
            batch.single({
                name: "ObjectAclQuery",
                properties: {
                    Identifier: Page().getUrlParam("Identifier"),
                    Type: Page().getUrlParam("Type")
                },
                callback: function (acl) {
                    //debug.log(acl.IsInherited);
                    $(widget).Menu("toolbar").ButtonMenuItem("btnResetInheritance").setVisible(!acl.IsInherited);
                    $(widget).Menu("toolbar").ButtonMenuItem("btnBreakInheritance").setVisible(acl.IsInherited);
                }
            });
        };

        return exports;
    });