﻿define("/CMS/Widgets/Permission/EditWidget",
    [
        "Indigox.Web.JsLib.Utils.UrlUtil",
        "Indigox.Web.JsLib.Utils.ArrayUtil",
        "Indigox.Web.JsLib.Proxy.InstructionProxy",
        "Indigox.Web.JsLib.Models.RecordManager",
        "Indigox.Web.JsLib.Controllers.FormController",
        "/CMS/Widgets/Permission/Permissions",
        "Indigox/CMS/Application/Permission/Permission"
    ],
    function (
        UrlUtil,
        ArrayUtil,
        InstructionProxy,
        RecordManager,
        FormController,
        Permissions
    ) {
        var itemList = Permissions;

        var exports = function (widget) {
            configureControl(widget);
            configureButton(widget);
            configureDialog(widget);
        };

        function configureControl(widget) {
            $(widget).CheckBoxList('Permissions').first().configure({
                items: itemList
            });
            $(widget).RadioBoxList("Granting").first().configure({
                items: [
                    { text: "允许", value: true },
                    { text: "禁止", value: false }
                ]
            });
        }

        function configureDialog(widget) {
            var dialog = $(widget).Dialog("PermissionEditDialog").first();

            var userControl = $(dialog).UserSelect("User").first();
            var grantingControl = $(dialog).RadioBoxList("Granting").first();
            var grantToAnonymousUser = $(dialog).Button("GrantToAnonymousUser").first();

            grantToAnonymousUser.on('clicked', function (source) {
                userControl.setValue([{
                    "UserID": "Anonymous",
                    "UserName": "匿名用户"
                }]);
            });

            dialog.on('opened', function () {
                $('toolbar').ButtonMenuItem().setEnable(false);
                var option = this.getParam("Option");
                var record = this.getParam("Record");

                var controller = $(this).Content("PermissionEditPanel").first().getController();

                if (option === 'create') {
                    userControl.setEnable(true);
                    grantingControl.setEnable(true);
                    grantingControl.setReadonly(false);
                    grantToAnonymousUser.setVisible(true);

                    var identifier = this.getParam("Identifier");
                    var type = this.getParam("Type");
                    RecordManager.getInstance().getDataSchema("Permission").getColumn("Identifier").setDefaultValue(identifier);
                    RecordManager.getInstance().getDataSchema("Permission").getColumn("Type").setDefaultValue(type);

                    controller.clearModel();
                    controller.insertRecord(0);
                }
                else if (option === 'edit') {
                    userControl.setEnable(false);
                    grantingControl.setEnable(false);
                    grantingControl.setReadonly(true);
                    grantToAnonymousUser.setVisible(false);

                    controller.clearModel();
                    controller.setParam("UserID", record.get("User")[0].UserID);
                    controller.setParam("Identifier", record.get("Identifier"));
                    controller.setParam("Type", record.get("Type"));
                    controller.setParam("Granting", record.get("Granting")[0]);
                    controller.load();
                }
            });

            dialog.on('closed', function () {
                $('toolbar').ButtonMenuItem().setEnable(true);
            });

            dialog.on('loading', function () {
                $(widget).Content("PermissionEditPanel").first().configure({
                    controller: new FormController({
                        model: RecordManager.getInstance().createRecordSet('Permission', {
                            proxy: new InstructionProxy({
                                query: "UserPermissionQuery",
                                createCommand: "AddPermissionCommand",
                                updateCommand: "SetPermissionCommand"
                            })
                        })
                    })
                });
            });
        }

        function configureButton(widget) {
            $(widget).Button("btnSavePermission").first().on("clicked", function () {
                Page().mask();
                var form = $(widget).Content("PermissionEditPanel").first();

                form.on("submit", function (source, successed) {
                    if (successed) {
                        $(widget).Dialog("PermissionEditDialog").first().close();
                        $.Paging("Paging").first().reset(); // Paging is in ListWidget
                        Page().unmask();
                    }
                    else {
                        alert("保存授权记录失败！");
                        Page().unmask();
                    }
                    this.un('submit', arguments.callee);
                });
                form.submit();
            });

            $(widget).Button("btnCancelSave").first().on("clicked", function () {
                $(widget).Dialog("PermissionEditDialog").first().close();
            });
        }

        return exports;
    });