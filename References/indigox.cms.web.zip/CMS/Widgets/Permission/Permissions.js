﻿define("/CMS/Widgets/Permission/Permissions", function () {
    var exports = [
    // object permissions
        {value: 0x1, text: "查看对象" },
        { value: 0x2, text: "编辑对象" },
        { value: 0x4, text: "删除对象" },
        { value: 0x8, text: "新建对象" },
        { value: 0x10, text: "列表" },
        { value: 0x20, text: "设置权限" },
    // workflow permissions
        {value: 0x400, text: "终止流程" },
        { value: 0x800, text: "取消流程" },
        { value: 0x1000, text: "跳转流程" },
        { value: 0x2000, text: "驳回流程" },
        { value: 0x4000, text: "撤回流程" },
        { value: 0x8000, text: "转办流程" },
        { value: 0x10000, text: "回复沟通" }
    ];

    return exports;
});