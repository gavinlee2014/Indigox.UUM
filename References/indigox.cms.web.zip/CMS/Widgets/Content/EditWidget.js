﻿define("/CMS/Widgets/Content/EditWidget",
    [
        "Indigox.Web.JsLib.Utils.StringUtil",
        "Indigox.Web.JsLib.CQRS.Batch",
        "Indigox.Web.JsLib.CQRS.AutoBatch",
        "Indigox.Web.JsLib.Proxy.InstructionProxy",
        "Indigox.Web.JsLib.Models.RecordManager",
        "Indigox.Web.JsLib.Controllers.FormController",
        "Indigox.Web.JsLib.Controllers.ListController",
        "/CMS/Widgets/Content/CMS"
    ],
    function (
        StringUtil,
        Batch,
        AutoBatch,
        InstructionProxy,
        RecordManager,
        FormController,
        ListController,
        CMS
    ) {
        var exports = function (widget) {
            var title, objID, contentType, folderID, viewName;

            title = widget.getParam("Title");
            if (!StringUtil.isNullOrEmpty(title)) {
                $(widget).Dialog('ContentEditDialog').setTitle(title);
                $(widget).Panel('ContentEditPanel').setTitle(title);
            }

            var dialog = $(widget).Dialog('ContentEditDialog').first();
            if (dialog) {
                dialog.on('opened', function () {
                    objID = dialog.getParam("ObjID");
                    contentType = dialog.getParam("ContentType");
                    folderID = dialog.getParam("FolderID");
                    viewName = dialog.getParam("ViewName");
                    properties = dialog.getParam("Properties");

                    loadData(widget, objID, contentType, folderID, viewName, properties);
                });
            }
            else {
                objID = Page().getUrlParam("ObjID");
                contentType = Page().getUrlParam("ContentType");
                folderID = Page().getUrlParam("FolderID");
                viewName = Page().getUrlParam("ViewName");
                properties = Page().getParam("NewFormData");

                loadData(widget, objID, contentType, folderID, viewName, properties);

                Page().listenUrlParamChanged(['ObjID', 'FolderID', 'ContentType', 'ViewName'], { container: widget }, function () {
                    objID = Page().getUrlParam("ObjID");
                    contentType = Page().getUrlParam("ContentType");
                    folderID = Page().getUrlParam("FolderID");
                    viewName = Page().getUrlParam("ViewName");
                    properties = Page().getParam("NewFormData");

                    loadData(widget, objID, contentType, folderID, viewName, properties);
                });
            }
        };

        function loadData(widget, objID, contentType, folderID, viewName, properties) {
            if (!viewName) {
                viewName = "ReadOnly";
            }

            var formControl = $(widget).Content("ContentEditForm").first();
            var cms = new CMS(widget, formControl);
            cms.reset();

            if (!objID) {
                cms.newObject(contentType, folderID, viewName, properties);
            }
            else {
                cms.loadObject(objID, viewName);
            }
        }

        return exports;
    });