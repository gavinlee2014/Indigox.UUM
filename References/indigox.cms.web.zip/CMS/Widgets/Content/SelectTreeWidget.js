﻿define("/CMS/Widgets/Content/SelectTreeWidget",
    [
        "Indigox.Web.JsLib.Utils.StringUtil",
        "Indigox.Web.JsLib.Utils.UrlUtil",
        "Indigox.Web.JsLib.CQRS.AutoBatch",
        "Indigox.Web.JsLib.Proxy.ArrayProxy",
        "Indigox.Web.JsLib.Models.RecordManager",
        "Indigox.Web.JsLib.Controllers.HierarchyController",
        "Indigox.Web.JsLib.Controls.Selection.ParentPriorityTreeMode",
        "Indigox/CMS/Application/Object/ObjectInfo"
    ],
function (
        StringUtil,
        UrlUtil,
        AutoBatch,
        ArrayProxy,
        RecordManager,
        HierarchyController,
        ParentPriorityTreeMode
) {
    var limit = 10;
    //var folderId = Page().getUrlParam("FolderID");
    var tableName = Page().getUrlParam("TableName");

    var exports = function (widget) {
        if (tableName == null) {
            tableName = "Document";
        }

        $(widget).Tree("ObjectTree").first().configure({
            valueField: "ObjID",
            treeNodeType: "checktreenode",
            mode: "SINGLE",
            allowDeselect: false,
            selectable: true,
            expandLevel: 1
        });

        $(widget).Tree("ObjectTree").first().configure({
            controller: new HierarchyController({
                model: RecordManager.getInstance().createRecordSet("ObjectInfo", {
                    proxy: new ArrayProxy(),
                    addRecords: true
                }),
                rootValue: null,
                nodeOptions: {
                    binding: {
                        mapping: {
                            text: "Title",
                            value: function (record) {
                                return record.get("ObjID");
                            }
                        }
                    }
                }
            })
        });

        AutoBatch.getCurrentBatch()
            .list({
                name: "ObjectListQuery",
                properties: {
                    TableName: tableName,
                    WhereClause: " Title != '' "
                }
            })
            .done(function (data) {
                var tree = $(widget).Tree("ObjectTree").first();
                tree.getController().getModel().getProxy().setArray(data);
                tree.getController().load();
            });

        $(widget).Button("btnOk").on("clicked", function (source, e) {
            var tree = $(widget).Tree("ObjectTree").first();
            var id = tree.getSelMode().selected.get(0);
            var data = tree.getController().getModel().dataIndexer[id].data;
            window.returnValue = JSON.stringify(data);
            window.close();
        });

        $(widget).Button("btnCancel").on("clicked", function (source, e) {
            window.returnValue = null;
            window.close();
        });
    };

    return exports;
});