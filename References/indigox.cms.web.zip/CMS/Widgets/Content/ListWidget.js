﻿define("/CMS/Widgets/Content/ListWidget",
    [
        "Indigox.Web.JsLib.Utils.StringUtil",
        "Indigox.Web.JsLib.Utils.UrlUtil",
        "Indigox.Web.JsLib.Utils.Util",
        "Indigox.Web.JsLib.Formatters",
        "Indigox.Web.JsLib.CQRS.Batch",
        "Indigox.Web.JsLib.Proxy.ArrayProxy",
        "Indigox.Web.JsLib.Proxy.InstructionProxy",
        "Indigox.Web.JsLib.Models.RecordManager",
        "Indigox.Web.JsLib.Controllers.ListController",
        "Indigox.Web.JsLib.Controllers.FormController",
        "/CMS/Widgets/Content/SearchSpecificationContentType",
        "/CMS/Widgets/Content/SearchSpecificationSchema",
        "Indigox/CMS/Application/Object/ObjectInfo"
    ],
    function (
        StringUtil,
        UrlUtil,
        Util,
        Formatters,
        Batch,
        ArrayProxy,
        InstructionProxy,
        RecordManager,
        ListController,
        FormController,
        searchSpecificationContentType,
        searchSpecificationSchema
    ) {
        var limit = 10;

        var exports = function (widget) {
            var folderViewUrl = widget.getParam("FolderViewUrl") || "#/Content/List.htm";
            var contentViewUrl = widget.getParam("ContentViewUrl") || "#/Content/View.htm";

            initSearchPanel(widget);

            $(widget).DataList("ObjectList").first().getItemTemplate().configureChildren({
                "ContentType": {
                    binding: {
                        mapping: {
                            value: function (record) {
                                var tableName = record.get("TableName");
                                if (StringUtil.isNullOrEmpty(tableName)) {
                                    return "未定义";
                                }
                                else {
                                    switch (tableName) {
                                        case "Notice":
                                            return "公告";
                                        case "Folder":
                                            return "文件夹";
                                        case "News":
                                            return "新闻";
                                        case "Document":
                                            return "文档";
                                        case "ContractApplication":
                                            return "合同会签";
                                        default:
                                            return "其它";
                                    }
                                }
                            }
                        }
                    }
                },
                "Title": {
                    mode: 0,
                    binding: {
                        mapping: {
                            value: function (record) {
                                var url = "";
                                if (record.get("TableName") == "Folder") {
                                    url = UrlUtil.join(folderViewUrl, {
                                        FolderID: record.get("ObjID")
                                    });
                                }
                                else {
                                    url = UrlUtil.join(contentViewUrl, {
                                        ObjID: record.get("ObjID"),
                                        TableName: record.get("TableName"),
                                        FolderID: record.get("ParentObjID")
                                    });
                                }
                                return "<a href='" + url + "'>" + record.get("DispTitle") + "</a>";
                            }
                        }
                    }
                },
                "CreateUser": {
                    binding: {
                        mapping: {
                            value: new Formatters.UserNameFormatter()
                        }
                    }
                },
                "CreateTime": {
                    binding: {
                        mapping: {
                            value: new Formatters.DateTimeFormatter({ format: "yyyy/MM/dd HH:mm" })
                        }
                    }
                },
                "LastModifyTime": {
                    binding: {
                        mapping: {
                            value: new Formatters.DateTimeFormatter({ format: "yyyy/MM/dd HH:mm" })
                        }
                    }
                },
                "ReadCount": {
                    binding: {
                        mapping: {
                            value: function (record) {
                                var count = record.get("ReadCount");
                                if (!StringUtil.isNullOrEmpty(count)) {
                                    return count.toString();
                                }
                                return "0";
                            }
                        }
                    }
                }
            });

            bindObjectList(widget);

            Page().listenUrlParamChanged(['FolderID'], { container: widget }, function () {
                //TODO: clear search condition.
                //$(widget).Content("SearchPanel").first().reset();
                bindObjectList(widget);
            });
        };

        function initSearchPanel(widget) {
            var contentType = searchSpecificationContentType;
            var searchPanel = $(widget).Content("SearchPanel").first();
            searchPanel.setControls(contentType.controls);

            searchPanel.configure({
                controller: new FormController({
                    model: RecordManager.getInstance().createRecordSet("SearchSpecification", {
                        proxy: new ArrayProxy({
                            array: [{}]
                        })
                    })
                })
            });

            $(widget).Button("btnSearch").first().on("clicked", function () {
                var controller = searchPanel.getController();
                controller.updateRecord();
                var specification = Util.copy({}, controller.getModel().getRecord(0).data);

                var paging = $(widget).Paging("Paging").first();
                var whereClause = " Title != ''" + getWhereClause(specification);
                paging.getArrayController().setParam("WhereClause", whereClause);
                paging.reset();
            });

        }

        function bindObjectList(widget) {
            var folderID = Page().getUrlParam("FolderID");

            var batch = Batch.beginBatch();
            batch.single({
                name: "SubItemTypeQuery",
                properties: {
                    FolderID: folderID
                }
            })
            .done(function (subItemType) {
                if (!subItemType) {
                    subItemType = "Folder";
                    //alert("未设置文件夹的内容类型!");
                }

                var list = $(widget).DataList("ObjectList").first();

                var arrayController = new ListController({
                    model: RecordManager.getInstance().createRecordSet('ObjectInfo', {
                        proxy: new InstructionProxy({
                            query: "ObjectListQuery"
                        })
                    }),
                    params: {
                        TableName: subItemType,
                        ParentObjID: folderID,
                        WhereClause: " Title != ''",
                        OrderClause: "CreateTime DESC",
                        FetchSize: limit
                    }
                });

                $(widget).Paging("Paging").first().configure({
                    pageSize: limit,
                    arrayController: arrayController
                });

                $(widget).DataList("ObjectList").first().configure({
                    controller: arrayController
                });
            });

            batch.syncCommit();
        }

        function getWhereClause(specification) {
            //debug.log(specification);
            var whereClause = '';
            for (var p in specification) {
                if (p) {
                    var v = specification[p];
                    if (v && v.length > 0) {
                        switch (p) {
                            case 'Title':
                                whereClause = whereClause + ' and Title like \'%' + v + '%\'';
                                break;

                            case 'CreateUser':
                                whereClause = whereClause + ' and CreateUser = \'' + v[0].UserID + '\'';
                                break;

                            case 'CreateTimeBegin':
                                whereClause = whereClause + ' and CreateTime >= \'' + v + '\'';
                                break;

                            case 'CreateTimeEnd':
                                whereClause = whereClause + ' and CreateTime <= \'' + v + '\'';
                                break;
                        }
                    }
                }
            }
            //debug.log('whereClause: ' + whereClause);
            return whereClause;
        }

        return exports;
    });