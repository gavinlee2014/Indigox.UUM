﻿define("/CMS/Widgets/Content/Content",
    [
        "Indigox.Web.JsLib.Proxy.ArrayProxy",
        "Indigox.Web.JsLib.CQRS.Batch",
        "Indigox.Web.JsLib.Models.RecordManager",
        "Indigox.Web.JsLib.Controllers.FormController",
        "Indigox.Web.JsLib.Controllers.ListController"
    ],
function (
        ArrayProxy,
        Batch,
        RecordManager,
        FormController,
        ListController
) {

    return {
        submitForm: function (widget, formControl, callback, errorCallback, batch) {
            var commitImmediatly = false;

            var entity = this.getFormData(widget, formControl);

            if (!batch) {
                batch = Batch.beginBatch();
                commitImmediatly = true;
            }
            batch.execute({
                name: "UpdateObjectCommand",
                properties: {
                    Entity: entity
                },
                callback: callback,
                errorCallback: errorCallback
            });

            if (commitImmediatly) {
                batch.commit();
            }
        },
        configureForm: function (widget, formControl, data) {
            var entity = data.entity;
            var schemas = data.schemas;
            var formView = data.formView;

            var proxy = new ArrayProxy({ array: [entity] });

            var recordSets = this.createRecordSets(schemas, proxy);

            var tableName = entity.TableName;

            var controller = new FormController({
                model: recordSets[tableName]
            });

            formControl.setControls(formView.controls);

            this.configureSubForms(widget, schemas, recordSets);

            formControl.setController(controller);
        },

        //@private
        configureSubForms: function (widget, schemas, recordSets) {
            for (var i = 0, length = schemas.length; i < length; i++) {
                var schemaName = schemas[i].name;

                var grid = $(widget).GridView(schemaName).first();
                if (grid) {
                    grid.configure({
                        controller: new ListController({
                            model: recordSets[schemaName]
                        })
                    });
                }
            }
        },

        //@private
        createRecordSets: function (schemas, proxy) {
            var recordsets = {};
            var recordManager = RecordManager.getInstance();
            var mapping = {};

            for (var i = 0, length = schemas.length; i < length; i++) {
                var schemaName = schemas[i].name;
                var schema = schemas[i].schema;

                recordManager.register(schemaName, schema);
                recordsets[schemaName] = recordManager.createRecordSet(schemaName, {
                    proxy: ((i === 0) ? proxy : null)
                });
                mapping[schemaName] = schemas[i].virtualColumn;
            }

            recordManager.createDataAdapter(recordsets, mapping);

            return recordsets;
        },

        validate: function (widget, formControl) {
            //var widget = $.Widget(widgetName).first();
            //var form = $(widget).Content(formName).first();
            var validator = $(widget).Validator("Validator").first();

            if (!isNullOrUndefined(validator)) {
                var result = validator.validate(formControl);
                if (false === result.matched) {
                    return false;
                }
            }

            return true;
        },

        getFormData: function (widget, formControl) {
            //var widget = $.Widget(widgetName).first();
            //var form = $(widget).Content(formName).first();
            var controller = formControl.getController();

            controller.updateRecord();

            var recordSet = controller.getModel();
            var record = recordSet.getRecord(0);

            var entity = recordSet.convertRawData(record);
            //debug.log('entity', entity);

            return entity;
        }
    };
});