﻿define("/CMS/Widgets/Content/SearchSpecificationContentType", function () {

    var SearchSpecificationContentType = {
        controls: [{
            controlType: "fieldset",
            items: [{
                controlType: "fieldcontainer",
                text: "标题",
                children: [{
                    controlType: "textbox",
                    name: "Title"
                }]
            }]
        }, {
            controlType: "fieldset",
            items: [{
                controlType: "fieldcontainer",
                text: "作者",
                children: [{
                    controlType: "userselect",
                    mode: "2",
                    multi: false,
                    name: "CreateUser"
                }]
            }]
        }, {
            controlType: "fieldset",
            items: [{
                controlType: "fieldcontainer",
                text: "创建时间",
                children: [{
                    controlType: "datepicker",
                    name: "CreateTimeBegin",
                    width: "40%"
                }, {
                    controlType: "label",
                    value: "至",
                    width: "5%"
                }, {
                    controlType: "datepicker",
                    name: "CreateTimeEnd",
                    width: "40%"
                }]
            }]
        }]
    };

    return SearchSpecificationContentType;
});