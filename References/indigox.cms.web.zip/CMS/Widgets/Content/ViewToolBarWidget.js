﻿define("/CMS/Widgets/Content/ViewToolBarWidget",
    [
        "Indigox.Web.JsLib.Utils.UrlUtil",
        "Indigox.Web.JsLib.Utils.ErrorHandler",
        "Indigox.Web.JsLib.CQRS.Batch",
        "Indigox.Web.JsLib.Proxy.InstructionProxy",
        "Indigox.Web.JsLib.Models.RecordManager",
        "Indigox.Web.JsLib.Controllers.PluginController",
        "Indigox.Web.JsLib.Controls.Html.Dialog",
        "Indigox.Web.JsLib.Controls.Html.Menu",
        "Indigox.Web.JsLib.Controls.Plugins.PermissionPlugin",
        "/CMS/Widgets/Content/EffectivePermission"
    ],
    function (
        UrlUtil,
        ErrorHandler,
        Batch,
        InstructionProxy,
        RecordManager,
        PluginController,
        Dialog,
        Menu,
        PermissionPlugin
    ) {
        var editUrl = "";
        var exports = function (widget) {
            var objID = Page().getUrlParam("ObjID");
            editUrl = widget.getParam("EditUrl") || "#/Content/Edit.htm";

            var pluginController = new PluginController({
                model: RecordManager.getInstance().createRecordSet('EffectivePermission', {
                    proxy: new InstructionProxy({
                        query: "EffectivePermissionQuery"
                    })
                }),
                params: {
                    Identifier: objID,
                    Type: "Indigox.CMS.ObjectModel.Interfaces.IObject"
                }
            });

            pluginController.load();

            $(widget).Menu("toolbar").first().configure({
                menuItemType: "buttonmenuitem",
                orientation: Menu.ORIENTATION_HORIZONTAL,
                staticDisplayLevels: 1,
                childNodes: [{
                    name: "btnEdit",
                    value: "编辑文档",
                    visible: false,
                    events: {
                        clicked: btnEdit_Click
                    },
                    plugins: [{
                        name: "permission",
                        config: {
                            controller: pluginController,
                            permission: PermissionPlugin.WRITE
                        }
                    }]
                }, {
                    name: "btnDelete",
                    value: "删除文档",
                    visible: false,
                    events: {
                        clicked: btnDelete_Click
                    },
                    plugins: [{
                        name: "permission",
                        config: {
                            controller: pluginController,
                            permission: PermissionPlugin.DELETE
                        }
                    }]
                }, {
                    name: "btnPermission",
                    value: "管理权限",
                    visible: false,
                    events: {
                        clicked: btnPermission_Click
                    },
                    plugins: [{
                        name: "permission",
                        config: {
                            controller: pluginController,
                            permission: PermissionPlugin.ADMINISTRATION
                        }
                    }]
                }, {
                    name: "btnRecommend",
                    value: "推荐文档",
                    visible: false,
                    events: {
                        clicked: btnRecommend_Click
                    }
                }, {
                    name: "btnPrint",
                    value: "打印文档",
                    events: {
                        clicked: btnPrint_Click
                    }
                }, {
                    name: "btnCancel",
                    value: "返回列表",
                    events: {
                        clicked: function (src, e) {
                            $(widget).Menu("toolbar").ButtonMenuItem().setEnable(false);
                            UrlUtil.goBack();
                        }
                    }
                }]
            });
        };

        function btnEdit_Click(src, e) {
            //$(widget).Menu("toolbar").ButtonMenuItem().setEnable(false);

            try {
                var form = $.Widget("ContentViewWidget").Content("ContentViewForm").first();
                var entity = form.getController().getModel().getRecord(0).data;
                //debug.log("entity: ", entity);

                var objID = entity.ObjID;
                var contentType = entity.TableName;

                var dialog = $.Dialog('ContentEditDialog').first();
                if (dialog) {
                    dialog.open({
                        ObjID: objID,
                        ContentType: contentType,
                        ViewName: "CMS"
                    });
                    dialog.on('closed', function () {
                        debug.log('dialog closed..');
                        if (dialog.dialogResult === Dialog.DIALOG_RESULT_OK) {
                            //refresh form;
                        }
                        dialog.un('closed', arguments.callee);
                    });
                }
                else {
                    UrlUtil.goTo(editUrl, {
                        ObjID: objID,
                        ContentType: contentType,
                        ViewName: "CMS"
                    });
                }
            } catch (error) {
                ErrorHandler.logAlert(error);
                //$(widget).Menu("toolbar").ButtonMenuItem().setEnable(true);
            }
        }

        function btnDelete_Click(src, e) {
            if (confirm("你确定要删除该文档吗？")) {
                //$(widget).Menu('toolbar').ButtonMenuItem().setEnable(false);
                var objID = Page().getUrlParam("ObjID");

                var batch = Batch.beginBatch();
                batch.execute({
                    name: "DeleteObjectCommand",
                    properties: {
                        Entity: {
                            ObjID: objID
                        }
                    }
                })
                .done(function (data) {
                    UrlUtil.goBack();
                })
                .fail(function (error) {
                    ErrorHandler.logAlert(error);
                    //$(widget).Menu('toolbar').ButtonMenuItem().setEnable(true);
                });
                batch.commit();
            }
        }

        function btnPermission_Click(src, e) {
            var objID = Page().getUrlParam("ObjID");

            var url = UrlUtil.join("#/Admin/Permission/List.htm", {
                Identifier: objID,
                Type: "Indigox.CMS.ObjectModel.Interfaces.IObject"
            });
            UrlUtil.goTo(url);
        }

        function btnRecommend_Click(src, e) {
            $(widget).Menu("toolbar").ButtonMenuItem().setEnable(false);

            var dialog = $.Dialog("recommendDialog").first();
            dialog.open();

            dialog.on("closed", function () {
                $(widget).Menu('toolbar').ButtonMenuItem().setEnable(true);
                this.un('submit', arguments.callee);
            });
        }

        

        function btnPrint_Click(src, e) {
            oWin = window.open("/CMS/Content/Print.htm", "_blank");
            fillPrint();
            oWin.focus();
            oWin.document.close();
        }

        var oWin = null;

        function fillPrint() {
            if (oWin.document.readyState != "complete" || oWin.document.getElementById("content") == null) {
                setTimeout(fillPrint, 500);
            }
            else {
                var prnhtml = document.getElementById($.Widget("ContentViewWidget").first().id).innerHTML;
                oWin.document.getElementById("content").innerHTML = prnhtml;
                //oWin.document.title = gProcDef.Name;
            }
        }

        return exports;
    });