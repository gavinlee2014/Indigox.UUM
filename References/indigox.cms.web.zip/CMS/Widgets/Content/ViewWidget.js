﻿define("/CMS/Widgets/Content/ViewWidget",
    [
        "Indigox.Web.JsLib.Utils.StringUtil",
        "Indigox.Web.JsLib.CQRS.Batch",
        "Indigox.Web.JsLib.CQRS.AutoBatch",
        "/CMS/Widgets/Content/CMS"
    ],
    function (
        StringUtil,
        Batch,
        AutoBatch,
        CMS
    ) {
        var exports = function (widget) {
            var objID = Page().getUrlParam("ObjID");
            var viewName = Page().getUrlParam("ViewName");

            title = widget.getParam("Title");
            if (!StringUtil.isNullOrEmpty(title)) {
                $(widget).Panel('ContentViewPanel').setTitle(title);
            }

            loadData(widget, objID, viewName);

            Page().listenUrlParamChanged(['ObjID'], { container: widget }, function () {
                var objID = Page().getUrlParam("ObjID");
                var viewName = Page().getUrlParam("ViewName");

                loadData(widget, objID, viewName);
            });
        };

        function loadData(widget, objID, viewName) {
            if (!viewName) {
                viewName = "ReadOnly";
            }

            var formControl = $(widget).Content("ContentViewForm").first();
            var cms = new CMS(widget, formControl);
            cms.loadObject(objID, viewName);
        }

        return exports;
    });