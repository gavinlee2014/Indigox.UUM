﻿define("/CMS/Widgets/Content/EffectivePermission",
    [
        "Indigox.Web.JsLib.Models.RecordManager"
    ],
function (
    RecordManager
) {
    RecordManager.getInstance().register("EffectivePermission", {
        "columns": [
            { name: 'EffectivePermission', text: '有效权限', type: String }
        ],
        primaryKey: ['EffectivePermission']
    });
});