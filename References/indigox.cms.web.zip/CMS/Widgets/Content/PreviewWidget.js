﻿define("/CMS/Widgets/Content/PreviewWidget",
    [
        "Indigox.Web.JsLib.Models.RecordManager",
        "Indigox.Web.JsLib.Utils.UrlUtil",
        "Indigox.Web.JsLib.Controllers.FormController",
        "Indigox.Web.JsLib.Controllers.ListController",
        "Indigox.Web.JsLib.Proxy.ArrayProxy"
    ],
    function (
        RecordManager,
        UrlUtil,
        FormController,
        ListController,
        ArrayProxy
    ) {
        var exports = function (widget) {
            var tableName = UrlUtil.get('t');
            var viewName = UrlUtil.get('v');
            if (viewName == null) {
                viewName = "ReadOnly";
            }

            var ct = ContentTypeService.GetContentType(tableName, false, viewName);

            var proxy = new ArrayProxy({
                array: [{}]
            });

            var schemas = SchemaService.GetSchemas(tableName);
            var recordsets = createRecordSets(schemas, proxy);

            var controller = new FormController({
                model: recordsets[tableName]
            });

            var formControl = $(widget).Content("ContentEditForm").first();
            formControl.setControls(ct.controls);
            formControl.configure({
                controller: controller
            });

            for (var i = 0, length = schemas.length; i < length; i++) {
                var schemaName = schemas[i].name;

                var grid = $.GridView(schemaName).first();
                if (grid) {
                    var gridController = new ListController();
                    gridController.configure({
                        model: recordsets[schemaName]
                    });
                    grid.setController(gridController);
                }
            }
        };

        function createRecordSets(schemas, proxy) {
            var recordsets = {};
            var recordManager = RecordManager.getInstance();
            var mapping = {};

            for (var i = 0, length = schemas.length; i < length; i++) {
                var schemaName = schemas[i].name;
                var schema = schemas[i].schema;

                recordManager.register(schemaName, schema);
                recordsets[schemaName] = recordManager.createRecordSet(schemaName, {
                    proxy: ((i == 0) ? proxy : null)
                });
                mapping[schemaName] = schemas[i].virtualColumn;
            }

            recordManager.createDataAdapter(recordsets, mapping);

            return recordsets;
        }

        return exports;
    });