﻿define("/CMS/Widgets/Content/SelectListWidget",
    [
        "Indigox.Web.JsLib.Utils.StringUtil",
        "Indigox.Web.JsLib.Utils.UrlUtil",
        "Indigox.Web.JsLib.Utils.Util",
        "Indigox.Web.JsLib.CQRS.AutoBatch",
        "Indigox.Web.JsLib.Proxy.InstructionProxy",
        "Indigox.Web.JsLib.Models.RecordManager",
        "Indigox.Web.JsLib.Controllers.ListController",
        "Indigox/CMS/Application/Object/ObjectInfo"
    ],
function (
        StringUtil,
        UrlUtil,
        Util,
        AutoBatch,
        InstructionProxy,
        RecordManager,
        ListController,
        ObjectInfo
) {

    var limit = 10;
    var folderId = UrlUtil.get("fid");
    var tableName = UrlUtil.get("t");

    var exports = function (widget) {
        if (folderId == null) {
            folderId = 0;
        }

        if (tableName == null) {
            tableName = "Document";
        }

        widget.on("loaded", function () {
            var proxy = new InstructionProxy({
                query: "ObjectListQuery"
            });

            var params = {
                TableName: tableName,
                ParentObjID: folderId,
                WhereClause: " Title != '' ",
                OrderClause: "CreateTime DESC",
                FetchSize: limit
            };

            var list = $(widget).GridView("ObjectList").first();
            list.configure({
                columns: [
                    { "caption": "名称", "field": "DispTitle", "defaultValue": "", "controlType": "textbox", "readOnly": true },
                    { "caption": "作者", "field": "CreateUser", "defaultValue": "", "controlType": "textbox", "readOnly": true,
                        binding: {
                            mapping: {
                                value: function (record) {
                                    var user = record.get("CreateUser");
                                    if (user && user.length > 0) {
                                        return user[0].UserName;
                                    }
                                }
                            }
                        }
                    },
                    { "caption": "创建时间", "field": "CreateTime", "defaultValue": "", "controlType": "textbox", "readOnly": true,
                        binding: {
                            mapping: {
                                value: function (record) {
                                    var time = record.get("CreateTime");
                                    if (!StringUtil.isNullOrEmpty(time)) {
                                        time = time.substr(0, 16);
                                    }
                                    return time;
                                }
                            }
                        }
                    }
                ]
            });

            AutoBatch.getCurrentBatch().single({
                name: "SchemaQuery",
                properties: {
                    TableName: tableName
                }
            })
            .done(function (schemas) {
                if (schemas.length == 0) {
                    return;
                }

                var schemaName = schemas[0].name;
                var schema = schemas[0].schema;

                RecordManager.getInstance().register(schemaName, schema);

                var arrayController = new ListController({
                    model: RecordManager.getInstance().createRecordSet(schemaName, {
                        proxy: proxy
                    }),
                    params: params
                });

                $(widget).Paging("Paging").first().configure({
                    pageSize: limit,
                    arrayController: arrayController
                });

                list.setController(arrayController);
            });

        });

        $(widget).Button('btnOk').on('clicked', function (source, e) {
            var list = $.GridView("ObjectList").first();
            var data = list.getSelMode().selected.get(0).data;
            window.returnValue = JSON.stringify(data);
            window.close();
        });

        $(widget).Button('btnCancel').on('clicked', function (source, e) {
            window.returnValue = null;
            window.close();
        });
    };

    return exports;
});