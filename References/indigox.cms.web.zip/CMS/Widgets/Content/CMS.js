﻿define("/CMS/Widgets/Content/CMS",
    [
        "Indigox.Web.JsLib.Proxy.ArrayProxy",
        "Indigox.Web.JsLib.CQRS.Batch",
        "Indigox.Web.JsLib.CQRS.AutoBatch",
        "Indigox.Web.JsLib.Models.RecordManager",
        "Indigox.Web.JsLib.Controllers.FormController",
        "Indigox.Web.JsLib.Controllers.ListController"
    ],
    function (
        ArrayProxy,
        Batch,
        AutoBatch,
        RecordManager,
        FormController,
        ListController
    ) {
        function Content(container, formControl) {
            this.container = container;
            this.formControl = formControl;
        }

        Content.prototype.newObject = function (contentType, folderID, viewName, properties) {
            var me = this;
            AutoBatch.getCurrentBatch().single({
                name: "DefaultContentQuery",
                properties: {
                    FolderID: folderID,
                    TableName: contentType,
                    ViewName: viewName
                }
            })
            .done(function (data) {
                if (properties) {
                    for (var key in properties) {
                        if (!isNullOrUndefined(properties[key])) {
                            data.entity[key] = properties[key];
                        }
                    }
                }
                me.configureForm(data);
            });
        }

        Content.prototype.loadObject = function (objID, viewName) {
            var me = this;
            AutoBatch.getCurrentBatch().single({
                name: "ContentQuery",
                properties: {
                    ObjID: objID,
                    ViewName: viewName
                }
            })
            .done(function (data) {
                me.configureForm(data);
            });
        }

        Content.prototype.configureForm = function (data) {
            var entity = data.entity;
            var schemas = data.schemas;
            var formView = data.formView;
            var proxy = new ArrayProxy({ array: [entity] });
            var recordSets = this.createRecordSets(schemas, proxy);
            var tableName = entity.TableName;
            var controller = new FormController({
                model: recordSets[tableName]
            });

            this.formControl.setControls(formView.controls);
            this.configureSubForms(schemas, recordSets);
            this.formControl.setController(controller);
        };

        Content.prototype.submitForm = function (isCreate, viewName, commandName) {
            var entity = this.getFormData();
            var batch = Batch.beginBatch();
            var promise = batch.execute({
                name: commandName || "UpdateObjectCommand",
                properties: {
                    Entity: entity,
                    ViewName: viewName || "CMS",
                    IsCreate: !!isCreate
                }
            });
            batch.commit();
            return promise;
        }

        Content.prototype.deleteObject = function (objID) {
            var batch = Batch.beginBatch();
            var promise = batch.execute({
                name: "DeleteObjectCommand",
                properties: {
                    Entity: {
                        ObjID: objID
                    }
                }
            });
            batch.commit();
            return promise;
        };

        //@private
        Content.prototype.configureSubForms = function (schemas, recordSets) {
            for (var i = 0, length = schemas.length; i < length; i++) {
                var schemaName = schemas[i].name;

                var grid = $(this.container).GridView(schemaName).first();
                if (grid) {
                    grid.configure({
                        controller: new ListController({
                            model: recordSets[schemaName]
                        })
                    });
                }
            }
        };

        //@private
        Content.prototype.createRecordSets = function (schemas, proxy) {
            var recordsets = {};
            var recordManager = RecordManager.getInstance();
            var mapping = {};

            for (var i = 0, length = schemas.length; i < length; i++) {
                var schemaName = schemas[i].name;
                var schema = schemas[i].schema;

                recordManager.register(schemaName, schema);
                recordsets[schemaName] = recordManager.createRecordSet(schemaName, {
                    proxy: ((i === 0) ? proxy : null)
                });
                mapping[schemaName] = schemas[i].virtualColumn;
            }

            recordManager.createDataAdapter(recordsets, mapping);

            return recordsets;
        };

        Content.prototype.validate = function () {
            var validator = $(this.container).Validator("Validator").first();

            if (!isNullOrUndefined(validator)) {
                var result = validator.validate(this.formControl);
                if (false === result.matched) {
                    return false;
                }
            }

            return true;
        };

        Content.prototype.getFormData = function () {
            var controller = this.formControl.getController();

            controller.updateRecord();

            var recordSet = controller.getModel();
            var record = recordSet.getRecord(0);

            var entity = recordSet.convertRawData(record);
            //debug.log('entity', entity);

            return entity;
        };

        Content.prototype.reset = function () {
            this.formControl.reset();
            var formController = this.formControl.getController()
            if (formController) { formController.clearModel(); }
        };

        return Content;
    });