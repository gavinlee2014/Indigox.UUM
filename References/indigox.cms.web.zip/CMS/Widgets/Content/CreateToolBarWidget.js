﻿define("/CMS/Widgets/Content/CreateToolBarWidget",
    [
        "Indigox.Web.JsLib.Utils.UrlUtil",
        "Indigox.Web.JsLib.Utils.ErrorHandler",
        "Indigox.Web.JsLib.Controls.Html.Dialog",
        "Indigox.Web.JsLib.Controls.Html.Menu",
        "/CMS/Widgets/Content/CMS"
    ],
    function (
        UrlUtil,
        ErrorHandler,
        Dialog,
        Menu,
        CMS
    ) {
        var exports = function (widget) {
            function btnSave_Click(source, e) {
                var wrapper = findContentEditWidget(),
                    isCreate = true,
                    viewName = "CMS",
                    commandName = "UpdateObjectCommand";

                if (wrapper.isDialog) {
                    var dialog = wrapper.container;
                    viewName = dialog.getParam("ViewName") || viewName;
                    commandName = dialog.getParam("CommandName") || commandName;
                }
                else {
                    viewName = widget.getParam("viewName") || Page().getUrlParam("ViewName") || viewName;
                    commandName =widget.getParam("commandName")|| Page().getUrlParam("CommandName") || commandName;
                }

                var cms = new CMS(wrapper.container, wrapper.formControl);

                if (!cms.validate()) {
                    return;
                }

                Page().mask();
                cms.submitForm(isCreate, viewName, commandName)
                    .done(function (data) {
                        alert("保存成功!");
                        if (wrapper.isDialog) {
                            var dialog = wrapper.container;
                            dialog.dialogResult = Dialog.DIALOG_RESULT_OK;
                            dialog.close();
                        }
                        else {
                            UrlUtil.goBack();
                        }
                    })
                    .fail(function (error) {
                        ErrorHandler.logAlert(error);
                        alert("保存失败");
                    })
                    .always(function (data) {
                        Page().unmask();
                    });
            }

            function btnClose_Click(source, e) {
                var wrapper = findContentEditWidget();
                if (wrapper.isDialog) {
                    var dialog = wrapper.container;
                    dialog.close();
                }
                else {
                    UrlUtil.goBack();
                }
            }

            $(widget).Menu("toolbar").first().configure({
                menuItemType: "buttonmenuitem",
                orientation: Menu.ORIENTATION_HORIZONTAL,
                staticDisplayLevels: 1,
                childNodes: [{
                    name: "btnSave",
                    value: "保存",
                    events: {
                        clicked: btnSave_Click
                    }
                }, {
                    name: "btnClose",
                    value: "返回",
                    events: {
                        clicked: btnClose_Click
                    }
                }]
            });
        };

        function findContentEditWidget() {
            var contentEditDialog = $.Dialog('ContentEditDialog').first();
            var contentEditPanel = $.Panel('ContentEditPanel').first();
            var contentEditForm = $.Content('ContentEditForm').first();
            var container = contentEditDialog || contentEditPanel;

            return {
                container: container,
                isDialog: !!contentEditDialog,
                formControl: contentEditForm
            };
        }

        return exports;
    });