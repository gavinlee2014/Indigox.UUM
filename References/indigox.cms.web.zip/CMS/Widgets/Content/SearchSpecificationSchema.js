﻿define("/CMS/Widgets/Content/SearchSpecificationSchema",
    [
        "Indigox.Web.JsLib.Models.RecordManager"
    ],
function (
    RecordManager
) {
    RecordManager.getInstance().register("SearchSpecification", {
        "columns": [{
            "name": "CreateUser",
            "text": "作者",
            "defaultValue": null,
            "controlType": "textbox",
            "controlConfig": null,
            "readOnly": false,
            "required": false,
            "display": true
        }, {
            "name": "CreateUserOrg",
            "text": "部门",
            "defaultValue": null,
            "controlType": "textbox",
            "controlConfig": null,
            "readOnly": false,
            "required": false,
            "display": true
        }, {
            "name": "Title",
            "text": "标题",
            "defaultValue": null,
            "controlType": "textbox",
            "controlConfig": null,
            "readOnly": false,
            "required": false,
            "display": true
        }, {
            "name": "CreateTimeBegin",
            "text": "创建时间Begin",
            "defaultValue": null,
            "controlType": "datepicker",
            "controlConfig": null,
            "readOnly": false,
            "required": false,
            "display": true
        }, {
            "name": "CreateTimeEnd",
            "text": "创建时间End",
            "defaultValue": null,
            "controlType": "datepicker",
            "controlConfig": null,
            "readOnly": false,
            "required": false,
            "display": true
        }]
    });
});