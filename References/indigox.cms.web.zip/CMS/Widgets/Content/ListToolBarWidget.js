﻿define("/CMS/Widgets/Content/ListToolBarWidget",
    [
        "Indigox.Web.JsLib.Utils.UrlUtil",
        "Indigox.Web.JsLib.Utils.StringUtil",
        "Indigox.Web.JsLib.Utils.ErrorHandler",
        "Indigox.Web.JsLib.CQRS.Batch",
        "Indigox.Web.JsLib.Proxy.InstructionProxy",
        "Indigox.Web.JsLib.Models.RecordManager",
        "Indigox.Web.JsLib.Controllers.PluginController",
        "Indigox.Web.JsLib.Controls.Html.Dialog",
        "Indigox.Web.JsLib.Controls.Html.Menu",
        "Indigox.Web.JsLib.Controls.Plugins.PermissionPlugin",
        "/CMS/Widgets/Content/EffectivePermission"
    ],
    function (
        UrlUtil,
        StringUtil,
        ErrorHandler,
        Batch,
        InstructionProxy,
        RecordManager,
        PluginController,
        Dialog,
        Menu,
        PermissionPlugin
    ) {
        var createUrl = "#/Content/Create.htm";

        var exports = function (widget) {
            if (widget.getParam("CreateUrl")) {
                createUrl = widget.getParam("CreateUrl");
            }
            initializeButtons(widget);

            Page().listenUrlParamChanged(['FolderID'], { container: widget }, function () {
                initializeButtons(widget);
            });
        };

        function initializeButtons(widget) {
            var folderID = Page().getUrlParam("FolderID") || 0;

            var pluginController = new PluginController({
                model: RecordManager.getInstance().createRecordSet('EffectivePermission', {
                    proxy: new InstructionProxy({
                        query: "EffectivePermissionQuery"
                    })
                }),
                params: {
                    Identifier: folderID,
                    Type: "Indigox.CMS.ObjectModel.Interfaces.IObject"
                }
            });

            pluginController.load();

            $(widget).Menu("toolbar").first().configure({
                menuItemType: "buttonmenuitem",
                orientation: Menu.ORIENTATION_HORIZONTAL,
                staticDisplayLevels: 1,
                childNodes: [{
                    name: "btnAddContent",
                    value: "新建",
                    visible: false,
                    events: {
                        clicked: function (src, e) {
                            var folderID = Page().getUrlParam("FolderID") || 0;

                            var batch = Batch.beginBatch();
                            batch.single({
                                name: "SubItemTypeQuery",
                                properties: {
                                    FolderID: folderID
                                }
                            })
                            .done(function (subItemType) {
                                createObject(folderID, subItemType);
                            });
                            batch.commit();
                        }
                    },
                    plugins: [{
                        name: "permission",
                        config: {
                            controller: pluginController,
                            permission: PermissionPlugin.CREATE
                        }
                    }]
                }, {
                    name: "btnAddFolder",
                    value: "新建文件夹",
                    visible: false,
                    events: {
                        clicked: function (src, e) {
                            $(widget).Menu('toolbar').ButtonMenuItem().setEnable(false);

                            var dialog = $.Dialog("FolderCreateDialog").first();
                            dialog.open();

                            dialog.on("closed", function () {
                                $(widget).Menu('toolbar').ButtonMenuItem().setEnable(true);
                                this.un('closed', arguments.callee);
                            });
                        }
                    },
                    plugins: [{
                        name: "permission",
                        config: {
                            controller: pluginController,
                            permission: PermissionPlugin.CREATE
                        }
                    }]
                }, {
                    name: "btnEditFolder",
                    value: "编辑文件夹",
                    events: {
                        clicked: function (src, e) {
                            $(widget).Menu('toolbar').ButtonMenuItem().setEnable(false);

                            var dialog = $.Dialog("FolderEditDialog").first();
                            dialog.open();

                            dialog.on("closed", function () {
                                $(widget).Menu('toolbar').ButtonMenuItem().setEnable(true);
                                this.un('submit', arguments.callee);
                            });
                        }
                    },
                    plugins: [{
                        name: "permission",
                        config: {
                            controller: pluginController,
                            permission: PermissionPlugin.WRITE
                        }
                    }]
                }, {
                    name: "btnDeleteFolder",
                    value: "删除文件夹",
                    events: {
                        clicked: function (src, e) {
                            if (confirm("你确定要删除该文件夹及其子文件夹吗？")) {
                                $(widget).Menu('toolbar').ButtonMenuItem().setEnable(false);
                                var folderID = Page().getUrlParam("FolderID");

                                if (folderID && folderID > 0) {
                                    var batch = Batch.beginBatch();
                                    batch.execute({
                                        name: "DeleteObjectCommand",
                                        properties: {
                                            Entity: {
                                                ObjID: folderID
                                            }
                                        },
                                        callback: function (data) {
                                            var recordSet = $("FolderTree").first().getController().getModel();
                                            var record = $("FolderTree").first().getController().getModel().getRecord(folderID);
                                            recordSet.removeRecord(record);
                                            UrlUtil.goBack();
                                        },
                                        errorCallback: function (error) {
                                            ErrorHandler.logAlert(error);
                                            $(widget).Menu('toolbar').ButtonMenuItem().setEnable(true);
                                        }
                                    });
                                    batch.commit();
                                }
                            }
                        }
                    },
                    plugins: [{
                        name: "permission",
                        config: {
                            controller: pluginController,
                            permission: PermissionPlugin.DELETE
                        }
                    }]
                }, {
                    name: "btnPermission",
                    value: "权限管理",
                    events: {
                        clicked: function (src, e) {
                            $(widget).Menu('toolbar').ButtonMenuItem().setEnable(false);
                            var folderID = Page().getUrlParam("FolderID") || 0;

                            var url = UrlUtil.join("#/Admin/Permission/List.htm", {
                                Identifier: folderID,
                                Type: "Indigox.CMS.ObjectModel.Interfaces.IObject"
                            });
                            UrlUtil.goTo(url);
                        }
                    },
                    plugins: [{
                        name: "permission",
                        config: {
                            controller: pluginController,
                            permission: PermissionPlugin.ADMINISTRATION
                        }
                    }]
                }]
            });
        }

        

        function createObject(folderID, contentType) {
            if (StringUtil.isNullOrEmpty(contentType)) {
                alert("请先设置文件的内容类型再新建!");
                return;
            }

            if (contentType === "Folder") {
                alert("该文件夹下不允许新建文档，如需在该文件夹下新建文档，请联系管理修改文件夹配置!");
                return;
            }

            var dialog = $.Dialog('ContentEditDialog').first();
            if (dialog) {
                dialog.open({
                    FolderID: folderID,
                    ContentType: contentType,
                    ViewName: "CMS"
                });
                dialog.on('closed', function () {
                    debug.log('dialog closed..');
                    if (dialog.dialogResult === Dialog.DIALOG_RESULT_OK) {
                        //refresh list;
                    }
                    dialog.un('closed', arguments.callee);
                });
            }
            else {
                var url = UrlUtil.join(createUrl, {
                    FolderID: folderID,
                    ContentType: contentType,
                    ViewName: "CMS"
                });
                UrlUtil.goTo(url);
            }
        }

        return exports;
    });