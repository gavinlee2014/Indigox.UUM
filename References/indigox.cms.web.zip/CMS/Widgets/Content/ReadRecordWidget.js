﻿define("/CMS/Widgets/Content/ReadRecordWidget",
    [
        "Indigox.Web.JsLib.CQRS.Batch",
        "Indigox.Web.JsLib.Proxy.ArrayProxy",
        "Indigox.Web.JsLib.Proxy.InstructionProxy",
        "Indigox.Web.JsLib.Models.RecordManager",
        "Indigox.Web.JsLib.Controllers.FormController",
        "Indigox/CMS/Application/Object/ReadRecord"
    ],
function (
        Batch,
        ArrayProxy,
        InstructionProxy,
        RecordManager,
        FormController
) {
        var exports = function (widget) {
            var objID = Page().getUrlParam("ObjID");
            auditObjectReaded(objID);

            $(widget).Panel("readRecordPanel").first().on("expanded", function () {
                configureFormControl(widget);

                $(widget).Content("readRecord").first().configure({
                    controller: new FormController({
                        model: RecordManager.getInstance().createRecordSet("ReadRecord", {
                            proxy: new InstructionProxy({
                                query: "ObjectReadHistoryQuery"
                            })
                        }),
                        params: {
                            ObjID: objID
                        }
                    })
                });

                this.un('expanded', arguments.callee);
            });

            Page().listenUrlParamChanged(["ObjID"], { container: widget }, function () {
                var objID = Page().getUrlParam("ObjID");

                auditObjectReaded(objID);

                var form = $(widget).Content("readRecord").first();
                var controller = form.getController();
                if (controller) { // readRecordPanel is not expanded
                    controller.setParam("ObjID", objID);
                    controller.clearModel();
                    controller.load();
                }
            });
        };

        function configureFormControl(widget) {
            $(widget).Literal("ReadCount").first().configure({
                binding: {
                    mapping: {
                        value: function (record) {
                            if (!isNullOrUndefined(record.get("ReadCount"))) {
                                return record.get("ReadCount");
                            }
                            else {
                                return 0;
                            }
                        }
                    }
                }
            });

            $(widget).Literal("DocReadUsers").first().configure({
                binding: {
                    mapping: {
                        value: function (record) {
                            var users = record.get("DocReadUsers");
                            return getUserNames(users);
                        }
                    }
                }
            });

            $(widget).Literal("DefaultReaders").first().configure({
                binding: {
                    mapping: {
                        value: function (record) {
                            var users = record.get("DefaultReaders");
                            return getUserNames(users);
                        }
                    }
                }
            });
        }

        function getUserNames(users) {
            if (!isNullOrUndefined(users)) {
                var userName = "";
                var i = null;
                var length = null;
                for (i = 0, length = users.length; i < length; i++) {
                    if (userName === "") {
                        userName += users[i].UserName;
                    } else {
                        userName += "," + users[i].UserName;
                    }
                }
                return userName;
            }
            return "";
        }

        function auditObjectReaded(objID) {
            var batch = Batch.beginBatch();
            batch.execute({
                name: "AuditObjectReadedCommand",
                properties: {
                    ObjID: objID
                }
            });
            batch.commit();
        }

        return exports;
    });