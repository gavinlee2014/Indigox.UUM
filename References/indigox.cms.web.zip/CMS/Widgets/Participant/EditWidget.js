﻿define("/CMS/Widgets/Participant/EditWidget",
    [
        "Indigox.Web.JsLib.Utils.ErrorHandler",
        "Indigox.Web.JsLib.Utils.UrlUtil",
        "Indigox.Web.JsLib.CQRS.Batch",
        "Indigox.Web.JsLib.CQRS.AutoBatch",
        "Indigox.Web.JsLib.Models.RecordManager",
        "Indigox.Web.JsLib.Controllers.FormController",
        "/CMS/Widgets/Content/Content"
    ],
    function (
        ErrorHandler,
        UrlUtil,
        Batch,
        AutoBatch,
        RecordManager,
        FormController,
        content
    ) {
        function loadData(widget) {
            var workItemID = Page().getUrlParam("WorkItemID");

            var formControl = $(widget).Content("ParticipantEditPanel").first();

            queryDefaultFormData(workItemID, function (data) {
                content.configureForm(widget, formControl, data);
            });
        }

        var exports = function (widget) {
            var dialog = $(widget).Dialog('ParticipantDialog').first();

            dialog.on('closed', function () {
                $('toolbar').ButtonMenuItem().setEnable(true);
            });

            dialog.on("loaded", function () {
                //loadData(widget);
            });

            dialog.on("opened", function () {
                loadData(widget);
            });

            $(widget).Button("btnParticipantCancel").first().on('clicked', function () {
                dialog.close();
            });

            $(widget).Button("btnParticipantSubmit").first().on('clicked', function () {
                Page().mask();
                var formControl = $(widget).Content("ParticipantEditPanel").first();
                var workItemID = Page().getUrlParam("WorkItemID");

                if (!confirm("您确认要提交吗？") || !content.validate(widget, formControl)) {
                    Page().unmask();
                    return;
                }

                var successCallback = function () {
                    var batch = Batch.beginBatch();
                    batch.execute({
                        name: 'FinishWorkItemCommand',
                        properties: {
                            WorkItemID: workItemID,
                            Suggestion: $(widget).RichTextBox("Text").first().getValue()
                        },
                        callback: function (data) {
                            alert("提交成功!");
                            dialog.close();
                            Page().unmask();
                            UrlUtil.goBack();
                        },
                        errorCallback: function (error) {
                            ErrorHandler.logAlert(error);
                            Page().unmask();
                        }
                    });
                    batch.commit();
                };
                var errCallback = function () {
                    alert("提交表单失败");
                    Page().unmask();
                };

                content.submitForm(widget, formControl, successCallback, errCallback);
            });

            $(widget).Button("btnParticipantSave").first().on('clicked', function () {
                Page().mask();
                var successCallback = function () {
                    alert("保存成功!");
                    dialog.close();
                    Page().unmask();
                };
                var errCallback = function () {
                    alert("保存失败!");
                    Page().unmask();
                };

                var formControl = $(widget).Content("ParticipantEditPanel").first();
                content.submitForm(widget, formControl, successCallback, errCallback);
            });
        };

        function queryDefaultFormData(workItemID, callback) {
            var batch = AutoBatch.getCurrentBatch();
            batch.single({
                name: "WorkItemParticipantQuery",
                properties: {
                    WorkItemID: workItemID
                },
                callback: callback
            });
        }

        return exports;
    });